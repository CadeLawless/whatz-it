<?php

declare(strict_types=1);

// The staging service code and secrets live beside public_html so direct HTTP
// requests can reach only this small front controller. Select the external
// configuration explicitly so a legacy service-local development file can
// never take precedence on Hostinger.
$domainRoot = dirname(__DIR__, 2);
$config = $domainRoot . '/whatzit-secrets/deck-platform-staging-config.php';
$service = $domainRoot . '/whatzit-platform-staging/current/deck-manager/public/platform-api.php';

if (!is_readable($config) || !is_readable($service)) {
    http_response_code(503);
    header('Content-Type: application/json; charset=utf-8');
    header('Cache-Control: no-store');
    echo '{"ok":false,"error":{"code":"service_unavailable","message":"The catalog service is not deployed."}}';
    exit;
}

putenv('WHATZIT_CONFIG_PATH=' . $config);
require $service;
