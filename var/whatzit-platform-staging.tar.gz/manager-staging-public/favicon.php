<?php

declare(strict_types=1);

$path = dirname(__DIR__, 2) . '/whatzit-platform-staging/current/assets/favicon.png';
$bytes = is_readable($path) ? file_get_contents($path) : false;
if (!is_string($bytes)) {
    http_response_code(404);
    exit;
}
header('Content-Type: image/png');
header('Content-Length: ' . strlen($bytes));
header('Cache-Control: public, max-age=86400');
echo $bytes;
