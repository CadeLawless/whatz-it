<?php

declare(strict_types=1);

$domainRoot = dirname(__DIR__, 2);
$config = $domainRoot . '/whatzit-secrets/deck-manager-staging-config.php';
$service = $domainRoot . '/whatzit-platform-staging/current/deck-manager/public/index.php';

if (!is_readable($config) || !is_readable($service)) {
    http_response_code(503);
    header('Content-Type: text/plain; charset=utf-8');
    header('Cache-Control: no-store');
    echo "Deck Manager staging is not configured.\n";
    exit;
}

putenv('WHATZIT_CONFIG_PATH=' . $config);
require $service;
