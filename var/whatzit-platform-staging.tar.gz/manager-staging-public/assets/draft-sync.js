(function (root, factory) {
  const api = factory();
  if (typeof module === "object" && module.exports) module.exports = api;
  if (root) root.WhatzItDraftSync = api;
})(typeof window !== "undefined" ? window : globalThis, function () {
  "use strict";

  class DraftAutosave {
    constructor({ save, onStatus = () => {}, onError = () => {}, delay = 800, timers = globalThis }) {
      this.save = save;
      this.onStatus = onStatus;
      this.onError = onError;
      this.delay = delay;
      this.timers = timers;
      this.enabled = false;
      this.status = "idle";
      this.timer = null;
      this.inFlight = null;
      this.flushInFlight = null;
      this.queued = false;
      this.blocked = false;
    }

    configure(enabled) {
      this.enabled = Boolean(enabled);
      if (!this.enabled) this.reset("idle");
    }

    changed({ blocked = false } = {}) {
      if (!this.enabled || this.status === "conflict") return;
      this.blocked = Boolean(blocked);
      if (this.blocked) {
        this.cancelTimer();
        this.setStatus("media");
        return;
      }
      if (this.inFlight) this.queued = true;
      this.cancelTimer();
      this.setStatus("pending");
      this.timer = this.timers.setTimeout(() => {
        this.timer = null;
        void this.run();
      }, this.delay);
    }

    async run() {
      if (!this.enabled || this.blocked || this.status === "conflict") return false;
      this.cancelTimer();
      if (this.inFlight) {
        this.queued = true;
        await this.inFlight;
        return this.status === "saved";
      }
      this.queued = false;
      this.setStatus("saving");
      this.inFlight = Promise.resolve().then(() => this.save());
      try {
        await this.inFlight;
        this.setStatus("saved");
      } catch (error) {
        this.setStatus(error?.payload?.conflict ? "conflict" : "error");
        this.onError(error);
      } finally {
        this.inFlight = null;
      }
      if (this.queued && this.status !== "conflict") return this.run();
      return this.status === "saved";
    }

    flush() {
      if (this.flushInFlight) return this.flushInFlight;
      const request = this.flushPending();
      this.flushInFlight = request;
      return request.finally(() => {
        if (this.flushInFlight === request) this.flushInFlight = null;
      });
    }

    async flushPending() {
      if (!this.enabled || this.blocked) return true;
      while (this.timer || this.inFlight || this.queued) {
        const succeeded = await this.run();
        if (!succeeded && !this.timer && !this.inFlight) return false;
      }
      return this.status !== "conflict" && this.status !== "error";
    }

    reset(status = "idle") {
      this.cancelTimer();
      this.queued = false;
      this.blocked = false;
      this.setStatus(status);
    }

    cancelTimer() {
      if (this.timer !== null) this.timers.clearTimeout(this.timer);
      this.timer = null;
    }

    setStatus(status) {
      this.status = status;
      this.onStatus(status);
    }
  }

  function hasBrowserOnlyChanges({ storageBackend, dirty, draftSaveStatus }) {
    return storageBackend === "github"
      ? Boolean(dirty)
      : ["pending", "saving", "media", "error", "conflict"].includes(draftSaveStatus);
  }

  function normalizeUtcTimestamp(value) {
    const text = String(value || "");
    return /^\d{4}-\d{2}-\d{2} \d{2}:\d{2}:\d{2}(?:\.\d{1,6})?$/.test(text)
      ? `${text.replace(" ", "T")}Z`
      : text;
  }

  function mergeStashedCatalog(base, stashed, current) {
    const MISSING = Symbol("missing");
    const conflicts = [];
    const equal = (left, right) => {
      if (left === MISSING || right === MISSING) return left === right;
      return JSON.stringify(left) === JSON.stringify(right);
    };
    const copy = (value) => value === MISSING ? MISSING : JSON.parse(JSON.stringify(value));
    const isObject = (value) => value !== MISSING && value !== null
      && typeof value === "object" && !Array.isArray(value);
    const keyedCollection = (path) => path === "$.decks" || path === "$.bundles" || path.endsWith(".cards");

    function mergeNode(baseValue, stashedValue, currentValue, path) {
      if (equal(stashedValue, baseValue)) return copy(currentValue);
      if (equal(currentValue, baseValue) || equal(stashedValue, currentValue)) return copy(stashedValue);

      if (Array.isArray(baseValue) && Array.isArray(stashedValue) && Array.isArray(currentValue)) {
        if (keyedCollection(path)) return mergeKeyedArray(baseValue, stashedValue, currentValue, path);
        conflicts.push(path);
        return copy(currentValue);
      }

      if (isObject(baseValue) && isObject(stashedValue) && isObject(currentValue)) {
        const result = {};
        const keys = new Set([
          ...Object.keys(baseValue),
          ...Object.keys(stashedValue),
          ...Object.keys(currentValue),
        ]);
        keys.forEach((key) => {
          const merged = mergeNode(
            key in baseValue ? baseValue[key] : MISSING,
            key in stashedValue ? stashedValue[key] : MISSING,
            key in currentValue ? currentValue[key] : MISSING,
            `${path}.${key}`,
          );
          if (merged !== MISSING) result[key] = merged;
        });
        return result;
      }

      conflicts.push(path);
      return copy(currentValue);
    }

    function mergeKeyedArray(baseItems, stashedItems, currentItems, path) {
      const valid = (items) => items.every((item) => isObject(item) && typeof item.id === "string");
      if (!valid(baseItems) || !valid(stashedItems) || !valid(currentItems)) {
        conflicts.push(path);
        return copy(currentItems);
      }
      const maps = [baseItems, stashedItems, currentItems].map(
        (items) => new Map(items.map((item) => [item.id, item])),
      );
      const [baseMap, stashedMap, currentMap] = maps;
      const ids = new Set([...baseMap.keys(), ...stashedMap.keys(), ...currentMap.keys()]);
      const mergedById = new Map();
      ids.forEach((id) => {
        const merged = mergeNode(
          baseMap.has(id) ? baseMap.get(id) : MISSING,
          stashedMap.has(id) ? stashedMap.get(id) : MISSING,
          currentMap.has(id) ? currentMap.get(id) : MISSING,
          `${path}[${id}]`,
        );
        if (merged !== MISSING) mergedById.set(id, merged);
      });

      const baseIds = baseItems.map((item) => item.id);
      const stashedIds = stashedItems.map((item) => item.id);
      const currentIds = currentItems.map((item) => item.id);
      const sharedBaseIds = new Set(baseIds.filter((id) => stashedMap.has(id) && currentMap.has(id)));
      const baseShared = baseIds.filter((id) => sharedBaseIds.has(id));
      const stashedShared = stashedIds.filter((id) => sharedBaseIds.has(id));
      const currentShared = currentIds.filter((id) => sharedBaseIds.has(id));
      const stashedReordered = !equal(stashedShared, baseShared);
      const currentReordered = !equal(currentShared, baseShared);
      if (stashedReordered && currentReordered && !equal(stashedShared, currentShared)) {
        conflicts.push(`${path}#order`);
      }
      const preferredOrder = stashedReordered && !currentReordered ? stashedIds : currentIds;
      const orderedIds = [...preferredOrder, ...stashedIds, ...currentIds]
        .filter((id, index, values) => mergedById.has(id) && values.indexOf(id) === index);
      return orderedIds.map((id) => mergedById.get(id));
    }

    const value = mergeNode(base, stashed, current, "$");
    return { value, conflicts: [...new Set(conflicts)] };
  }

  return { DraftAutosave, hasBrowserOnlyChanges, mergeStashedCatalog, normalizeUtcTimestamp };
});
