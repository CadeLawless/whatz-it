(function () {
  "use strict";

  const app = document.getElementById("app");
  if (!app) return;

  const FS = window.WhatzItFS;
  const DraftAutosave = window.WhatzItDraftSync?.DraftAutosave;
  const hasBrowserOnlyChanges = window.WhatzItDraftSync?.hasBrowserOnlyChanges;
  const mergeStashedCatalog = window.WhatzItDraftSync?.mergeStashedCatalog;
  const normalizeUtcTimestamp = window.WhatzItDraftSync?.normalizeUtcTimestamp;
  // Derive the public app directory from this script so routing works both at
  // 127.0.0.1:8787/ and when Hostinger serves Deck Manager in a subdirectory.
  const appBaseUrl = new URL("../", document.currentScript?.src || window.location.href);
  const TAB_NAMES = new Set(["decks", "bundles", "cards", "backups"]);
  const TAB_TITLES = {
    decks: "Decks",
    bundles: "Bundles",
    cards: "Cards",
    backups: "History",
  };
  const state = {
    authenticated: false,
    authBackend: "github",
    adminLogin: "",
    csrfToken: "",
    storageBackend: "github",
    connected: false,
    connection: null,
    catalog: null,
    syncedCatalog: null,
    originalCatalog: null,
    snapshot: null,
    images: [],
    backups: [],
    catalogValid: false,
    catalogErrors: [],
    dirty: false,
    selectedDeckId: null,
    selectedCardIds: new Set(),
    selectedCardDeckId: null,
    pendingImageOps: [],
    importPreview: null,
    dragDeckIndex: null,
    dragBundleIndex: null,
    imageDeckSelections: {},
    collapsedDeckSections: new Set(),
    collapsedBundles: new Set(),
    bundleDeckDraft: new Set(),
    dragOrder: null,
    dragBundleDeck: null,
    deckDragPreview: null,
    armedDeckDragTile: null,
    featuredCardDrag: null,
    armedFeaturedCardRow: null,
    dismissedDuplicateGroups: new Set(),
    duplicateDeckSignature: "",
    draftSaveStatus: "idle",
    devPreview: null,
    devPreviewConfigured: false,
    currentStash: null,
  };

  let draftConflictNotice = null;
  let publishPreparationInFlight = false;
  let devPreviewUpdateInFlight = false;

  const $ = (selector, root = document) => root.querySelector(selector);
  const $$ = (selector, root = document) => Array.from(root.querySelectorAll(selector));
  const dialogs = {
    bundle: $("#bundle-dialog"),
    bundleDecks: $("#bundle-decks-dialog"),
    deck: $("#deck-dialog"),
    card: $("#card-dialog"),
    import: $("#import-dialog"),
    duplicates: $("#duplicates-dialog"),
    save: $("#save-dialog"),
    confirm: $("#confirm-dialog"),
    draftSaveError: $("#draft-save-error-dialog"),
    stashResolution: $("#stash-resolution-dialog"),
  };

  function clone(value) {
    return value == null ? value : JSON.parse(JSON.stringify(value));
  }

  function catalogBundles(catalog = state.catalog) {
    return catalog?.bundles || [];
  }

  function allDeckEntries(catalog = state.catalog) {
    return (catalog?.decks || []).map((deck, deckIndex) => ({
      deck,
      deckIndex,
      bundles: catalogBundles(catalog).filter((bundle) => (bundle.deckIds || []).includes(deck.id)),
    }));
  }

  function allDecks(catalog = state.catalog) {
    return catalog?.decks || [];
  }

  function findDeckEntry(deckId, catalog = state.catalog) {
    return allDeckEntries(catalog).find(({ deck }) => deck.id === deckId) || null;
  }

  function bundleById(bundleId, catalog = state.catalog) {
    return catalogBundles(catalog).find((bundle) => bundle.id === bundleId) || null;
  }

  function syncDeckOrders(catalog = state.catalog) {
    if (!catalog) return;
    const decks = allDecks(catalog);
    const deckById = new Map(decks.map((deck) => [deck.id, deck]));
    const eligible = {
      free: decks.filter((deck) => deck.access === "free").map((deck) => deck.id),
      paid: decks.filter((deck) => deck.access === "paid").map((deck) => deck.id),
    };
    const current = catalog.deckOrders || {};
    catalog.deckOrders = Object.fromEntries(Object.entries(eligible).map(([scope, ids]) => {
      const allowed = new Set(ids);
      const kept = (current[scope] || []).filter((id, index, values) =>
        allowed.has(id) && values.indexOf(id) === index && deckById.has(id),
      );
      const keptSet = new Set(kept);
      return [scope, [...kept, ...ids.filter((id) => !keptSet.has(id))]];
    }));
  }

  function orderedDecks(scope, catalog = state.catalog) {
    syncDeckOrders(catalog);
    const byId = new Map(allDecks(catalog).map((deck) => [deck.id, deck]));
    return (catalog?.deckOrders?.[scope] || []).map((id) => byId.get(id)).filter(Boolean);
  }

  function sortBundles() {
    if (!state.catalog?.bundles) return;
    state.catalog.bundles.sort((left, right) => Number(left.order || 0) - Number(right.order || 0));
    normalizeBundleOrders();
  }

  function normalizeBundleOrders() {
    catalogBundles().forEach((bundle, index) => {
      bundle.order = index + 1;
    });
  }

  function escapeHtml(value) {
    return String(value ?? "")
      .replaceAll("&", "&amp;")
      .replaceAll("<", "&lt;")
      .replaceAll(">", "&gt;")
      .replaceAll('"', "&quot;")
      .replaceAll("'", "&#039;");
  }

  function basename(path) {
    return String(path || "").replaceAll("\\", "/").split("/").pop();
  }

  function slugify(value, fallback = "") {
    return FS.slugifyId(value, fallback);
  }

  function fileFromBase64(data, filename, mime) {
    const binary = atob(data);
    const bytes = Uint8Array.from(binary, (character) => character.charCodeAt(0));
    return new File([bytes], filename, { type: mime, lastModified: Date.now() });
  }

  function formatBytes(bytes) {
    const value = Number(bytes || 0);
    if (value < 1024) return `${value} B`;
    if (value < 1024 * 1024) return `${(value / 1024).toFixed(1)} KB`;
    return `${(value / (1024 * 1024)).toFixed(1)} MB`;
  }

  function formatDate(value) {
    if (!value) return "Unknown time";
    const date = new Date(normalizeUtcTimestamp(value));
    return Number.isNaN(date.getTime())
      ? String(value)
      : date.toLocaleString(undefined, { timeZoneName: "short" });
  }

  async function request(action, options = {}) {
    try {
      if (action === "parse_import") {
        const input = options.json || {};
        return {
          ok: true,
          preview: FS.parseImport(input.format, input.input, input.existingCards, input.delimiterEnabled, input.delimiter),
        };
      }
      const endpointAction = {
        status: "session",
        reload: "state",
        save: "publish",
        publish_preview: "publish_preview",
        save_draft: "save_draft",
        discard_draft: "discard_draft",
        rollback: "rollback",
        stage_upload: "stage_upload",
        local_login: "local_login",
        logout: "logout",
      }[action];
      if (!endpointAction) throw new Error("Unknown Deck Manager action.");
      const method = options.method || "GET";
      const headers = { Accept: "application/json" };
      if (method !== "GET" && state.csrfToken) headers["X-CSRF-Token"] = state.csrfToken;
      let body = options.body || null;
      if (options.json) {
        headers["Content-Type"] = "application/json";
        body = JSON.stringify(options.json);
      }
      const response = await fetch(`api.php?action=${encodeURIComponent(endpointAction)}`, {
        method,
        headers,
        body,
        credentials: "same-origin",
      });
      const payload = await response.json().catch(() => ({ message: "The server returned an unreadable response." }));
      if (!response.ok || payload.ok === false) {
        const error = new Error(payload.message || `Request failed with HTTP ${response.status}.`);
        error.payload = {
          validationErrors: payload.validationErrors || [],
          conflict: Boolean(payload.conflict || response.status === 409),
        };
        throw error;
      }
      return payload;
    } catch (error) {
      error.payload ||= {
        validationErrors: error.validationErrors || [],
        conflict: Boolean(error.conflict),
      };
      throw error;
    }
  }

  function emptyServerState() {
    return {
      connected: false,
      connection: { errors: [], warnings: [] },
      catalog: null,
      catalogValid: false,
      catalogErrors: [],
      snapshot: null,
      images: [],
      backups: [],
    };
  }

  function githubServerState(remote) {
    let catalog = null;
    let publishedCatalog = null;
    const errors = [];
    try {
      catalog = FS.parseCatalogDocument(remote.source, remote.connection.jsonPath);
      publishedCatalog = remote.publishedSource
        ? FS.parseCatalogDocument(remote.publishedSource, remote.connection.jsonPath)
        : clone(catalog);
      errors.push(...FS.validateCatalog(catalog));
    } catch (error) {
      errors.push({ path: "$", message: `Catalog parse error: ${error.message}` });
    }
    const references = new Map();
    (catalog?.decks || []).forEach((deck) => {
      const filename = basename(deck.coverImage).toLowerCase();
      if (!filename) return;
      if (!references.has(filename)) references.set(filename, []);
      references.get(filename).push({ id: deck.id, title: deck.title });
    });
    const images = (remote.images || []).map((image) => {
      const imageReferences = references.get(image.filename.toLowerCase()) || [];
      return { ...image, references: imageReferences, orphaned: imageReferences.length === 0 };
    });
    const known = new Set(images.map((image) => image.relativePath.toLowerCase()));
    (catalog?.decks || []).forEach((deck, index) => {
      if (deck.coverImage && !known.has(deck.coverImage.toLowerCase())) {
        errors.push({ path: `decks[${index}].coverImage`, message: `Referenced image is missing: ${deck.coverImage}` });
      }
    });
    return {
      connected: true,
      connection: remote.connection,
      catalog,
      publishedCatalog,
      catalogValid: Boolean(catalog) && errors.length === 0,
      catalogErrors: errors,
      snapshot: remote.snapshot,
      images,
      backups: remote.history || [],
      devPreview: remote.devPreview || null,
    };
  }

  function releaseImageUrls(images) {
    (images || []).forEach((image) => {
      if (image.previewUrl?.startsWith("blob:")) URL.revokeObjectURL(image.previewUrl);
    });
  }

  function prepareImages(images) {
    return (images || []).map((image) => ({
      ...image,
      previewUrl: image.previewUrl || (image.file instanceof Blob ? URL.createObjectURL(image.file) : null),
    }));
  }

  function setRepositoryLoading(loading, {
    title = "Getting the latest decks.",
    message = "Connecting securely to the WHATZ IT? repository…",
    completed = 0,
    total = 0,
  } = {}) {
    const loader = $("#repository-loader");
    loader.hidden = !loading;
    if (!loading) return;
    $("#repository-loader-title").textContent = title;
    $("#repository-loader-message").textContent = message;
    const progress = $("#repository-loading-progress");
    const bar = $("span", progress);
    const determinate = total > 0;
    progress.classList.toggle("indeterminate", !determinate);
    if (determinate) {
      const percent = Math.max(0, Math.min(100, Math.round((completed / total) * 100)));
      bar.style.width = `${percent}%`;
      progress.setAttribute("aria-valuemin", "0");
      progress.setAttribute("aria-valuemax", String(total));
      progress.setAttribute("aria-valuenow", String(completed));
      $("#repository-loader-count").textContent = `${completed} of ${total} cover${total === 1 ? "" : "s"} ready`;
    } else {
      bar.style.removeProperty("width");
      progress.removeAttribute("aria-valuemin");
      progress.removeAttribute("aria-valuemax");
      progress.removeAttribute("aria-valuenow");
      $("#repository-loader-count").textContent = "This can take a moment on the first visit.";
    }
  }

  async function preloadCoverImages(serverState) {
    const referencedNames = new Set(
      (serverState.catalog?.decks || [])
        .map((deck) => basename(deck.coverImage).toLowerCase())
        .filter(Boolean),
    );
    const targets = serverState.images.filter((image) => referencedNames.has(image.filename.toLowerCase()));
    if (!targets.length) return [];
    let completed = 0;
    const failures = [];
    setRepositoryLoading(true, {
      title: "Warming up the deck shelf.",
      message: "Loading every cover before the editor appears…",
      completed,
      total: targets.length,
    });
    await runWithConcurrency(targets, 4, async (image) => {
      try {
        const blob = await fetchCoverPreview(image.previewUrl);
        image.previewUrl = URL.createObjectURL(blob);
      } catch (error) {
        console.warn("Deck cover preview failed after retries", {
          filename: image.filename,
          error: error instanceof Error ? error.message : String(error),
        });
        image.previewUrl = null;
        failures.push(image.filename);
      } finally {
        completed++;
        setRepositoryLoading(true, {
          title: "Warming up the deck shelf.",
          message: "Loading every cover before the editor appears…",
          completed,
          total: targets.length,
        });
      }
    });
    return failures;
  }

  async function fetchCoverPreview(url) {
    let lastError = null;
    for (let attempt = 0; attempt < 3; attempt++) {
      const controller = new AbortController();
      const timeout = window.setTimeout(() => controller.abort(), 8_000);
      try {
        const response = await fetch(url, {
          credentials: "same-origin",
          cache: attempt === 0 ? "force-cache" : "reload",
          signal: controller.signal,
        });
        if (!response.ok) throw new Error(`HTTP ${response.status}`);
        return await response.blob();
      } catch (error) {
        lastError = error;
        if (attempt < 2) {
          await new Promise((resolve) => setTimeout(resolve, 150 * (2 ** attempt)));
        }
      } finally {
        window.clearTimeout(timeout);
      }
    }
    throw lastError || new Error("Cover preview request failed.");
  }

  async function runWithConcurrency(items, limit, worker) {
    let nextIndex = 0;
    const runners = Array.from(
      { length: Math.min(limit, items.length) },
      async () => {
        while (nextIndex < items.length) {
          const item = items[nextIndex++];
          await worker(item);
        }
      },
    );
    await Promise.all(runners);
  }

  async function prepareRemoteState(remote) {
    const serverState = githubServerState(remote);
    const failedImages = await preloadCoverImages(serverState);
    return { serverState, failedImages };
  }

  function setBusy(button, busy, label) {
    if (!button) return;
    if (busy) {
      button.dataset.originalLabel = button.textContent;
      button.textContent = label || "Working…";
      button.disabled = true;
    } else {
      button.textContent = button.dataset.originalLabel || button.textContent;
      delete button.dataset.originalLabel;
      button.disabled = false;
    }
  }

  function notice(message, type = "info", details = [], actions = []) {
    const activeDialog = document.querySelector("dialog[open]");
    const isFormError = type === "error" && activeDialog?.querySelector("form");
    let area = $("#notice-area");
    if (isFormError) {
      area = $(".dialog-notice-area", activeDialog);
      if (!area) {
        area = document.createElement("section");
        area.className = "notice-area dialog-notice-area";
        area.setAttribute("aria-live", "assertive");
        activeDialog.querySelector("h2")?.insertAdjacentElement("afterend", area);
      }
    }
    const item = document.createElement("div");
    item.className = `notice ${type}`;
    const detailHtml = details.length
      ? `<ul>${details.map((detail) => `<li>${escapeHtml(detail)}</li>`).join("")}</ul>`
      : "";
    const actionsHtml = actions
      .map((action, index) => `<button type="button" class="button ${escapeHtml(action.className || "")}" data-notice-action="${index}">${escapeHtml(action.label)}</button>`)
      .join("");
    item.innerHTML = `<strong>${escapeHtml(message)}</strong>${detailHtml}${actionsHtml}<button type="button" class="notice-close" aria-label="Dismiss">×</button>`;
    $(".notice-close", item).addEventListener("click", () => item.remove());
    $$("[data-notice-action]", item).forEach((button) => {
      button.addEventListener("click", () => {
        const action = actions[Number(button.dataset.noticeAction)];
        action?.handler(item);
      });
    });
    area.prepend(item);
    return item;
  }

  function clearDialogNotices(dialog) {
    $(".dialog-notice-area", dialog)?.replaceChildren();
  }

  function clearNotices() {
    $("#notice-area").replaceChildren();
  }

  function catalogDiffersFromPublished() {
    return JSON.stringify(state.catalog) !== JSON.stringify(state.originalCatalog);
  }

  function renderDraftSaveStatus() {
    const pill = $("#dirty-status");
    pill.className = "dirty-pill";
    if (state.storageBackend !== "database") {
      pill.textContent = state.dirty ? "Unsaved changes" : "No unsaved changes";
      pill.classList.toggle("dirty", state.dirty);
      return;
    }
    const labels = {
      idle: state.dirty ? "Draft loaded" : "No draft changes",
      pending: "Draft save pending",
      saving: "Saving draft…",
      saved: state.dirty ? "Draft saved" : "No draft changes",
      media: "Media held in browser",
      error: "Draft save failed",
      conflict: "Draft conflict",
    };
    pill.textContent = labels[state.draftSaveStatus] || "Draft status unknown";
    pill.classList.toggle("dirty", ["error", "conflict"].includes(state.draftSaveStatus));
    pill.classList.toggle("saving", ["pending", "saving"].includes(state.draftSaveStatus));
    pill.classList.toggle("saved", state.draftSaveStatus === "saved");
  }

  const draftAutosave = new DraftAutosave({
    save: async () => {
      const savingCatalog = clone(state.catalog);
      const payload = await request("save_draft", {
        method: "POST",
        json: { catalog: savingCatalog, baseSnapshot: state.snapshot },
      });
      state.snapshot = payload.snapshot;
      state.syncedCatalog = savingCatalog;
      renderConnection();
    },
    onStatus: (status) => {
      state.draftSaveStatus = status;
      renderDraftSaveStatus();
      renderDevPreviewStatus();
    },
    onError: (error) => {
      if (error.payload?.conflict) {
        draftConflictNotice?.remove();
        draftConflictNotice = notice(
          "Another editor saved this database draft first.",
          "warning",
          ["Your browser changes were not overwritten. Save them on this device, load the newest draft, then restore them safely."],
          [{ label: "Save My Work & Get Latest", handler: () => void reloadFromDisk() }],
        );
      } else {
        notice(`Draft autosave failed: ${error.message}`, "error");
      }
      showDraftSaveError(error);
    },
  });

  function setDirty(dirty = true, { schedule = true, saved = false } = {}) {
    state.dirty = state.storageBackend === "database" && dirty
      ? catalogDiffersFromPublished() || state.pendingImageOps.length > 0
      : Boolean(dirty);
    if (state.storageBackend === "database") {
      if (dirty && state.devPreview) state.devPreview.current = false;
      if (schedule && dirty) {
        draftAutosave.changed({ blocked: state.pendingImageOps.length > 0 });
      } else if (saved) {
        draftAutosave.reset(state.dirty ? "saved" : "idle");
      } else if (!dirty) {
        draftAutosave.reset("idle");
      }
    }
    renderDraftSaveStatus();
    const publishDisabled = !state.connected || !state.catalog || !state.dirty;
    $$("[data-publish-action]").forEach((button) => {
      button.disabled = publishDisabled;
    });
    renderDevPreviewStatus();
    renderStashControls();
  }

  function stashId() {
    return `working-draft:${state.storageBackend}:${state.adminLogin || "anonymous"}`;
  }

  function renderStashControls() {
    const reloadButton = $("#reload-disk");
    if (!reloadButton) return;
    const hasLocalWork = hasBrowserOnlyChanges(state);
    reloadButton.innerHTML = hasLocalWork
      ? '<span aria-hidden="true">&#128190;</span> Save My Work &amp; Get Latest'
      : '<span aria-hidden="true">&#8635;</span> Get Latest Changes';
    reloadButton.setAttribute("aria-label", hasLocalWork
      ? "Save my work on this device and get the latest shared changes"
      : "Get the latest shared changes");
    reloadButton.title = hasLocalWork
      ? "Save your work on this device, then load the latest shared version"
      : "Load the latest shared version";
  }

  async function refreshStashState() {
    if (!FS.stashStore || !state.authenticated) {
      state.currentStash = null;
      renderStashControls();
      return;
    }
    try {
      state.currentStash = await FS.stashStore.get(stashId()) || null;
    } catch (error) {
      state.currentStash = null;
      notice(`Saved browser stashes are unavailable: ${error.message}`, "error");
    }
    renderStashControls();
    showStashResolutionDialog();
  }

  function showStashResolutionDialog() {
    if (!state.currentStash || !state.connected || dialogs.stashResolution.open) return;
    const created = state.currentStash.createdAt ? formatDate(state.currentStash.createdAt) : "an earlier session";
    $("#stash-resolution-message").textContent = `Deck Manager found work saved ${created}. Restore it onto the latest shared version or discard it before continuing.`;
    $("#stash-resolution-problem").hidden = true;
    $("#stash-resolution-problem").replaceChildren();
    const discardButton = $("#discard-stash");
    discardButton.dataset.confirmDiscard = "false";
    discardButton.textContent = "Discard Saved Work";
    dialogs.stashResolution.showModal();
  }

  function showStashResolutionProblem(message, details = []) {
    const problem = $("#stash-resolution-problem");
    problem.replaceChildren();
    const summary = document.createElement("strong");
    summary.textContent = message;
    problem.append(summary);
    if (details.length) {
      const list = document.createElement("ul");
      details.forEach((detail) => {
        const item = document.createElement("li");
        item.textContent = detail;
        list.append(item);
      });
      problem.append(list);
    }
    problem.hidden = false;
  }

  async function stashCurrentChanges({ announce = true } = {}) {
    if (!state.catalog || !state.syncedCatalog || !hasBrowserOnlyChanges(state)) {
      if (announce) notice("There are no browser-only changes to stash.", "info");
      return false;
    }
    const stash = {
      id: stashId(),
      createdAt: new Date().toISOString(),
      storageBackend: state.storageBackend,
      administrator: state.adminLogin,
      baseSnapshot: clone(state.snapshot),
      baseCatalog: clone(state.syncedCatalog),
      catalog: clone(state.catalog),
      baseImages: state.images.map(({ filename, hash }) => ({ filename, hash })),
      imageOperations: state.pendingImageOps.map(({ previewUrl, ...operation }) => operation),
      selectedDeckId: state.selectedDeckId,
    };
    try {
      await FS.stashStore.put(stash);
      state.currentStash = stash;
      renderStashControls();
      if (announce) {
        notice("Your work was saved safely on this device.", "success", [
          "Get the latest shared version, then choose Restore My Saved Work.",
        ]);
      }
      return true;
    } catch (error) {
      notice(`Could not stash browser changes: ${error.message}`, "error");
      return false;
    }
  }

  function currentChangesMatchStash(stash = state.currentStash) {
    if (!stash || JSON.stringify(stash.catalog) !== JSON.stringify(state.catalog)) return false;
    const operationFingerprint = (operation) => ({
      ...Object.fromEntries(Object.entries(operation).filter(([key]) => !["file", "previewUrl"].includes(key))),
      file: operation.file instanceof Blob
        ? {
            name: operation.file.name || "",
            size: operation.file.size,
            type: operation.file.type,
            lastModified: operation.file.lastModified || 0,
          }
        : null,
    });
    return JSON.stringify((stash.imageOperations || []).map(operationFingerprint))
      === JSON.stringify(state.pendingImageOps.map(operationFingerprint));
  }

  function stashedMediaConflicts(stash) {
    const currentByName = new Map(state.images.map((image) => [image.filename.toLowerCase(), image]));
    const conflicts = [];
    (stash.imageOperations || []).forEach((operation) => {
      const type = operation.type;
      const sourceName = String(operation.from || operation.filename || "");
      const destinationName = String(operation.to || operation.filename || "");
      const source = currentByName.get(sourceName.toLowerCase());
      const destination = currentByName.get(destinationName.toLowerCase());
      if (type === "add" && destination) {
        conflicts.push(`cover image ${destinationName}`);
      } else if (["replace", "remove", "rename"].includes(type)
        && (!source || (operation.expectedHash && source.hash !== operation.expectedHash))) {
        conflicts.push(`cover image ${sourceName}`);
      } else if (type === "rename" && destination && destination.filename.toLowerCase() !== sourceName.toLowerCase()) {
        conflicts.push(`cover image ${destinationName}`);
      }
    });
    return conflicts;
  }

  async function restoreCurrentStash() {
    const stash = state.currentStash;
    if (!stash || !state.catalog) return false;
    if (hasBrowserOnlyChanges(state)) {
      showStashResolutionProblem(
        "This browser has newer unsaved work that must be handled before the saved work can be restored.",
        ["Use Save My Work & Get Latest, then restore the newest saved copy."],
      );
      return false;
    }
    const merged = mergeStashedCatalog(stash.baseCatalog, stash.catalog, state.catalog);
    const conflicts = [...merged.conflicts, ...stashedMediaConflicts(stash)];
    if (conflicts.length) {
      showStashResolutionProblem(
        "Your saved work cannot be restored automatically because the same content changed in both versions.",
        conflicts,
      );
      return false;
    }

    try {
      await FS.stashStore.delete(stash.id);
    } catch (error) {
      showStashResolutionProblem(`Your saved work could not be removed from browser storage: ${error.message}`);
      return false;
    }

    state.catalog = merged.value;
    state.pendingImageOps = (stash.imageOperations || []).map((operation) => ({
      ...operation,
      ...(operation.file instanceof Blob ? { previewUrl: URL.createObjectURL(operation.file) } : {}),
    }));
    if (stash.selectedDeckId && allDecks().some((deck) => deck.id === stash.selectedDeckId)) {
      state.selectedDeckId = stash.selectedDeckId;
    }
    state.importPreview = null;
    state.currentStash = null;
    setDirty(true);
    renderAll();
    dialogs.stashResolution.close("restored");
    notice("Your saved work was restored on top of the latest shared version.", "success");
    return true;
  }

  async function discardCurrentStash() {
    const stash = state.currentStash;
    if (!stash) return;
    const button = $("#discard-stash");
    if (button.dataset.confirmDiscard !== "true") {
      button.dataset.confirmDiscard = "true";
      button.textContent = "Confirm Discard Saved Work";
      showStashResolutionProblem("Discarding removes this recovery copy from this browser and cannot be undone.");
      return;
    }
    try {
      await FS.stashStore.delete(stash.id);
      state.currentStash = null;
      renderStashControls();
      dialogs.stashResolution.close("discarded");
      notice("The saved recovery copy was discarded.", "success");
    } catch (error) {
      showStashResolutionProblem(`Saved work could not be discarded: ${error.message}`);
    }
  }

  function renderDevPreviewStatus() {
    const button = $("#update-dev-preview");
    const floatingButton = $("#floating-dev-preview");
    const label = $("#dev-preview-status");
    if (!button || !floatingButton || !label) return;
    const available = state.storageBackend === "database" && state.devPreviewConfigured;
    button.hidden = !available;
    label.hidden = !available;
    if (!available) {
      floatingButton.hidden = true;
      return;
    }
    const current = Boolean(state.devPreview?.current);
    const disabled = !state.connected
      || !state.catalog
      || current
      || devPreviewUpdateInFlight
      || ["pending", "saving", "error", "conflict"].includes(state.draftSaveStatus);
    button.textContent = devPreviewUpdateInFlight
      ? "Updating Test App…"
      : current
        ? "Test App Is Current"
        : "Update Test App";
    button.disabled = disabled;
    floatingButton.disabled = disabled;
    floatingButton.hidden = current || $("#workspace").hidden;
    floatingButton.innerHTML = devPreviewUpdateInFlight
      ? "Updating Test App…"
      : '<span aria-hidden="true">&#8635;</span> Update Test App';
    label.textContent = state.devPreview
      ? `Expo dev preview ${state.devPreview.previewRevision}${current ? " matches this draft." : " is behind this draft."}`
      : "No Expo dev preview has been created yet.";
  }

  function selectedDeck() {
    return findDeckEntry(state.selectedDeckId)?.deck || null;
  }

  function syncDeckCardCount(deck) {
    if (!deck || !Array.isArray(deck.cards)) return;

    // Preserve cardCount as an optional catalog field.
    // If this deck already tracks it, keep it synchronized with the cards array.
    if ("cardCount" in deck) {
      deck.cardCount = deck.cards.length;
    }
  }

  function useServerState(serverState, preserveSelection = false) {
    const oldSelection = state.selectedDeckId;
    state.connected = Boolean(serverState.connected);
    state.connection = serverState.connection || null;
    state.catalog = serverState.catalog ? clone(serverState.catalog) : null;
    state.syncedCatalog = serverState.catalog ? clone(serverState.catalog) : null;
    state.originalCatalog = serverState.publishedCatalog
      ? clone(serverState.publishedCatalog)
      : (serverState.catalog ? clone(serverState.catalog) : null);
    state.snapshot = serverState.snapshot || null;
    releaseImageUrls(state.images);
    state.images = prepareImages(serverState.images);
    state.backups = serverState.backups || [];
    state.devPreview = serverState.devPreview || null;
    state.catalogValid = Boolean(serverState.catalogValid);
    state.catalogErrors = serverState.catalogErrors || [];
    state.pendingImageOps.forEach((operation) => {
      if (operation.previewUrl) URL.revokeObjectURL(operation.previewUrl);
    });
    state.pendingImageOps = [];
    state.importPreview = null;
    state.collapsedDeckSections = new Set();
    state.collapsedBundles = new Set();
    const decks = allDecks();
    if (preserveSelection && decks.some((deck) => deck.id === oldSelection)) {
      state.selectedDeckId = oldSelection;
    } else {
      state.selectedDeckId = decks[0]?.id || null;
    }
    const persistedDraftChanged = state.storageBackend === "database" && catalogDiffersFromPublished();
    setDirty(persistedDraftChanged, { schedule: false, saved: persistedDraftChanged });
    renderAll();
  }

  async function loadStatus() {
    try {
      const session = await request("status");
      state.authenticated = Boolean(session.authenticated);
      state.authBackend = session.authBackend || "github";
      state.adminLogin = session.user?.login || "";
      state.csrfToken = session.csrfToken || "";
      state.storageBackend = session.storageBackend || "github";
      state.devPreviewConfigured = Boolean(session.developmentPreviewConfigured);
      draftAutosave.configure(state.storageBackend === "database");
      if (!session.configured) {
        $("#auth-message").textContent = state.storageBackend === "database"
          ? "Deck Manager needs its database platform settings before it can start."
          : "Deck Manager needs its GitHub App settings before it can start.";
        const problems = $("#configuration-problems");
        problems.hidden = false;
        problems.innerHTML = session.configurationProblems.map((problem) => `<li>${escapeHtml(problem)}</li>`).join("");
        return;
      }
      if (!session.authenticated) {
        const local = state.authBackend === "local";
        $("#auth-message").textContent = local
          ? "Sign in with the Deck Manager administrator account."
          : `Sign in with an authorized GitHub account to manage ${session.repository}.`;
        $("#local-login-form").hidden = !local;
        $("#github-login").hidden = local;
        return;
      }
      setRepositoryLoading(true, {
        message: state.storageBackend === "database"
          ? "Connecting securely to the catalog database…"
          : "Connecting securely to the WHATZ IT? repository…",
      });
      const payload = await request("reload");
      const { serverState, failedImages } = await prepareRemoteState(payload.state);
      useServerState(serverState);
      await refreshStashState();
      $("#auth-gate").hidden = true;
      $("#connection-bar").hidden = false;
      $("#workspace").hidden = false;
      $("#logout").hidden = false;
      $("#floating-publish").hidden = false;
      renderDevPreviewStatus();
      setRepositoryLoading(false);
      if (failedImages.length) {
        notice("Some cover images could not be loaded.", "warning", failedImages);
      }
    } catch (error) {
      setRepositoryLoading(false);
      useServerState(emptyServerState());
      $("#connection-bar").hidden = true;
      $("#auth-gate").hidden = false;
      $("#workspace").hidden = true;
      $("#floating-publish").hidden = true;
      $("#auth-message").textContent = state.storageBackend === "database"
        ? "Deck Manager could not load the catalog database."
        : "Deck Manager could not load the GitHub repository.";
      notice(error.message, "error");
    }
  }

  function renderAll() {
    renderConnection();
    renderCounts();
    renderDecks();
    renderBundles();
    renderCardDeckSelect();
    renderCards();
    renderBackups();
    renderCatalogErrors();
    updateEnabledState();
  }

  function renderConnection() {
    const connection = state.connection || {};
    const database = state.storageBackend === "database";
    $("#storage-location-label").textContent = database ? "Catalog storage" : "GitHub repository";
    $("#storage-backend-label").textContent = database ? "Backend" : "Branch";
    $("#loader-storage-label").textContent = database ? "Database draft sync" : "GitHub content sync";
    $("#history-storage-label").textContent = database ? "Database" : "GitHub";
    $("#history-storage-copy").textContent = database
      ? "Every publish is an immutable database revision with an administrator, automatic change summary, and guarded forward rollback."
      : "Every publish is an atomic GitHub commit and can be reviewed or reverted by a repository maintainer.";
    $("#connected-app").textContent = connection.appRoot || "CadeLawless/whatz-it";
    $("#connected-json").textContent = connection.branch || "—";
    $("#connected-images").textContent = state.adminLogin ? `@${state.adminLogin}` : "—";
    [$("#connected-app"), $("#connected-json"), $("#connected-images")].forEach((element) => {
      element.title = element.textContent;
    });

    const status = $("#connection-status");
    status.className = "status-pill";
    if (state.connected) {
      const backendLabel = database ? "Database" : "GitHub";
      status.textContent = state.catalogValid ? `${backendLabel} current` : `${backendLabel} · needs attention`;
      status.classList.add(state.catalogValid ? "connected" : "invalid");
    } else {
      status.textContent = connection.errors?.length ? "Invalid connection" : "Unconnected";
      if (connection.errors?.length) status.classList.add("invalid");
    }
    const revision = state.catalog?.revision;
    if (database) {
      $("#revision-status").textContent = `Revision ${Number.isInteger(revision) ? revision : "—"} · draft v${state.snapshot?.draftVersion || "—"}`;
    } else {
      const commit = state.snapshot?.commitSha ? state.snapshot.commitSha.slice(0, 7) : "—";
      $("#revision-status").textContent = `Revision ${Number.isInteger(revision) ? revision : "—"} · commit ${commit}`;
    }
    $("#discard-draft").hidden = !database;
    $("#editor-storage-copy").textContent = database
      ? "Edit decks, bundles, cards, ordering, prices, and cover art in a recoverable database draft. Catalog publication remains an explicit review step."
      : "Edit decks, bundles, cards, ordering, prices, and cover art from the protected WHATZ IT? repository. Nothing reaches GitHub until you review and publish.";
    $("#publish-dialog-title").textContent = "Publish these changes live?";
    $("#commit-message-field").hidden = database;
    $("#publish-description").textContent = database
      ? "Deck Manager records the automatic change summary and publishing administrator in immutable history."
      : "A detailed description of every published catalog and image change is added to the commit automatically.";
    $("#publish-warning").textContent = database
      ? "Deck Manager will verify the active revision and draft version, validate catalog and media, then activate one new revision atomically."
      : "Deck Manager will verify that nobody has published since you loaded the page, validate every path and cover reference, then create one atomic commit.";
  }

  function renderCounts() {
    const decks = allDecks();
    $("#deck-count").textContent = decks.length;
    $("#bundle-count").textContent = catalogBundles().length;
    $("#card-count").textContent = decks.reduce((total, deck) => total + (deck.cards?.length || 0), 0);
    $("#backup-count").textContent = state.backups.length;
  }

  function updateEnabledState() {
    const editable = state.connected && Boolean(state.catalog);
    [".add-deck", "#add-bundle", "#validate-catalog", "#deck-search", "#bundle-search", "#card-deck-picker-trigger", "#card-deck-picker-search", "#card-search"].forEach((selector) => {
      $(selector).disabled = !editable;
    });
    $("#add-card").disabled = !editable || !selectedDeck();
    $("#bulk-import").disabled = !editable || !selectedDeck();
    $("#reload-disk").disabled = !state.connected;
    $$("[data-publish-action]").forEach((button) => {
      button.disabled = !editable || !state.dirty;
    });
  }

  function renderCatalogErrors() {
    $$(".notice.catalog-error").forEach((element) => element.remove());
    if (!state.connected) {
      const errors = state.connection?.errors || [];
      if (errors.length) notice(
        state.storageBackend === "database" ? "The catalog database connection is unavailable." : "The GitHub repository connection is unavailable.",
        "error",
        errors,
      ).classList.add("catalog-error");
      return;
    }
    if (!state.catalog) {
      const missing = state.catalogErrors.some((error) => String(error.message).includes("does not exist"));
      notice(
        state.storageBackend === "database"
          ? "The database catalog could not be loaded."
          : (missing ? "The configured catalog file is missing on GitHub." : "The GitHub catalog could not be loaded."),
        "error",
        state.catalogErrors.map((error) => `${error.path}: ${error.message}`),
      ).classList.add("catalog-error");
      return;
    }
    if (state.catalogErrors.length) {
      notice("Publishing is blocked until these catalog problems are fixed.", "error", state.catalogErrors.map((error) => `${error.path}: ${error.message}`)).classList.add("catalog-error");
    }
  }

  function previewForCover(coverImage) {
    const filename = basename(coverImage);
    if (!filename) return null;
    const staged = state.pendingImageOps.find((operation) => (operation.type === "add" || operation.type === "replace") && operation.filename.toLowerCase() === filename.toLowerCase());
    if (staged?.previewUrl) return staged.previewUrl;
    const rename = state.pendingImageOps.find((operation) => operation.type === "rename" && operation.to.toLowerCase() === filename.toLowerCase());
    const diskFilename = rename ? rename.from : filename;
    const image = state.images.find((item) => item.filename.toLowerCase() === diskFilename.toLowerCase());
    return image?.previewUrl || null;
  }

  function formatDeckPrice(value) {
    if (value === undefined || value === null || value === "") return "";
    return Number(value).toFixed(2).replace(/\.00$/, "");
  }

  const deckReflowAnimations = new WeakMap();

  function updateDeckDragPreview(event) {
    const preview = state.deckDragPreview;
    if (!preview || (!event.clientX && !event.clientY)) return;
    const x = event.clientX - preview.offsetX;
    const y = event.clientY - preview.offsetY;
    const deltaX = event.clientX - preview.clientX;
    const deltaY = event.clientY - preview.clientY;
    if (deltaX || deltaY) {
      preview.directionX = deltaX;
      preview.directionY = deltaY;
    }
    preview.clientX = event.clientX;
    preview.clientY = event.clientY;
    preview.x = x;
    preview.y = y;
    preview.element.style.transform = `translate3d(${x}px, ${y}px, 0)`;
    moveDeckPlaceholderAtOverlap();
  }

  function startDeckDragPreview(tile, event) {
    const bounds = tile.getBoundingClientRect();
    const preview = tile.cloneNode(true);
    preview.classList.remove("dragging", "drag-before", "drag-after");
    preview.classList.add("deck-drag-preview");
    preview.removeAttribute("draggable");
    preview.setAttribute("aria-hidden", "true");
    preview.style.width = `${bounds.width}px`;
    preview.style.height = `${bounds.height}px`;
    document.body.append(preview);
    state.deckDragPreview = {
      element: preview,
      offsetX: Math.max(0, Math.min(bounds.width, event.clientX - bounds.left)),
      offsetY: Math.max(0, Math.min(bounds.height, event.clientY - bounds.top)),
      width: bounds.width,
      height: bounds.height,
      clientX: event.clientX,
      clientY: event.clientY,
      directionX: 0,
      directionY: 0,
      x: bounds.left,
      y: bounds.top,
    };
    updateDeckDragPreview(event);

    const transparentImage = document.createElement("canvas");
    transparentImage.width = 1;
    transparentImage.height = 1;
    event.dataTransfer.setDragImage(transparentImage, 0, 0);
    document.addEventListener("dragover", updateDeckDragPreview, true);
  }

  function finishDeckDragPreview() {
    document.removeEventListener("dragover", updateDeckDragPreview, true);
    state.deckDragPreview?.element.remove();
    state.deckDragPreview = null;
    document.body.classList.remove("deck-dragging");
  }

  function deckDropAfter(tile) {
    const preview = state.deckDragPreview;
    if (!preview) return false;
    return Math.abs(preview.directionX) >= Math.abs(preview.directionY)
      ? preview.directionX >= 0
      : preview.directionY >= 0;
  }

  function deckLayoutBounds(tile) {
    const bounds = tile.getBoundingClientRect();
    let translateX = 0;
    let translateY = 0;
    const transform = getComputedStyle(tile).transform;
    if (transform && transform !== "none" && typeof DOMMatrixReadOnly !== "undefined") {
      try {
        const matrix = new DOMMatrixReadOnly(transform);
        translateX = matrix.m41;
        translateY = matrix.m42;
      } catch {
        // A failed transform parse should not prevent sorting.
      }
    }
    return {
      left: bounds.left - translateX,
      right: bounds.right - translateX,
      top: bounds.top - translateY,
      bottom: bounds.bottom - translateY,
      width: bounds.width,
      height: bounds.height,
    };
  }

  function deckOverlapArea(preview, target) {
    const width = Math.max(0, Math.min(preview.x + preview.width, target.right) - Math.max(preview.x, target.left));
    const height = Math.max(0, Math.min(preview.y + preview.height, target.bottom) - Math.max(preview.y, target.top));
    return width * height;
  }

  function moveDeckPlaceholderAtOverlap() {
    const drag = state.dragOrder || state.dragBundleDeck;
    const preview = state.deckDragPreview;
    const source = drag?.tile;
    if (!source || !preview) return;

    const sourceBounds = deckLayoutBounds(source);
    const rowThreshold = sourceBounds.height * .45;
    const overlaps = $$(".deck-tile", source.parentElement)
      .filter((tile) => tile !== source)
      .map((tile) => {
        const bounds = deckLayoutBounds(tile);
        return { tile, bounds, area: deckOverlapArea(preview, bounds) };
      })
      .filter(({ area }) => area > 0)
      .sort((left, right) => {
        if (right.area !== left.area) return right.area - left.area;
        if (preview.directionY > 0) return right.bounds.top - left.bounds.top;
        if (preview.directionY < 0) return left.bounds.top - right.bounds.top;
        if (preview.directionX > 0) return right.bounds.left - left.bounds.left;
        return left.bounds.left - right.bounds.left;
      });
    if (!overlaps.length) return;

    const target = overlaps[0];
    const lowerRow = target.bounds.top > sourceBounds.top + rowThreshold;
    const upperRow = target.bounds.top < sourceBounds.top - rowThreshold;
    const rightInRow = !lowerRow && !upperRow && target.bounds.left > sourceBounds.left;
    const leftInRow = !lowerRow && !upperRow && target.bounds.left < sourceBounds.left;
    let moved = false;
    if (lowerRow && preview.directionY > 0) {
      moved = moveDeckPlaceholder(source, target.tile, true);
    } else if (upperRow && preview.directionY < 0) {
      moved = moveDeckPlaceholder(source, target.tile, false);
    } else if (rightInRow && preview.directionX > 0) {
      moved = moveDeckPlaceholder(source, target.tile, true);
    } else if (leftInRow && preview.directionX < 0) {
      moved = moveDeckPlaceholder(source, target.tile, false);
    }
    drag.moved ||= moved;
  }

  function syncLiveDeckLists(lists) {
    lists.forEach((list) => {
      if (!list?.classList.contains("pack-deck-grid")) return;
      const hasDeck = Boolean($(".deck-tile", list));
      list.classList.toggle("empty-pack", !hasDeck);
      const emptyMessage = $(".pack-empty", list);
      if (emptyMessage) emptyMessage.hidden = hasDeck;
    });
  }

  function moveDeckPlaceholder(source, target, after) {
    if (!source || !target || source === target) return false;
    if ((!after && source.nextElementSibling === target) || (after && target.nextElementSibling === source)) return false;

    const sourceList = source.parentElement;
    const targetList = target.parentElement;
    const lists = sourceList === targetList ? [sourceList] : [sourceList, targetList];
    const tiles = lists.flatMap((list) => $$(".deck-tile", list)).filter((tile) => tile !== source);
    const first = new Map(tiles.map((tile) => [tile, tile.getBoundingClientRect()]));

    if (after) target.after(source);
    else target.before(source);
    syncLiveDeckLists(lists);

    tiles.forEach((tile) => {
      const before = first.get(tile);
      const next = tile.getBoundingClientRect();
      const x = before.left - next.left;
      const y = before.top - next.top;
      if (!x && !y) return;
      deckReflowAnimations.get(tile)?.cancel();
      const animation = tile.animate(
        [
          { transform: `translate3d(${x}px, ${y}px, 0)` },
          { transform: "translate3d(0, 0, 0)" },
        ],
        { duration: 220, easing: "cubic-bezier(.2, .8, .2, 1)" },
      );
      deckReflowAnimations.set(tile, animation);
    });
    return true;
  }

  function appendDeckPlaceholder(source, list) {
    if (!source || !list || source.parentElement === list && source === list.lastElementChild) return false;
    const sourceList = source.parentElement;
    const lists = [sourceList, list]
      .filter((item, index, values) => item && values.indexOf(item) === index);
    const tiles = lists
      .flatMap((item) => $$(".deck-tile", item))
      .filter((tile) => tile !== source);
    const first = new Map(tiles.map((tile) => [tile, tile.getBoundingClientRect()]));
    list.append(source);
    syncLiveDeckLists(lists);
    tiles.forEach((tile) => {
      const before = first.get(tile);
      const next = tile.getBoundingClientRect();
      const x = before.left - next.left;
      const y = before.top - next.top;
      if (!x && !y) return;
      deckReflowAnimations.get(tile)?.cancel();
      const animation = tile.animate(
        [
          { transform: `translate3d(${x}px, ${y}px, 0)` },
          { transform: "translate3d(0, 0, 0)" },
        ],
        { duration: 220, easing: "cubic-bezier(.2, .8, .2, 1)" },
      );
      deckReflowAnimations.set(tile, animation);
    });
    return true;
  }

  function clearDeckDropIndicators() {
    $$(".deck-tile, .pack-section").forEach((tile) => {
      tile.classList.remove("drag-before", "drag-after", "pack-drag-before", "pack-drag-after");
      delete tile.dataset.dropPosition;
    });
  }

  function finishDeckDrag() {
    clearDeckDropIndicators();
    $$(".deck-tile").forEach((tile) => tile.classList.remove("dragging"));
    $$(".pack-section").forEach((section) => section.classList.remove("dragging"));
    $$(".pack-deck-grid").forEach((grid) => grid.classList.remove("pack-drop-target"));
    state.dragDeckIndex = null;
    state.dragPackIndex = null;
    document.body.classList.remove("deck-dragging");
  }

  function autoScrollDeckDrag(event) {
    const legacyDeckDrag = state.dragDeckIndex && Number.isInteger(state.dragDeckIndex.index);
    if (!legacyDeckDrag && !Number.isInteger(state.dragPackIndex) && !state.dragOrder && !state.dragBundleDeck) return;
    const edge = Math.min(140, window.innerHeight * 0.22);
    let amount = 0;
    if (event.clientY < edge) amount = -Math.ceil((edge - event.clientY) / 4);
    else if (event.clientY > window.innerHeight - edge) amount = Math.ceil((event.clientY - (window.innerHeight - edge)) / 4);
    if (amount) window.scrollBy(0, Math.max(-32, Math.min(32, amount)));
  }

  function renderDecks() {
    const grid = $("#deck-grid");
    const decks = allDecks();
    const query = $("#deck-search").value.trim().toLocaleLowerCase();
    const matches = (deck) => !query || [deck.title, deck.description, deck.id, deck.access, ...(deck.tags || [])]
      .some((value) => String(value || "").toLocaleLowerCase().includes(query));
    const free = orderedDecks("free").filter(matches);
    const paid = orderedDecks("paid").filter(matches);
    const visibleCount = decks.filter(matches).length;
    $("#deck-filter-count").textContent = query
      ? `${visibleCount} of ${decks.length} decks`
      : `${decks.length} deck${decks.length === 1 ? "" : "s"}`;
    if (!visibleCount) {
      grid.className = "deck-library empty-state";
      grid.innerHTML = state.catalog
        ? `<div><strong>${decks.length ? "No matching decks" : "No decks yet"}</strong><p>${decks.length ? "Try a different search." : "Add a deck to start building the library."}</p></div>`
        : `<div><strong>${state.storageBackend === "database" ? "Database unavailable" : "Repository unavailable"}</strong><p>Get the latest ${state.storageBackend === "database" ? "database draft" : "GitHub catalog"} to begin editing.</p></div>`;
      return;
    }
    const section = (scope, title, description, items) => {
      const collapsed = !query && state.collapsedDeckSections.has(scope);
      return `
      <section class="deck-order-section ${collapsed ? "collapsed" : ""}" data-order-scope="${scope}">
        <header>
          <button type="button" class="deck-section-toggle" data-deck-section-toggle="${scope}" aria-expanded="${collapsed ? "false" : "true"}">
            <span class="pack-chevron" aria-hidden="true">&#8964;</span>
            <span><strong>${title}</strong><small>${description}</small></span>
            <span class="section-count">${items.length}</span>
          </button>
          ${scope === "paid"
          ? '<button type="button" class="button accent icon-button deck-section-add" data-add-paid-deck aria-label="Add paid deck" title="Add paid deck">&#43;</button>'
          : ""}
        </header>
        <div class="deck-grid deck-order-grid ${items.length ? "" : "empty-order"}" data-deck-order-list="${scope}" ${collapsed ? "hidden" : ""}>
          ${items.length
          ? items.map((deck, orderIndex) => renderLibraryDeckTile(deck, allDecks().indexOf(deck), { orderScope: scope, orderIndex })).join("")
          : `<div class="pack-empty"><strong>No ${title.toLowerCase()}</strong><p>${query ? "No decks in this group match the search." : "Decks appear here automatically."}</p></div>`}
        </div>
      </section>`;
    };
    grid.className = "deck-library";
    grid.innerHTML = [
      section("free", "Free decks", "Order used anywhere the app presents free decks.", free),
      section("paid", "Paid decks", "Order used by the app’s all-paid-decks page.", paid),
    ].join("");
    $$("[data-deck-section-toggle]", grid).forEach((button) => {
      button.addEventListener("click", () => {
        const scope = button.dataset.deckSectionToggle;
        if (state.collapsedDeckSections.has(scope)) state.collapsedDeckSections.delete(scope);
        else state.collapsedDeckSections.add(scope);
        renderDecks();
      });
    });
    $("[data-add-paid-deck]", grid)?.addEventListener("click", () => openDeckDialog(-1, "paid"));
    $$(".deck-tile", grid).forEach((tile) => {
      tile.addEventListener("pointerdown", (event) => {
        state.armedDeckDragTile = event.target.closest(".deck-cover") ? tile : null;
      });
      tile.addEventListener("click", (event) => {
        const action = event.target.closest("[data-action]")?.dataset.action;
        if (!action) return;
        const index = Number(tile.dataset.deckIndex);
        if (action === "edit") openDeckDialog(index);
        if (action === "duplicate") duplicateDeck(index);
        if (action === "remove") removeDeck(index);
        if (action === "cards") {
          state.selectedDeckId = allDecks()[index].id;
          switchTab("cards");
          renderCardDeckSelect();
          renderCards();
        }
      });
      tile.addEventListener("dragstart", (event) => {
        if (state.armedDeckDragTile !== tile || $("#deck-search").value.trim()) {
          event.preventDefault();
          return;
        }
        state.dragOrder = {
          scope: tile.dataset.orderScope,
          deckId: tile.dataset.deckId,
          tile,
          moved: false,
          originalOrder: [...(state.catalog.deckOrders?.[tile.dataset.orderScope] || [])],
        };
        event.dataTransfer.effectAllowed = "move";
        event.dataTransfer.setData("text/plain", tile.dataset.deckId);
        startDeckDragPreview(tile, event);
        tile.classList.add("dragging");
        document.body.classList.add("deck-dragging");
      });
      tile.addEventListener("dragend", finishOrderDrag);
    });
    $$("[data-deck-order-list]", grid).forEach((list) => {
      list.addEventListener("dragover", (event) => {
        if (!state.dragOrder || state.dragOrder.scope !== list.dataset.deckOrderList) return;
        event.preventDefault();
        event.dataTransfer.dropEffect = "move";
      });
      list.addEventListener("drop", (event) => {
        if (!state.dragOrder || state.dragOrder.scope !== list.dataset.deckOrderList) return;
        event.preventDefault();
        const scope = state.dragOrder.scope;
        const nextOrder = $$(".deck-tile", list).map((tile) => tile.dataset.deckId);
        state.catalog.deckOrders[scope] = nextOrder;
        if (
          nextOrder.length !== state.dragOrder.originalOrder.length
          || nextOrder.some((deckId, index) => deckId !== state.dragOrder.originalOrder[index])
        ) setDirty();
        finishOrderDrag(false);
        renderDecks();
      });
    });
  }

  function renderLibraryDeckTile(deck, index, { compact = false, bundleId = "", bundleIndex = 0, orderScope = "", orderIndex = 0 } = {}) {
    const preview = previewForCover(deck.coverImage);
    const image = preview
      ? `<img src="${escapeHtml(preview)}" alt="${escapeHtml(deck.title)} cover">`
      : `<span class="cover-placeholder">${deck.coverImage ? "Missing image" : "No cover assigned"}</span>`;
    const memberships = catalogBundles().filter((bundle) => (bundle.deckIds || []).includes(deck.id));
    const accessLabel = deck.access === "paid"
      ? `Paid${deck.price === undefined ? "" : ` · ${formatDeckPrice(deck.price)}`}`
      : "Free";
    return `
      <article class="deck-tile ${compact ? "compact" : ""}" data-deck-index="${index}" data-deck-id="${escapeHtml(deck.id)}" data-bundle-id="${escapeHtml(bundleId)}" data-order-scope="${escapeHtml(orderScope)}" draggable="${orderScope || bundleId ? "true" : "false"}">
        <div class="deck-cover" title="${orderScope || bundleId ? "Drag deck to reorder" : ""}">
          ${image}
          ${orderScope || bundleId ? `<span class="drag-handle" title="Drag to reorder">↕ Drag</span>` : ""}
          ${orderScope ? `<span class="deck-order">${orderIndex + 1}</span>` : bundleId ? `<span class="deck-order">${bundleIndex + 1}</span>` : ""}
        </div>
        <div class="deck-info">
          <h3>${escapeHtml(deck.title)}</h3>
          <p>${escapeHtml(deck.description || "No description")}</p>
          <div class="deck-meta">
            <span class="access-badge ${deck.access === "paid" ? "paid" : ""}">${escapeHtml(accessLabel)}</span>
            <span>${deck.cards?.length || 0} card${deck.cards?.length === 1 ? "" : "s"}</span>
            ${compact ? "" : `<span>${memberships.length ? `${memberships.length} bundle${memberships.length === 1 ? "" : "s"}` : "No bundles"}</span>`}
            <span>${escapeHtml(deck.id)}</span>
          </div>
        </div>
        <div class="deck-actions">
          ${bundleId ? `<button type="button" class="mini-button icon-button danger" data-bundle-remove-deck="${escapeHtml(deck.id)}" aria-label="Remove ${escapeHtml(deck.title)} from this bundle" title="Remove from bundle">&#8722;</button>` : `
            <button type="button" class="mini-button icon-button" data-action="cards" aria-label="Edit cards in ${escapeHtml(deck.title)}" title="Cards">&#9638;</button>
            <button type="button" class="mini-button icon-button" data-action="edit" aria-label="Edit ${escapeHtml(deck.title)}" title="Edit deck">&#9998;</button>
            <button type="button" class="mini-button icon-button" data-action="duplicate" aria-label="Duplicate ${escapeHtml(deck.title)}" title="Duplicate deck">&#10697;</button>
            <button type="button" class="mini-button icon-button danger" data-action="remove" aria-label="Remove ${escapeHtml(deck.title)}" title="Remove deck">&#215;</button>
          `}
        </div>
      </article>`;
  }

  function clearOrderDropIndicators(root = document) {
    $$(".deck-tile", root).forEach((tile) => {
      tile.classList.remove("drag-before", "drag-after", "dragging");
      delete tile.dataset.dropAfter;
    });
  }

  function finishOrderDrag(restore = true) {
    const shouldRestore = restore && state.dragOrder?.moved;
    clearOrderDropIndicators($("#deck-grid"));
    finishDeckDragPreview();
    state.dragOrder = null;
    state.armedDeckDragTile = null;
    if (shouldRestore) renderDecks();
  }

  function renderBundles() {
    const list = $("#bundle-list");
    const bundles = catalogBundles();
    const query = $("#bundle-search").value.trim().toLocaleLowerCase();
    const visible = bundles.filter((bundle) => {
      const decks = (bundle.deckIds || []).map((id) => findDeckEntry(id)?.deck).filter(Boolean);
      return !query
        || [bundle.id, bundle.title, bundle.description, bundle.access].some((value) => String(value || "").toLocaleLowerCase().includes(query))
        || decks.some((deck) => [deck.id, deck.title, deck.description].some((value) => String(value || "").toLocaleLowerCase().includes(query)));
    });
    $("#bundle-filter-count").textContent = query
      ? `${visible.length} of ${bundles.length} bundles`
      : `${bundles.length} bundle${bundles.length === 1 ? "" : "s"}`;
    if (!visible.length) {
      list.className = "pack-list empty-state";
      list.innerHTML = `<div><strong>${bundles.length ? "No matching bundles" : "No bundles yet"}</strong><p>${bundles.length ? "Try a different search." : "Add a bundle, then choose any decks from the library."}</p></div>`;
      return;
    }
    list.className = "pack-list";
    list.innerHTML = visible.map((bundle) => {
      const index = bundles.indexOf(bundle);
      const decks = (bundle.deckIds || []).map((id) => findDeckEntry(id)?.deck).filter(Boolean);
      const accessLabel = bundle.access === "paid"
        ? `Paid${bundle.price === undefined ? "" : ` · ${formatDeckPrice(bundle.price)}`}`
        : "Free";
      const collapsed = !query && state.collapsedBundles.has(bundle.id);
      return `
        <section class="pack-section ${collapsed ? "collapsed" : ""}" data-bundle-section data-bundle-id="${escapeHtml(bundle.id)}" data-bundle-index="${index}">
          <header class="pack-header">
            <button type="button" class="pack-toggle" data-bundle-toggle aria-expanded="${collapsed ? "false" : "true"}">
              <span class="pack-chevron" aria-hidden="true">&#8964;</span>
              <span>
                <strong>${escapeHtml(bundle.title)}</strong>
                <small>${escapeHtml(bundle.id)} · ${decks.length} deck${decks.length === 1 ? "" : "s"}</small>
                ${bundle.description ? `<span class="bundle-description">${escapeHtml(bundle.description)}</span>` : ""}
              </span>
            </button>
            <div class="pack-header-meta"><span class="access-badge ${bundle.access === "paid" ? "paid" : ""}">${escapeHtml(accessLabel)}</span></div>
            <div class="pack-actions">
              <button type="button" class="mini-button icon-button" data-bundle-action="add-decks" aria-label="Add decks to ${escapeHtml(bundle.title)}" title="Add decks">&#43;</button>
              <button type="button" class="mini-button icon-button" data-bundle-action="edit" aria-label="Edit ${escapeHtml(bundle.title)}" title="Edit bundle">&#9998;</button>
              <button type="button" class="mini-button icon-button" data-bundle-action="up" aria-label="Move ${escapeHtml(bundle.title)} up" title="Move bundle up" ${index === 0 ? "disabled" : ""}>&#8593;</button>
              <button type="button" class="mini-button icon-button" data-bundle-action="down" aria-label="Move ${escapeHtml(bundle.title)} down" title="Move bundle down" ${index === bundles.length - 1 ? "disabled" : ""}>&#8595;</button>
              <button type="button" class="mini-button icon-button danger" data-bundle-action="remove" aria-label="Remove ${escapeHtml(bundle.title)}" title="${bundle.id === "free-bundle" ? "Free Bundle is required by the app" : "Remove bundle"}" ${bundle.id === "free-bundle" ? "disabled" : ""}>&#215;</button>
            </div>
          </header>
          <div class="pack-content" ${collapsed ? "hidden" : ""}>
            <div class="deck-grid pack-deck-grid ${decks.length ? "" : "empty-pack"}" data-bundle-drop="${escapeHtml(bundle.id)}">
              ${decks.length
          ? decks.map((deck, bundleIndex) => renderLibraryDeckTile(deck, allDecks().indexOf(deck), { compact: true, bundleId: bundle.id, bundleIndex })).join("")
          : '<div class="pack-empty"><strong>This bundle has no decks</strong><p>Use + Add Deck to choose from the full deck library.</p></div>'}
            </div>
          </div>
        </section>`;
    }).join("");
    $$("[data-bundle-section]", list).forEach((section) => {
      const bundleId = section.dataset.bundleId;
      $("[data-bundle-toggle]", section).addEventListener("click", () => {
        if (state.collapsedBundles.has(bundleId)) state.collapsedBundles.delete(bundleId);
        else state.collapsedBundles.add(bundleId);
        renderBundles();
      });
      section.addEventListener("click", (event) => {
        const action = event.target.closest("[data-bundle-action]")?.dataset.bundleAction;
        const deckId = event.target.closest("[data-bundle-remove-deck]")?.dataset.bundleRemoveDeck;
        const index = Number(section.dataset.bundleIndex);
        if (action === "add-decks") openBundleDecksDialog(bundleId);
        if (action === "edit") openBundleDialog(bundleId);
        if (action === "up") moveBundle(index, index - 1);
        if (action === "down") moveBundle(index, index + 1);
        if (action === "remove") removeBundle(bundleId);
        if (deckId) removeDeckFromBundle(bundleId, deckId);
      });
      $$(".deck-tile", section).forEach((tile) => {
        tile.addEventListener("pointerdown", (event) => {
          state.armedDeckDragTile = event.target.closest(".deck-cover") ? tile : null;
        });
        tile.addEventListener("dragstart", (event) => {
          if (state.armedDeckDragTile !== tile || $("#bundle-search").value.trim()) {
            event.preventDefault();
            return;
          }
          state.dragBundleDeck = {
            bundleId,
            deckId: tile.dataset.deckId,
            tile,
            moved: false,
          };
          event.dataTransfer.effectAllowed = "move";
          event.dataTransfer.setData("text/plain", tile.dataset.deckId);
          startDeckDragPreview(tile, event);
          tile.classList.add("dragging");
          document.body.classList.add("deck-dragging");
        });
        tile.addEventListener("dragend", finishBundleDeckDrag);
        tile.addEventListener("dragover", (event) => {
          if (!state.dragBundleDeck) return;
          event.preventDefault();
          event.stopPropagation();
          event.dataTransfer.dropEffect = "move";
          if (state.dragBundleDeck.tile.parentElement === tile.parentElement) return;
          const moved = moveDeckPlaceholder(state.dragBundleDeck.tile, tile, deckDropAfter(tile));
          state.dragBundleDeck.moved ||= moved;
        });
      });
      const dropZone = $("[data-bundle-drop]", section);
      dropZone.addEventListener("dragover", (event) => {
        if (!state.dragBundleDeck) return;
        event.preventDefault();
        event.dataTransfer.dropEffect = "move";
        if (event.target.closest(".deck-tile")) return;
        const otherDecks = $$(".deck-tile", dropZone).filter((tile) => tile !== state.dragBundleDeck.tile);
        if (otherDecks.length) return;
        const moved = appendDeckPlaceholder(state.dragBundleDeck.tile, dropZone);
        state.dragBundleDeck.moved ||= moved;
        dropZone.classList.add("pack-drop-target");
      });
      dropZone.addEventListener("dragleave", () => dropZone.classList.remove("pack-drop-target"));
      dropZone.addEventListener("drop", (event) => {
        if (!state.dragBundleDeck) return;
        event.preventDefault();
        const sourceBundle = bundleById(state.dragBundleDeck.bundleId);
        const currentList = state.dragBundleDeck.tile.parentElement;
        const targetBundle = bundleById(currentList?.dataset.bundleDrop);
        if (!sourceBundle || !targetBundle) return finishBundleDeckDrag();
        const draggedDeck = findDeckEntry(state.dragBundleDeck.deckId)?.deck;
        if (targetBundle.id === "free-bundle" && draggedDeck?.access !== "free") {
          finishBundleDeckDrag();
          notice("Free Bundle may contain free decks only.", "error");
          return;
        }
        const sourceList = $$("[data-bundle-drop]", list).find((item) => item.dataset.bundleDrop === sourceBundle.id);
        const nextSourceOrder = sourceList ? $$(".deck-tile", sourceList).map((item) => item.dataset.deckId) : sourceBundle.deckIds;
        const nextTargetOrder = $$(".deck-tile", currentList).map((item) => item.dataset.deckId);
        const sourceChanged = nextSourceOrder.some((deckId, index) => deckId !== sourceBundle.deckIds[index])
          || nextSourceOrder.length !== sourceBundle.deckIds.length;
        const targetChanged = nextTargetOrder.some((deckId, index) => deckId !== targetBundle.deckIds[index])
          || nextTargetOrder.length !== targetBundle.deckIds.length;
        sourceBundle.deckIds = nextSourceOrder;
        targetBundle.deckIds = nextTargetOrder;
        syncDeckOrders();
        if (sourceChanged || targetChanged) setDirty();
        finishBundleDeckDrag(false);
        renderAll();
      });
    });
  }

  function clearBundleDropIndicators(root = document) {
    $$(".deck-tile", root).forEach((tile) => {
      tile.classList.remove("drag-before", "drag-after", "dragging");
      delete tile.dataset.dropAfter;
    });
    $$(".pack-deck-grid", root).forEach((grid) => grid.classList.remove("pack-drop-target"));
  }

  function finishBundleDeckDrag(restore = true) {
    const shouldRestore = restore && state.dragBundleDeck?.moved;
    clearBundleDropIndicators($("#bundle-list"));
    finishDeckDragPreview();
    state.dragBundleDeck = null;
    state.armedDeckDragTile = null;
    if (shouldRestore) renderBundles();
  }

  function moveBundle(from, to) {
    if (to < 0 || to >= catalogBundles().length) return;
    const [moved] = state.catalog.bundles.splice(from, 1);
    state.catalog.bundles.splice(to, 0, moved);
    normalizeBundleOrders();
    setDirty();
    renderAll();
  }

  function renderBundleDeckPicker() {
    const form = $("#bundle-decks-form");
    const bundle = bundleById(form.elements.bundleId.value);
    const picker = $("#bundle-deck-picker");
    const query = $("#bundle-deck-search").value.trim().toLocaleLowerCase();
    const decks = allDecks().filter((deck) => !query || [deck.id, deck.title, deck.description, ...(deck.tags || [])]
      .some((value) => String(value || "").toLocaleLowerCase().includes(query)));
    picker.innerHTML = decks.length
      ? decks.map((deck) => {
        const unavailable = bundle?.id === "free-bundle" && deck.access !== "free" && !state.bundleDeckDraft.has(deck.id);
        return `
          <label class="bundle-deck-option">
            <input type="checkbox" name="deckIds" value="${escapeHtml(deck.id)}" ${state.bundleDeckDraft.has(deck.id) ? "checked" : ""} ${unavailable ? 'disabled title="Paid decks cannot be added to Free Bundle"' : ""}>
            <span class="bundle-deck-thumb">${previewForCover(deck.coverImage) ? `<img src="${escapeHtml(previewForCover(deck.coverImage))}" alt="">` : ""}</span>
            <span><strong>${escapeHtml(deck.title)}</strong><small>${escapeHtml(deck.id)} · ${deck.cards?.length || 0} cards</small></span>
          </label>`;
      }).join("")
      : '<div class="empty-state"><div><strong>No matching decks</strong><p>Try a different search, or add a deck from the Decks tab.</p></div></div>';
    $$('input[name="deckIds"]', picker).forEach((input) => input.addEventListener("change", () => {
      if (input.checked) state.bundleDeckDraft.add(input.value);
      else state.bundleDeckDraft.delete(input.value);
    }));
  }

  function openBundleDecksDialog(bundleId) {
    const bundle = bundleById(bundleId);
    if (!bundle) return;
    const form = $("#bundle-decks-form");
    form.elements.bundleId.value = bundleId;
    state.bundleDeckDraft = new Set(bundle.deckIds || []);
    $("#bundle-decks-title").textContent = `Decks in ${bundle.title}`;
    $("#bundle-deck-search").value = "";
    renderBundleDeckPicker();
    dialogs.bundleDecks.showModal();
  }

  function removeDeckFromBundle(bundleId, deckId) {
    const bundle = bundleById(bundleId);
    if (!bundle) return;
    bundle.deckIds = bundle.deckIds.filter((id) => id !== deckId);
    syncDeckOrders();
    setDirty();
    renderAll();
  }

  function renderLegacyDecks() {
    const list = $("#deck-grid");
    const packs = catalogPacks();
    const totalDecks = allDecks().length;
    const query = $("#deck-search").value.trim().toLocaleLowerCase();
    const visiblePacks = packs.map((pack) => {
      const packMatches = !query || [pack.id, pack.title, pack.access].some((value) => String(value || "").toLocaleLowerCase().includes(query));
      const decks = (pack.decks || []).map((deck, index) => ({ deck, index })).filter(({ deck }) => {
        if (packMatches) return true;
        return [
          deck.title,
          deck.description,
          deck.id,
          deck.access,
          ...(deck.tags || []),
        ].some((value) => String(value || "").toLocaleLowerCase().includes(query));
      });
      return { pack, decks, packMatches };
    }).filter(({ decks, packMatches }) => packMatches || decks.length);
    const visibleDeckCount = visiblePacks.reduce((total, item) => total + item.decks.length, 0);
    $("#deck-filter-count").textContent = query
      ? `${visiblePacks.length} pack${visiblePacks.length === 1 ? "" : "s"} · ${visibleDeckCount} of ${totalDecks} decks`
      : `${packs.length} pack${packs.length === 1 ? "" : "s"} · ${totalDecks} deck${totalDecks === 1 ? "" : "s"}`;
    if (!packs.length) {
      list.className = "pack-list empty-state";
      list.innerHTML = state.catalog
        ? "<div><strong>This catalog has no bundles</strong><p>Add Free Bundle before adding decks.</p></div>"
        : "<div><strong>Connect your app repository</strong><p>The managed packs.ts catalog will become the only source of pack and deck content shown here.</p></div>";
      return;
    }
    if (!visiblePacks.length) {
      list.className = "pack-list empty-state";
      list.innerHTML = "<div><strong>No matching bundles or decks</strong><p>Try a different search.</p></div>";
      return;
    }
    list.className = "pack-list";
    list.innerHTML = visiblePacks.map(({ pack, decks }) => {
      const packIndex = packs.indexOf(pack);
      const collapsed = !query && state.collapsedPacks.has(pack.id);
      const packAccess = pack.access === "paid"
        ? `Paid${pack.price === undefined ? "" : ` · ${formatDeckPrice(pack.price)}`}`
        : "Free";
      const deckTiles = decks.map(({ deck, index }) => renderDeckTile(pack, deck, index)).join("");
      return `
        <section class="pack-section ${collapsed ? "collapsed" : ""}" data-pack-id="${escapeHtml(pack.id)}" data-pack-index="${packIndex}">
          <header class="pack-header">
            <span class="pack-drag-handle" data-pack-drag draggable="${pack.id !== "free-pack" && !query ? "true" : "false"}" title="${query ? "Clear search before reordering bundles" : pack.id === "free-pack" ? "Free Bundle is always first" : "Drag to reorder bundle"}">↕</span>
            <button type="button" class="pack-toggle" data-pack-toggle aria-expanded="${collapsed ? "false" : "true"}">
              <span class="pack-chevron" aria-hidden="true">⌄</span>
              <span><strong>${escapeHtml(pack.title)}</strong><small>${escapeHtml(pack.id)} · ${pack.decks.length} deck${pack.decks.length === 1 ? "" : "s"}</small></span>
            </button>
            <div class="pack-header-meta">
              <span class="access-badge ${pack.access === "paid" ? "paid" : ""}">${escapeHtml(packAccess)}</span>
            </div>
            <div class="pack-actions">
              <button type="button" class="mini-button" data-pack-action="add-deck">+ Add deck</button>
              <button type="button" class="mini-button" data-pack-action="edit">Edit bundle</button>
              <button type="button" class="mini-button" data-pack-action="up" ${packIndex <= 1 ? "disabled" : ""}>Move up</button>
              <button type="button" class="mini-button" data-pack-action="down" ${pack.id === "free-pack" || packIndex === packs.length - 1 ? "disabled" : ""}>Move down</button>
              <button type="button" class="mini-button danger" data-pack-action="remove" ${pack.id === "free-pack" ? "disabled title=\"Free Bundle cannot be removed\"" : ""}>Remove bundle</button>
            </div>
          </header>
          <div class="pack-content" ${collapsed ? "hidden" : ""}>
            <div class="deck-grid pack-deck-grid ${decks.length ? "" : "empty-pack"}" data-pack-drop="${escapeHtml(pack.id)}">
              ${deckTiles || `<div class="pack-empty"><strong>${query && pack.decks.length ? "No matching decks in this bundle" : "This bundle has no decks"}</strong><p>${query && pack.decks.length ? "The bundle itself matched your search." : "Use + Add deck to choose one from the library."}</p></div>`}
            </div>
          </div>
        </section>`;
    }).join("");

    $$(".pack-section", list).forEach((section) => {
      const packId = section.dataset.packId;
      $("[data-pack-toggle]", section).addEventListener("click", () => {
        if (state.collapsedPacks.has(packId)) state.collapsedPacks.delete(packId);
        else state.collapsedPacks.add(packId);
        renderDecks();
      });
      section.addEventListener("click", (event) => {
        const action = event.target.closest("[data-pack-action]")?.dataset.packAction;
        const packIndex = Number(section.dataset.packIndex);
        if (action === "add-deck") openDeckDialog(packId);
        if (action === "edit") openPackDialog(packId);
        if (action === "up" && packIndex > 1) movePack(packIndex, packIndex - 1);
        if (action === "down" && packIndex < catalogPacks().length - 1) movePack(packIndex, packIndex + 1, true);
        if (action === "remove") removePack(packId);
      });
      const packDrag = $("[data-pack-drag]", section);
      packDrag.addEventListener("dragstart", (event) => {
        if (packId === "free-pack" || query) {
          event.preventDefault();
          return;
        }
        state.dragPackIndex = Number(section.dataset.packIndex);
        event.dataTransfer.effectAllowed = "move";
        event.dataTransfer.setData("text/plain", packId);
        section.classList.add("dragging");
        document.body.classList.add("deck-dragging");
      });
      packDrag.addEventListener("dragend", finishDeckDrag);
      section.addEventListener("dragover", (event) => {
        if (!Number.isInteger(state.dragPackIndex)) return;
        event.preventDefault();
        const bounds = section.getBoundingClientRect();
        const before = event.clientY < bounds.top + bounds.height / 2;
        clearDeckDropIndicators();
        section.classList.toggle("pack-drag-before", before);
        section.classList.toggle("pack-drag-after", !before);
        section.dataset.dropPosition = before ? "before" : "after";
      });
      section.addEventListener("drop", (event) => {
        if (!Number.isInteger(state.dragPackIndex)) return;
        event.preventDefault();
        event.stopPropagation();
        movePack(state.dragPackIndex, Number(section.dataset.packIndex), section.dataset.dropPosition === "after");
      });
    });

    $$(".deck-tile", list).forEach((tile) => {
      const dragSurface = $(".deck-cover", tile);
      dragSurface.addEventListener("dragstart", (event) => {
        state.dragDeckIndex = { packId: tile.dataset.packId, index: Number(tile.dataset.deckIndex) };
        event.dataTransfer.effectAllowed = "move";
        event.dataTransfer.setData("text/plain", tile.dataset.deckId);
        tile.classList.add("dragging");
        document.body.classList.add("deck-dragging");
      });
      dragSurface.addEventListener("dragend", finishDeckDrag);
      tile.addEventListener("dragover", (event) => {
        event.preventDefault();
        event.stopPropagation();
        event.dataTransfer.dropEffect = "move";
        clearDeckDropIndicators();
        const bounds = tile.getBoundingClientRect();
        const nearMiddleRow = Math.abs(event.clientY - (bounds.top + bounds.height / 2)) < Math.min(44, bounds.height * .18);
        const isBefore = nearMiddleRow
          ? event.clientX < bounds.left + bounds.width / 2
          : event.clientY < bounds.top + bounds.height / 2;
        tile.classList.toggle("drag-before", isBefore);
        tile.classList.toggle("drag-after", !isBefore);
        tile.dataset.dropPosition = isBefore ? "before" : "after";
      });
      tile.addEventListener("drop", (event) => {
        event.preventDefault();
        event.stopPropagation();
        moveDraggedDeck(tile.dataset.packId, Number(tile.dataset.deckIndex), tile.dataset.dropPosition === "after");
      });
      tile.addEventListener("click", (event) => {
        const action = event.target.closest("[data-action]")?.dataset.action;
        if (!action) return;
        const packId = tile.dataset.packId;
        const index = Number(tile.dataset.deckIndex);
        const pack = packById(packId);
        if (action === "edit") openDeckDialog(packId, index);
        if (action === "duplicate") duplicateDeck(packId, index);
        if (action === "remove") removeDeck(packId, index);
        if (action === "up" && index > 0) moveDeck(packId, index, index - 1);
        if (action === "down" && index < pack.decks.length - 1) moveDeck(packId, index, index + 1);
        if (action === "cards") {
          state.selectedDeckId = pack.decks[index].id;
          switchTab("cards");
          renderCardDeckSelect();
          renderCards();
        }
      });
    });

    $$(".pack-deck-grid", list).forEach((grid) => {
      grid.addEventListener("dragover", (event) => {
        if (!state.dragDeckIndex || event.target.closest(".deck-tile")) return;
        event.preventDefault();
        grid.classList.add("pack-drop-target");
      });
      grid.addEventListener("dragleave", () => grid.classList.remove("pack-drop-target"));
      grid.addEventListener("drop", (event) => {
        if (event.target.closest(".deck-tile")) return;
        event.preventDefault();
        moveDraggedDeck(grid.dataset.packDrop, packById(grid.dataset.packDrop).decks.length, false);
      });
    });
  }

  function renderDeckTile(pack, deck, index) {
    const preview = previewForCover(deck.coverImage);
    const image = preview
      ? `<img src="${escapeHtml(preview)}" alt="${escapeHtml(deck.title)} cover">`
      : `<span class="cover-placeholder">${deck.coverImage ? "Missing image" : "No cover assigned"}</span>`;
    const accessLabel = deck.access === "paid"
      ? `Paid${deck.price === undefined ? "" : ` · ${formatDeckPrice(deck.price)}`}`
      : "Free";
    return `
        <article class="deck-tile" data-pack-id="${escapeHtml(pack.id)}" data-deck-index="${index}" data-deck-id="${escapeHtml(deck.id)}">
          <div class="deck-cover" draggable="true">
            ${image}
            <span class="drag-handle" title="Drag to reorder">↕ Drag</span>
            <span class="deck-order">${index + 1}</span>
          </div>
          <div class="deck-info">
            <h3>${escapeHtml(deck.title)}</h3>
            <p>${escapeHtml(deck.description || "No description")}</p>
            <div class="deck-meta">
              <span class="access-badge ${deck.access === "paid" ? "paid" : ""}">${escapeHtml(accessLabel)}</span>
              <span>${deck.cards?.length || 0} card${deck.cards?.length === 1 ? "" : "s"}</span>
              <span>v${escapeHtml(deck.version)}</span>
              <span>${escapeHtml(deck.id)}</span>
            </div>
          </div>
          <div class="deck-actions">
            <button type="button" class="mini-button" data-action="cards">Cards</button>
            <button type="button" class="mini-button" data-action="edit">Edit</button>
            <button type="button" class="mini-button" data-action="up" ${index === 0 ? "disabled" : ""}>Move up</button>
            <button type="button" class="mini-button" data-action="down" ${index === pack.decks.length - 1 ? "disabled" : ""}>Move down</button>
            <button type="button" class="mini-button" data-action="duplicate">Duplicate</button>
            <button type="button" class="mini-button danger" data-action="remove">Remove</button>
          </div>
        </article>`;
  }

  function normalizeDeckOrders() {
    allDecks().forEach((deck, index) => {
      deck.order = index + 1;
    });
  }

  function moveDeck(from, to) {
    if (to < 0 || to >= allDecks().length) return;
    const [moved] = state.catalog.decks.splice(from, 1);
    state.catalog.decks.splice(to, 0, moved);
    normalizeDeckOrders();
    setDirty();
    renderAll();
  }

  function moveLegacyPack(from, target, after = false) {
    if (from <= 0 || from === target && !after) return finishDeckDrag();
    const packs = catalogPacks();
    let insertion = target + (after ? 1 : 0);
    const [moved] = packs.splice(from, 1);
    if (from < insertion) insertion--;
    insertion = Math.max(1, Math.min(insertion, packs.length));
    packs.splice(insertion, 0, moved);
    normalizePackOrders();
    setDirty();
    finishDeckDrag();
    renderAll();
  }

  function moveLegacyDraggedDeck(targetPackId, targetIndex, after) {
    const source = state.dragDeckIndex;
    if (!source) return;
    const sourcePack = packById(source.packId);
    const targetPack = packById(targetPackId);
    if (!sourcePack || !targetPack) return finishDeckDrag();
    let insertion = targetIndex + (after ? 1 : 0);
    const [moved] = sourcePack.decks.splice(source.index, 1);
    if (sourcePack === targetPack && source.index < insertion) insertion--;
    targetPack.decks.splice(Math.max(0, Math.min(insertion, targetPack.decks.length)), 0, moved);
    normalizeDeckOrders(sourcePack);
    normalizeDeckOrders(targetPack);
    setDirty();
    finishDeckDrag();
    renderAll();
  }

  function uniqueDeckId(base) {
    const clean = slugify(base, "new-deck");
    const used = new Set(allDecks().map((deck) => deck.id.toLowerCase()));
    let candidate = clean;
    let suffix = 2;
    while (used.has(candidate.toLowerCase())) candidate = `${clean}-${suffix++}`;
    return candidate;
  }

  function deckFormRecord() {
    const index = Number($("#deck-form").elements.index.value);
    return index >= 0 ? allDecks()[index] : null;
  }

  function imageNameIsTaken(filename, allowedFilename = "") {
    const key = String(filename || "").toLowerCase();
    const allowed = String(allowedFilename || "").toLowerCase();
    if (!key || key === allowed) return false;
    return state.images.some((image) => image.filename.toLowerCase() === key)
      || state.pendingImageOps.some((operation) =>
        String(operation.to || operation.filename || "").toLowerCase() === key
      );
  }

  function updateDeckDerivedValidity() {
    const form = $("#deck-form");
    const existing = deckFormRecord();
    const id = form.elements.id.value.trim().toLowerCase();
    const filename = form.elements.coverImage.value.trim().toLowerCase();
    const oldCover = basename(existing?.coverImage).toLowerCase();
    const duplicateId = Boolean(id) && allDecks().some((deck) =>
      deck !== existing && deck.id.toLowerCase() === id
    );
    const assignedCover = Boolean(filename) && allDecks().some((deck) =>
      deck !== existing && basename(deck.coverImage).toLowerCase() === filename
    );
    const invalidCoverFilename = Boolean(filename) && !/^[a-z0-9][a-z0-9_-]*\.webp$/.test(filename);
    form.elements.id.setCustomValidity(duplicateId ? "This deck ID is already in use." : "");
    form.elements.coverImage.setCustomValidity(
      invalidCoverFilename
        ? "Cover filenames must end in .webp and use only lowercase letters, numbers, hyphens, or underscores."
        : assignedCover || imageNameIsTaken(filename, oldCover)
        ? "This WebP filename is already in use."
        : "",
    );
  }

  function syncDeckFieldsFromTitle() {
    const form = $("#deck-form");
    const slug = slugify(form.elements.title.value);
    form.elements.id.value = slug;
    form.elements.coverImage.value = slug ? `${slug}.webp` : "";
    if (!form.elements.coverUpload.files?.[0]) refreshDeckCoverPreview();
    updateDeckDerivedValidity();
    updateSuggestedAppleProductId(form, "deck");
  }

  function suggestedAppleProductId(targetType, targetId) {
    const storeTargetId = targetId.replaceAll("_", "__").replaceAll("-", "_");
    return targetId ? `com.cadelawless.whatzit.${targetType}.${storeTargetId}` : "";
  }

  function updateSuggestedAppleProductId(form, targetType) {
    form.elements.appleProductId.value = suggestedAppleProductId(
      targetType,
      form.elements.id.value.trim(),
    );
  }

  function renderAppleBundleScenarios() {
    const form = $("#bundle-form");
    const bundle = bundleFormRecord();
    const deckCount = Array.isArray(bundle?.deckIds) ? bundle.deckIds.length : 0;
    const scenarios = FS.appleBundleScenarioProducts(form.elements.id.value, deckCount);
    const list = $("#apple-bundle-scenarios-list");
    const summary = $("#apple-bundle-scenarios-summary");
    $("#copy-all-apple-bundle-products").disabled = scenarios.length === 0;
    summary.textContent = deckCount > 0
      ? `${deckCount} deck${deckCount === 1 ? "" : "s"}: full price plus ${Math.max(0, deckCount - 1)} discount scenario${deckCount === 2 ? "" : "s"}.`
      : "Add decks to generate discount scenarios; the full-price ID is shown now.";
    list.innerHTML = scenarios.map(({ ownedDeckCount, productId }) => `
      <div class="apple-bundle-scenario">
        <span><strong>${ownedDeckCount === 0 ? "Full price" : `Owns ${ownedDeckCount} of ${deckCount}`}</strong><code>${escapeHtml(productId)}</code></span>
        <button type="button" class="mini-button" data-copy-apple-product="${escapeHtml(productId)}">Copy</button>
      </div>
    `).join("");
  }

  async function copyPlainText(value, successMessage) {
    try {
      await navigator.clipboard.writeText(value);
      notice(successMessage, "success");
    } catch {
      const fallback = document.createElement("textarea");
      fallback.value = value;
      fallback.setAttribute("readonly", "");
      fallback.style.position = "fixed";
      fallback.style.opacity = "0";
      document.body.append(fallback);
      fallback.select();
      const copied = document.execCommand("copy");
      fallback.remove();
      notice(copied ? successMessage : "Could not access the clipboard. Copy the product ID manually.", copied ? "success" : "error");
    }
  }

  function updateDeckPriceField() {
    const form = $("#deck-form");
    const paid = form.elements.access.value === "paid";
    $("#deck-price-field").hidden = !paid;
    $("#deck-apple-product-field").hidden = !paid;
    if (!paid) form.elements.price.value = "";
  }

  function updateDeckCoverPreview(value = "") {
    const preview = $("#deck-cover-preview");
    const url = previewForCover(value);
    preview.innerHTML = url
      ? `<img src="${escapeHtml(url)}" alt="Selected deck cover preview">`
      : `<span>${value ? "Cover preview unavailable" : "No cover selected"}</span>`;
  }

  function refreshDeckCoverPreview() {
    // The filename input renames an existing cover on save; it is not an image picker.
    // Keep showing the current cover while the user types its next filename.
    updateDeckCoverPreview(deckFormRecord()?.coverImage || "");
  }

  function openDeckDialog(index = -1, defaultAccess = "paid") {
    const form = $("#deck-form");
    const deck = index >= 0 ? allDecks()[index] : {
      id: uniqueDeckId("new-deck"),
      title: "",
      description: "",
      version: 1,
      coverImage: "",
      tags: [],
      access: defaultAccess,
      price: 1.99,
      cards: [],
    };
    form.elements.index.value = index;
    form.elements.coverUpload.value = "";
    form.elements.title.value = deck.title;
    form.elements.description.value = deck.description || "";
    form.elements.version.value = deck.version || 1;
    form.elements.id.value = deck.id;
    form.elements.tags.value = (deck.tags || []).join(", ");
    form.elements.access.value = deck.access || "free";
    form.elements.price.value = deck.price ?? "";
    form.elements.appleProductStatus.value = deck.storeProducts?.apple?.status ?? "";
    updateSuggestedAppleProductId(form, "deck");
    updateDeckPriceField();
    setCoverFilename(form.elements.coverImage, deck.coverImage);
    updateDeckCoverPreview(deck.coverImage);
    $("#deck-cover-drop-zone span").textContent = "or click to choose one";
    $("#deck-dialog-title").textContent = index >= 0 ? "Edit deck" : "Add deck";
    updateDeckDerivedValidity();
    dialogs.deck.showModal();
  }

  function uniqueBundleId(base) {
    const clean = slugify(base, "new-bundle");
    const used = new Set(catalogBundles().map((bundle) => bundle.id.toLowerCase()));
    let candidate = clean;
    let suffix = 2;
    while (used.has(candidate.toLowerCase())) candidate = `${clean}-${suffix++}`;
    return candidate;
  }

  function bundleFormRecord() {
    return bundleById($("#bundle-form").elements.originalId.value);
  }

  function updateBundleDerivedValidity() {
    const form = $("#bundle-form");
    const existing = bundleFormRecord();
    const id = form.elements.id.value.trim().toLowerCase();
    const duplicate = Boolean(id) && catalogBundles().some((bundle) =>
      bundle !== existing && bundle.id.toLowerCase() === id
    );
    form.elements.id.setCustomValidity(duplicate ? "This bundle ID is already in use." : "");
  }

  function syncBundleIdFromTitle() {
    const form = $("#bundle-form");
    if (form.elements.originalId.value === "free-bundle") return;
    form.elements.id.value = slugify(form.elements.title.value);
    updateBundleDerivedValidity();
    updateSuggestedAppleProductId(form, "bundle");
    renderAppleBundleScenarios();
  }

  function updateBundlePriceField() {
    const form = $("#bundle-form");
    const paid = form.elements.access.value === "paid";
    $("#bundle-price-field").hidden = !paid;
    $("#bundle-apple-product-field").hidden = !paid;
    if (!paid) form.elements.price.value = "";
    renderAppleBundleScenarios();
  }

  function openBundleDialog(bundleId = "") {
    const form = $("#bundle-form");
    const bundle = bundleById(bundleId) || {
      id: uniqueBundleId("new-bundle"),
      order: catalogBundles().length + 1,
      title: "",
      description: "",
      access: "free",
      deckIds: [],
    };
    const isRequiredFreeBundle = bundle.id === "free-bundle";
    form.elements.originalId.value = bundleId;
    form.elements.id.value = bundle.id;
    form.elements.id.readOnly = isRequiredFreeBundle;
    form.elements.id.title = isRequiredFreeBundle ? "The mobile app requires this stable ID." : "";
    form.elements.title.value = bundle.title;
    form.elements.description.value = bundle.description || "";
    form.elements.access.value = bundle.access || "free";
    form.elements.access.disabled = isRequiredFreeBundle;
    form.elements.access.title = isRequiredFreeBundle ? "Free Bundle access must remain free." : "";
    form.elements.price.value = bundle.price ?? "";
    form.elements.appleProductStatus.value = bundle.storeProducts?.apple?.status ?? "";
    updateSuggestedAppleProductId(form, "bundle");
    renderAppleBundleScenarios();
    updateBundlePriceField();
    updateBundleDerivedValidity();
    $("#bundle-dialog-title").textContent = bundleId ? "Edit bundle" : "Add bundle";
    dialogs.bundle.showModal();
  }

  async function removeLegacyPack(packId) {
    const index = catalogPacks().findIndex((pack) => pack.id === packId);
    const pack = catalogPacks()[index];
    if (!pack || pack.id === "free-pack") return;
    const detail = pack.decks.length
      ? ` This also removes its ${pack.decks.length} deck${pack.decks.length === 1 ? "" : "s"} and all of their cards from the unsaved catalog.`
      : "";
    if (!(await confirmAction("Remove this bundle?", `Remove “${pack.title}” from the unsaved catalog?${detail} Cover image files will not be deleted.`))) return;
    const [removed] = state.catalog.packs.splice(index, 1);
    normalizePackOrders();
    if (removed.decks.some((deck) => deck.id === state.selectedDeckId)) state.selectedDeckId = allDecks()[0]?.id || null;
    state.collapsedPacks.delete(removed.id);
    setDirty();
    renderAll();
    notice(`Removed “${removed.title}” from the unsaved catalog.`, "warning", [], [{
      label: "Undo removal",
      handler: (item) => {
        state.catalog.packs.splice(index, 0, removed);
        normalizePackOrders();
        setDirty();
        renderAll();
        item.remove();
      },
    }]);
  }

  async function removeBundle(bundleId) {
    const index = catalogBundles().findIndex((bundle) => bundle.id === bundleId);
    const bundle = catalogBundles()[index];
    if (!bundle) return;
    if (bundle.id === "free-bundle") {
      notice("Free Bundle is required by the mobile app and cannot be removed.", "error");
      return;
    }
    if (!(await confirmAction("Remove this bundle?", `Remove “${bundle.title}” from the unsaved catalog? Its decks remain in the deck library.`))) return;
    const [removed] = state.catalog.bundles.splice(index, 1);
    normalizeBundleOrders();
    syncDeckOrders();
    setDirty();
    renderAll();
    notice(`Removed “${removed.title}” from the unsaved catalog.`, "warning", [], [{
      label: "Undo removal",
      handler: (item) => {
        state.catalog.bundles.splice(index, 0, removed);
        normalizeBundleOrders();
        syncDeckOrders();
        setDirty();
        renderAll();
        item.remove();
      },
    }]);
  }

  function setCoverFilename(input, selected) {
    input.value = basename(selected);
  }

  function pruneUnreferencedStagedCovers() {
    state.pendingImageOps = state.pendingImageOps.filter((operation) => {
      if (operation.type !== "add") return true;
      const relativePath = `assets/images/decks/${operation.filename}`.toLowerCase();
      const referenced = allDecks().some((deck) => String(deck.coverImage || "").toLowerCase() === relativePath);
      if (!referenced && operation.previewUrl) URL.revokeObjectURL(operation.previewUrl);
      return referenced;
    });
  }

  function cleanupRemovedDeckCover(deck) {
    const cleanup = FS.planDeckCoverCleanup(
      deck.coverImage,
      allDecks().map((item) => item.coverImage),
      state.images,
      state.pendingImageOps,
    );
    state.pendingImageOps = cleanup.operations;
    return cleanup;
  }

  function undoDeckCoverCleanup(cleanup) {
    if (!cleanup) return;
    if (cleanup.addedOperation) {
      state.pendingImageOps = state.pendingImageOps.filter((operation) => operation !== cleanup.addedOperation);
    }
    cleanup.removedOperations.forEach(({ operation, index }) => {
      if (!state.pendingImageOps.includes(operation)) {
        state.pendingImageOps.splice(Math.min(index, state.pendingImageOps.length), 0, operation);
      }
    });
  }

  function stageDeckCoverRename(oldFilename, newFilename) {
    if (!oldFilename || oldFilename.toLowerCase() === newFilename.toLowerCase()) return true;
    const stagedAdd = state.pendingImageOps.find((operation) =>
      operation.type === "add" && operation.filename.toLowerCase() === oldFilename.toLowerCase()
    );
    if (stagedAdd) {
      stagedAdd.filename = newFilename;
      if (stagedAdd.file instanceof Blob) {
        stagedAdd.file = new File([stagedAdd.file], newFilename, {
          type: "image/webp",
          lastModified: Date.now(),
        });
      }
      return true;
    }
    const published = state.images.find((image) => image.filename.toLowerCase() === oldFilename.toLowerCase());
    if (!published) return false;
    const pendingReplacement = state.pendingImageOps.find((operation) =>
      operation.type === "replace" && operation.filename.toLowerCase() === oldFilename.toLowerCase()
    );
    if (pendingReplacement) {
      pendingReplacement.type = "add";
      pendingReplacement.filename = newFilename;
      delete pendingReplacement.expectedHash;
      state.pendingImageOps.push({
        type: "remove",
        filename: published.filename,
        expectedHash: published.hash,
      });
      return true;
    }
    state.pendingImageOps.push({
      type: "rename",
      from: published.filename,
      to: newFilename,
      expectedHash: published.hash,
    });
    return true;
  }

  async function duplicateLegacyDeck(packId, index) {
    const pack = packById(packId);
    const source = pack.decks[index];
    const copy = clone(source);
    copy.id = uniqueDeckId(`${source.id}-copy`);
    copy.title = `${source.title} Copy`;
    copy.cards = copy.cards.map((card) => ({ ...card, id: uniqueCardId(copy, `${card.id}-copy`) }));
    pack.decks.splice(index + 1, 0, copy);
    normalizeDeckOrders(pack);
    setDirty();
    renderAll();
    notice(`Duplicated “${source.title}” with new stable IDs.`, "success");
  }

  async function removeLegacyDeck(packId, index) {
    const pack = packById(packId);
    const deck = pack.decks[index];
    if (!(await confirmAction("Remove this deck?", `Remove “${deck.title}” from the unsaved catalog? Its unreferenced cover image will also be removed when you publish.`))) return;
    const [removed] = pack.decks.splice(index, 1);
    const coverCleanup = cleanupRemovedDeckCover(removed);
    normalizeDeckOrders(pack);
    if (state.selectedDeckId === removed.id) state.selectedDeckId = allDecks()[0]?.id || null;
    setDirty();
    renderAll();
    notice(`Removed “${removed.title}” from the unsaved catalog.`, "warning", [], [{
      label: "Undo removal",
      handler: (item) => {
        pack.decks.splice(index, 0, removed);
        undoDeckCoverCleanup(coverCleanup);
        normalizeDeckOrders(pack);
        setDirty();
        renderAll();
        item.remove();
      },
    }]);
  }

  function duplicateDeck(index) {
    const source = allDecks()[index];
    const copy = clone(source);
    copy.id = uniqueDeckId(`${source.id}-copy`);
    copy.title = `${source.title} Copy`;
    copy.cards = copy.cards.map((card) => ({ ...card, id: uniqueCardId(copy, `${card.id}-copy`) }));
    state.catalog.decks.splice(index + 1, 0, copy);
    normalizeDeckOrders();
    syncDeckOrders();
    setDirty();
    renderAll();
    notice(`Duplicated “${source.title}” with new stable IDs.`, "success");
  }

  async function removeDeck(index) {
    const deck = allDecks()[index];
    if (!(await confirmAction("Remove this deck?", `Remove “${deck.title}” from the unsaved catalog and every bundle? Its unreferenced cover image will also be removed when you publish.`))) return;
    const removedOrderPositions = Object.fromEntries(Object.entries(state.catalog.deckOrders || {})
      .map(([scope, order]) => [scope, order.indexOf(deck.id)]));
    const [removed] = state.catalog.decks.splice(index, 1);
    const memberships = catalogBundles()
      .filter((bundle) => bundle.deckIds.includes(removed.id))
      .map((bundle) => ({ bundleId: bundle.id, index: bundle.deckIds.indexOf(removed.id) }));
    catalogBundles().forEach((bundle) => { bundle.deckIds = bundle.deckIds.filter((id) => id !== removed.id); });
    const coverCleanup = cleanupRemovedDeckCover(removed);
    normalizeDeckOrders();
    syncDeckOrders();
    if (state.selectedDeckId === removed.id) state.selectedDeckId = allDecks()[0]?.id || null;
    setDirty();
    renderAll();
    notice(`Removed “${removed.title}” from the unsaved catalog.`, "warning", [], [{
      label: "Undo removal",
      handler: (item) => {
        state.catalog.decks.splice(index, 0, removed);
        memberships.forEach(({ bundleId, index: membershipIndex }) => {
          const bundle = bundleById(bundleId);
          if (bundle) bundle.deckIds.splice(Math.min(membershipIndex, bundle.deckIds.length), 0, removed.id);
        });
        undoDeckCoverCleanup(coverCleanup);
        normalizeDeckOrders();
        syncDeckOrders();
        Object.entries(removedOrderPositions).forEach(([scope, orderIndex]) => {
          const order = state.catalog.deckOrders[scope];
          if (!Array.isArray(order) || orderIndex < 0 || !order.includes(removed.id)) return;
          state.catalog.deckOrders[scope] = order.filter((id) => id !== removed.id);
          state.catalog.deckOrders[scope].splice(Math.min(orderIndex, state.catalog.deckOrders[scope].length), 0, removed.id);
        });
        setDirty();
        renderAll();
        item.remove();
      },
    }]);
  }

  function renderCardDeckSelect() {
    const decks = [...allDecks()].reverse();
    if (state.selectedDeckId && decks.some((deck) => deck.id === state.selectedDeckId)) {
    } else {
      state.selectedDeckId = decks[0]?.id || null;
    }
    renderCardDeckPickerResults();
    $("#cards-heading").textContent = selectedDeck()?.title || "Choose a deck";
  }

  function cardPickerDecks() {
    const query = $("#card-deck-picker-search").value.trim().toLocaleLowerCase();
    return [...allDecks()].reverse().filter((deck) => !query || [deck.title, deck.id, ...(deck.tags || [])]
      .some((value) => String(value || "").toLocaleLowerCase().includes(query)));
  }

  function renderCardDeckPickerResults() {
    const results = $("#card-deck-picker-results");
    const trigger = $("#card-deck-picker-trigger");
    const deck = selectedDeck();
    trigger.textContent = deck ? `${deck.title} (${deck.cards?.length || 0})` : "Choose a deck";
    trigger.setAttribute("aria-label", deck ? `Deck to edit: ${deck.title}` : "Choose a deck to edit");
    const decks = cardPickerDecks();
    results.innerHTML = decks.length ? decks.map((item) => {
      const preview = previewForCover(item.coverImage);
      const selected = item.id === state.selectedDeckId;
      return `<button type="button" class="card-deck-picker-option" role="option" aria-selected="${selected}" data-card-deck-id="${escapeHtml(item.id)}">
        <span class="card-deck-picker-cover">${preview ? `<img src="${escapeHtml(preview)}" alt="">` : ""}</span>
        <span class="card-deck-picker-copy"><strong>${escapeHtml(item.title)}</strong><small>${item.cards?.length || 0} card${item.cards?.length === 1 ? "" : "s"}</small></span>
      </button>`;
    }).join("") : '<div class="card-deck-picker-empty">No matching decks.</div>';
    $$('[data-card-deck-id]', results).forEach((option) => option.addEventListener("click", () => {
      state.selectedDeckId = option.dataset.cardDeckId;
      closeCardDeckPicker();
      renderCards();
      renderCardDeckPickerResults();
    }));
  }

  function closeCardDeckPicker() {
    $("#card-deck-picker-popup").hidden = true;
    $("#card-deck-picker-trigger").setAttribute("aria-expanded", "false");
  }

  function toggleCardDeckPicker() {
    const popup = $("#card-deck-picker-popup");
    const opening = popup.hidden;
    popup.hidden = !opening;
    $("#card-deck-picker-trigger").setAttribute("aria-expanded", String(opening));
    if (opening) {
      renderCardDeckPickerResults();
      $("#card-deck-picker-search").focus();
    }
  }

  function duplicateTextWarnings(deck) {
    return duplicateCardGroups(deck).map((group) => group.text);
  }

  function duplicateCardGroups(deck) {
    const groups = new Map();
    (deck?.cards || []).forEach((card, index) => {
      const text = String(card.text || "").trim();
      if (!text) return;
      const key = text.toLocaleLowerCase();
      const group = groups.get(key) || { text, cards: [] };
      group.cards.push({ card, index });
      groups.set(key, group);
    });
    return Array.from(groups.values()).filter((group) => group.cards.length > 1);
  }

  function duplicateGroupKey(group) {
    return String(group?.text || "").trim().toLocaleLowerCase();
  }

  function duplicateDeckSignature(deck) {
    return (deck?.cards || [])
      .map((card) => `${String(card.id || "")}\u0000${String(card.text || "").trim().toLocaleLowerCase()}\u0000${String(card.byline || "").trim().toLocaleLowerCase()}`)
      .join("\u0001");
  }

  function renderDuplicateReviewDialog() {
    const deck = selectedDeck();
    const groups = duplicateCardGroups(deck).filter((group) => !state.dismissedDuplicateGroups.has(duplicateGroupKey(group)));
    const list = $("#duplicates-list");
    const summary = $("#duplicates-summary");
    if (!deck) {
      $("#duplicates-title").textContent = "Review duplicates";
      summary.textContent = "Choose a deck first.";
      list.replaceChildren();
      return;
    }

    $("#duplicates-title").textContent = `Review duplicates in ${deck.title}`;
    summary.textContent = groups.length
      ? `${groups.length} duplicate text group${groups.length === 1 ? "" : "s"} found. Delete any extra cards, or keep the ones you want.`
      : "No duplicate card text found in this deck.";

    if (!groups.length) {
      list.innerHTML = '<div class="empty-state"><div><strong>No duplicates found</strong><p>This deck is clean right now.</p></div></div>';
      return;
    }

    list.innerHTML = groups.map((group, groupIndex) => `
      <section class="duplicate-group" data-duplicate-group="${groupIndex}">
        <header>
          <div>
            <strong>${escapeHtml(group.text)}</strong>
            <small>${group.cards.length} matching cards</small>
          </div>
          <button type="button" class="button subtle duplicate-keep-all" data-duplicate-action="keep-all" data-duplicate-key="${escapeHtml(duplicateGroupKey(group))}">Keep All</button>
        </header>
        <div class="duplicate-card-list">
          ${group.cards.map(({ card, index }, cardIndex) => `
            <article class="duplicate-card-row" data-card-index="${index}">
              <div class="card-copy">
                <strong>${escapeHtml(card.text)}</strong>
                ${card.byline ? `<small>${escapeHtml(card.byline)}</small>` : ""}
              </div>
              <span class="card-id">${escapeHtml(card.id)}</span>
              <div class="card-row-actions">
                <button type="button" class="mini-button danger duplicate-delete" data-duplicate-action="delete" data-card-index="${index}"><span aria-hidden="true">&#215;</span><span> Delete</span></button>
              </div>
            </article>
          `).join("")}
        </div>
      </section>
    `).join("");

    $$("[data-duplicate-action]", list).forEach((button) => {
      button.addEventListener("click", async (event) => {
        event.preventDefault();
        const action = button.dataset.duplicateAction;
        const index = Number(button.dataset.cardIndex);
        if (action === "keep-all") {
          state.dismissedDuplicateGroups.add(button.dataset.duplicateKey || "");
          renderCards();
          renderDuplicateReviewDialog();
          return;
        }
        if (!(await confirmAction("Delete this duplicate card?", "This will remove the selected duplicate from the unsaved deck."))) return;
        await removeCard(index, { skipConfirmation: true });
        renderDuplicateReviewDialog();
      });
    });
  }

  function renderCards() {
    const list = $("#card-list");
    const deck = selectedDeck();
    if (state.selectedCardDeckId !== deck?.id) {
      state.selectedCardIds.clear();
      state.selectedCardDeckId = deck?.id || null;
    }
    $("#cards-heading").textContent = deck?.title || "Choose a deck";
    $("#add-card").disabled = !deck;
    $("#bulk-import").disabled = !deck;
    if (!deck) {
      renderFeaturedCards();
      list.className = "card-list empty-state";
      list.innerHTML = "<div><strong>No deck selected</strong><p>Open a deck from the deck grid or select one above.</p></div>";
      $("#duplicate-warning").hidden = true;
      state.dismissedDuplicateGroups.clear();
      state.duplicateDeckSignature = "";
      renderCardBulkActions(null);
      return;
    }

    const query = $("#card-search").value.trim().toLocaleLowerCase();
    renderFeaturedCards(!query);

    const signature = duplicateDeckSignature(deck);
    if (state.duplicateDeckSignature !== signature) {
      state.duplicateDeckSignature = signature;
      state.dismissedDuplicateGroups.clear();
    }
    const activeGroupKeys = new Set(duplicateCardGroups(deck).map((group) => duplicateGroupKey(group)));
    state.dismissedDuplicateGroups = new Set([...state.dismissedDuplicateGroups].filter((key) => activeGroupKeys.has(key)));
    const visibleDuplicateGroups = duplicateCardGroups(deck).filter((group) => !state.dismissedDuplicateGroups.has(duplicateGroupKey(group)));
    const warning = $("#duplicate-warning");
    warning.hidden = visibleDuplicateGroups.length === 0;
    warning.innerHTML = visibleDuplicateGroups.length
      ? `<span>Duplicate card text: ${visibleDuplicateGroups.map((group) => group.text).join(", ")}</span><button type="button" class="button subtle" id="see-duplicates">See Duplicates</button>`
      : "";

    const cards = deck.cards.map((card, index) => ({ card, index })).filter(({ card }) => {
      return !query || card.text.toLocaleLowerCase().includes(query) || String(card.byline || "").toLocaleLowerCase().includes(query);
    });
    renderCardBulkActions(deck);
    if (!cards.length) {
      list.className = "card-list empty-state";
      list.innerHTML = `<div><strong>${deck.cards.length ? "No matching cards" : "This deck has no cards"}</strong><p>${deck.cards.length ? "Try another search." : "Add a card or use bulk import."}</p></div>`;
      return;
    }

    list.className = "card-list";
    list.innerHTML = cards.map(({ card, index }) => `
      <article class="card-row" data-card-index="${index}">
        <label class="card-select"><input type="checkbox" data-card-select="${escapeHtml(card.id)}" aria-label="Select ${escapeHtml(card.id)}" ${state.selectedCardIds.has(card.id) ? "checked" : ""}></label>
        <div class="card-copy"><strong>${escapeHtml(card.text)}</strong>${card.byline ? `<small>${escapeHtml(card.byline)}</small>` : ""}${Number.isInteger(card.featuredOrder) ? `<span class="featured-badge">Featured #${card.featuredOrder}</span>` : ""}</div>
        <span class="card-id">${escapeHtml(card.id)}</span>
        <div class="card-row-actions">
          ${Number.isInteger(card.featuredOrder)
            ? `<button type="button" class="mini-button" disabled title="Already featured">Featured</button>`
            : `<button type="button" class="mini-button" data-card-action="feature" aria-label="Add ${escapeHtml(card.id)} to featured cards" title="Add to Featured">Add to Featured</button>`}
          <button type="button" class="mini-button icon-button" data-card-action="edit" aria-label="Edit card ${escapeHtml(card.id)}" title="Edit card">&#9998;</button>
          <button type="button" class="mini-button icon-button danger" data-card-action="remove" aria-label="Remove card ${escapeHtml(card.id)}" title="Remove card">&#215;</button>
        </div>
      </article>`).join("");

    $$(".card-row", list).forEach((row) => {
      row.addEventListener("click", (event) => {
        const action = event.target.closest("[data-card-action]")?.dataset.cardAction;
        if (!action) return;
        const index = Number(row.dataset.cardIndex);
        if (action === "feature") featureCard(index);
        if (action === "edit") openCardDialog(index);
        if (action === "remove") removeCard(index);
      });
    });
    $$('[data-card-select]', list).forEach((input) => {
      input.addEventListener("change", () => {
        if (input.checked) state.selectedCardIds.add(input.dataset.cardSelect);
        else state.selectedCardIds.delete(input.dataset.cardSelect);
        renderCardBulkActions(deck);
      });
    });
    $("#see-duplicates")?.addEventListener("click", () => {
      renderDuplicateReviewDialog();
      dialogs.duplicates.showModal();
    });
  }

  function uniqueCardId(deck, base) {
    const clean = slugify(base, "card");
    const used = new Set((deck.cards || []).map((card) => card.id.toLowerCase()));
    let candidate = clean.slice(0, 80);
    let suffix = 2;
    while (used.has(candidate.toLowerCase())) candidate = `${clean.slice(0, 72)}-${suffix++}`;
    return candidate;
  }

  function openCardDialog(index = -1) {
    const deck = selectedDeck();
    if (!deck) return;
    const form = $("#card-form");
    const card = index >= 0 ? deck.cards[index] : { id: uniqueCardId(deck, `${deck.id}-card`), text: "", byline: "" };
    form.elements.index.value = index;
    form.elements.text.value = card.text;
    form.elements.byline.value = card.byline || "";
    form.elements.featured.checked = Number.isInteger(card.featuredOrder);
    form.elements.featuredOrder.value = Number.isInteger(card.featuredOrder) ? card.featuredOrder : nextFeaturedOrder(deck);
    updateFeaturedOrderField();
    form.elements.id.value = card.id;
    $("#card-dialog-title").textContent = index >= 0 ? "Edit card" : "Add card";
    form.elements.id.setCustomValidity("");
    dialogs.card.showModal();
  }

  function featuredCards(deck = selectedDeck()) {
    return (deck?.cards || [])
      .map((card, index) => ({ card, index }))
      .filter(({ card }) => Number.isInteger(card.featuredOrder))
      .sort((left, right) => left.card.featuredOrder - right.card.featuredOrder);
  }

  function renderFeaturedCards(visible = true) {
    const section = $("#featured-card-section");
    const list = $("#featured-card-list");
    const cards = featuredCards();

    section.hidden = !visible || cards.length === 0;
    if (!visible) {
      list.replaceChildren();
      return;
    }

    list.innerHTML = cards.map(({ card, index }) => `
    <article
      class="featured-card-row"
      data-card-index="${index}"
      draggable="true"
    >
      <button
        type="button"
        class="featured-card-handle"
        aria-label="Drag ${escapeHtml(card.id)} to reorder"
        title="Drag to reorder"
      >↕</button>

      <span class="featured-card-position">
        ${card.featuredOrder}
      </span>

      <div class="card-copy">
        <strong>${escapeHtml(card.text)}</strong>
        ${card.byline ? `<small>${escapeHtml(card.byline)}</small>` : ""}
      </div>

      <span class="card-id">
        ${escapeHtml(card.id)}
      </span>

      <div class="featured-card-actions">
        <button
          type="button"
          class="mini-button danger featured-card-unfeature"
          data-featured-action="unfeature"
          aria-label="Remove ${escapeHtml(card.id)} from featured cards"
          title="Remove from featured cards"
        >Remove from Featured</button>
        <button
          type="button"
          class="mini-button icon-button"
          data-featured-action="edit"
          aria-label="Edit ${escapeHtml(card.id)}"
          title="Edit card"
        >&#9998;</button>
        <button
          type="button"
          class="mini-button icon-button danger"
          data-featured-action="remove"
          aria-label="Delete ${escapeHtml(card.id)}"
          title="Delete card"
        >&#215;</button>
      </div>
    </article>
  `).join("");

    $$(".featured-card-row", list).forEach((row) => {
      const handle = $(".featured-card-handle", row);

      handle.addEventListener("pointerdown", () => {
        state.armedFeaturedCardRow = row;
      });

      row.addEventListener("pointerdown", (event) => {
        if (!event.target.closest(".featured-card-handle")) {
          state.armedFeaturedCardRow = null;
        }
      });

      row.addEventListener("dragstart", (event) => {
        if (state.armedFeaturedCardRow !== row) {
          event.preventDefault();
          return;
        }

        startFeaturedCardDrag(row, event);
      });

      row.addEventListener("dragend", () => {
        finishFeaturedCardDrag();
      });

      $("[data-featured-action='unfeature']", row)?.addEventListener("click", () => {
        const deck = selectedDeck();
        const card = deck?.cards[Number(row.dataset.cardIndex)];
        if (!deck || !card) return;
        delete card.featuredOrder;
        featuredCards(deck).forEach(({ card: featuredCard }, index) => {
          featuredCard.featuredOrder = index + 1;
        });
        setDirty();
        renderCards();
        renderDecks();
        notice(`Removed “${card.text}” from the featured cards.`, "success");
      });
      $("[data-featured-action='edit']", row)?.addEventListener("click", () => {
        openCardDialog(Number(row.dataset.cardIndex));
      });
      $("[data-featured-action='remove']", row)?.addEventListener("click", () => {
        removeCard(Number(row.dataset.cardIndex));
      });
    });

    list.addEventListener("dragover", handleFeaturedCardDragOver);

    list.addEventListener("drop", (event) => {
      if (!state.featuredCardDrag) return;

      event.preventDefault();
      event.stopPropagation();

      commitFeaturedCardDrag();
    });
  }

  function startFeaturedCardDrag(row, event) {
    const list = $("#featured-card-list");
    const bounds = row.getBoundingClientRect();

    const placeholder = document.createElement("div");
    placeholder.className = "featured-card-placeholder";
    placeholder.style.height = `${bounds.height}px`;

    const preview = row.cloneNode(true);

    preview.classList.add("featured-card-drag-preview");
    preview.classList.remove("featured-card-drag-source");
    preview.removeAttribute("draggable");
    preview.removeAttribute("data-card-index");

    const previewHandle = $(".featured-card-handle", preview);

    if (previewHandle) {
      previewHandle.removeAttribute("draggable");
    }

    preview.style.width = `${bounds.width}px`;
    preview.style.height = `${bounds.height}px`;

    document.body.appendChild(preview);

    const offsetX = Math.max(
      0,
      Math.min(bounds.width, event.clientX - bounds.left)
    );

    const offsetY = Math.max(
      0,
      Math.min(bounds.height, event.clientY - bounds.top)
    );

    state.featuredCardDrag = {
      index: Number(row.dataset.cardIndex),
      row,
      placeholder,
      preview,
      list,
      offsetX,
      offsetY,
      lastClientY: event.clientY,
    };

    event.dataTransfer.effectAllowed = "move";

    event.dataTransfer.setData(
      "text/plain",
      String(row.dataset.cardIndex)
    );

    positionFeaturedCardPreview(event);

    document.body.classList.add("featured-card-dragging");

    document.addEventListener(
      "dragover",
      positionFeaturedCardPreview,
      true
    );

    /*
     * IMPORTANT:
     * Wait until the browser has established the native drag before
     * visually replacing the original row.
     *
     * Hiding/removing the native drag source synchronously during
     * dragstart can cause Chrome to immediately cancel the drag.
     */
    requestAnimationFrame(() => {
      const drag = state.featuredCardDrag;

      if (!drag || drag.row !== row) {
        return;
      }

      row.before(placeholder);
      row.classList.add("featured-card-drag-source");
    });
  }

  function positionFeaturedCardPreview(event) {
    const drag = state.featuredCardDrag;

    if (!drag || (!event.clientX && !event.clientY)) {
      return;
    }

    drag.preview.style.left =
      `${event.clientX - drag.offsetX}px`;

    drag.preview.style.top =
      `${event.clientY - drag.offsetY}px`;

    drag.lastClientY = event.clientY;
  }

  function handleFeaturedCardDragOver(event) {
    const drag = state.featuredCardDrag;

    if (!drag) {
      return;
    }

    event.preventDefault();

    event.dataTransfer.dropEffect = "move";

    const list = drag.list;

    const rows = $$(".featured-card-row", list).filter(
      (row) => row !== drag.row
    );

    /*
     * If this is the only featured card, just keep its
     * placeholder inside the list.
     */
    if (!rows.length) {
      if (drag.placeholder.parentElement !== list) {
        list.appendChild(drag.placeholder);
      }

      return;
    }

    /*
     * Record the current locations BEFORE moving the placeholder.
     * We'll use these positions for the FLIP animation.
     */
    const oldPositions = new Map();

    rows.forEach((row) => {
      oldPositions.set(
        row,
        row.getBoundingClientRect()
      );
    });

    let inserted = false;

    /*
     * Find the first row whose midpoint is below the cursor.
     * The placeholder belongs immediately before that row.
     */
    for (const row of rows) {
      const bounds = row.getBoundingClientRect();

      const midpoint =
        bounds.top + bounds.height / 2;

      if (event.clientY < midpoint) {
        /*
         * Avoid touching the DOM repeatedly if the placeholder
         * is already in the correct position.
         */
        if (drag.placeholder.nextElementSibling !== row) {
          row.before(drag.placeholder);
        }

        inserted = true;
        break;
      }
    }

    /*
     * Cursor is below every card, so place the placeholder
     * at the very end.
     */
    if (!inserted) {
      list.appendChild(drag.placeholder);
    }

    animateFeaturedCardRows(
      rows,
      oldPositions
    );
  }

  function animateFeaturedCardRows(
    rows,
    oldPositions
  ) {
    /*
     * Respect the operating system's reduced-motion preference.
     */
    if (
      window.matchMedia?.(
        "(prefers-reduced-motion: reduce)"
      ).matches
    ) {
      return;
    }

    rows.forEach((row) => {
      const oldBounds =
        oldPositions.get(row);

      if (!oldBounds) {
        return;
      }

      const newBounds =
        row.getBoundingClientRect();

      const deltaX =
        oldBounds.left - newBounds.left;

      const deltaY =
        oldBounds.top - newBounds.top;

      if (!deltaX && !deltaY) {
        return;
      }

      /*
       * Cancel any previous movement animation on this row.
       * This keeps rapid dragging smooth instead of stacking
       * animation after animation.
       */
      row
        .getAnimations?.()
        .forEach((animation) => {
          animation.cancel();
        });

      row.animate(
        [
          {
            transform:
              `translate(${deltaX}px, ${deltaY}px)`,
          },
          {
            transform:
              "translate(0, 0)",
          },
        ],
        {
          duration: 180,
          easing:
            "cubic-bezier(.2,.8,.2,1)",
        }
      );
    });
  }

  function commitFeaturedCardDrag() {
    const drag =
      state.featuredCardDrag;

    const deck =
      selectedDeck();

    if (!drag || !deck) {
      finishFeaturedCardDrag();
      return;
    }

    const ordered =
      featuredCards(deck);

    /*
     * Find the featured-card entry corresponding to the
     * original deck.cards index that we started dragging.
     */
    const movedIndex =
      ordered.findIndex(
        ({ index }) =>
          index === drag.index
      );

    if (movedIndex < 0) {
      finishFeaturedCardDrag();
      return;
    }

    /*
     * Remove the dragged card from the current featured order.
     */
    const [moved] =
      ordered.splice(
        movedIndex,
        1
      );

    /*
     * Work out exactly where the placeholder currently sits
     * in the rendered list.
     */
    const siblings =
      Array.from(
        drag.list.children
      );

    const placeholderIndex =
      siblings.indexOf(
        drag.placeholder
      );

    /*
     * Count the real featured rows before the placeholder.
     * The hidden native drag source does NOT count.
     */
    const beforePlaceholder =
      siblings
        .slice(
          0,
          placeholderIndex
        )
        .filter(
          (element) =>
            element.classList.contains(
              "featured-card-row"
            ) &&
            element !== drag.row
        );

    const destinationIndex =
      beforePlaceholder.length;

    /*
     * Put the dragged card at the placeholder position.
     */
    ordered.splice(
      destinationIndex,
      0,
      moved
    );

    /*
     * Normalize featuredOrder back to sequential 1-based
     * positions for storage in the catalog.
     */
    ordered.forEach(
      ({ card }, index) => {
        card.featuredOrder =
          index + 1;
      }
    );

    finishFeaturedCardDrag();

    setDirty();

    renderCards();
    renderDecks();
  }

  function finishFeaturedCardDrag() {
    const drag =
      state.featuredCardDrag;

    document.removeEventListener(
      "dragover",
      positionFeaturedCardPreview,
      true
    );

    document.body.classList.remove(
      "featured-card-dragging"
    );

    state.armedFeaturedCardRow = null;

    if (!drag) {
      return;
    }

    /*
     * Remove our custom floating copy and drop placeholder.
     */
    drag.preview?.remove();
    drag.placeholder?.remove();

    /*
     * Restore the native drag-source row.
     */
    if (drag.row) {
      drag.row.classList.remove(
        "featured-card-drag-source"
      );
    }

    state.featuredCardDrag = null;
  }
  function nextFeaturedOrder(deck) {
    return Math.max(0, ...(deck.cards || []).map((card) => Number.isInteger(card.featuredOrder) ? card.featuredOrder : 0)) + 1;
  }

  function updateFeaturedOrderField() {
    const form = $("#card-form");
    const enabled = form.elements.featured.checked;
    form.elements.featuredOrder.disabled = !enabled;
    $("#featured-order-field").hidden = !enabled;
  }

  function featureCard(index) {
    const deck = selectedDeck();
    const card = deck?.cards[index];
    if (!deck || !card || Number.isInteger(card.featuredOrder)) return;
    card.featuredOrder = nextFeaturedOrder(deck);
    setDirty();
    renderCards();
    renderDecks();
    notice(`Added “${card.text}” to the featured cards.`, "success");
  }

  async function removeCard(index, { skipConfirmation = false } = {}) {
    const deck = selectedDeck();
    if (!deck) return;
    const card = deck.cards[index];
    if (!card) return;
    if (!skipConfirmation && !(await confirmAction(
      "Delete this card?",
      `Delete “${card.text}” from the unsaved deck? You can undo this action before publishing.`,
    ))) return;

    const [removed] = deck.cards.splice(index, 1);
    if (!removed) return;

    syncDeckCardCount(deck);

    setDirty();
    renderCards();
    renderDecks();
    renderCounts();
    renderCardDeckSelect();

    notice(`Removed “${removed.text}” from the unsaved deck.`, "warning", [], [{
      label: "Undo removal",
      handler: (item) => {
        deck.cards.splice(index, 0, removed);
        syncDeckCardCount(deck);

        setDirty();
        renderCards();
        renderDecks();
        renderCounts();
        renderCardDeckSelect();
        item.remove();
      },
    }]);
  }

  function renderCardBulkActions(deck) {
    const actions = $("#card-bulk-actions");
    const count = $("#selected-card-count");
    const selectAll = $("#select-all-cards");
    const copy = $("#copy-selected-cards");
    const remove = $("#remove-selected-cards");
    if (!actions || !count || !selectAll || !copy || !remove) return;

    const availableIds = new Set((deck?.cards || []).map((card) => card.id));
    state.selectedCardIds = new Set([...state.selectedCardIds].filter((id) => availableIds.has(id)));
    const selectedCount = state.selectedCardIds.size;
    actions.hidden = !deck;
    count.textContent = `${selectedCount} selected`;
    selectAll.disabled = !deck?.cards.length;
    selectAll.textContent = selectedCount === deck?.cards.length ? "Clear selection" : "Select all cards";
    copy.disabled = selectedCount === 0;
    remove.disabled = selectedCount === 0;
  }

  async function copySelectedCards() {
    const deck = selectedDeck();
    const selected = (deck?.cards || []).filter((card) => state.selectedCardIds.has(card.id));
    if (!selected.length) return;
    const plainText = selected.map((card) => {
      const text = String(card.text || "").trim();
      const byline = String(card.byline || "").trim();
      return byline ? `${text} | ${byline}` : text;
    }).join("\n");
    const finishCopy = () => {
      state.selectedCardIds.clear();
      renderCards();
      notice(`Copied ${selected.length} card${selected.length === 1 ? "" : "s"} in bulk-import format.`, "success");
    };
    try {
      await navigator.clipboard.writeText(plainText);
      finishCopy();
    } catch {
      const fallback = document.createElement("textarea");
      fallback.value = plainText;
      fallback.setAttribute("readonly", "");
      fallback.style.position = "fixed";
      fallback.style.opacity = "0";
      document.body.append(fallback);
      fallback.select();
      const clipboardCopied = document.execCommand("copy");
      fallback.remove();
      if (clipboardCopied) finishCopy();
      else notice("Could not access the clipboard. Copy the selected cards manually.", "error");
    }
  }

  async function removeSelectedCards() {
    const deck = selectedDeck();
    const selectedIds = new Set(state.selectedCardIds);
    const selected = deck?.cards
      .map((card, index) => ({ card, index }))
      .filter(({ card }) => selectedIds.has(card.id)) || [];
    if (!deck || !selected.length) return;
    if (!(await confirmAction(
      `Delete ${selected.length} card${selected.length === 1 ? "" : "s"}?`,
      "These cards will be removed from the unsaved deck. You can undo this action before publishing.",
    ))) return;

    deck.cards = deck.cards.filter((card) => !selectedIds.has(card.id));
    state.selectedCardIds.clear();
    syncDeckCardCount(deck);
    setDirty();
    renderCards();
    renderDecks();
    renderCounts();
    renderCardDeckSelect();

    notice(`Removed ${selected.length} card${selected.length === 1 ? "" : "s"} from the unsaved deck.`, "warning", [], [{
      label: "Undo removal",
      handler: (item) => {
        selected.forEach(({ card, index }) => deck.cards.splice(index, 0, card));
        syncDeckCardCount(deck);
        setDirty();
        renderCards();
        renderDecks();
        renderCounts();
        renderCardDeckSelect();
        item.remove();
      },
    }]);
  }

  function pendingLabel(operation) {
    if (operation.type === "add") return `Add ${operation.filename}`;
    if (operation.type === "replace") return `Replace ${operation.filename}`;
    if (operation.type === "rename") return `Rename ${operation.from} → ${operation.to}`;
    return `Remove ${operation.filename} in the ${state.storageBackend === "database" ? "database publication" : "GitHub commit"}`;
  }

  function renderImages() {
    $("#image-assign-target").textContent = allDecks().length
      ? "Choose any deck from an image’s dropdown to update that deck’s cover in unsaved editor state."
      : "Add a deck before assigning cover images.";
    const pending = $("#pending-images");
    pending.hidden = state.pendingImageOps.length === 0;
    pending.innerHTML = state.pendingImageOps.length
      ? `<strong>Pending image operations (published with the catalog)</strong><ul>${state.pendingImageOps.map((operation) => `<li>${escapeHtml(pendingLabel(operation))}</li>`).join("")}</ul>`
      : "";
    $("#clear-image-operations").disabled = state.pendingImageOps.length === 0;

    const query = $("#image-search").value.trim().toLocaleLowerCase();
    const removed = new Set(state.pendingImageOps.filter((operation) => operation.type === "remove").map((operation) => operation.filename.toLowerCase()));
    const renames = new Map(state.pendingImageOps.filter((operation) => operation.type === "rename").map((operation) => [operation.from.toLowerCase(), operation]));
    const diskItems = state.images
      .filter((image) => !query || image.filename.toLocaleLowerCase().includes(query))
      .map((image) => ({ ...image, pendingRemove: removed.has(image.filename.toLowerCase()), rename: renames.get(image.filename.toLowerCase()), staged: false }));
    const stagedItems = state.pendingImageOps
      .filter((operation) => operation.type === "add" && (!query || operation.filename.toLocaleLowerCase().includes(query)))
      .map((operation) => ({
        filename: operation.filename,
        width: operation.width,
        height: operation.height,
        size: operation.size,
        references: currentReferences(operation.filename),
        orphaned: currentReferences(operation.filename).length === 0,
        previewUrl: operation.previewUrl,
        staged: true,
      }));
    const items = [...stagedItems, ...diskItems];
    const grid = $("#image-grid");
    if (!items.length) {
      grid.className = "image-grid empty-state";
      grid.innerHTML = `<div><strong>${state.connected ? "No matching deck images" : "No image library yet"}</strong><p>${state.connected ? "Stage a supported image or clear the search." : "Connect an app repository to scan assets/images/decks."}</p></div>`;
      return;
    }
    grid.className = "image-grid";
    grid.innerHTML = items.map((image) => {
      const shownName = image.rename?.to || image.filename;
      const preview = image.previewUrl;
      const references = currentReferences(shownName);
      const rememberedDeckId = state.imageDeckSelections[shownName.toLowerCase()];
      const assignedDeckId = references.some((deck) => deck.id === rememberedDeckId)
        ? rememberedDeckId
        : (references[0]?.id || "");
      return `
        <article class="image-tile" data-image="${escapeHtml(image.filename)}" data-staged="${image.staged ? "true" : "false"}">
          <div class="image-preview"><img src="${escapeHtml(preview)}" alt="Preview of ${escapeHtml(shownName)}"></div>
          <div class="image-info">
            <strong title="${escapeHtml(shownName)}">${escapeHtml(shownName)}</strong>
            <p>${escapeHtml(image.width)}×${escapeHtml(image.height)} · ${escapeHtml(formatBytes(image.size))}</p>
            <div class="image-meta">
              <span>${references.length} deck reference${references.length === 1 ? "" : "s"}</span>
              ${references.length === 0 ? '<span class="orphan-badge">Orphaned</span>' : ""}
              ${image.staged ? "<span>Staged</span>" : ""}
              ${image.pendingRemove ? '<span class="missing-badge">Pending removal</span>' : ""}
              ${image.rename ? "<span>Pending rename</span>" : ""}
            </div>
          </div>
          <div class="image-actions">
            <select class="image-deck-assign" data-image-deck aria-label="Assign ${escapeHtml(image.filename)} as a deck cover" ${image.pendingRemove || !allDecks().length ? "disabled" : ""}>
              <option value="" disabled ${assignedDeckId ? "" : "selected"}>Assign cover to...</option>
              ${allDeckEntries().map(({ pack, deck }) => `<option value="${escapeHtml(deck.id)}" ${deck.id === assignedDeckId ? "selected" : ""}>${escapeHtml(pack.title)} — ${escapeHtml(deck.title)}</option>`).join("")}
            </select>
            ${image.staged ? "" : '<button type="button" class="mini-button" data-image-action="replace">Replace</button>'}
            ${image.staged ? "" : '<button type="button" class="mini-button" data-image-action="rename">Rename</button>'}
            <button type="button" class="mini-button danger" data-image-action="remove">${image.staged ? "Unstage" : "Remove file"}</button>
          </div>
        </article>`;
    }).join("");

    $$(".image-tile", grid).forEach((tile) => {
      tile.addEventListener("click", async (event) => {
        const action = event.target.closest("[data-image-action]")?.dataset.imageAction;
        if (!action) return;
        const filename = tile.dataset.image;
        const staged = tile.dataset.staged === "true";
        if (action === "replace") chooseReplacement(filename);
        if (action === "rename") renameImage(filename);
        if (action === "remove") staged ? unstageImage(filename) : removeImage(filename);
      });
      $("[data-image-deck]", tile)?.addEventListener("change", (event) => {
        const deckId = event.target.value;
        if (!deckId) return;
        assignImage(tile.dataset.image, tile.dataset.staged === "true", deckId);
      });
    });
  }

  function currentReferences(filename) {
    const relative = `assets/images/decks/${filename}`.toLowerCase();
    return allDecks().filter((deck) => String(deck.coverImage || "").toLowerCase() === relative);
  }

  function assignImage(filename, staged = false, deckId = "") {
    const deck = findDeckEntry(deckId)?.deck;
    if (!deck) {
      notice("Choose a deck from the image dropdown first.", "warning");
      return;
    }
    const operation = staged
      ? state.pendingImageOps.find((item) => item.type === "add" && item.filename === filename)
      : state.pendingImageOps.find((item) => item.type === "rename" && item.from === filename);
    const finalName = operation?.to || operation?.filename || filename;
    deck.coverImage = `assets/images/decks/${finalName}`;
    state.imageDeckSelections[finalName.toLowerCase()] = deck.id;
    setDirty();
    renderDecks();
    renderImages();
    notice(`Assigned ${finalName} to “${deck.title}” in unsaved editor state.`, "success");
  }

  async function stageOneFile(file, replacementFilename = null, desiredFilename = "") {
    // Chrome may keep a selected File lazily backed by its source path. Copy
    // the bytes now so a moved or temporary source cannot break the later save.
    const durableFile = await FS.snapshotImageFile(file);
    const filename = desiredFilename || (
      replacementFilename?.toLowerCase().endsWith(".webp")
        ? replacementFilename
        : `${slugify(file.name.replace(/\.[^.]+$/, ""), "deck-cover")}.webp`
    );
    const formData = new FormData();
    formData.append("image", durableFile, durableFile.name);
    formData.append("filename", filename);
    const payload = await request("stage_upload", { method: "POST", body: formData });
    const staged = payload.staged;
    const convertedFile = fileFromBase64(staged.data, staged.filename, staged.mime);
    delete staged.data;
    staged.file = convertedFile;
    staged.previewUrl = URL.createObjectURL(convertedFile);
    const existing = state.images.find((image) => image.filename.toLowerCase() === (replacementFilename || staged.filename).toLowerCase());
    if (replacementFilename) {
      if (replacementFilename.toLowerCase() !== staged.filename.toLowerCase()) {
        URL.revokeObjectURL(staged.previewUrl);
        throw new Error("Rename this legacy cover to a .webp filename before replacing it.");
      }
      if (!existing) throw new Error(`Image ${replacementFilename} is no longer in the library.`);
      state.pendingImageOps = state.pendingImageOps.filter((operation) => !(operation.type === "replace" && operation.filename.toLowerCase() === replacementFilename.toLowerCase()));
      state.pendingImageOps.push({
        type: "replace",
        filename: existing.filename,
        file: staged.file,
        hash: staged.hash,
        expectedHash: existing.hash,
        width: staged.width,
        height: staged.height,
        size: staged.size,
        previewUrl: staged.previewUrl,
      });
    } else if (existing) {
      if (!(await confirmAction("Replace the existing image?", `${existing.filename} already exists. Stage this upload as a replacement?`))) {
        URL.revokeObjectURL(staged.previewUrl);
        return false;
      }
      state.pendingImageOps = state.pendingImageOps.filter((operation) => !(operation.type === "replace" && operation.filename.toLowerCase() === existing.filename.toLowerCase()));
      state.pendingImageOps.push({
        type: "replace",
        filename: existing.filename,
        file: staged.file,
        hash: staged.hash,
        expectedHash: existing.hash,
        width: staged.width,
        height: staged.height,
        size: staged.size,
        previewUrl: staged.previewUrl,
      });
    } else {
      const collision = state.pendingImageOps.some((operation) => operation.type === "add" && operation.filename.toLowerCase() === staged.filename.toLowerCase());
      if (collision) throw new Error(`A staged image already uses ${staged.filename}.`);
      state.pendingImageOps.push({ type: "add", ...staged });
    }
    setDirty();
    renderAll();
    return true;
  }

  function chooseReplacement(filename) {
    const input = document.createElement("input");
    input.type = "file";
    input.accept = ".webp,.png,.jpg,.jpeg,image/webp,image/png,image/jpeg";
    input.addEventListener("change", async () => {
      if (!input.files?.[0]) return;
      try {
        await stageOneFile(input.files[0], filename);
        notice(`Replacement for ${filename} is staged.`, "success");
      } catch (error) {
        notice(error.message, "error");
      }
    });
    input.click();
  }

  async function renameImage(filename) {
    const image = state.images.find((item) => item.filename === filename);
    if (!image) return;
    const proposed = window.prompt("New image filename (WebP, PNG, JPG, or JPEG):", filename);
    if (proposed == null || proposed === filename) return;
    if (!/^[A-Za-z0-9][A-Za-z0-9_-]*\.(webp|png|jpe?g)$/i.test(proposed)) {
      notice("Use a safe image filename with no spaces, folders, or extra extensions.", "error");
      return;
    }
    const collision = state.images.some((item) => item.filename.toLowerCase() === proposed.toLowerCase())
      || state.pendingImageOps.some((operation) => (operation.to || operation.filename || "").toLowerCase() === proposed.toLowerCase());
    if (collision) {
      notice(`An image already uses ${proposed}.`, "error");
      return;
    }
    const references = currentReferences(filename);
    if (!(await confirmAction("Rename this image?", `Rename ${filename} to ${proposed} and update ${references.length} pending deck reference${references.length === 1 ? "" : "s"}?`))) return;
    references.forEach((deck) => {
      deck.coverImage = `assets/images/decks/${proposed}`;
    });
    state.pendingImageOps.push({
      type: "rename",
      from: filename,
      to: proposed,
      expectedHash: image.hash,
      referenceDeckIds: references.map((deck) => deck.id),
    });
    setDirty();
    renderAll();
  }

  async function removeImage(filename) {
    const image = state.images.find((item) => item.filename === filename);
    if (!image) return;
    const references = currentReferences(filename);
    if (references.length) {
      notice(`Cannot remove ${filename} while it is referenced.`, "error", references.map((deck) => `${deck.title} (${deck.id})`));
      return;
    }
    const database = state.storageBackend === "database";
    if (!(await confirmAction(
      database ? "Remove this image from the active catalog?" : "Remove this image from GitHub?",
      database
        ? `${filename} will become unreferenced in the next publication. Its immutable historical bytes will remain available for rollback.`
        : `${state.connection.imageDirectory}/${filename} will be deleted in the next publish. Git history will retain the previous version.`,
    ))) return;
    state.pendingImageOps.push({ type: "remove", filename, expectedHash: image.hash });
    setDirty();
    renderAll();
  }

  function unstageImage(filename) {
    const operation = state.pendingImageOps.find((item) => item.type === "add" && item.filename === filename);
    if (operation?.previewUrl) URL.revokeObjectURL(operation.previewUrl);
    state.pendingImageOps = state.pendingImageOps.filter((item) => !(item.type === "add" && item.filename === filename));
    allDecks().forEach((deck) => {
      if (deck.coverImage.toLowerCase() === `assets/images/decks/${filename}`.toLowerCase()) deck.coverImage = "";
    });
    setDirty();
    renderAll();
  }

  function revertPendingImageReferences() {
    state.pendingImageOps.forEach((operation) => {
      if (operation.type === "rename") {
        allDecks().forEach((deck) => {
          if (deck.coverImage.toLowerCase() === `assets/images/decks/${operation.to}`.toLowerCase()) {
            deck.coverImage = `assets/images/decks/${operation.from}`;
          }
        });
      }
      if (operation.type === "add") {
        allDecks().forEach((deck) => {
          if (deck.coverImage.toLowerCase() === `assets/images/decks/${operation.filename}`.toLowerCase()) deck.coverImage = "";
        });
      }
      if (operation.previewUrl) URL.revokeObjectURL(operation.previewUrl);
    });
    state.pendingImageOps = [];
  }

  function renderBackups() {
    const list = $("#backup-list");
    if (!state.backups.length) {
      list.className = "backup-list empty-state";
      list.innerHTML = `<div><strong>No publishes yet</strong><p>Deck Manager ${state.storageBackend === "database" ? "revisions" : "commits"} will appear here.</p></div>`;
      return;
    }
    list.className = "backup-list";
    const database = state.storageBackend === "database";
    list.innerHTML = state.backups.map((backup) => {
      const summary = backup.summary || {};
      const label = summary.label || summarizeBackup(summary);
      const activeRevision = Number(backup.revision) === Number(state.catalog?.revision);
      const action = database
        ? (activeRevision
          ? '<button type="button" class="button" disabled>Active revision</button>'
          : `<button type="button" class="button" data-rollback-revision="${Number(backup.revision)}">Restore revision</button>`)
        : `<a class="button" href="${escapeHtml(backup.url)}" target="_blank" rel="noopener noreferrer">View commit</a>`;
      const source = database
        ? `${escapeHtml(backup.eventType || "publish")} · ${escapeHtml(backup.sourceJson)} · @${escapeHtml(backup.administrator || "unknown")}`
        : `Commit ${escapeHtml(backup.sourceJson)}`;
      return `
        <article class="backup-row" data-backup-id="${escapeHtml(backup.id)}">
          <div><strong>${escapeHtml(formatDate(backup.createdAt))}</strong><small>${escapeHtml(backup.id)}</small></div>
          <div class="backup-summary">${escapeHtml(label)}<small>${source}</small></div>
          ${action}
        </article>`;
    }).join("");
    $$('[data-rollback-revision]', list).forEach((button) => {
      button.addEventListener("click", () => void rollbackDatabaseRevision(Number(button.dataset.rollbackRevision)));
    });
  }

  async function rollbackDatabaseRevision(revision) {
    if (state.storageBackend !== "database" || !Number.isInteger(revision)) return;
    if (state.dirty) {
      notice("Discard the unpublished database draft before restoring history.", "warning", [], [{
        label: "Discard Draft",
        handler: () => void discardDatabaseDraft(),
      }]);
      return;
    }
    if (!(await confirmAction(
      `Restore revision ${revision}?`,
      `Revision ${revision} will be copied into a new forward-moving catalog revision. Existing history and immutable media will be retained.`,
    ))) return;
    try {
      const payload = await request("rollback", {
        method: "POST",
        json: { confirm: true, revision, baseSnapshot: state.snapshot },
      });
      await applySaveResult(payload);
      notice(payload.message, "success");
    } catch (error) {
      notice(error.message, error.payload?.conflict ? "warning" : "error", [], error.payload?.conflict
        ? [{ label: "Save My Work & Get Latest", handler: () => void reloadFromDisk() }]
        : []);
    }
  }

  function summarizeBackup(summary) {
    const values = [];
    Object.entries(summary).forEach(([key, value]) => {
      if (Array.isArray(value) && value.length) values.push(`${key}: ${value.length}`);
      else if (typeof value === "number" && value > 0) values.push(`${key}: ${value}`);
    });
    return values.join(" · ") || "Catalog save";
  }

  function tabFromLocation() {
    if (!window.location.pathname.startsWith(appBaseUrl.pathname)) return "decks";
    const route = window.location.pathname
      .slice(appBaseUrl.pathname.length)
      .replace(/^\/+|\/+$/g, "");
    return TAB_NAMES.has(route) ? route : "decks";
  }

  function tabUrl(name) {
    return new URL(TAB_NAMES.has(name) ? name : "decks", appBaseUrl);
  }

  function switchTab(name, { historyMode = "push" } = {}) {
    const selected = TAB_NAMES.has(name) ? name : "decks";
    $$(".tab").forEach((tab) => {
      const active = tab.dataset.tab === selected;
      tab.classList.toggle("active", active);
      if (active) tab.setAttribute("aria-current", "page");
      else tab.removeAttribute("aria-current");
      tab.href = tabUrl(tab.dataset.tab).href;
    });
    $$(".tab-panel").forEach((panel) => panel.classList.toggle("active", panel.id === `panel-${selected}`));
    document.title = `${TAB_TITLES[selected]} | WHATZ IT? Deck Manager`;

    const nextUrl = tabUrl(selected);
    if (window.location.href === nextUrl.href || historyMode === "none") return;
    if (historyMode === "replace") window.history.replaceState({ tab: selected }, "", nextUrl);
    else window.history.pushState({ tab: selected }, "", nextUrl);
  }

  function legacyClientValidation() {
    const errors = [];
    const catalog = state.catalog;
    if (!catalog) return ["No catalog is loaded."];
    if (catalog.schemaVersion !== 2) errors.push("schemaVersion must be 2.");
    if (!Array.isArray(catalog.packs)) errors.push("packs must be an array.");
    const packIds = new Set();
    const deckIds = new Set();
    const projected = projectedImageNames();
    const validCommerce = (value, label) => {
      if (!["free", "paid"].includes(value.access)) errors.push(`${label} must be Free or Paid.`);
      if ("price" in value && (value.access !== "paid" || typeof value.price !== "number" || !Number.isFinite(value.price) || value.price < 0 || value.price > 99999.99 || Math.abs(Math.round(value.price * 100) - value.price * 100) > 1e-8)) {
        errors.push(`${label} has an invalid price.`);
      }
    };
    (catalog.packs || []).forEach((pack, packIndex) => {
      if (!pack.id || !/^[A-Za-z0-9][A-Za-z0-9_-]*$/.test(pack.id)) errors.push(`Bundle ${packIndex + 1} has an invalid ID.`);
      if (packIds.has(String(pack.id).toLowerCase())) errors.push(`Duplicate bundle ID: ${pack.id}.`);
      packIds.add(String(pack.id).toLowerCase());
      if (!pack.title?.trim()) errors.push(`Bundle ${pack.id || packIndex + 1} needs a title.`);
      if (pack.order !== packIndex + 1) errors.push(`Bundle ${pack.id || packIndex + 1} has a non-sequential order.`);
      validCommerce(pack, `Bundle ${pack.id || packIndex + 1}`);
      if (!Array.isArray(pack.decks)) {
        errors.push(`Bundle ${pack.id || packIndex + 1} decks must be an array.`);
        return;
      }
      pack.decks.forEach((deck, index) => {
        if (!deck.id || !/^[A-Za-z0-9][A-Za-z0-9_-]*$/.test(deck.id)) errors.push(`Deck ${index + 1} in ${pack.id} has an invalid ID.`);
        if (deckIds.has(deck.id.toLowerCase())) errors.push(`Duplicate deck ID: ${deck.id}.`);
        deckIds.add(deck.id.toLowerCase());
        if (!deck.title?.trim()) errors.push(`Deck ${deck.id || index + 1} needs a title.`);
        if (!Number.isInteger(Number(deck.version)) || Number(deck.version) < 1) errors.push(`Deck ${deck.id || index + 1} needs a positive integer version.`);
        if (deck.order !== index + 1) errors.push(`Deck ${deck.id || index + 1} has a non-sequential order.`);
        validCommerce(deck, `Deck ${deck.id || index + 1}`);
        if (deck.coverImage) {
          if (!/^assets\/images\/decks\/[A-Za-z0-9][A-Za-z0-9_-]*\.(webp|png|jpe?g)$/i.test(deck.coverImage)) errors.push(`Deck ${deck.id} has an unsafe coverImage path.`);
          else if (!projected.has(basename(deck.coverImage).toLowerCase())) errors.push(`Deck ${deck.id} references missing image ${deck.coverImage}.`);
        }
        const cardIds = new Set();
        (deck.cards || []).forEach((card, cardIndex) => {
          if (!card.id || !/^[A-Za-z0-9][A-Za-z0-9_-]*$/.test(card.id)) errors.push(`Card ${cardIndex + 1} in ${deck.id} has an invalid ID.`);
          if (cardIds.has(card.id.toLowerCase())) errors.push(`Duplicate card ID ${card.id} in ${deck.id}.`);
          cardIds.add(card.id.toLowerCase());
          if (!card.text?.trim()) errors.push(`Card ${card.id || cardIndex + 1} in ${deck.id} has blank text.`);
        });
      });
    });
    if (catalog.packs?.[0]?.id !== "free-pack") errors.push("Free Bundle must be first.");
    return Array.from(new Set(errors));
  }

  function structuralClientValidationLegacy() {
    const errors = [];
    const catalog = state.catalog;
    if (!catalog) return ["No catalog is loaded."];
    if (catalog.schemaVersion !== 3) errors.push("schemaVersion must be 3.");
    if (!Array.isArray(catalog.decks)) errors.push("decks must be an array.");
    if (!Array.isArray(catalog.bundles)) errors.push("bundles must be an array.");
    const projected = projectedImageNames();
    const deckIds = new Set();
    const validCommerce = (value, label) => {
      if (!["free", "paid"].includes(value.access)) errors.push(`${label} must be Free or Paid.`);
      if ("price" in value && (value.access !== "paid" || typeof value.price !== "number" || !Number.isFinite(value.price) || value.price < 0 || value.price > 99999.99 || Math.abs(Math.round(value.price * 100) - value.price * 100) > 1e-8)) {
        errors.push(`${label} has an invalid price.`);
      }
    };
    allDecks().forEach((deck, index) => {
      if (!deck.id || !/^[A-Za-z0-9][A-Za-z0-9_-]*$/.test(deck.id)) errors.push(`Deck ${index + 1} has an invalid ID.`);
      if (deckIds.has(String(deck.id).toLowerCase())) errors.push(`Duplicate deck ID: ${deck.id}.`);
      deckIds.add(String(deck.id).toLowerCase());
      if (!deck.title?.trim()) errors.push(`Deck ${deck.id || index + 1} needs a title.`);
      if (deck.order !== index + 1) errors.push(`Deck ${deck.id || index + 1} has a non-sequential order.`);
      if (!Number.isInteger(Number(deck.version)) || Number(deck.version) < 1) errors.push(`Deck ${deck.id || index + 1} needs a positive integer version.`);
      validCommerce(deck, `Deck ${deck.id || index + 1}`);
      if (deck.coverImage) {
        if (!/^assets\/images\/decks\/[A-Za-z0-9][A-Za-z0-9_-]*\.(webp|png|jpe?g)$/i.test(deck.coverImage)) errors.push(`Deck ${deck.id} has an unsafe coverImage path.`);
        else if (!projected.has(basename(deck.coverImage).toLowerCase())) errors.push(`Deck ${deck.id} references missing image ${deck.coverImage}.`);
      }
      const cardIds = new Set();
      (deck.cards || []).forEach((card, cardIndex) => {
        if (!card.id || !/^[A-Za-z0-9][A-Za-z0-9_-]*$/.test(card.id)) errors.push(`Card ${cardIndex + 1} in ${deck.id} has an invalid ID.`);
        if (cardIds.has(String(card.id).toLowerCase())) errors.push(`Duplicate card ID ${card.id} in ${deck.id}.`);
        cardIds.add(String(card.id).toLowerCase());
        if (!card.text?.trim()) errors.push(`Card ${card.id || cardIndex + 1} in ${deck.id} has blank text.`);
      });
    });
    const bundleIds = new Set();
    catalogBundles().forEach((bundle, index) => {
      if (!bundle.id || !/^[A-Za-z0-9][A-Za-z0-9_-]*$/.test(bundle.id)) errors.push(`Bundle ${index + 1} has an invalid ID.`);
      if (bundleIds.has(String(bundle.id).toLowerCase())) errors.push(`Duplicate bundle ID: ${bundle.id}.`);
      bundleIds.add(String(bundle.id).toLowerCase());
      if (!bundle.title?.trim()) errors.push(`Bundle ${bundle.id || index + 1} needs a title.`);
      if (bundle.order !== index + 1) errors.push(`Bundle ${bundle.id || index + 1} has a non-sequential order.`);
      validCommerce(bundle, `Bundle ${bundle.id || index + 1}`);
      const members = new Set();
      (bundle.deckIds || []).forEach((deckId) => {
        if (!deckIds.has(String(deckId).toLowerCase())) errors.push(`Bundle ${bundle.id} references unknown deck ${deckId}.`);
        if (members.has(String(deckId).toLowerCase())) errors.push(`Bundle ${bundle.id} references deck ${deckId} more than once.`);
        members.add(String(deckId).toLowerCase());
      });
    });
    return Array.from(new Set(errors));
  }

  function clientValidation() {
    const catalog = state.catalog;
    if (!catalog) return ["No catalog is loaded."];
    syncDeckOrders();
    const errors = FS.validateCatalog(catalog).map((error) => `${error.path}: ${error.message}`);
    const projected = projectedImageNames();
    allDecks().forEach((deck) => {
      if (deck.coverImage && !projected.has(basename(deck.coverImage).toLowerCase())) {
        errors.push(`Deck ${deck.id} references missing image ${deck.coverImage}.`);
      }
    });
    return Array.from(new Set(errors));
  }

  function projectedImageNames() {
    const names = new Set(state.images.map((image) => image.filename.toLowerCase()));
    state.pendingImageOps.forEach((operation) => {
      if (operation.type === "add" || operation.type === "replace") names.add(operation.filename.toLowerCase());
      if (operation.type === "rename") {
        names.delete(operation.from.toLowerCase());
        names.add(operation.to.toLowerCase());
      }
      if (operation.type === "remove") names.delete(operation.filename.toLowerCase());
    });
    return names;
  }

  function legacyCatalogDiff() {
    const before = state.originalCatalog || { packs: [], revision: 0 };
    const after = state.catalog || { packs: [] };
    const beforePacks = new Map(catalogPacks(before).map((pack) => [pack.id, pack]));
    const afterPacks = new Map(catalogPacks(after).map((pack) => [pack.id, pack]));
    const beforeDecks = new Map(allDeckEntries(before).map(({ pack, deck, deckIndex }) => [deck.id, { deck, packId: pack.id, index: deckIndex }]));
    const afterDecks = new Map(allDeckEntries(after).map(({ pack, deck, deckIndex }) => [deck.id, { deck, packId: pack.id, index: deckIndex }]));
    const summary = {
      packsAdded: [],
      packsEdited: [],
      packsRemoved: [],
      decksAdded: [],
      decksEdited: [],
      decksReordered: [],
      decksRemoved: [],
      cardsAdded: [],
      cardsEdited: [],
      cardsRemoved: [],
      imagesAdded: [],
      imagesReplaced: [],
      imagesRenamed: [],
      imagesRemoved: [],
      imageReferencesUpdated: [],
      missingReferences: [],
      orphanedImagesUntouched: [],
    };
    afterPacks.forEach((pack, id) => {
      if (!beforePacks.has(id)) summary.packsAdded.push(id);
      else {
        const previous = beforePacks.get(id);
        if (["order", "title", "access", "price"].some((field) => JSON.stringify(previous[field]) !== JSON.stringify(pack[field]))) summary.packsEdited.push(id);
      }
    });
    beforePacks.forEach((_, id) => {
      if (!afterPacks.has(id)) summary.packsRemoved.push(id);
    });
    afterDecks.forEach(({ deck, index }, id) => {
      if (!beforeDecks.has(id)) {
        summary.decksAdded.push(id);
        summary.cardsAdded.push(...deck.cards.map((card) => `${id}/${card.id}`));
        return;
      }
      const previous = beforeDecks.get(id);
      if (previous.index !== index || previous.packId !== afterDecks.get(id).packId) summary.decksReordered.push(id);
      const deckFields = ["title", "description", "version", "coverImage", "tags", "access", "price", "storeProducts"];
      if (deckFields.some((field) => JSON.stringify(previous.deck[field]) !== JSON.stringify(deck[field]))) summary.decksEdited.push(id);
      if (previous.deck.coverImage !== deck.coverImage) summary.imageReferencesUpdated.push(id);
      const beforeCards = new Map(previous.deck.cards.map((card) => [card.id, { card }]));
      const afterCards = new Map(deck.cards.map((card) => [card.id, { card }]));
      afterCards.forEach(({ card }, cardId) => {
        if (!beforeCards.has(cardId)) summary.cardsAdded.push(`${id}/${cardId}`);
        else {
          const old = beforeCards.get(cardId);
          if (
            old.card.text !== card.text
            || (old.card.byline || "") !== (card.byline || "")
            || old.card.featuredOrder !== card.featuredOrder
          ) summary.cardsEdited.push(`${id}/${cardId}`);
        }
      });
      beforeCards.forEach((_, cardId) => {
        if (!afterCards.has(cardId)) summary.cardsRemoved.push(`${id}/${cardId}`);
      });
    });
    beforeDecks.forEach(({ deck }, id) => {
      if (!afterDecks.has(id)) {
        summary.decksRemoved.push(id);
        summary.cardsRemoved.push(...deck.cards.map((card) => `${id}/${card.id}`));
      }
    });
    state.pendingImageOps.forEach((operation) => {
      if (operation.type === "add") summary.imagesAdded.push(operation.filename);
      if (operation.type === "replace") summary.imagesReplaced.push(operation.filename);
      if (operation.type === "rename") summary.imagesRenamed.push(`${operation.from} → ${operation.to}`);
      if (operation.type === "remove") summary.imagesRemoved.push(operation.filename);
    });
    summary.missingReferences = clientValidation().filter((error) => error.includes("missing image"));
    const touched = new Set(state.pendingImageOps.flatMap((operation) => [operation.filename, operation.from, operation.to].filter(Boolean).map((name) => name.toLowerCase())));
    summary.orphanedImagesUntouched = state.images.filter((image) => image.orphaned && !touched.has(image.filename.toLowerCase())).map((image) => image.filename);
    return summary;
  }

  function catalogDiff() {
    const before = state.originalCatalog || { decks: [], bundles: [], revision: 0 };
    const after = state.catalog || { decks: [], bundles: [] };
    const beforeDecks = new Map(allDecks(before).map((deck, index) => [deck.id, { deck, index }]));
    const afterDecks = new Map(allDecks(after).map((deck, index) => [deck.id, { deck, index }]));
    const beforeBundles = new Map(catalogBundles(before).map((bundle) => [bundle.id, bundle]));
    const afterBundles = new Map(catalogBundles(after).map((bundle) => [bundle.id, bundle]));
    const summary = {
      bundlesAdded: [],
      bundlesEdited: [],
      bundlesRemoved: [],
      deckOrdersEdited: [],
      decksAdded: [],
      decksEdited: [],
      decksReordered: [],
      decksRemoved: [],
      cardsAdded: [],
      cardsEdited: [],
      cardsRemoved: [],
      imagesAdded: [],
      imagesReplaced: [],
      imagesRenamed: [],
      imagesRemoved: [],
      imageReferencesUpdated: [],
      missingReferences: [],
      orphanedImagesUntouched: [],
    };
    afterBundles.forEach((bundle, id) => {
      if (!beforeBundles.has(id)) summary.bundlesAdded.push(id);
      else if (JSON.stringify(beforeBundles.get(id)) !== JSON.stringify(bundle)) summary.bundlesEdited.push(id);
    });
    beforeBundles.forEach((_, id) => { if (!afterBundles.has(id)) summary.bundlesRemoved.push(id); });
    ["free", "paid"].forEach((scope) => {
      if (JSON.stringify(before.deckOrders?.[scope] || []) !== JSON.stringify(after.deckOrders?.[scope] || [])) {
        summary.deckOrdersEdited.push(scope);
      }
    });
    afterDecks.forEach(({ deck, index }, id) => {
      if (!beforeDecks.has(id)) {
        summary.decksAdded.push(id);
        summary.cardsAdded.push(...(deck.cards || []).map((card) => `${id}/${card.id}`));
        return;
      }
      const previous = beforeDecks.get(id);
      if (previous.index !== index) summary.decksReordered.push(id);
      const deckFields = ["title", "description", "version", "coverImage", "tags", "access", "price", "storeProducts"];
      if (deckFields.some((field) => JSON.stringify(previous.deck[field]) !== JSON.stringify(deck[field]))) summary.decksEdited.push(id);
      if (previous.deck.coverImage !== deck.coverImage) summary.imageReferencesUpdated.push(id);
      const beforeCards = new Map((previous.deck.cards || []).map((card) => [card.id, card]));
      const afterCards = new Map((deck.cards || []).map((card) => [card.id, card]));
      afterCards.forEach((card, cardId) => {
        if (!beforeCards.has(cardId)) summary.cardsAdded.push(`${id}/${cardId}`);
        else if (JSON.stringify(beforeCards.get(cardId)) !== JSON.stringify(card)) summary.cardsEdited.push(`${id}/${cardId}`);
      });
      beforeCards.forEach((_, cardId) => { if (!afterCards.has(cardId)) summary.cardsRemoved.push(`${id}/${cardId}`); });
    });
    beforeDecks.forEach(({ deck }, id) => {
      if (!afterDecks.has(id)) {
        summary.decksRemoved.push(id);
        summary.cardsRemoved.push(...(deck.cards || []).map((card) => `${id}/${card.id}`));
      }
    });
    state.pendingImageOps.forEach((operation) => {
      if (operation.type === "add") summary.imagesAdded.push(operation.filename);
      if (operation.type === "replace") summary.imagesReplaced.push(operation.filename);
      if (operation.type === "rename") summary.imagesRenamed.push(`${operation.from} → ${operation.to}`);
      if (operation.type === "remove") summary.imagesRemoved.push(operation.filename);
    });
    summary.missingReferences = clientValidation().filter((error) => error.includes("missing image"));
    const touched = new Set(state.pendingImageOps.flatMap((operation) => [operation.filename, operation.from, operation.to].filter(Boolean).map((name) => name.toLowerCase())));
    summary.orphanedImagesUntouched = state.images.filter((image) => image.orphaned && !touched.has(image.filename.toLowerCase())).map((image) => image.filename);
    return summary;
  }

  function renderSavePreview(summary) {
    const labels = {
      bundlesAdded: "Bundles added",
      bundlesEdited: "Bundles edited or reordered",
      bundlesRemoved: "Bundles removed",
      deckOrdersEdited: "Deck orders changed",
      decksAdded: "Decks added",
      decksEdited: "Decks edited",
      decksReordered: "Decks reordered",
      decksRemoved: "Decks removed",
      cardsAdded: "Cards added",
      cardsEdited: "Cards edited",
      cardsRemoved: "Cards removed",
      imagesAdded: "Images to add",
      imagesReplaced: "Images to replace",
      imagesRenamed: "Images to rename",
      imagesRemoved: "Images to remove",
      imageReferencesUpdated: "Image references updated",
      missingReferences: "Missing image references",
      orphanedImagesUntouched: "Orphaned images left untouched",
    };
    const rows = Object.entries(labels).map(([key, label]) => {
      const values = summary[key] || [];
      return `<span><strong>${escapeHtml(label)}:</strong> ${values.length}${values.length && values.length <= 5 ? `<br><small>${escapeHtml(values.join(", "))}</small>` : ""}</span>`;
    }).join("");
    $("#save-preview").innerHTML = `
      <div class="save-path"><strong>Catalog file:</strong> <code>${escapeHtml(state.connection.jsonPath)}</code></div>
      <div><strong>Destination:</strong> ${escapeHtml(state.connection.appRoot)} · ${escapeHtml(state.connection.branch)}</div>
      <div><strong>Revision:</strong> ${escapeHtml(state.catalog.revision)} → ${escapeHtml(Number(state.catalog.revision) + 1)}</div>
      <div class="save-grid">${rows}</div>`;
  }

  async function prepareSave() {
    if (publishPreparationInFlight || dialogs.save.open) return;
    publishPreparationInFlight = true;
    $$("[data-publish-action]").forEach((button) => { button.disabled = true; });
    try {
      if (state.storageBackend === "database" && !(await draftAutosave.flush())) {
        notice("Publishing is paused until the database draft conflict or save error is resolved.", "warning");
        return;
      }
      const errors = clientValidation();
      if (errors.length) {
        notice("Saving is blocked by validation errors.", "error", errors);
        return;
      }
      const summary = catalogDiff();
      renderSavePreview(summary);
      $("#commit-message").value = "";
      dialogs.save.showModal();
    } finally {
      publishPreparationInFlight = false;
      setDirty(state.dirty, { schedule: false });
    }
  }

  async function applySaveResult(payload) {
    const database = state.storageBackend === "database";
    setRepositoryLoading(true, {
      title: "Published. Refreshing the shelf.",
      message: database ? "Loading the activated database revision…" : "Loading the committed covers from GitHub…",
    });
    const { serverState, failedImages } = await prepareRemoteState(payload.state);
    useServerState(serverState, true);
    setRepositoryLoading(false);
    if (failedImages.length) {
      notice("The changes were published, but some cover previews could not be loaded.", "warning", failedImages);
    }
  }

  async function confirmSave() {
    const button = $("#confirm-save");
    try {
      setBusy(button, true, "Publishing Live…");
      const summary = catalogDiff();
      const formData = new FormData();
      const imageOperations = state.pendingImageOps.map(({ previewUrl, referenceDeckIds, file, ...operation }, index) => {
        if (file instanceof Blob) {
          const uploadKey = `upload_${index}`;
          formData.append(uploadKey, file, operation.filename);
          return { ...operation, uploadKey };
        }
        return operation;
      });
      formData.append("payload", JSON.stringify({
        confirm: true,
        catalog: state.catalog,
        baseSnapshot: state.snapshot,
        imageOperations,
        summary,
        commitMessage: $("#commit-message").value.trim(),
      }));
      const payload = await request("save", {
        method: "POST",
        body: formData,
      });
      dialogs.save.close();
      await applySaveResult(payload);
      const commitUrl = payload.result?.commitUrl;
      notice(payload.message, "success", [], commitUrl ? [{
        label: "View commit",
        handler: () => window.open(commitUrl, "_blank", "noopener,noreferrer"),
      }] : []);
    } catch (error) {
      setRepositoryLoading(false);
      const details = error.payload?.validationErrors?.map((item) => `${item.path}: ${item.message}`) || [];
      notice(error.message, error.payload?.conflict ? "warning" : "error", details);
    } finally {
      setBusy(button, false);
    }
  }

  async function updateDevPreview() {
    const button = $("#update-dev-preview");
    if (!button || state.storageBackend !== "database" || devPreviewUpdateInFlight) return;
    devPreviewUpdateInFlight = true;
    renderDevPreviewStatus();
    try {
      if (!(await draftAutosave.flush())) {
        notice("The Test App update is paused until the draft conflict or save error is resolved.", "warning");
        return;
      }
      const errors = clientValidation();
      if (errors.length) {
        notice("The Test App cannot be updated until these errors are fixed.", "error", errors);
        return;
      }
      const formData = new FormData();
      const imageOperations = state.pendingImageOps.map(({ previewUrl, referenceDeckIds, file, ...operation }, index) => {
        if (file instanceof Blob) {
          const uploadKey = `upload_${index}`;
          formData.append(uploadKey, file, operation.filename);
          return { ...operation, uploadKey };
        }
        return operation;
      });
      formData.append("payload", JSON.stringify({
        catalog: state.catalog,
        baseSnapshot: state.snapshot,
        imageOperations,
      }));
      const payload = await request("publish_preview", {
        method: "POST",
        body: formData,
      });
      const result = payload.result || {};
      if (result.draftVersion) {
        state.snapshot = {
          ...state.snapshot,
          draftId: result.draftId,
          draftVersion: result.draftVersion,
        };
      }
      state.devPreview = { ...result, current: true };
      notice(payload.message, "success");
    } catch (error) {
      const details = error.payload?.validationErrors?.map((item) => `${item.path}: ${item.message}`) || [];
      notice(error.message, error.payload?.conflict ? "warning" : "error", details);
    } finally {
      devPreviewUpdateInFlight = false;
      renderDevPreviewStatus();
      renderConnection();
    }
  }

  async function reloadFromDisk() {
    const database = state.storageBackend === "database";
    if (database && ["pending", "saving"].includes(state.draftSaveStatus)) {
      await draftAutosave.flush();
    }
    const browserOnlyChanges = database
      ? ["pending", "saving", "media", "error", "conflict"].includes(state.draftSaveStatus)
      : state.dirty;
    const alreadyStashed = browserOnlyChanges && currentChangesMatchStash();
    if (browserOnlyChanges && !alreadyStashed && !(await stashCurrentChanges({ announce: false }))) return;
    const button = $("#reload-disk");
    try {
      setBusy(button, true, "Getting latest…");
      setRepositoryLoading(true, {
        title: "Getting the latest decks.",
        message: database ? "Loading the newest database draft and cover references…" : "Checking GitHub for new catalog and cover changes…",
      });
      const payload = await request("reload");
      const { serverState, failedImages } = await prepareRemoteState(payload.state);
      clearNotices();
      useServerState(serverState, true);
      draftConflictNotice = null;
      notice(database ? "Deck Manager loaded the latest database draft." : "Deck Manager is up to date with GitHub.", "success");
      if (failedImages.length) {
        notice("Some cover images could not be loaded.", "warning", failedImages);
      }
      showStashResolutionDialog();
    } catch (error) {
      notice(error.message, "error");
    } finally {
      setRepositoryLoading(false);
      setBusy(button, false);
    }
  }

  async function discardDatabaseDraft() {
    if (state.storageBackend !== "database" || !state.snapshot) return;
    if (!(await confirmAction(
      "Discard the database draft?",
      "This removes every unpublished database draft change and starts a clean draft from the active catalog revision.",
    ))) return;
    const button = $("#discard-draft");
    try {
      setBusy(button, true, "Discarding…");
      if (["pending", "saving"].includes(state.draftSaveStatus) && !(await draftAutosave.flush())) return;
      draftAutosave.reset("idle");
      const payload = await request("discard_draft", {
        method: "POST",
        json: { baseSnapshot: state.snapshot },
      });
      const { serverState, failedImages } = await prepareRemoteState(payload.state);
      clearNotices();
      useServerState(serverState, true);
      notice("The database draft was discarded and refreshed from the active catalog.", "success");
      if (failedImages.length) notice("Some cover images could not be loaded.", "warning", failedImages);
    } catch (error) {
      notice(error.message, error.payload?.conflict ? "warning" : "error", [], error.payload?.conflict
        ? [{ label: "Save My Work & Get Latest", handler: () => void reloadFromDisk() }]
        : []);
    } finally {
      setRepositoryLoading(false);
      setBusy(button, false);
    }
  }

  async function previewImport() {
    const deck = selectedDeck();
    if (!deck) return;
    const form = $("#import-form");
    const button = $("#preview-import");
    try {
      setBusy(button, true, "Parsing…");
      const payload = await request("parse_import", {
        method: "POST",
        json: {
          format: form.elements.format.value,
          input: form.elements.input.value,
          existingCards: form.elements.mode.value === "append" ? deck.cards : [],
          delimiterEnabled: form.elements.delimiterEnabled.checked,
          delimiter: form.elements.delimiter.value,
        },
      });
      state.importPreview = payload.preview;
      const preview = payload.preview;
      $("#import-preview").innerHTML = `
        <strong>${preview.validCount} valid card${preview.validCount === 1 ? "" : "s"} from ${preview.rowCount} row${preview.rowCount === 1 ? "" : "s"}</strong>
        ${preview.errors.length ? `<div><strong>Invalid rows</strong><ul>${preview.errors.map((error) => `<li>${escapeHtml(error)}</li>`).join("")}</ul></div>` : ""}
        ${preview.warnings.length ? `<div><strong>Warnings</strong><ul>${preview.warnings.map((warning) => `<li>${escapeHtml(warning)}</li>`).join("")}</ul></div>` : ""}
        ${preview.cards.length ? `<div class="preview-scroll"><table class="preview-table"><thead><tr><th>ID</th><th>Text</th><th>Byline</th></tr></thead><tbody>${preview.cards.slice(0, 50).map((card) => `<tr><td>${escapeHtml(card.id)}</td><td>${escapeHtml(card.text)}</td><td>${escapeHtml(card.byline || "")}</td></tr>`).join("")}</tbody></table></div>` : ""}`;
      $("#apply-import").disabled = preview.cards.length === 0 || preview.errors.length > 0;
    } catch (error) {
      state.importPreview = null;
      $("#apply-import").disabled = true;
      notice(error.message, "error");
    } finally {
      setBusy(button, false);
    }
  }

  async function applyImport() {
    const deck = selectedDeck();
    const form = $("#import-form");
    if (!deck || !state.importPreview) return;
    if (form.elements.mode.value === "replace" && !(await confirmAction("Replace all cards in this deck?", `Replace ${deck.cards.length} existing card${deck.cards.length === 1 ? "" : "s"} with ${state.importPreview.cards.length} imported cards in unsaved editor state?`))) return;
    deck.cards = form.elements.mode.value === "replace"
      ? clone(state.importPreview.cards)
      : [...deck.cards, ...clone(state.importPreview.cards)];

    syncDeckCardCount(deck);

    dialogs.import.close();
    setDirty();
    renderCards();
    renderDecks();
    renderCounts();
    renderCardDeckSelect();
    notice("Imported cards were applied to unsaved editor state.", "success");
  }

  function confirmAction(title, message) {
    return new Promise((resolve) => {
      $("#confirm-title").textContent = title;
      $("#confirm-message").textContent = message;
      const handler = () => {
        dialogs.confirm.removeEventListener("close", handler);
        resolve(dialogs.confirm.returnValue === "confirm");
      };
      dialogs.confirm.addEventListener("close", handler);
      dialogs.confirm.showModal();
    });
  }

  // Top-level navigation and actions.
  document.addEventListener("dragover", autoScrollDeckDrag);
  $$(".dialog-close").forEach((button) => {
    button.addEventListener("click", () => {
      button.closest("dialog")?.close("cancel");
    });
  });

  function showDraftSaveError(error) {
    const conflict = Boolean(error?.payload?.conflict);
    $("#draft-save-error-title").textContent = conflict
      ? "Another editor saved first"
      : "Draft did not save";
    $("#draft-save-error-message").textContent = conflict
      ? "The shared draft changed before this browser could save. Your local work has not been overwritten."
      : `Autosave failed: ${error?.message || "The draft could not be saved."}`;
    $("#stash-draft-save-error").disabled = !hasBrowserOnlyChanges(state);
    if (!dialogs.draftSaveError.open) dialogs.draftSaveError.showModal();
  }
  Object.values(dialogs).forEach((dialog) => {
    dialog.addEventListener("close", () => clearDialogNotices(dialog));
  });
  $$(".tab").forEach((tab) => tab.addEventListener("click", (event) => {
    if (event.button !== 0 || event.metaKey || event.ctrlKey || event.shiftKey || event.altKey) return;
    event.preventDefault();
    switchTab(tab.dataset.tab);
  }));
  window.addEventListener("popstate", () => switchTab(tabFromLocation(), { historyMode: "none" }));
  $("#local-login-form").addEventListener("submit", async (event) => {
    event.preventDefault();
    const form = event.currentTarget;
    const submit = form.querySelector('button[type="submit"]');
    const errorMessage = $("#login-error");
    submit.disabled = true;
    errorMessage.hidden = true;
    try {
      await request("local_login", {
        method: "POST",
        json: {
          username: form.elements.username.value,
          password: form.elements.password.value,
        },
      });
      form.elements.password.value = "";
      await loadStatus();
    } catch (error) {
      form.elements.password.value = "";
      errorMessage.textContent = error.message;
      errorMessage.hidden = false;
      form.elements.password.focus();
    } finally {
      submit.disabled = false;
    }
  });
  window.addEventListener("beforeunload", (event) => {
    const browserOnlyChanges = hasBrowserOnlyChanges(state);
    if (!browserOnlyChanges) return;
    event.preventDefault();
    event.returnValue = "";
  });
  dialogs.stashResolution.addEventListener("cancel", (event) => event.preventDefault());
  $("#stash-resolution-form").addEventListener("submit", (event) => event.preventDefault());
  $("#reload-disk").addEventListener("click", () => void reloadFromDisk());
  $("#discard-draft").addEventListener("click", discardDatabaseDraft);
  $("#restore-stash").addEventListener("click", () => void restoreCurrentStash());
  $("#discard-stash").addEventListener("click", () => void discardCurrentStash());
  $("#dismiss-draft-save-error").addEventListener("click", () => dialogs.draftSaveError.close("cancel"));
  $("#stash-draft-save-error").addEventListener("click", async (event) => {
    const button = event.currentTarget;
    setBusy(button, true, "Saving Work…");
    dialogs.draftSaveError.close("recovering");
    await reloadFromDisk();
    setBusy(button, false);
  });
  $("#update-dev-preview").addEventListener("click", updateDevPreview);
  $("#floating-dev-preview").addEventListener("click", updateDevPreview);
  $("#logout").addEventListener("click", async () => {
    if (state.storageBackend === "github" && state.dirty
      && !(await confirmAction("Discard unpublished changes?", "Signing out will discard all unpublished editor changes."))) return;
    if (state.storageBackend === "database" && state.pendingImageOps.length
      && !(await confirmAction("Discard browser-held media?", "The database draft is saved, but staged media files remain only in this browser until publication."))) return;
    if (state.storageBackend === "database") await draftAutosave.flush();
    try {
      await request("logout", { method: "POST" });
      window.location.assign("decks");
    } catch (error) {
      notice(error.message, "error");
    }
  });
  $$("[data-publish-action]").forEach((button) => button.addEventListener("click", prepareSave));
  $("#confirm-save").addEventListener("click", confirmSave);
  $("#validate-catalog").addEventListener("click", () => {
    const errors = clientValidation();
    notice(errors.length ? "Validation found blocking errors." : "The pending catalog and image references pass browser validation.", errors.length ? "error" : "success", errors);
  });

  $(".add-deck").addEventListener("click", () => openDeckDialog());
  $("#add-bundle").addEventListener("click", () => openBundleDialog());
  $("#deck-search").addEventListener("input", renderDecks);
  $("#bundle-search").addEventListener("input", renderBundles);
  $("#bundle-form").elements.title.addEventListener("input", syncBundleIdFromTitle);
  $("#bundle-form").elements.id.addEventListener("input", () => {
    updateBundleDerivedValidity();
    updateSuggestedAppleProductId($("#bundle-form"), "bundle");
    renderAppleBundleScenarios();
  });
  $("#apple-bundle-scenarios-list").addEventListener("click", (event) => {
    const button = event.target.closest("[data-copy-apple-product]");
    if (!button) return;
    void copyPlainText(button.dataset.copyAppleProduct, "Copied Apple product ID.");
  });
  $("#copy-all-apple-bundle-products").addEventListener("click", () => {
    const bundle = bundleFormRecord();
    const deckCount = Array.isArray(bundle?.deckIds) ? bundle.deckIds.length : 0;
    const text = FS.appleBundleScenarioProducts($("#bundle-form").elements.id.value, deckCount)
      .map(({ productId }) => productId)
      .join("\n");
    if (text) void copyPlainText(text, "Copied all Apple bundle product IDs.");
  });
  $("#bundle-form").elements.access.addEventListener("change", updateBundlePriceField);
  $("#bundle-form").addEventListener("submit", async (event) => {
    event.preventDefault();
    const form = event.currentTarget;
    if (!form.reportValidity()) return;
    const originalId = form.elements.originalId.value;
    const existing = bundleById(originalId);
    const nextId = form.elements.id.value.trim();
    if (originalId === "free-bundle" && nextId !== "free-bundle") {
      notice("The mobile app requires the stable bundle ID free-bundle.", "error");
      return;
    }
    if (existing && nextId !== existing.id && !(await confirmAction("Change this stable bundle ID?", `Changing ${existing.id} to ${nextId} can break purchase references. Continue only if you intend to migrate that ID.`))) return;
    if (catalogBundles().some((bundle) => bundle !== existing && bundle.id.toLowerCase() === nextId.toLowerCase())) {
      notice(`Bundle ID ${nextId} is already in use.`, "error");
      return;
    }
    const bundle = existing || { order: catalogBundles().length + 1, deckIds: [] };
    bundle.id = nextId;
    bundle.title = form.elements.title.value.trim();
    bundle.description = form.elements.description.value.trim();
    bundle.access = bundle.id === "free-bundle" ? "free" : form.elements.access.value;
    const price = form.elements.price.value.trim();
    if (bundle.access === "paid" && price !== "") bundle.price = Number(price);
    else delete bundle.price;
    const appleStatus = form.elements.appleProductStatus.value;
    if (bundle.access === "paid" && appleStatus) {
      bundle.storeProducts = {
        ...(bundle.storeProducts || {}),
        apple: {
          ...(bundle.storeProducts?.apple || {}),
          productId: form.elements.appleProductId.value,
          status: appleStatus,
        },
      };
    } else if (bundle.storeProducts) {
      delete bundle.storeProducts.apple;
      if (!Object.keys(bundle.storeProducts).length) delete bundle.storeProducts;
    }
    if (!existing) state.catalog.bundles.push(bundle);
    sortBundles();
    dialogs.bundle.close();
    setDirty();
    renderAll();
  });
  $("#deck-form").elements.access.addEventListener("change", updateDeckPriceField);
  $("#deck-form").elements.title.addEventListener("input", syncDeckFieldsFromTitle);
  $("#deck-form").elements.id.addEventListener("input", () => {
    updateDeckDerivedValidity();
    updateSuggestedAppleProductId($("#deck-form"), "deck");
  });
  $("#deck-form").elements.coverImage.addEventListener("input", () => {
    updateDeckDerivedValidity();
    if (!$("#deck-form").elements.coverUpload.files?.[0]) refreshDeckCoverPreview();
  });
  function showSelectedDeckCover(file) {
    if (!file) return;
    if (file.type && !file.type.startsWith("image/")) {
      notice("Drop or choose an image file.", "error");
      return;
    }
    const form = $("#deck-form");
    if (!form.elements.coverImage.value.trim()) {
      const titleSlug = slugify(form.elements.title.value);
      if (titleSlug) {
        form.elements.coverImage.value = `${titleSlug}.webp`;
        updateDeckDerivedValidity();
      }
    }
    const url = URL.createObjectURL(file);
    $("#deck-cover-preview").innerHTML = `<img src="${escapeHtml(url)}" alt="New deck cover preview">`;
    $("#deck-cover-drop-zone span").textContent = file.name;
  }
  $("#deck-form").elements.coverUpload.addEventListener("change", (event) => {
    showSelectedDeckCover(event.target.files?.[0]);
  });
  const deckCoverDropZone = $("#deck-cover-drop-zone");
  ["dragenter", "dragover"].forEach((type) => deckCoverDropZone.addEventListener(type, (event) => {
    event.preventDefault();
    if (event.dataTransfer) event.dataTransfer.dropEffect = "copy";
    deckCoverDropZone.classList.add("drag-over");
  }));
  ["dragleave", "drop"].forEach((type) => deckCoverDropZone.addEventListener(type, () => {
    deckCoverDropZone.classList.remove("drag-over");
  }));
  deckCoverDropZone.addEventListener("drop", (event) => {
    event.preventDefault();
    const file = event.dataTransfer?.files?.[0];
    if (!file) return;
    const transfer = new DataTransfer();
    transfer.items.add(file);
    $("#deck-form").elements.coverUpload.files = transfer.files;
    showSelectedDeckCover(file);
  });
  $("#deck-form").addEventListener("submit", async (event) => {
    event.preventDefault();
    const form = event.currentTarget;
    if (!form.reportValidity()) return;
    const index = Number(form.elements.index.value);
    const existing = index >= 0 ? allDecks()[index] : null;
    const nextId = form.elements.id.value.trim();
    if (existing && nextId !== existing.id && !(await confirmAction("Change this stable deck ID?", `Changing ${existing.id} to ${nextId} can break references in the mobile app. Continue only if you intend to migrate that ID.`))) return;
    if (allDecks().some((deck) => deck !== existing && deck.id.toLowerCase() === nextId.toLowerCase())) {
      notice(`Deck ID ${nextId} is already in use.`, "error");
      return;
    }
    const uploadedCover = form.elements.coverUpload.files?.[0];
    const coverFilename = form.elements.coverImage.value.trim();
    const oldCoverFilename = basename(existing?.coverImage);
    if (coverFilename && allDecks().some((item) =>
      item !== existing && basename(item.coverImage).toLowerCase() === coverFilename.toLowerCase()
    )) {
      notice(`Cover filename ${coverFilename} is already assigned to another deck. Choose a unique filename.`, "error");
      return;
    }
    if (coverFilename && imageNameIsTaken(coverFilename, oldCoverFilename)) {
      notice(`Image filename ${coverFilename} is already in use. Choose a unique deck title or filename.`, "error");
      return;
    }
    let nextCoverImage = existing?.coverImage || "";
    let renamedExistingCover = false;
    if (uploadedCover) {
      try {
        const staged = await stageOneFile(
          uploadedCover,
          oldCoverFilename.toLowerCase() === coverFilename.toLowerCase() ? oldCoverFilename : null,
          coverFilename,
        );
        if (!staged) return;
        nextCoverImage = `assets/images/decks/${coverFilename}`;
      } catch (error) {
        notice(`${coverFilename || uploadedCover.name}: ${error.message}`, "error");
        return;
      }
    } else if (existing?.coverImage && coverFilename && oldCoverFilename.toLowerCase() !== coverFilename.toLowerCase()) {
      if (oldCoverFilename.toLowerCase().endsWith(".webp")) {
        renamedExistingCover = stageDeckCoverRename(oldCoverFilename, coverFilename);
      } else {
        const oldImage = state.images.find((image) => image.filename.toLowerCase() === oldCoverFilename.toLowerCase());
        try {
          if (!oldImage?.previewUrl) throw new Error("The current cover could not be loaded for conversion.");
          const response = await fetch(oldImage.previewUrl, { credentials: "same-origin" });
          if (!response.ok) throw new Error("The current cover could not be loaded for conversion.");
          const source = new File([await response.blob()], oldCoverFilename, { type: response.headers.get("Content-Type") || "" });
          await stageOneFile(source, null, coverFilename);
          renamedExistingCover = false;
        } catch (error) {
          notice(`${error.message} Choose a replacement image to continue.`, "error");
          return;
        }
      }
      if (!renamedExistingCover && !state.pendingImageOps.some((operation) =>
        operation.type === "add" && operation.filename.toLowerCase() === coverFilename.toLowerCase()
      )) {
        notice("The current cover image is missing. Choose a replacement image to use the new filename.", "error");
        return;
      }
      nextCoverImage = `assets/images/decks/${coverFilename}`;
    } else if (existing?.coverImage && !coverFilename) {
      nextCoverImage = "";
    } else if (!existing?.coverImage && uploadedCover) {
      nextCoverImage = `assets/images/decks/${coverFilename}`;
    }
    const deck = existing || { order: allDecks().length + 1, cards: [] };
    const oldId = existing?.id;
    const oldCoverImage = existing?.coverImage || "";
    deck.id = nextId;
    deck.title = form.elements.title.value.trim();
    deck.description = form.elements.description.value.trim();
    deck.version = Number(form.elements.version.value);
    deck.coverImage = nextCoverImage;
    deck.tags = form.elements.tags.value.split(",").map((tag) => tag.trim()).filter(Boolean);
    deck.access = form.elements.access.value;
    const price = form.elements.price.value.trim();
    if (deck.access === "paid" && price !== "") deck.price = Number(price);
    else delete deck.price;
    const appleStatus = form.elements.appleProductStatus.value;
    if (deck.access === "paid" && appleStatus) {
      deck.storeProducts = {
        ...(deck.storeProducts || {}),
        apple: { productId: form.elements.appleProductId.value, status: appleStatus },
      };
    } else if (deck.storeProducts) {
      delete deck.storeProducts.apple;
      if (!Object.keys(deck.storeProducts).length) delete deck.storeProducts;
    }
    if (!existing) state.catalog.decks.push(deck);
    if (oldCoverImage && oldCoverImage !== deck.coverImage && !renamedExistingCover) {
      cleanupRemovedDeckCover({ coverImage: oldCoverImage });
    }
    if (oldId && oldId !== deck.id) {
      catalogBundles().forEach((bundle) => {
        bundle.deckIds = bundle.deckIds.map((id) => id === oldId ? deck.id : id);
      });
      Object.keys(state.catalog.deckOrders || {}).forEach((scope) => {
        state.catalog.deckOrders[scope] = state.catalog.deckOrders[scope].map((id) => id === oldId ? deck.id : id);
      });
    }
    if (deck.access === "paid") {
      const freeBundle = bundleById("free-bundle");
      if (freeBundle) freeBundle.deckIds = freeBundle.deckIds.filter((id) => id !== deck.id && id !== oldId);
    }
    normalizeDeckOrders();
    syncDeckOrders();
    pruneUnreferencedStagedCovers();
    if (state.selectedDeckId === oldId) state.selectedDeckId = deck.id;
    if (!state.selectedDeckId) state.selectedDeckId = deck.id;
    dialogs.deck.close();
    setDirty();
    renderAll();
  });

  $("#bundle-deck-search").addEventListener("input", renderBundleDeckPicker);
  $("#bundle-decks-form").addEventListener("submit", (event) => {
    event.preventDefault();
    const form = event.currentTarget;
    const bundle = bundleById(form.elements.bundleId.value);
    if (!bundle) return;
    if (
      bundle.id === "free-bundle" &&
      allDecks().some((deck) => state.bundleDeckDraft.has(deck.id) && deck.access !== "free")
    ) {
      notice("Free Bundle may contain free decks only.", "error");
      return;
    }
    const kept = bundle.deckIds.filter((deckId) => state.bundleDeckDraft.has(deckId));
    const keptSet = new Set(kept);
    bundle.deckIds = [...kept, ...allDecks()
      .filter((deck) => state.bundleDeckDraft.has(deck.id) && !keptSet.has(deck.id))
      .map((deck) => deck.id)];
    syncDeckOrders();
    dialogs.bundleDecks.close();
    setDirty();
    renderAll();
  });

  $("#card-deck-picker-trigger").addEventListener("click", toggleCardDeckPicker);
  $("#card-deck-picker-search").addEventListener("input", renderCardDeckPickerResults);
  $("#card-deck-picker-search").addEventListener("keydown", (event) => {
    if (event.key === "Escape") {
      closeCardDeckPicker();
      $("#card-deck-picker-trigger").focus();
      return;
    }
    if (event.key === "Enter") {
      const [deck] = cardPickerDecks();
      if (!deck) return;
      event.preventDefault();
      state.selectedDeckId = deck.id;
      closeCardDeckPicker();
      renderCards();
      renderCardDeckPickerResults();
    }
  });
  document.addEventListener("click", (event) => {
    if (!$("#card-deck-picker").contains(event.target)) closeCardDeckPicker();
  });
  $("#card-search").addEventListener("input", renderCards);
  $("#select-all-cards").addEventListener("click", () => {
    const deck = selectedDeck();
    if (!deck) return;
    if (state.selectedCardIds.size === deck.cards.length) {
      state.selectedCardIds.clear();
    } else {
      state.selectedCardIds = new Set(deck.cards.map((card) => card.id));
    }
    renderCards();
  });
  $("#remove-selected-cards").addEventListener("click", removeSelectedCards);
  $("#copy-selected-cards").addEventListener("click", copySelectedCards);
  $("#add-card").addEventListener("click", () => openCardDialog());
  $("#card-form").elements.text.addEventListener("input", (event) => {
    const form = $("#card-form");
    const deck = selectedDeck();
    const index = Number(form.elements.index.value);
    const id = slugify(event.target.value, "card");
    form.elements.id.value = id;
    const duplicate = deck?.cards.some((card, cardIndex) =>
      cardIndex !== index && card.id.toLowerCase() === id.toLowerCase()
    );
    form.elements.id.setCustomValidity(duplicate ? "This card ID is already in use in this deck." : "");
  });
  $("#card-form").elements.id.addEventListener("input", (event) => {
    const form = $("#card-form");
    const deck = selectedDeck();
    const index = Number(form.elements.index.value);
    const id = event.target.value.trim().toLowerCase();
    const duplicate = deck?.cards.some((card, cardIndex) =>
      cardIndex !== index && card.id.toLowerCase() === id
    );
    event.target.setCustomValidity(duplicate ? "This card ID is already in use in this deck." : "");
  });
  $("#card-form").elements.featured.addEventListener("change", updateFeaturedOrderField);
  $("#card-form").elements.featuredOrder.addEventListener("input", (event) => {
    event.target.setCustomValidity("");
  });
  $("#card-form").addEventListener("submit", async (event) => {
    event.preventDefault();
    const form = event.currentTarget;
    if (!form.reportValidity()) return;
    const deck = selectedDeck();
    const index = Number(form.elements.index.value);
    const existing = index >= 0 ? deck.cards[index] : null;
    const nextId = form.elements.id.value.trim();
    if (existing && nextId !== existing.id && !(await confirmAction("Change this stable card ID?", `Changing ${existing.id} to ${nextId} can break references. Continue only if you intend to migrate that ID.`))) return;
    if (deck.cards.some((card, cardIndex) => cardIndex !== index && card.id.toLowerCase() === nextId.toLowerCase())) {
      notice(`Card ID ${nextId} is already in use in this deck.`, "error");
      return;
    }
    const card = existing || {};
    card.id = nextId;
    card.text = form.elements.text.value;
    const byline = form.elements.byline.value.trim();
    if (byline) card.byline = byline;
    else delete card.byline;
    if (form.elements.featured.checked) {
      const featuredOrder = Number(form.elements.featuredOrder.value);
      const orderInUse = deck.cards.some((candidate, cardIndex) =>
        cardIndex !== index && candidate.featuredOrder === featuredOrder
      );
      if (!Number.isInteger(featuredOrder) || featuredOrder < 1 || orderInUse) {
        form.elements.featuredOrder.setCustomValidity(orderInUse
          ? "Another featured card already uses this preview position."
          : "Preview position must be a positive whole number.");
        form.elements.featuredOrder.reportValidity();
        return;
      }
      form.elements.featuredOrder.setCustomValidity("");
      card.featuredOrder = featuredOrder;
    } else {
      delete card.featuredOrder;
    }
    if (!existing) {
      deck.cards.push(card);
      syncDeckCardCount(deck);
    }

    dialogs.card.close();
    setDirty();
    renderCards();
    renderDecks();
    renderCounts();
    renderCardDeckSelect();
  });

  $("#bulk-import").addEventListener("click", () => {
    state.importPreview = null;
    $("#import-form").reset();
    $("#import-form").elements.delimiter.value = "|";
    $("#import-preview").innerHTML = "";
    $("#apply-import").disabled = true;
    dialogs.import.showModal();
  });
  $("#preview-import").addEventListener("click", previewImport);
  $("#apply-import").addEventListener("click", applyImport);
  $("#close-duplicates").addEventListener("click", () => dialogs.duplicates.close());
  $("#duplicates-form").addEventListener("submit", (event) => event.preventDefault());

  switchTab(tabFromLocation(), { historyMode: "replace" });
  loadStatus();
})();
