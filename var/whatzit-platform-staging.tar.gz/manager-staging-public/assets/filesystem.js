(function (root, factory) {
  const api = factory();
  if (typeof module === "object" && module.exports) module.exports = api;
  root.WhatzItFS = api;
})(typeof globalThis !== "undefined" ? globalThis : this, function () {
  "use strict";

  const IMAGE_DIRECTORY = "assets/images/decks";
  const DEFAULT_CATALOG_PATH = "src/data/bundles.ts";
  const DEFAULT_JSON_PATH = DEFAULT_CATALOG_PATH;
  const LEGACY_CATALOG_PATHS = ["src/data/packs.ts", "src/data/decks.ts", "src/data/decks.json"];
  const DATABASE_NAME = "whatz-it-deck-manager";
  const DATABASE_VERSION = 2;
  const CONNECTION_KEY = "active";
  const CATALOG_START = "/* DECK_MANAGER_CATALOG_START */";
  const CATALOG_END = "/* DECK_MANAGER_CATALOG_END */";
  const COVERS_START = "/* DECK_MANAGER_COVERS_START */";
  const COVERS_END = "/* DECK_MANAGER_COVERS_END */";

  function normalizeRelativePath(path, extension = "") {
    const value = String(path || "").trim().replaceAll("\\", "/").replace(/^\.\/+/, "");
    if (!value || value.startsWith("/") || /^[A-Za-z]:\//.test(value)) {
      throw new Error("Use a path relative to the selected repository.");
    }
    const parts = value.split("/");
    if (parts.some((part) => !part || part === "." || part === ".." || /[\0-\x1f]/.test(part))) {
      throw new Error("The relative path contains an unsafe segment.");
    }
    if (extension && !value.toLowerCase().endsWith(extension.toLowerCase())) {
      throw new Error(`The selected path must end with ${extension}.`);
    }
    return parts.join("/");
  }

  function safeImageFilename(filename) {
    const value = String(filename || "");
    if (!/^[A-Za-z0-9][A-Za-z0-9_-]*\.(webp|png|jpe?g)$/i.test(value)) {
      throw new Error("Use a safe WebP, PNG, JPEG, or JPG filename without spaces, folders, or extra extensions.");
    }
    return value;
  }

  function basename(path) {
    return String(path || "").replaceAll("\\", "/").split("/").pop() || "";
  }

  function appleBundleScenarioProducts(bundleId, deckCount) {
    const normalizedCount = Number.isInteger(deckCount) && deckCount > 0 ? deckCount : 0;
    const storeTargetId = String(bundleId || "").trim().replaceAll("_", "__").replaceAll("-", "_");
    const fullProductId = storeTargetId ? `com.cadelawless.whatzit.bundle.${storeTargetId}` : "";
    if (!fullProductId) return [];
    return Array.from({ length: Math.max(1, normalizedCount) }, (_, ownedDeckCount) => ({
      ownedDeckCount,
      productId: ownedDeckCount === 0 ? fullProductId : `${fullProductId}.owned_${ownedDeckCount}`,
    }));
  }

  function slugifyId(value, fallback = "") {
    return String(value || "")
      .normalize("NFKD")
      .replace(/[\u0300-\u036f]/g, "")
      .toLowerCase()
      .replace(/[^a-z0-9]+/g, "-")
      .replace(/^-+|-+$/g, "")
      .slice(0, 100)
      || fallback;
  }

  function planDeckCoverCleanup(coverImage, remainingCoverImages, images, operations) {
    const coverFilename = basename(coverImage);
    const coverKey = coverFilename.toLowerCase();
    const currentOperations = Array.isArray(operations) ? operations : [];
    if (
      !coverKey ||
      (remainingCoverImages || []).some((path) => basename(path).toLowerCase() === coverKey)
    ) {
      return { operations: currentOperations, removedOperations: [], addedOperation: null };
    }

    let diskFilename = coverFilename;
    const removedOperations = [];
    currentOperations.forEach((operation, index) => {
      const filename = String(operation.filename || "").toLowerCase();
      const renameTarget = String(operation.to || "").toLowerCase();
      if (operation.type === "add" && filename === coverKey) {
        removedOperations.push({ operation, index });
        diskFilename = "";
      } else if (operation.type === "rename" && renameTarget === coverKey) {
        removedOperations.push({ operation, index });
        diskFilename = operation.from;
      }
    });

    if (diskFilename) {
      currentOperations.forEach((operation, index) => {
        if (
          operation.type === "replace" &&
          String(operation.filename || "").toLowerCase() === diskFilename.toLowerCase() &&
          !removedOperations.some((removed) => removed.operation === operation)
        ) {
          removedOperations.push({ operation, index });
        }
      });
    }

    const removed = new Set(removedOperations.map(({ operation }) => operation));
    const nextOperations = currentOperations.filter((operation) => !removed.has(operation));
    const diskImage = diskFilename
      ? (images || []).find((image) => String(image.filename || "").toLowerCase() === diskFilename.toLowerCase())
      : null;
    const alreadyRemoving = diskImage && nextOperations.some((operation) =>
      operation.type === "remove" &&
      String(operation.filename || "").toLowerCase() === diskImage.filename.toLowerCase()
    );
    const addedOperation = diskImage && !alreadyRemoving
      ? { type: "remove", filename: diskImage.filename, expectedHash: diskImage.hash }
      : null;
    if (addedOperation) nextOperations.push(addedOperation);

    return {
      operations: nextOperations,
      removedOperations: removedOperations.sort((left, right) => left.index - right.index),
      addedOperation,
    };
  }

  async function getDirectoryHandle(rootHandle, path, create = false) {
    const normalized = normalizeRelativePath(path);
    const parts = normalized.split("/");
    let current = rootHandle;
    for (const part of parts) {
      current = await current.getDirectoryHandle(part, { create });
    }
    return current;
  }

  async function getFileHandle(rootHandle, path, create = false) {
    const normalized = normalizeRelativePath(path);
    const parts = normalized.split("/");
    const filename = parts.pop();
    let directory = rootHandle;
    for (const part of parts) {
      directory = await directory.getDirectoryHandle(part, { create });
    }
    return directory.getFileHandle(filename, { create });
  }

  async function sha256(value) {
    const bytes = value instanceof ArrayBuffer
      ? value
      : ArrayBuffer.isView(value)
        ? value.buffer.slice(value.byteOffset, value.byteOffset + value.byteLength)
        : await value.arrayBuffer();
    const hash = await crypto.subtle.digest("SHA-256", bytes);
    return Array.from(new Uint8Array(hash), (byte) => byte.toString(16).padStart(2, "0")).join("");
  }

  async function fileSnapshot(handle, parsedCatalog = null) {
    const file = await handle.getFile();
    return {
      mtime: file.lastModified,
      size: file.size,
      hash: await sha256(file),
      revision: Number.isInteger(parsedCatalog?.revision) ? parsedCatalog.revision : null,
    };
  }

  function detectImageSignature(bytes) {
    const data = bytes instanceof Uint8Array ? bytes : new Uint8Array(bytes);
    if (
      data.length >= 8 &&
      data[0] === 0x89 && data[1] === 0x50 && data[2] === 0x4e && data[3] === 0x47 &&
      data[4] === 0x0d && data[5] === 0x0a && data[6] === 0x1a && data[7] === 0x0a
    ) return "image/png";
    if (data.length >= 3 && data[0] === 0xff && data[1] === 0xd8 && data[2] === 0xff) return "image/jpeg";
    if (
      data.length >= 12 &&
      String.fromCharCode(...data.slice(0, 4)) === "RIFF" &&
      String.fromCharCode(...data.slice(8, 12)) === "WEBP"
    ) return "image/webp";
    return "";
  }

  async function imageDimensions(file) {
    if (typeof createImageBitmap === "function") {
      const bitmap = await createImageBitmap(file);
      const dimensions = { width: bitmap.width, height: bitmap.height };
      bitmap.close();
      return dimensions;
    }
    if (typeof document !== "undefined") {
      const url = URL.createObjectURL(file);
      try {
        return await new Promise((resolve, reject) => {
          const image = new Image();
          image.onload = () => resolve({ width: image.naturalWidth, height: image.naturalHeight });
          image.onerror = () => reject(new Error("The selected file could not be decoded as an image."));
          image.src = url;
        });
      } finally {
        URL.revokeObjectURL(url);
      }
    }
    throw new Error("Image dimensions cannot be inspected in this environment.");
  }

  async function inspectImageFile(file, limits = {}) {
    const filename = safeImageFilename(file.name);
    const extension = filename.split(".").pop().toLowerCase();
    const maxFileBytes = Number(limits.maxFileBytes || 10 * 1024 * 1024);
    const maxWidth = Number(limits.maxWidth || 6000);
    const maxHeight = Number(limits.maxHeight || 6000);
    if (!file.size || file.size > maxFileBytes) {
      throw new Error(`Images must be between 1 byte and ${maxFileBytes} bytes.`);
    }
    const signature = detectImageSignature(await file.slice(0, 16).arrayBuffer());
    const extensions = {
      "image/png": ["png"],
      "image/jpeg": ["jpg", "jpeg"],
      "image/webp": ["webp"],
    };
    if (!signature || !extensions[signature]?.includes(extension)) {
      throw new Error("The image contents do not match the filename extension.");
    }
    if (file.type && file.type !== signature) {
      throw new Error("The browser MIME type does not match the image contents.");
    }
    const dimensions = await imageDimensions(file);
    if (dimensions.width < 1 || dimensions.height < 1 || dimensions.width > maxWidth || dimensions.height > maxHeight) {
      throw new Error(`Image dimensions must be between 1×1 and ${maxWidth}×${maxHeight}.`);
    }
    return {
      filename,
      mime: signature,
      width: dimensions.width,
      height: dimensions.height,
      size: file.size,
      hash: await sha256(file),
    };
  }

  async function snapshotImageFile(file) {
    const bytes = await file.arrayBuffer();
    return new File([bytes], file.name, {
      type: file.type,
      lastModified: file.lastModified,
    });
  }

  function validId(value) {
    return typeof value === "string" && /^[A-Za-z0-9][A-Za-z0-9_-]{0,99}$/.test(value);
  }

  function hasControlCharacters(value) {
    return /[\x00-\x08\x0b\x0c\x0e-\x1f\x7f]/.test(value);
  }

  function canonicalJson(value) {
    if (Array.isArray(value)) return value.map(canonicalJson);
    if (!value || typeof value !== "object") return value;
    return Object.keys(value).sort().reduce((result, key) => {
      result[key] = canonicalJson(value[key]);
      return result;
    }, {});
  }

  function equivalentJson(left, right) {
    return JSON.stringify(canonicalJson(left)) === JSON.stringify(canonicalJson(right));
  }

  function catalogDeckEntries(catalog) {
    return (catalog?.decks || []).map((deck, deckIndex) => ({
      deck,
      deckIndex,
      path: `decks[${deckIndex}]`,
    }));
  }

  function migrateLegacyFreeBundle(bundles) {
    if (!Array.isArray(bundles) || bundles.some((bundle) => bundle?.id === "free-bundle")) return bundles;
    return bundles.map((bundle) => bundle?.id === "free-pack"
      ? {
          ...bundle,
          id: "free-bundle",
          title: bundle.title === "Free Pack" ? "Free Bundle" : bundle.title,
        }
      : bundle);
  }

  function migrateCatalog(catalog) {
    if (!catalog || typeof catalog !== "object" || Array.isArray(catalog)) return catalog;
    if (catalog.schemaVersion === 5 && Array.isArray(catalog.decks) && Array.isArray(catalog.bundles)) return catalog;
    if (catalog.schemaVersion === 4 && Array.isArray(catalog.decks) && Array.isArray(catalog.bundles)) {
      return {
        ...catalog,
        schemaVersion: 5,
        bundles: migrateLegacyFreeBundle(catalog.bundles),
        deckOrders: {
          free: catalog.deckOrders?.free || catalog.decks.filter((deck) => deck.access === "free").map((deck) => deck.id),
          paid: catalog.deckOrders?.paid || catalog.decks.filter((deck) => deck.access === "paid").map((deck) => deck.id),
        },
      };
    }
    if (catalog.schemaVersion === 3 && Array.isArray(catalog.decks) && Array.isArray(catalog.bundles)) {
      return {
        ...catalog,
        schemaVersion: 5,
        bundles: migrateLegacyFreeBundle(catalog.bundles),
        deckOrders: {
          free: catalog.decks.filter((deck) => deck.access === "free").map((deck) => deck.id),
          paid: catalog.decks.filter((deck) => deck.access === "paid").map((deck) => deck.id),
        },
      };
    }
    if (catalog.schemaVersion !== 2 || !Array.isArray(catalog.packs)) return catalog;
    const decks = [];
    const seenDeckIds = new Set();
    const bundles = catalog.packs.map((pack, bundleIndex) => {
      const deckIds = [];
      (pack.decks || []).forEach((deck) => {
        const key = String(deck.id || "").toLowerCase();
        if (!seenDeckIds.has(key)) {
          seenDeckIds.add(key);
          decks.push({ ...deck, order: decks.length + 1 });
        }
        deckIds.push(deck.id);
      });
      const bundle = {
        id: pack.id,
        order: bundleIndex + 1,
        title: pack.title,
        description: typeof pack.description === "string" ? pack.description : "",
        access: pack.access,
        deckIds,
      };
      if ("price" in pack) bundle.price = pack.price;
      return bundle;
    });
    return migrateCatalog({
      schemaVersion: 3,
      revision: catalog.revision,
      updatedAt: catalog.updatedAt,
      decks,
      bundles,
    });
  }

  function validateCommerceFields(value, path, label, targetType, errors) {
    if (value.access !== "free" && value.access !== "paid") {
      errors.push({ path: `${path}.access`, message: `${label} access must be either "free" or "paid".` });
    }
    if ("price" in value) {
      const roundedPrice = Math.round(value.price * 100) / 100;
      if (
        value.access !== "paid" ||
        typeof value.price !== "number" ||
        !Number.isFinite(value.price) ||
        value.price < 0 ||
        value.price > 99999.99 ||
        Math.abs(value.price - roundedPrice) > Number.EPSILON
      ) {
        errors.push({
          path: `${path}.price`,
          message: `${label} price is optional for paid items, must be 0-99999.99 with at most two decimal places, and cannot be set when access is free.`,
        });
      }
    }
    if (!("storeProducts" in value)) return;
    if (!value.storeProducts || typeof value.storeProducts !== "object" || Array.isArray(value.storeProducts)) {
      errors.push({ path: `${path}.storeProducts`, message: `${label} store products must be an object.` });
      return;
    }
    if (value.access !== "paid") {
      errors.push({ path: `${path}.storeProducts`, message: `Free ${label.toLowerCase()}s cannot have store products.` });
    }
    Object.entries(value.storeProducts).forEach(([platform, mapping]) => {
      const mappingPath = `${path}.storeProducts.${platform}`;
      if (!["apple", "google"].includes(platform)) {
        errors.push({ path: mappingPath, message: "Store platform must be apple or google." });
        return;
      }
      if (!mapping || typeof mapping !== "object" || Array.isArray(mapping)) {
        errors.push({ path: mappingPath, message: "Store-product mapping must be an object." });
        return;
      }
      if (typeof mapping.productId !== "string" || !/^[A-Za-z0-9._-]{1,100}$/.test(mapping.productId)) {
        errors.push({ path: `${mappingPath}.productId`, message: "Store product ID is invalid." });
      } else if (platform === "apple" && mapping.productId !== `com.cadelawless.whatzit.${targetType}.${value.id.replaceAll("_", "__").replaceAll("-", "_")}`) {
        errors.push({ path: `${mappingPath}.productId`, message: "Apple product ID does not match the permanent catalog convention." });
      } else if (platform === "google" && !/^[a-z0-9][a-z0-9._]{0,39}$/.test(mapping.productId)) {
        errors.push({ path: `${mappingPath}.productId`, message: "Google product ID must use at most 40 lowercase letters, numbers, periods, or underscores." });
      }
      if (!["draft", "available", "retired"].includes(mapping.status)) {
        errors.push({ path: `${mappingPath}.status`, message: "Store product status is invalid." });
      }
      const tiers = mapping.ownedDeckCountProducts ?? {};
      if (!tiers || typeof tiers !== "object" || Array.isArray(tiers)) {
        errors.push({ path: `${mappingPath}.ownedDeckCountProducts`, message: "Bundle discount products must be an object." });
        return;
      }
      Object.entries(tiers).forEach(([ownedCount, tier]) => {
        const tierPath = `${mappingPath}.ownedDeckCountProducts.${ownedCount}`;
        if (targetType !== "bundle" || !/^[1-9]\d*$/.test(ownedCount) || Number(ownedCount) >= value.deckIds.length) {
          errors.push({ path: tierPath, message: "Discount tiers must use a partial owned-deck count." });
          return;
        }
        const expected = `${mapping.productId}.owned_${ownedCount}`;
        if (!tier || typeof tier !== "object" || Array.isArray(tier)) {
          errors.push({ path: tierPath, message: "A discount product must be an object." });
        } else {
          if (typeof tier.productId !== "string" || !/^[A-Za-z0-9._-]{1,100}$/.test(tier.productId)) {
            errors.push({ path: `${tierPath}.productId`, message: "Discount product ID is invalid." });
          } else if (platform === "apple" && tier.productId !== expected) {
            errors.push({ path: `${tierPath}.productId`, message: `Apple discount product ID must be ${expected}.` });
          } else if (platform === "google" && !/^[a-z0-9][a-z0-9._]{0,39}$/.test(tier.productId)) {
            errors.push({ path: `${tierPath}.productId`, message: "Google discount product ID must use at most 40 lowercase letters, numbers, periods, or underscores." });
          }
          if (!["draft", "available", "retired"].includes(tier.status)) {
            errors.push({ path: `${tierPath}.status`, message: "Discount product status is invalid." });
          }
        }
      });
    });
  }

  function validateCatalog(catalog) {
    const errors = [];
    if (!catalog || typeof catalog !== "object" || Array.isArray(catalog)) {
      return [{ path: "$", message: "The JSON root must be an object." }];
    }
    if (catalog.schemaVersion !== 5) errors.push({ path: "schemaVersion", message: "schemaVersion must be 5." });
    if (!Number.isInteger(catalog.revision) || catalog.revision < 0) errors.push({ path: "revision", message: "revision must be a non-negative integer." });
    if (typeof catalog.updatedAt !== "string" || !/^\d{4}-\d{2}-\d{2}T\d{2}:\d{2}:\d{2}Z$/.test(catalog.updatedAt)) {
      errors.push({ path: "updatedAt", message: "updatedAt must be an ISO-8601 UTC timestamp." });
    }
    if (!Array.isArray(catalog.decks)) {
      errors.push({ path: "decks", message: "decks must be an array." });
      return errors;
    }
    const deckIds = new Set();
    const decksById = new Map();
    const coverPaths = new Set();
    catalog.decks.forEach((deck, deckIndex) => {
      const path = `decks[${deckIndex}]`;
      if (!deck || typeof deck !== "object" || Array.isArray(deck)) {
        errors.push({ path, message: "Each deck must be an object." });
        return;
      }
      if (!validId(deck.id)) errors.push({ path: `${path}.id`, message: "Deck ID must use letters, numbers, dashes, or underscores." });
      else if (deckIds.has(deck.id.toLowerCase())) errors.push({ path: `${path}.id`, message: `Duplicate deck ID: ${deck.id}.` });
      else {
        deckIds.add(deck.id.toLowerCase());
        decksById.set(deck.id.toLowerCase(), deck);
      }
      if (deck.order !== deckIndex + 1) errors.push({ path: `${path}.order`, message: "Deck orders must be sequential, starting at 1." });
      if (typeof deck.title !== "string" || !deck.title.trim()) errors.push({ path: `${path}.title`, message: "Deck title cannot be blank." });
      if (typeof deck.description !== "string" || hasControlCharacters(deck.description)) errors.push({ path: `${path}.description`, message: "Deck description must be safe text." });
      if (!Number.isInteger(deck.version) || deck.version < 1) errors.push({ path: `${path}.version`, message: "Deck version must be a positive integer." });
      if (
        typeof deck.coverImage !== "string" ||
        (deck.coverImage && !/^assets\/images\/decks\/[A-Za-z0-9][A-Za-z0-9_-]*\.(webp|png|jpe?g)$/i.test(deck.coverImage))
      ) errors.push({ path: `${path}.coverImage`, message: "coverImage must be empty or an app-relative deck-image path." });
      else if (deck.coverImage) {
        const coverKey = deck.coverImage.toLowerCase();
        if (coverPaths.has(coverKey)) errors.push({ path: `${path}.coverImage`, message: `Each deck must use a unique cover image filename: ${deck.coverImage}.` });
        else coverPaths.add(coverKey);
      }
      if (!Array.isArray(deck.tags) || deck.tags.some((tag) => typeof tag !== "string" || !tag.trim() || hasControlCharacters(tag))) {
        errors.push({ path: `${path}.tags`, message: "tags must be nonblank safe strings." });
      }
      validateCommerceFields(deck, path, "Deck", "deck", errors);
      if (!Array.isArray(deck.cards)) {
        errors.push({ path: `${path}.cards`, message: "cards must be an array." });
        return;
      }
      const cardIds = new Set();
      const featuredOrders = new Set();
      deck.cards.forEach((card, cardIndex) => {
        const cardPath = `${path}.cards[${cardIndex}]`;
        if (!card || typeof card !== "object" || Array.isArray(card)) {
          errors.push({ path: cardPath, message: "Each card must be an object." });
          return;
        }
        if (!validId(card.id)) errors.push({ path: `${cardPath}.id`, message: "Card ID must use letters, numbers, dashes, or underscores." });
        else if (cardIds.has(card.id.toLowerCase())) errors.push({ path: `${cardPath}.id`, message: `Duplicate card ID in this deck: ${card.id}.` });
        else cardIds.add(card.id.toLowerCase());
        if (typeof card.text !== "string" || !card.text.trim() || hasControlCharacters(card.text)) {
          errors.push({ path: `${cardPath}.text`, message: "Card text cannot be blank or contain control characters." });
        }
        if ("byline" in card && (typeof card.byline !== "string" || hasControlCharacters(card.byline))) {
          errors.push({ path: `${cardPath}.byline`, message: "Byline must be safe text." });
        }
        if ("featuredOrder" in card) {
          if (!Number.isInteger(card.featuredOrder) || card.featuredOrder < 1) {
            errors.push({ path: `${cardPath}.featuredOrder`, message: "Featured order must be a positive integer." });
          } else if (featuredOrders.has(card.featuredOrder)) {
            errors.push({ path: `${cardPath}.featuredOrder`, message: `Featured order ${card.featuredOrder} is already in use in this deck.` });
          } else {
            featuredOrders.add(card.featuredOrder);
          }
        }
      });
    });
    if (!Array.isArray(catalog.bundles)) {
      errors.push({ path: "bundles", message: "bundles must be an array." });
      return errors;
    }
    const bundleIds = new Set();
    catalog.bundles.forEach((bundle, bundleIndex) => {
      const bundlePath = `bundles[${bundleIndex}]`;
      if (!bundle || typeof bundle !== "object" || Array.isArray(bundle)) {
        errors.push({ path: bundlePath, message: "Each bundle must be an object." });
        return;
      }
      if (!validId(bundle.id)) errors.push({ path: `${bundlePath}.id`, message: "Bundle ID must use letters, numbers, dashes, or underscores." });
      else if (bundleIds.has(bundle.id.toLowerCase())) errors.push({ path: `${bundlePath}.id`, message: `Duplicate bundle ID: ${bundle.id}.` });
      else bundleIds.add(bundle.id.toLowerCase());
      if (bundle.order !== bundleIndex + 1) errors.push({ path: `${bundlePath}.order`, message: "Bundle orders must be sequential, starting at 1." });
      if (typeof bundle.title !== "string" || !bundle.title.trim()) errors.push({ path: `${bundlePath}.title`, message: "Bundle title cannot be blank." });
      if ("description" in bundle && (
        typeof bundle.description !== "string" ||
        bundle.description.length > 500 ||
        hasControlCharacters(bundle.description)
      )) {
        errors.push({ path: `${bundlePath}.description`, message: "Bundle description must be safe text." });
      }
      validateCommerceFields(bundle, bundlePath, "Bundle", "bundle", errors);
      if (!Array.isArray(bundle.deckIds)) {
        errors.push({ path: `${bundlePath}.deckIds`, message: "Bundle deckIds must be an array." });
        return;
      }
      const memberIds = new Set();
      bundle.deckIds.forEach((deckId, memberIndex) => {
        const memberPath = `${bundlePath}.deckIds[${memberIndex}]`;
        if (!validId(deckId)) errors.push({ path: memberPath, message: "Bundle deck references must be stable deck IDs." });
        else if (memberIds.has(deckId.toLowerCase())) errors.push({ path: memberPath, message: `Duplicate deck reference in this bundle: ${deckId}.` });
        else if (!deckIds.has(deckId.toLowerCase())) errors.push({ path: memberPath, message: `Bundle references unknown deck ID: ${deckId}.` });
        else if (bundle.id === "free-bundle" && decksById.get(deckId.toLowerCase())?.access !== "free") {
          errors.push({ path: memberPath, message: "Free Bundle may contain free decks only." });
        }
        memberIds.add(String(deckId).toLowerCase());
      });
    });
    const freeBundles = catalog.bundles.filter((bundle) => bundle?.id === "free-bundle");
    if (freeBundles.length !== 1) {
      errors.push({ path: "bundles", message: "Catalog must contain exactly one bundle with the stable ID free-bundle." });
    } else if (freeBundles[0].access !== "free") {
      errors.push({ path: `bundles[${catalog.bundles.indexOf(freeBundles[0])}].access`, message: "Free Bundle access must remain free." });
    }
    if (!catalog.deckOrders || typeof catalog.deckOrders !== "object" || Array.isArray(catalog.deckOrders)) {
      errors.push({ path: "deckOrders", message: "deckOrders must define free and paid arrays." });
      return errors;
    }
    Object.keys(catalog.deckOrders).forEach((scope) => {
      if (!["free", "paid"].includes(scope)) {
        errors.push({ path: `deckOrders.${scope}`, message: "deckOrders supports free and paid arrays only." });
      }
    });
    const expectedOrders = {
      free: catalog.decks.filter((deck) => deck.access === "free").map((deck) => deck.id),
      paid: catalog.decks.filter((deck) => deck.access === "paid").map((deck) => deck.id),
    };
    Object.entries(expectedOrders).forEach(([scope, expectedIds]) => {
      const path = `deckOrders.${scope}`;
      const order = catalog.deckOrders[scope];
      if (!Array.isArray(order)) {
        errors.push({ path, message: `${scope} deck order must be an array.` });
        return;
      }
      const seen = new Set();
      order.forEach((deckId, index) => {
        const itemPath = `${path}[${index}]`;
        if (!validId(deckId)) errors.push({ path: itemPath, message: "Deck order entries must be stable deck IDs." });
        else if (seen.has(deckId.toLowerCase())) errors.push({ path: itemPath, message: `Duplicate deck in ${scope} order: ${deckId}.` });
        else if (!deckIds.has(deckId.toLowerCase())) errors.push({ path: itemPath, message: `Unknown deck in ${scope} order: ${deckId}.` });
        seen.add(String(deckId).toLowerCase());
      });
      const expected = new Set(expectedIds.map((id) => id.toLowerCase()));
      if (order.length !== expected.size || order.some((id) => !expected.has(String(id).toLowerCase()))) {
        errors.push({ path, message: `${scope} deck order must contain every eligible deck exactly once.` });
      }
    });
    return errors;
  }

  function emptyCatalog() {
    return {
      schemaVersion: 5,
      revision: 0,
      updatedAt: new Date().toISOString().replace(/\.\d{3}Z$/, "Z"),
      decks: [],
      bundles: [{
        id: "free-bundle",
        order: 1,
        title: "Free Bundle",
        description: "",
        access: "free",
        deckIds: [],
      }],
      deckOrders: {
        free: [],
        paid: [],
      },
    };
  }

  function catalogKind(path) {
    const value = normalizeRelativePath(path);
    if (/\.json$/i.test(value)) return "json";
    if (/\.ts$/i.test(value)) return "typescript";
    throw new Error("The catalog path must end with .ts or .json.");
  }

  function managedSection(source, startMarker, endMarker) {
    const start = source.indexOf(startMarker);
    const end = source.lastIndexOf(endMarker);
    if (start < 0 || end < 0 || end <= start) {
      throw new Error(`The TypeScript catalog is missing its managed ${startMarker.includes("CATALOG") ? "catalog" : "cover registry"} markers.`);
    }
    return source.slice(start + startMarker.length, end).trim();
  }

  function parseCatalogDocument(source, path = DEFAULT_CATALOG_PATH) {
    const parsed = catalogKind(path) === "json"
      ? JSON.parse(source)
      : JSON.parse(managedSection(source, CATALOG_START, CATALOG_END));
    return migrateCatalog(parsed);
  }

  function renderCoverRegistry(catalog) {
    const paths = [...new Set(catalogDeckEntries(catalog).map(({ deck }) => deck.coverImage).filter(Boolean))].sort();
    return `{\n${paths.map((path) => `  ${JSON.stringify(path)}: require(${JSON.stringify(`../../${path}`)}),`).join("\n")}\n}`;
  }

  function stringifyManagedCatalog(catalog) {
    const lines = [
      "{",
      `  "schemaVersion": ${JSON.stringify(catalog.schemaVersion)},`,
      `  "revision": ${JSON.stringify(catalog.revision)},`,
      `  "updatedAt": ${JSON.stringify(catalog.updatedAt)},`,
      '  "decks": [',
    ];
    (catalog.decks || []).forEach((deck, deckIndex) => {
      lines.push(
        "    {",
        `      "id": ${JSON.stringify(deck.id)},`,
        `      "order": ${JSON.stringify(deck.order)},`,
        `      "title": ${JSON.stringify(deck.title)},`,
        `      "description": ${JSON.stringify(deck.description)},`,
        `      "coverImage": ${JSON.stringify(deck.coverImage)},`,
        `      "version": ${JSON.stringify(deck.version)},`,
        `      "tags": ${JSON.stringify(deck.tags)},`,
        `      "access": ${JSON.stringify(deck.access)},`,
      );
      if ("cardContentVersion" in deck) lines.push(`      "cardContentVersion": ${JSON.stringify(deck.cardContentVersion)},`);
      if ("cardCount" in deck) lines.push(`      "cardCount": ${JSON.stringify(deck.cardCount)},`);
      if ("storeProducts" in deck) lines.push(`      "storeProducts": ${JSON.stringify(deck.storeProducts)},`);
      if ("price" in deck) lines.push(`      "price": ${JSON.stringify(deck.price)},`);
      lines.push('      "cards": [');
      (deck.cards || []).forEach((card, cardIndex) => {
        const suffix = cardIndex === deck.cards.length - 1 ? "" : ",";
        lines.push(`        ${JSON.stringify(card)}${suffix}`);
      });
      lines.push("      ]", `    }${deckIndex === catalog.decks.length - 1 ? "" : ","}`);
    });
    lines.push('  ],', '  "bundles": [');
    (catalog.bundles || []).forEach((bundle, bundleIndex) => {
      lines.push(
        "    {",
        `      "id": ${JSON.stringify(bundle.id)},`,
        `      "order": ${JSON.stringify(bundle.order)},`,
        `      "title": ${JSON.stringify(bundle.title)},`,
        `      "description": ${JSON.stringify(bundle.description || "")},`,
        `      "access": ${JSON.stringify(bundle.access)},`,
      );
      if ("version" in bundle) lines.push(`      "version": ${JSON.stringify(bundle.version)},`);
      if ("storeProducts" in bundle) lines.push(`      "storeProducts": ${JSON.stringify(bundle.storeProducts)},`);
      if ("price" in bundle) lines.push(`      "price": ${JSON.stringify(bundle.price)},`);
      lines.push(
        `      "deckIds": ${JSON.stringify(bundle.deckIds || [])}`,
        `    }${bundleIndex === catalog.bundles.length - 1 ? "" : ","}`,
      );
    });
    lines.push(
      "  ],",
      '  "deckOrders": {',
      `    "free": ${JSON.stringify(catalog.deckOrders?.free || [])},`,
      `    "paid": ${JSON.stringify(catalog.deckOrders?.paid || [])}`,
      "  }",
      "}",
    );
    return lines.join("\n");
  }

  function replaceManagedSection(source, startMarker, endMarker, value) {
    const start = source.indexOf(startMarker);
    const end = source.lastIndexOf(endMarker);
    if (start < 0 || end < 0 || end <= start) return null;
    return `${source.slice(0, start + startMarker.length)}\n${value}\n${source.slice(end)}`;
  }

  function renderTypeScriptCatalog(catalog) {
    return `import type { Bundle, Deck } from '@/types/deck';

type PortableDeck = Omit<Deck, 'coverImage'> & {
  coverImage?: string;
  tags: string[];
  cardCount?: number;
  cardContentVersion?: number;
};

type PortableBundle = Omit<Bundle, 'decks'> & {
  version?: number;
};

type PortableCatalog = {
  schemaVersion: 5;
  revision: number;
  updatedAt: string;
  decks: PortableDeck[];
  bundles: PortableBundle[];
  deckOrders: {
    free: string[];
    paid: string[];
  };
};

const bundleCatalog: PortableCatalog =
${CATALOG_START}
${stringifyManagedCatalog(catalog)}
${CATALOG_END};

const deckCoverImages: Record<string, number> =
${COVERS_START}
${renderCoverRegistry(catalog)}
${COVERS_END};

export type StandaloneDeck = Deck;

export const decks: StandaloneDeck[] = bundleCatalog.decks.map((deck) => ({
    id: deck.id,
    order: deck.order,
    title: deck.title,
    description: deck.description,
    version: deck.version,
    access: deck.access,
    ...("price" in deck ? { price: deck.price } : {}),
    ...("storeProducts" in deck ? { storeProducts: deck.storeProducts } : {}),
    cards: deck.cards,
    ...(deck.coverImage ? { coverImage: deckCoverImages[deck.coverImage] } : {}),
}));

const decksById = new Map(decks.map((deck) => [deck.id, deck]));

export const bundles: Bundle[] = bundleCatalog.bundles.map((bundle) => ({
  ...bundle,
  decks: bundle.deckIds
    .map((deckId) => decksById.get(deckId))
    .filter((deck): deck is StandaloneDeck => Boolean(deck)),
}));

const bundlesById = new Map(bundles.map((bundle) => [bundle.id, bundle]));

const orderedDecks = (deckIds: string[]) =>
  deckIds
    .map((deckId) => decksById.get(deckId))
    .filter((deck): deck is StandaloneDeck => Boolean(deck));

export const FREE_BUNDLE_ID = 'free-bundle';
export const freeBundleDecks = bundlesById.get(FREE_BUNDLE_ID)?.decks ?? [];
export const paidDecks = orderedDecks(bundleCatalog.deckOrders.paid);

export function getDeckById(deckId: string | undefined) {
  return deckId ? decksById.get(deckId) : undefined;
}

export function getBundleById(bundleId: string | undefined) {
  return bundleId ? bundlesById.get(bundleId) : undefined;
}

export function getBundlesForDeck(deckId: string | undefined) {
  if (!deckId) return [];
  return bundles.filter((bundle) => bundle.deckIds.includes(deckId));
}
`;
  }

  function serializeCatalogDocument(catalog, path = DEFAULT_CATALOG_PATH, existingSource = "") {
    if (catalogKind(path) === "json") return `${JSON.stringify(catalog, null, 2)}\n`;
    if (!existingSource) return renderTypeScriptCatalog(catalog);
    if (
      /\bconst\s+packCatalog\s*:\s*PortableCatalog\b/.test(existingSource) ||
      /\bschemaVersion\s*:\s*[234]\s*;/.test(existingSource)
    ) {
      // Earlier TypeScript modules encoded their data shape throughout the
      // generated runtime, not only inside the managed JSON markers.
      // Regenerate the module so its code and catalog migrate
      // atomically. The coordinated save has already backed up the exact file.
      return renderTypeScriptCatalog(catalog);
    }
    const withCatalog = replaceManagedSection(
      existingSource,
      CATALOG_START,
      CATALOG_END,
      stringifyManagedCatalog(catalog),
    );
    if (!withCatalog) throw new Error("The TypeScript file is not managed by Deck Manager and will not be overwritten.");
    const withCovers = replaceManagedSection(
      withCatalog,
      COVERS_START,
      COVERS_END,
      renderCoverRegistry(catalog),
    );
    if (!withCovers) throw new Error("The TypeScript cover registry markers are missing; the file will not be overwritten.");
    return withCovers;
  }

  function openDatabase() {
    if (typeof indexedDB === "undefined") throw new Error("IndexedDB is required to remember repository access and backups.");
    return new Promise((resolve, reject) => {
      const request = indexedDB.open(DATABASE_NAME, DATABASE_VERSION);
      request.onupgradeneeded = () => {
        const database = request.result;
        if (!database.objectStoreNames.contains("settings")) database.createObjectStore("settings");
        if (!database.objectStoreNames.contains("backups")) {
          const backups = database.createObjectStore("backups", { keyPath: "id" });
          backups.createIndex("appKey", "appKey", { unique: false });
        }
        if (!database.objectStoreNames.contains("stashes")) {
          database.createObjectStore("stashes", { keyPath: "id" });
        }
      };
      request.onsuccess = () => resolve(request.result);
      request.onerror = () => reject(request.error || new Error("Unable to open browser storage."));
    });
  }

  async function databaseRequest(storeName, mode, callback) {
    const database = await openDatabase();
    return new Promise((resolve, reject) => {
      const transaction = database.transaction(storeName, mode);
      const store = transaction.objectStore(storeName);
      let request;
      try {
        request = callback(store);
      } catch (error) {
        database.close();
        reject(error);
        return;
      }
      request.onsuccess = () => resolve(request.result);
      request.onerror = () => reject(request.error || new Error("Browser storage request failed."));
      transaction.oncomplete = () => database.close();
      transaction.onerror = () => {
        database.close();
        reject(transaction.error || new Error("Browser storage transaction failed."));
      };
    });
  }

  const connectionStore = {
    save(value) {
      return databaseRequest("settings", "readwrite", (store) => store.put(value, CONNECTION_KEY));
    },
    load() {
      return databaseRequest("settings", "readonly", (store) => store.get(CONNECTION_KEY));
    },
    clear() {
      return databaseRequest("settings", "readwrite", (store) => store.delete(CONNECTION_KEY));
    },
  };

  const backupStore = {
    put(value) {
      return databaseRequest("backups", "readwrite", (store) => store.put(value));
    },
    async list(appKey, jsonPath) {
      const all = await databaseRequest("backups", "readonly", (store) => store.getAll());
      return (all || [])
        .filter((item) => item.appKey === appKey && item.jsonPath === jsonPath)
        .sort((a, b) => String(b.createdAt).localeCompare(String(a.createdAt)));
    },
    get(id) {
      return databaseRequest("backups", "readonly", (store) => store.get(id));
    },
  };

  const stashStore = {
    put(value) {
      return databaseRequest("stashes", "readwrite", (store) => store.put(value));
    },
    get(id) {
      return databaseRequest("stashes", "readonly", (store) => store.get(id));
    },
    delete(id) {
      return databaseRequest("stashes", "readwrite", (store) => store.delete(id));
    },
  };

  async function verifyPermission(handle, request = false) {
    const options = { mode: "readwrite" };
    if ((await handle.queryPermission(options)) === "granted") return true;
    if (!request) return false;
    return (await handle.requestPermission(options)) === "granted";
  }

  class Repository {
    constructor(rootHandle, jsonPath = DEFAULT_JSON_PATH) {
      this.rootHandle = rootHandle;
      this.jsonPath = normalizeRelativePath(jsonPath || DEFAULT_JSON_PATH);
      catalogKind(this.jsonPath);
      this.imageDirectoryPath = IMAGE_DIRECTORY;
      this.appKey = "";
      this.limits = { maxFileBytes: 10 * 1024 * 1024, maxWidth: 6000, maxHeight: 6000 };
    }

    async validate({ requestPermission = false } = {}) {
      if (!(await verifyPermission(this.rootHandle, requestPermission))) {
        return {
          connected: false,
          permissionRequired: true,
          errors: ["Read/write permission is required for the selected repository."],
          warnings: [],
          appRoot: `${this.rootHandle.name} (permission required)`,
          jsonPath: this.jsonPath,
          imageDirectory: IMAGE_DIRECTORY,
        };
      }
      const errors = [];
      const warnings = [];
      let packageFile;
      try {
        packageFile = await (await this.rootHandle.getFileHandle("package.json")).getFile();
      } catch {
        errors.push("The selected folder is missing package.json.");
      }
      try {
        await this.rootHandle.getDirectoryHandle("src");
      } catch {
        errors.push("The selected folder is missing the expected src directory.");
      }
      try {
        await getDirectoryHandle(this.rootHandle, IMAGE_DIRECTORY);
      } catch {
        errors.push("The selected folder is missing assets/images/decks.");
      }
      let jsonExists = true;
      try {
        await getFileHandle(this.rootHandle, this.jsonPath);
      } catch {
        jsonExists = false;
        warnings.push("The selected bundle catalog does not exist. It will not be created during a connection test.");
        try {
          const parts = this.jsonPath.split("/");
          parts.pop();
          await getDirectoryHandle(this.rootHandle, parts.join("/"));
        } catch {
          errors.push("The parent directory for the selected bundle catalog does not exist.");
        }
      }
      this.appKey = `${this.rootHandle.name}:${packageFile ? (await sha256(packageFile)).slice(0, 20) : "unknown"}`;
      return {
        connected: errors.length === 0,
        errors,
        warnings,
        jsonExists,
        appRoot: `${this.rootHandle.name} (browser-granted folder)`,
        jsonPath: this.jsonPath,
        imageDirectory: IMAGE_DIRECTORY,
        appIdentity: this.appKey,
        limits: this.limits,
      };
    }

    async saveConnection() {
      await connectionStore.save({
        rootHandle: this.rootHandle,
        jsonPath: this.jsonPath,
        savedAt: new Date().toISOString(),
      });
    }

    static async resume() {
      const saved = await connectionStore.load();
      if (!saved?.rootHandle) return null;
      let savedPath = saved.jsonPath || DEFAULT_CATALOG_PATH;
      if (LEGACY_CATALOG_PATHS.includes(savedPath.toLowerCase())) {
        try {
          await getFileHandle(saved.rootHandle, savedPath);
        } catch {
          try {
            await getFileHandle(saved.rootHandle, DEFAULT_CATALOG_PATH);
            savedPath = DEFAULT_CATALOG_PATH;
            await connectionStore.save({ ...saved, jsonPath: savedPath, migratedAt: new Date().toISOString() });
          } catch {
            // Keep the user's saved path when the new default does not exist or
            // the browser needs permission again.
          }
        }
      }
      return new Repository(saved.rootHandle, savedPath);
    }

    async readCatalog() {
      let handle;
      try {
        handle = await getFileHandle(this.rootHandle, this.jsonPath);
      } catch {
        return {
          exists: false,
          valid: false,
          catalog: null,
          errors: [{ path: "$", message: "The selected bundle catalog file does not exist." }],
          snapshot: null,
        };
      }
      const file = await handle.getFile();
      const text = await file.text();
      let catalog;
      try {
        catalog = parseCatalogDocument(text, this.jsonPath);
      } catch (error) {
        return {
          exists: true,
          valid: false,
          catalog: null,
          errors: [{ path: "$", message: `Catalog parse error in ${this.jsonPath}: ${error.message}` }],
          snapshot: await fileSnapshot(handle),
        };
      }
      const errors = validateCatalog(catalog);
      return {
        exists: true,
        valid: errors.length === 0,
        catalog,
        errors,
        snapshot: await fileSnapshot(handle, catalog),
      };
    }

    async scanImages(catalog = null) {
      const directory = await getDirectoryHandle(this.rootHandle, IMAGE_DIRECTORY);
      const references = new Map();
      for (const { deck } of catalogDeckEntries(catalog)) {
        if (!deck.coverImage) continue;
        const filename = deck.coverImage.split("/").pop();
        const key = filename.toLowerCase();
        if (!references.has(key)) references.set(key, []);
        references.get(key).push({ id: deck.id, title: deck.title });
      }
      const images = [];
      for await (const [filename, handle] of directory.entries()) {
        if (handle.kind !== "file" || !/\.(webp|png|jpe?g)$/i.test(filename)) continue;
        try {
          const file = await handle.getFile();
          const signature = detectImageSignature(await file.slice(0, 16).arrayBuffer());
          if (!signature) continue;
          const dimensions = await imageDimensions(file);
          const imageReferences = references.get(filename.toLowerCase()) || [];
          images.push({
            filename,
            relativePath: `${IMAGE_DIRECTORY}/${filename}`,
            mime: signature,
            width: dimensions.width,
            height: dimensions.height,
            size: file.size,
            hash: await sha256(file),
            references: imageReferences,
            orphaned: imageReferences.length === 0,
            file,
          });
        } catch {
          // An unreadable or malformed image is omitted and will be reported as
          // missing if the catalog references it.
        }
      }
      return images.sort((a, b) => a.filename.localeCompare(b.filename, undefined, { sensitivity: "base" }));
    }

    async loadState() {
      const connection = await this.validate();
      if (!connection.connected) {
        return { connected: false, connection, catalog: null, catalogValid: false, catalogErrors: [], snapshot: null, images: [], backups: [] };
      }
      const loaded = await this.readCatalog();
      const catalog = loaded.catalog && typeof loaded.catalog === "object" ? loaded.catalog : null;
      const images = await this.scanImages(catalog);
      const known = new Set(images.map((image) => image.relativePath.toLowerCase()));
      const missing = [];
      for (const { deck, path } of catalogDeckEntries(catalog)) {
        if (deck.coverImage && !known.has(deck.coverImage.toLowerCase())) {
          missing.push({ path: `${path}.coverImage`, message: `Referenced image is missing: ${deck.coverImage}` });
        }
      }
      return {
        connected: true,
        connection,
        catalog,
        catalogValid: loaded.valid && missing.length === 0,
        catalogErrors: [...loaded.errors, ...missing],
        snapshot: loaded.snapshot,
        images,
        backups: await backupStore.list(this.appKey, this.jsonPath),
        lastModified: loaded.snapshot?.mtime ? new Date(loaded.snapshot.mtime).toISOString() : null,
      };
    }

    async createCatalog() {
      const validation = await this.validate({ requestPermission: true });
      if (!validation.connected) throw new Error(validation.errors.join(" "));
      try {
        await getFileHandle(this.rootHandle, this.jsonPath);
        throw new Error("The selected catalog file now exists. Reload it instead.");
      } catch (error) {
        if (error.message.includes("now exists")) throw error;
      }
      const handle = await getFileHandle(this.rootHandle, this.jsonPath, true);
      await this.writeFile(handle, serializeCatalogDocument(emptyCatalog(), this.jsonPath));
      return this.loadState();
    }

    async writeFile(handle, value) {
      const writable = await handle.createWritable({ keepExistingData: false });
      try {
        await writable.write(value);
        await writable.close();
      } catch (error) {
        try { await writable.abort(); } catch {}
        throw error;
      }
    }

    async assertSnapshot(expected) {
      if (!expected?.hash) throw new Error("The loaded catalog revision is unavailable. Reload before saving.");
      const handle = await getFileHandle(this.rootHandle, this.jsonPath);
      const actual = await fileSnapshot(handle);
      if (actual.hash !== expected.hash || actual.size !== expected.size) {
        const error = new Error("The bundle catalog changed on disk after it was loaded. Reload before saving.");
        error.conflict = true;
        throw error;
      }
    }

    async projectedImageNames(operations) {
      const images = await this.scanImages();
      const names = new Map(images.map((image) => [image.filename.toLowerCase(), image.filename]));
      for (const operation of operations) {
        if (operation.type === "add" || operation.type === "replace") names.set(operation.filename.toLowerCase(), operation.filename);
        if (operation.type === "rename") {
          names.delete(operation.from.toLowerCase());
          names.set(operation.to.toLowerCase(), operation.to);
        }
        if (operation.type === "remove") names.delete(operation.filename.toLowerCase());
      }
      return names;
    }

    async validateOperations(operations) {
      const diskImages = await this.scanImages();
      const known = new Map(diskImages.map((image) => [image.filename.toLowerCase(), image]));
      const normalized = [];
      const targeted = new Set();
      for (const original of operations) {
        const operation = { ...original };
        if (!["add", "replace", "rename", "remove"].includes(operation.type)) throw new Error("An image operation has an unsupported type.");
        if (operation.type === "add" || operation.type === "replace") {
          operation.filename = safeImageFilename(operation.filename);
          if (!(operation.file instanceof Blob)) throw new Error(`The staged image ${operation.filename} is no longer available. Select it again.`);
          const key = operation.filename.toLowerCase();
          if (targeted.has(key)) throw new Error(`More than one operation targets ${operation.filename}.`);
          if (operation.type === "add" && known.has(key)) throw new Error(`Image ${operation.filename} already exists.`);
          if (operation.type === "replace") {
            const current = known.get(key);
            if (!current) throw new Error(`Image ${operation.filename} no longer exists.`);
            if (current.hash !== operation.expectedHash) {
              const error = new Error(`Image ${operation.filename} changed on disk after it was loaded.`);
              error.conflict = true;
              throw error;
            }
          }
          known.set(key, { filename: operation.filename, hash: operation.hash });
          targeted.add(key);
        } else if (operation.type === "rename") {
          operation.from = safeImageFilename(operation.from);
          operation.to = safeImageFilename(operation.to);
          const fromKey = operation.from.toLowerCase();
          const toKey = operation.to.toLowerCase();
          const current = known.get(fromKey);
          if (!current) throw new Error(`Image ${operation.from} no longer exists.`);
          if (current.hash !== operation.expectedHash) {
            const error = new Error(`Image ${operation.from} changed on disk after it was loaded.`);
            error.conflict = true;
              throw error;
          }
          if (fromKey === toKey && operation.from !== operation.to) {
            throw new Error("Case-only image renames are not supported. Rename to a temporary filename, save, then rename again.");
          }
          if (fromKey !== toKey && known.has(toKey)) throw new Error(`Image ${operation.to} already exists.`);
          known.delete(fromKey);
          known.set(toKey, { filename: operation.to, hash: current.hash });
          targeted.add(toKey);
        } else {
          operation.filename = safeImageFilename(operation.filename);
          const key = operation.filename.toLowerCase();
          const current = known.get(key);
          if (!current) throw new Error(`Image ${operation.filename} no longer exists.`);
          if (current.hash !== operation.expectedHash) {
            const error = new Error(`Image ${operation.filename} changed on disk after it was loaded.`);
            error.conflict = true;
            throw error;
          }
          known.delete(key);
        }
        normalized.push(operation);
      }
      return normalized;
    }

    async createBackup(affectedFilenames, summary, kind = "save") {
      let jsonExisted = true;
      let jsonText = null;
      let revision = null;
      try {
        const file = await (await getFileHandle(this.rootHandle, this.jsonPath)).getFile();
        jsonText = await file.text();
        try { revision = parseCatalogDocument(jsonText, this.jsonPath).revision ?? null; } catch {}
      } catch {
        jsonExisted = false;
      }
      const directory = await getDirectoryHandle(this.rootHandle, IMAGE_DIRECTORY);
      const files = [];
      for (const filename of [...new Set(affectedFilenames)]) {
        try {
          const file = await (await directory.getFileHandle(filename)).getFile();
          files.push({ filename, existed: true, blob: file, hash: await sha256(file) });
        } catch {
          files.push({ filename, existed: false, blob: null, hash: null });
        }
      }
      const now = new Date();
      const backup = {
        id: `${now.toISOString().replace(/[-:.]/g, "")}-${crypto.randomUUID().slice(0, 8)}`,
        appKey: this.appKey,
        jsonPath: this.jsonPath,
        createdAt: now.toISOString(),
        kind,
        revision,
        jsonExisted,
        jsonText,
        files,
        summary,
      };
      await backupStore.put(backup);
      return backup;
    }

    async applyImageWrites(operations) {
      const directory = await getDirectoryHandle(this.rootHandle, IMAGE_DIRECTORY);
      for (const operation of operations.filter((item) => item.type === "rename")) {
        const sourceFile = await (await directory.getFileHandle(operation.from)).getFile();
        const destination = await directory.getFileHandle(operation.to, { create: true });
        await this.writeFile(destination, sourceFile);
        await directory.removeEntry(operation.from);
      }
      for (const operation of operations.filter((item) => item.type === "add" || item.type === "replace")) {
        const destination = await directory.getFileHandle(operation.filename, { create: true });
        await this.writeFile(destination, operation.file);
      }
    }

    async applyImageRemovals(operations) {
      const directory = await getDirectoryHandle(this.rootHandle, IMAGE_DIRECTORY);
      for (const operation of operations.filter((item) => item.type === "remove")) {
        await directory.removeEntry(operation.filename);
      }
    }

    async applyBackup(backup) {
      if (backup.jsonExisted) {
        const handle = await getFileHandle(this.rootHandle, this.jsonPath, true);
        await this.writeFile(handle, backup.jsonText);
      } else {
        const parts = this.jsonPath.split("/");
        const filename = parts.pop();
        const directory = parts.length ? await getDirectoryHandle(this.rootHandle, parts.join("/")) : this.rootHandle;
        try { await directory.removeEntry(filename); } catch {}
      }
      const imageDirectory = await getDirectoryHandle(this.rootHandle, IMAGE_DIRECTORY);
      for (const entry of backup.files || []) {
        if (entry.existed) {
          const handle = await imageDirectory.getFileHandle(entry.filename, { create: true });
          await this.writeFile(handle, entry.blob);
        } else {
          try { await imageDirectory.removeEntry(entry.filename); } catch {}
        }
      }
    }

    async save(catalog, baseSnapshot, imageOperations, summary) {
      const validation = await this.validate({ requestPermission: true });
      if (!validation.connected) throw new Error(validation.errors.join(" "));
      await this.assertSnapshot(baseSnapshot);
      const operations = await this.validateOperations(imageOperations);
      const nextCatalog = JSON.parse(JSON.stringify(catalog));
      nextCatalog.schemaVersion = 5;
      nextCatalog.revision = Number(baseSnapshot.revision || 0) + 1;
      nextCatalog.updatedAt = new Date().toISOString().replace(/\.\d{3}Z$/, "Z");
      nextCatalog.decks.forEach((deck, index) => { deck.order = index + 1; });
      nextCatalog.bundles.forEach((bundle, index) => { bundle.order = index + 1; });
      const errors = validateCatalog(nextCatalog);
      if (errors.length) {
        const error = new Error("The catalog has blocking validation errors.");
        error.validationErrors = errors;
        throw error;
      }
      const projected = await this.projectedImageNames(operations);
      const missing = catalogDeckEntries(nextCatalog)
        .filter(({ deck }) => deck.coverImage && !projected.has(deck.coverImage.split("/").pop().toLowerCase()))
        .map(({ deck, path }) => ({ path: `${path}.coverImage`, message: `${deck.title} → ${deck.coverImage}` }));
      if (missing.length) {
        const error = new Error("Referenced deck images are missing.");
        error.validationErrors = missing;
        throw error;
      }
      const affected = operations.flatMap((operation) => operation.type === "rename" ? [operation.from, operation.to] : [operation.filename]);
      const backup = await this.createBackup(affected, summary, "save");
      try {
        await this.applyImageWrites(operations);
        const jsonHandle = await getFileHandle(this.rootHandle, this.jsonPath);
        const currentSource = await (await jsonHandle.getFile()).text();
        await this.writeFile(jsonHandle, serializeCatalogDocument(nextCatalog, this.jsonPath, currentSource));
        await this.applyImageRemovals(operations);
        const verified = await this.readCatalog();
        if (!verified.valid || !equivalentJson(verified.catalog, nextCatalog)) {
          const error = new Error("The saved catalog could not be verified.");
          error.validationErrors = verified.errors || [];
          throw error;
        }
        const verifiedImages = await this.scanImages(nextCatalog);
        const known = new Set(verifiedImages.map((image) => image.relativePath.toLowerCase()));
        if (catalogDeckEntries(nextCatalog).some(({ deck }) => deck.coverImage && !known.has(deck.coverImage.toLowerCase()))) {
          throw new Error("A cover reference did not resolve after saving.");
        }
        return {
          catalog: nextCatalog,
          snapshot: verified.snapshot,
          images: verifiedImages,
          backup,
          backups: await backupStore.list(this.appKey, this.jsonPath),
        };
      } catch (error) {
        try { await this.applyBackup(backup); } catch (rollbackError) {
          error.message += ` Rollback also failed: ${rollbackError.message}`;
        }
        throw error;
      }
    }

    async restore(backupId, baseSnapshot) {
      await this.assertSnapshot(baseSnapshot);
      const backup = await backupStore.get(backupId);
      if (!backup || backup.appKey !== this.appKey || backup.jsonPath !== this.jsonPath) {
        throw new Error("This backup does not belong to the connected repository and catalog file.");
      }
      const affected = (backup.files || []).map((entry) => entry.filename);
      const safety = await this.createBackup(affected, { label: `Safety backup before restoring ${backupId}` }, "pre-restore");
      try {
        await this.applyBackup(backup);
        const loaded = await this.readCatalog();
        if (!loaded.valid) throw new Error("The restored catalog did not pass validation.");
        const images = await this.scanImages(loaded.catalog);
        const known = new Set(images.map((image) => image.relativePath.toLowerCase()));
        if (catalogDeckEntries(loaded.catalog).some(({ deck }) => deck.coverImage && !known.has(deck.coverImage.toLowerCase()))) {
          throw new Error("A restored cover reference does not resolve.");
        }
        return {
          catalog: loaded.catalog,
          snapshot: loaded.snapshot,
          images,
          backup: safety,
          backups: await backupStore.list(this.appKey, this.jsonPath),
        };
      } catch (error) {
        try { await this.applyBackup(safety); } catch {}
        throw error;
      }
    }
  }

  function parseImport(format, input, existingCards = [], delimiterEnabled = true, delimiter = "|") {
    const rows = format === "csv" ? parseCsv(input) : parsePlain(input, delimiterEnabled, delimiter);
    const existingIds = new Set(existingCards.map((card) => String(card.id || "").toLowerCase()).filter(Boolean));
    const existingText = new Set(existingCards.map((card) => String(card.text || "").trim().toLocaleLowerCase()).filter(Boolean));
    const seenIds = new Set();
    const seenText = new Set();
    const cards = [];
    const errors = [];
    const warnings = [];
    rows.forEach((row, index) => {
      const number = index + 1;
      const text = String(row.text || "").trim();
      const byline = String(row.byline || "").trim();
      let id = String(row.id || "").trim();
      if (!text) {
        errors.push(`Row ${number} has blank card text.`);
        return;
      }
      if (id && !validId(id)) {
        errors.push(`Row ${number} has an invalid card ID.`);
        return;
      }
      if (id && (existingIds.has(id.toLowerCase()) || seenIds.has(id.toLowerCase()))) {
        errors.push(`Row ${number} duplicates card ID "${id}".`);
        return;
      }
      const textKey = text.toLocaleLowerCase();
      if (existingText.has(textKey) || seenText.has(textKey)) warnings.push(`Row ${number} duplicates existing card text.`);
      if (!id) {
        const base = text.toLowerCase().replace(/[^a-z0-9]+/g, "-").replace(/^-|-$/g, "").slice(0, 72) || "card";
        id = base;
        let suffix = 2;
        while (existingIds.has(id.toLowerCase()) || seenIds.has(id.toLowerCase())) id = `${base}-${suffix++}`;
        warnings.push(`Row ${number} will use generated ID "${id}".`);
      }
      const card = { id, text };
      if (byline) card.byline = byline;
      cards.push(card);
      seenIds.add(id.toLowerCase());
      seenText.add(textKey);
    });
    return { cards, errors, warnings: [...new Set(warnings)], rowCount: rows.length, validCount: cards.length };
  }

  function parsePlain(input, delimiterEnabled, delimiter) {
    return String(input || "").split(/\r?\n/).filter((line) => line.trim()).map((line) => {
      if (delimiterEnabled && delimiter && line.includes(delimiter)) {
        const index = line.indexOf(delimiter);
        return { id: "", text: line.slice(0, index).trim(), byline: line.slice(index + delimiter.length).trim() };
      }
      return { id: "", text: line.trim(), byline: "" };
    });
  }

  function parseCsv(input) {
    const records = [];
    let record = [];
    let field = "";
    let quoted = false;
    const value = String(input || "");
    for (let index = 0; index <= value.length; index++) {
      const character = value[index] ?? "\n";
      if (quoted) {
        if (character === '"' && value[index + 1] === '"') {
          field += '"';
          index++;
        } else if (character === '"') quoted = false;
        else field += character;
      } else if (character === '"') quoted = true;
      else if (character === ",") {
        record.push(field);
        field = "";
      } else if (character === "\n") {
        record.push(field.replace(/\r$/, ""));
        field = "";
        if (record.some((item) => item !== "")) records.push(record);
        record = [];
      } else field += character;
    }
    if (quoted) throw new Error("CSV input has an unterminated quoted field.");
    if (!records.length) return [];
    const header = records.shift().map((item) => item.trim().toLowerCase());
    if (!header.includes("text")) throw new Error("CSV input must include a text column.");
    return records.map((values) => {
      const row = { id: "", text: "", byline: "" };
      header.forEach((name, index) => {
        if (name in row) row[name] = values[index] || "";
      });
      return row;
    });
  }

  return {
    IMAGE_DIRECTORY,
    DEFAULT_CATALOG_PATH,
    DEFAULT_JSON_PATH,
    Repository,
    connectionStore,
    backupStore,
    stashStore,
    normalizeRelativePath,
    slugifyId,
    safeImageFilename,
    appleBundleScenarioProducts,
    planDeckCoverCleanup,
    detectImageSignature,
    inspectImageFile,
    snapshotImageFile,
    validateCatalog,
    equivalentJson,
    emptyCatalog,
    parseCatalogDocument,
    serializeCatalogDocument,
    renderTypeScriptCatalog,
    parseImport,
    sha256,
  };
});
