# Deck platform implementation decisions and staging evidence

Last updated: 2026-08-11

This record covers only the additive database/read-service foundation. The
mobile app and Deck Manager continue to use the checked-in TypeScript catalog
and GitHub publishing path.

## Confirmed for this slice

- MySQL/MariaDB is accessed only by PHP through `mysqli`; the mobile app never
  receives database credentials.
- Database settings come from server environment variables or the existing
  external PHP configuration file. No credentials are committed.
- Migrations are ordered, checksummed, and forward-only. Test commands reject a
  database name that is not explicitly recognizable as a test database.
- Revision 32 is imported without changing stable IDs, source ordering, legacy
  entity versions, cards, prices, bundle membership, or media references.
- Public artifacts are immutable and content-addressed. The discovery manifest
  contains no cards. Only free deck card artifacts are emitted publicly.
- The manifest is written last, after every referenced immutable file exists.
- Existing GitHub publication remains the production write path until the
  database path has parity coverage, a rollout flag, and a demonstrated
  rollback procedure.

## Deployment values still required

The following must be confirmed in Hostinger before this service can be
deployed or treated as production-ready:

- MySQL/MariaDB product/version, storage and connection limits, database name,
  provisioned user permissions, TLS support, and backup retention/restore
  procedure;
- production PHP version and availability of `mysqli`, `mysqlnd`, GD/WebP,
  `hash`, and JSON extensions;
- the HTTPS API base URL, HTTPS content base URL, public document root, and an
  absolute artifact directory layout;
- whether immutable files are served directly by Apache or through PHP;
- a database-and-media backup schedule and a tested restore location; and
- the old-app/content-schema compatibility window and final
  `minimumAppVersion` value.

Until those are supplied, local URLs are development-only, the manifest leaves
`minimumAppVersion` unset, and no production migration should be run.

Commerce, accounts, cross-platform ownership, bundle entitlement policy,
refund grace behavior, and store integrations remain deliberately out of scope
for this slice.

## Hostinger staging environment confirmed 2026-08-12

- Staging API origin: `https://api-staging.playwhatzit.com`
- Public document root:
  `/home/ACCOUNT/domains/playwhatzit.com/public_html/api-staging`
- Private service/artifact root:
  `/home/ACCOUNT/domains/playwhatzit.com/whatzit-platform-staging`
- Database: dedicated staging database `ACCOUNT_whatzit_test`, accessed by
  PHP through Hostinger's documented local hostname `localhost`; Remote MySQL
  remains disabled.
- Runtime: PHP 8.3.30 with `mysqli`, `mysqlnd`, GD, JSON, and hash extensions.
- Deployment access: SSH on port 65002 with a dedicated local administration
  key. Secrets remain in an external mode-600 `config.local.php` outside
  `public_html`.
- Migration 001, initial schema-5 revision-32 import, and artifact generation
  completed successfully on 2026-08-12. Generated staging manifest SHA-256:
  `e95a0367eba1c20026b0773f56b4d874758af96e93763835bc490646fc1fa814`.
- Database export reproduced the source catalog byte-for-byte with catalog
  SHA-256 `4fe43030bec19ce48bafc7a5985433af0679d76a782b29ebe5c2611b94a38734`
  (20 decks, 2 bundles, and 3,814 cards).
- The public manifest returned revision 32 with a matching SHA-256 and honored
  conditional requests with `304 Not Modified`. A free revision-1 artifact
  returned `200` with all 304 cards for `celebrity-shuffle`; the paid
  `life-your-voice` artifact returned typed `403 entitlement_required` without
  exposing cards.

Hostinger reports weekly file/database backups with approximately two months of
retention for this hosting account. The newly created staging database was not
yet present in historical backups on 2026-08-12; its next scheduled backup was
due the same day. A restore drill remains pending until that first backup is
available. The drill must restore a downloaded copy into a separate disposable
`*_test` database and must not overwrite the working staging database.

Still unresolved before production: exact hosting resource limits, successful
database/media restore drill, production origin, compatibility window, and
production database/user provisioning.

## Hostinger Phase 2 publication drill confirmed 2026-08-12

- Migration 002 applied repeatably and created the draft, preparation, and
  publication-event tables without changing the active revision-32 catalog or
  its public manifest.
- A persisted draft advanced from draft version 1 to 2. A deliberately stale
  save was rejected, the draft was discarded, and the active catalog remained
  revision 32.
- An intentionally blocked immutable-artifact promotion produced a failed
  preparation for target revision 33. The preparing database revision was
  removed, no publication event was recorded, and revision 32 remained public.
- A metadata-only edit to `celebrity-shuffle` published atomically as revision
  33. Its deck version advanced from 1 to 2 while card-content version 1 and
  the content hash remained unchanged. The public manifest SHA-256 was
  `3ff1c1bff1127e5cdc6bf6516f59e053ccaf1f561b6d268712a5b513b5837c7f`.
- Forward rollback restored revision 32's catalog content as new revision 34.
  Revision 33 became retired, the rollback event linked source revision 33 to
  historical revision 32, and normalized exported catalog parity was exact.
  `celebrity-shuffle` advanced monotonically to deck version 3 while retaining
  card-content version 1. The active revision-34 manifest SHA-256 is
  `d50de74ce4d625ed3f1fab5b5e2877f370fe53395fc3df606fb75f98a30bd3b8`.
- Conditional manifest requests continued returning `304`, free content
  remained available, no active test draft remained, and the intentional
  failed preparation remained visible through operational status.

This drill demonstrates draft conflict handling, failed-preparation
containment, automatic version assignment, atomic publication, audit history,
and forward rollback on Hostinger staging. It does not enable the database
Deck Manager path: `WHATZIT_DECK_MANAGER_STORAGE` remains `github`, the browser
manager still publishes through GitHub, and the mobile app remains unchanged.

## Hostinger Phase 2C adapter drill confirmed 2026-08-12

- The external platform configuration moved to the mode-600
  `whatzit-secrets/deck-platform-config.php` location outside deployed service
  code and now declares the private seed/media root used by authoring.
- The database manager adapter loaded revision 34 through the legacy-compatible
  state envelope with 20 decks, 2 bundles, 20 covers, and 2 publication-history
  records. Its optimistic snapshot identified database storage, draft ID,
  draft version 1, and base revision 34.
- A draft-only metadata edit returned a complete replacement snapshot at draft
  version 2. Reusing the stale version-1 snapshot was rejected, and active
  catalog revision 34 did not change.
- Adapter history returned revision 34 as a rollback sourced from revision 33
  and revision 33 as a publish sourced from revision 32. Historical exports of
  revisions 32 and 34 retained exact normalized catalog parity.
- Discarding the edited draft returned a new clean version-1 draft based on
  revision 34 with the test marker removed. The replacement test draft was
  then discarded, leaving zero active drafts and revision 34 active.

This validates the database service adapter directly on Hostinger. It does not
constitute browser/API rollout: `WHATZIT_DECK_MANAGER_STORAGE` remains
`github`, the hosted Deck Manager HTTP dispatcher has not been switched, and
the existing GitHub path remains the recovery path.

## Hostinger Phase 2D media drill confirmed 2026-08-12

- The Phase 2D package deployed without migrations or an active-catalog
  change. Revision 34 and its manifest SHA-256
  `d50de74ce4d625ed3f1fab5b5e2877f370fe53395fc3df606fb75f98a30bd3b8`
  remained active before the drill.
- A same-filename replacement of `celebrity-shuffle.webp` published atomically
  as revision 35. The deck version advanced from 3 to 4 while card-content
  version 1 and its content hash remained unchanged. The cover hash changed
  from `cf3562120ddb63dc7c96aea4dcfe328bc4128f516c5f1f8a0840e931938dec4d`
  to `a14f062357246feb51f3bd23a1f91e3782daf7a3f5a2c10368dbf1e6f8640f65`;
  both immutable cover URLs returned bytes matching their hashes. Revision
  35's manifest SHA-256 was
  `7daf3cd92e592052fa30a81fbc3b87ce68cfbaac7f5d5619d8d3b72af4a319d6`.
- Forward rollback of historical revision 34 published as revision 36. It
  restored the exact original cover hash under the unchanged filename,
  advanced the deck version monotonically from 4 to 5, and left card-content
  version and hash unchanged. The audit event records source revision 35,
  rollback target 34, and administrator `phase2d-test`. Revision 36's manifest
  SHA-256 is
  `e8abc0e452e8e89e985142cf072d2da579a345d8bf5e44f0e72893e7cc1e7e40`.
- The private media preparation was removed after publication, leaving zero
  media workspaces and zero active drafts. The seed copy of
  `celebrity-shuffle.webp` retained the original SHA-256, proving that staging
  and rollback did not mutate the configured seed directory.

This validates private cover projection, same-path byte changes, immutable
media history, media-aware versioning, cleanup, and exact historical cover
restoration on Hostinger. Database browser rollout is still disabled:
`WHATZIT_DECK_MANAGER_STORAGE` remains `github`, so the established GitHub
Deck Manager continues to be the active authoring and recovery path.

## Hostinger Phase 2E browser drill confirmed 2026-08-12

- A separate `manager-staging.playwhatzit.com` document root loaded the
  database-backed Deck Manager using a mode-600 combined configuration outside
  `public_html`. The existing production Deck Manager configuration and its
  default GitHub storage path were not changed.
- GitHub authentication completed successfully on the staging origin. The
  authenticated browser loaded all database decks, bundles, cards, covers, and
  publication history at active revision 36.
- A metadata edit autosaved as a versioned database draft, survived a browser
  refresh, and did not change the public revision. Navigation stopped warning
  after a successful autosave while retaining warnings for pending, failed,
  conflicted, media-only, and legacy GitHub browser changes.
- Two tabs attempted to save the same draft version. The first save succeeded,
  the stale second save was rejected without overwriting it, and Get Latest
  recovered the persisted server draft. Discard Draft removed all test markers
  without publication.
- A controlled browser metadata publication advanced revision 36 to revision
  37. Restoring historical revision 36 through the browser created new forward
  revision 38, removed the test marker, retained monotonic history, and left no
  unpublished draft changes.
- Database history timestamps are stored and transmitted as explicit UTC and
  rendered in the administrator's browser-local timezone. Existing history is
  converted without rewriting immutable audit rows.

This completes browser parity for persisted metadata drafts, optimistic
conflict handling, recovery, publication, audit display, and forward rollback
on the isolated staging manager. Production remains on the existing GitHub
Deck Manager path until authentication replacement, backup/restore evidence,
and the remaining production rollout requirements are satisfied.

## Hostinger Phase 2F local authentication confirmed 2026-08-12

- Migration 003 added one enabled administrator slot and persistent,
  privacy-preserving login-attempt throttling. The administrator password is
  stored only as PHP's current `PASSWORD_DEFAULT` hash and can be provisioned
  or reset only through the SSH command-line tool.
- The manager-staging configuration now selects database storage and local
  authentication, contains a private rate-limit hashing secret, and contains
  zero GitHub configuration keys. It remains mode 600 outside `public_html`.
- The staging manager presents the custom WHATZ IT? username/password page,
  rejects incorrect credentials, rotates into an authenticated session after a
  valid login, loads active revision 38, and returns to the custom login page
  on explicit logout. No GitHub authorization or connection is requested.
- Hostinger directory password protection was removed only from the isolated
  manager-staging document root after the application login passed. A private
  browser session reaches the custom application login directly without an
  HTTP Basic Authentication popup. Production directory protection was
  restored and remains separate.

This completes the database Deck Manager authentication replacement on
staging. The legacy production manager remains untouched during the rollout
window, but it is not exposed as an authentication option or fallback inside
the database manager.

## Phase 4 Apple commerce foundation recorded 2026-08-14

- Apple deck and bundle purchases use non-consumable In-App Purchases. Permanent
  identifiers are derived from the app bundle namespace and stable catalog ID:
  `com.cadelawless.whatzit.deck.<deck_id>` and
  `com.cadelawless.whatzit.bundle.<bundle_id>`. Hyphens in stable catalog IDs
  are converted to underscores because App Store Connect's live IAP form
  rejects hyphens even though its current help page lists them as supported.
  Existing underscores are doubled first to keep this mapping one-to-one.
- The Expo SDK 57 native integration is `expo-iap` from the current OpenIAP
  project. StoreKit callbacks submit the StoreKit 2 signed transaction to the
  PHP API; only an authenticated App Store Server API lookup can grant the
  idempotent entitlement. The transaction is finished only after that grant.
  The integration requires a rebuilt development client before sandbox testing.
- Apple launches without a separate WHATZ IT? player account. A random
  installation identity/app-account UUID correlates transactions without PII;
  App Store restore/reconciliation may associate a verified purchase with a
  replacement installation after reinstall. Cross-platform ownership is not
  automatic and remains out of scope until a deliberate account policy exists.
- Bundle entitlements use current membership by default, so a later catalog
  addition becomes available to an existing bundle owner after reconciliation.
  Removing previously sold value must be an explicit reviewed migration and
  never silently revokes an already installed deck.
- A verified refund/revocation locks the entitlement on the next successful
  reconciliation. Content is retained initially rather than immediately
  deleted. An offline device retains its last verified state until reconnecting;
  no time-based offline lease is introduced in this slice.
- Migration 004 stores Apple transaction identifiers, hashes future Google
  purchase tokens, and stores only signed-payload hashes rather than raw signed
  receipts. Grants remain idempotent per installation/product and all grant,
  restore, reconciliation, refund, and revoke transitions are append-only.
- Google-compatible columns and constraints are additive, but Google product
  IDs and billing integration are not being created from an unverified naming
  assumption. Their convention will be recorded before any Play Console
  product is created.
- The implementation now includes additive staging-only verification,
  entitlement, restore, and protected-content routes plus keychain-backed
  installation credentials. It does not switch production routing or the
  database/GitHub manager rollback paths. A verified entitlement automatically
  downloads and hash-validates card content into SQLite so it remains playable
  after the first successful online preparation.
