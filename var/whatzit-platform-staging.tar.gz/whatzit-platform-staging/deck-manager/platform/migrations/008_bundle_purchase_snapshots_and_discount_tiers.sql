ALTER TABLE store_products
    ADD COLUMN owned_deck_count SMALLINT UNSIGNED NULL AFTER bundle_membership_policy,
    ADD CONSTRAINT chk_store_product_owned_count CHECK (
        (deck_id IS NOT NULL AND owned_deck_count IS NULL)
        OR (bundle_id IS NOT NULL AND (owned_deck_count IS NULL OR owned_deck_count > 0))
    );

UPDATE store_products
SET bundle_membership_policy = 'purchase_snapshot'
WHERE bundle_id IS NOT NULL;

CREATE UNIQUE INDEX uq_store_product_bundle_tier
    ON store_products (platform, bundle_id, owned_deck_count);

CREATE TABLE IF NOT EXISTS purchase_deck_grants (
    platform VARCHAR(10) CHARACTER SET ascii COLLATE ascii_bin NOT NULL,
    original_store_transaction_id VARCHAR(190) CHARACTER SET ascii COLLATE ascii_bin NOT NULL,
    deck_id VARCHAR(100) NOT NULL,
    source_transaction_pk BIGINT UNSIGNED NOT NULL,
    granted_at TIMESTAMP(6) NOT NULL DEFAULT CURRENT_TIMESTAMP(6),
    PRIMARY KEY (platform, original_store_transaction_id, deck_id),
    KEY idx_purchase_deck_grant_deck (deck_id, platform),
    KEY idx_purchase_deck_grant_transaction (source_transaction_pk),
    CONSTRAINT fk_purchase_deck_grant_deck FOREIGN KEY (deck_id)
        REFERENCES decks (deck_id),
    CONSTRAINT fk_purchase_deck_grant_transaction FOREIGN KEY (source_transaction_pk)
        REFERENCES store_transactions (store_transaction_pk),
    CONSTRAINT chk_purchase_deck_grant_platform CHECK (platform IN ('apple', 'google'))
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_bin;
