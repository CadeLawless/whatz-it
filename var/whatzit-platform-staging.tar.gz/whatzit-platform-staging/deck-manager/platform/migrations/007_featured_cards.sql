ALTER TABLE cards
    ADD COLUMN featured_order INT UNSIGNED NULL AFTER card_order,
    ADD UNIQUE KEY uq_card_featured_order (catalog_revision, deck_id, featured_order);
