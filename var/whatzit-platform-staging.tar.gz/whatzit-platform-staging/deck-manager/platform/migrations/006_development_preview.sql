CREATE TABLE IF NOT EXISTS development_previews (
    preview_id BIGINT UNSIGNED NOT NULL AUTO_INCREMENT,
    preview_revision BIGINT UNSIGNED NOT NULL,
    state ENUM('prepared', 'active', 'retired', 'failed') NOT NULL,
    draft_id BIGINT UNSIGNED NOT NULL,
    draft_version INT UNSIGNED NOT NULL,
    draft_hash CHAR(64) CHARACTER SET ascii COLLATE ascii_bin NOT NULL,
    catalog_json MEDIUMTEXT NOT NULL,
    manifest_hash CHAR(64) CHARACTER SET ascii COLLATE ascii_bin NOT NULL,
    created_by VARCHAR(100) CHARACTER SET utf8mb4 COLLATE utf8mb4_bin NOT NULL,
    created_at TIMESTAMP(6) NOT NULL DEFAULT CURRENT_TIMESTAMP(6),
    activated_at TIMESTAMP(6) NULL,
    PRIMARY KEY (preview_id),
    UNIQUE KEY uq_development_previews_revision (preview_revision),
    KEY idx_development_previews_state_created (state, created_at),
    CONSTRAINT fk_development_previews_draft FOREIGN KEY (draft_id)
        REFERENCES catalog_drafts (draft_id),
    CONSTRAINT chk_development_previews_hashes CHECK (
        draft_hash REGEXP '^[a-f0-9]{64}$'
        AND manifest_hash REGEXP '^[a-f0-9]{64}$'
    )
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_bin;
