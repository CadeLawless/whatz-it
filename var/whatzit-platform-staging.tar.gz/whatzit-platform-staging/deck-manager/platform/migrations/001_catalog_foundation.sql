CREATE TABLE IF NOT EXISTS schema_migrations (
    version INT UNSIGNED NOT NULL PRIMARY KEY,
    name VARCHAR(190) NOT NULL,
    checksum CHAR(64) CHARACTER SET ascii COLLATE ascii_bin NOT NULL,
    applied_at TIMESTAMP(6) NOT NULL DEFAULT CURRENT_TIMESTAMP(6)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_bin;

CREATE TABLE IF NOT EXISTS catalog_revisions (
    revision BIGINT UNSIGNED NOT NULL PRIMARY KEY,
    schema_version INT UNSIGNED NOT NULL,
    state VARCHAR(20) CHARACTER SET ascii COLLATE ascii_bin NOT NULL,
    source_updated_at CHAR(20) CHARACTER SET ascii COLLATE ascii_bin NOT NULL,
    source_hash CHAR(64) CHARACTER SET ascii COLLATE ascii_bin NOT NULL,
    manifest_hash CHAR(64) CHARACTER SET ascii COLLATE ascii_bin NULL,
    imported_at TIMESTAMP(6) NOT NULL DEFAULT CURRENT_TIMESTAMP(6),
    CONSTRAINT chk_catalog_revision_state CHECK (state IN ('preparing', 'active', 'retired'))
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_bin;

CREATE TABLE IF NOT EXISTS active_catalog_revision (
    singleton_id TINYINT UNSIGNED NOT NULL PRIMARY KEY,
    revision BIGINT UNSIGNED NOT NULL,
    CONSTRAINT chk_active_catalog_singleton CHECK (singleton_id = 1),
    CONSTRAINT fk_active_catalog_revision FOREIGN KEY (revision)
        REFERENCES catalog_revisions (revision)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_bin;

CREATE TABLE IF NOT EXISTS decks (
    deck_id VARCHAR(100) NOT NULL PRIMARY KEY,
    lifecycle_status VARCHAR(20) CHARACTER SET ascii COLLATE ascii_bin NOT NULL DEFAULT 'active',
    CONSTRAINT chk_deck_lifecycle CHECK (lifecycle_status IN ('active', 'retired'))
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_bin;

CREATE TABLE IF NOT EXISTS deck_revisions (
    catalog_revision BIGINT UNSIGNED NOT NULL,
    deck_id VARCHAR(100) NOT NULL,
    deck_version INT UNSIGNED NOT NULL,
    card_content_version INT UNSIGNED NOT NULL,
    catalog_order INT UNSIGNED NOT NULL,
    title VARCHAR(120) NOT NULL,
    description LONGTEXT NOT NULL,
    cover_path VARCHAR(512) NOT NULL,
    cover_hash CHAR(64) CHARACTER SET ascii COLLATE ascii_bin NULL,
    cover_bytes BIGINT UNSIGNED NULL,
    tags_json LONGTEXT NOT NULL,
    access_level VARCHAR(10) CHARACTER SET ascii COLLATE ascii_bin NOT NULL,
    price_cents INT UNSIGNED NULL,
    card_count INT UNSIGNED NOT NULL,
    content_hash CHAR(64) CHARACTER SET ascii COLLATE ascii_bin NOT NULL,
    content_bytes BIGINT UNSIGNED NOT NULL,
    PRIMARY KEY (catalog_revision, deck_id),
    UNIQUE KEY uq_deck_catalog_order (catalog_revision, catalog_order),
    CONSTRAINT fk_deck_revision_catalog FOREIGN KEY (catalog_revision)
        REFERENCES catalog_revisions (revision) ON DELETE CASCADE,
    CONSTRAINT fk_deck_revision_deck FOREIGN KEY (deck_id)
        REFERENCES decks (deck_id),
    CONSTRAINT chk_deck_access CHECK (access_level IN ('free', 'paid'))
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_bin;

CREATE TABLE IF NOT EXISTS cards (
    catalog_revision BIGINT UNSIGNED NOT NULL,
    deck_id VARCHAR(100) NOT NULL,
    card_id VARCHAR(100) NOT NULL,
    card_order INT UNSIGNED NOT NULL,
    text_value LONGTEXT NOT NULL,
    has_byline TINYINT(1) NOT NULL DEFAULT 0,
    byline LONGTEXT NULL,
    PRIMARY KEY (catalog_revision, deck_id, card_id),
    UNIQUE KEY uq_card_order (catalog_revision, deck_id, card_order),
    CONSTRAINT fk_card_deck_revision FOREIGN KEY (catalog_revision, deck_id)
        REFERENCES deck_revisions (catalog_revision, deck_id) ON DELETE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_bin;

CREATE TABLE IF NOT EXISTS deck_orders (
    catalog_revision BIGINT UNSIGNED NOT NULL,
    access_level VARCHAR(10) CHARACTER SET ascii COLLATE ascii_bin NOT NULL,
    position INT UNSIGNED NOT NULL,
    deck_id VARCHAR(100) NOT NULL,
    PRIMARY KEY (catalog_revision, access_level, position),
    UNIQUE KEY uq_deck_order_member (catalog_revision, access_level, deck_id),
    CONSTRAINT fk_deck_order_catalog FOREIGN KEY (catalog_revision)
        REFERENCES catalog_revisions (revision) ON DELETE CASCADE,
    CONSTRAINT fk_deck_order_deck FOREIGN KEY (deck_id)
        REFERENCES decks (deck_id),
    CONSTRAINT chk_deck_order_access CHECK (access_level IN ('free', 'paid'))
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_bin;

CREATE TABLE IF NOT EXISTS bundles (
    bundle_id VARCHAR(100) NOT NULL PRIMARY KEY,
    lifecycle_status VARCHAR(20) CHARACTER SET ascii COLLATE ascii_bin NOT NULL DEFAULT 'active',
    CONSTRAINT chk_bundle_lifecycle CHECK (lifecycle_status IN ('active', 'retired'))
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_bin;

CREATE TABLE IF NOT EXISTS bundle_revisions (
    catalog_revision BIGINT UNSIGNED NOT NULL,
    bundle_id VARCHAR(100) NOT NULL,
    bundle_version INT UNSIGNED NOT NULL,
    catalog_order INT UNSIGNED NOT NULL,
    title VARCHAR(120) NOT NULL,
    has_description TINYINT(1) NOT NULL DEFAULT 0,
    description VARCHAR(500) NULL,
    access_level VARCHAR(10) CHARACTER SET ascii COLLATE ascii_bin NOT NULL,
    price_cents INT UNSIGNED NULL,
    PRIMARY KEY (catalog_revision, bundle_id),
    UNIQUE KEY uq_bundle_catalog_order (catalog_revision, catalog_order),
    CONSTRAINT fk_bundle_revision_catalog FOREIGN KEY (catalog_revision)
        REFERENCES catalog_revisions (revision) ON DELETE CASCADE,
    CONSTRAINT fk_bundle_revision_bundle FOREIGN KEY (bundle_id)
        REFERENCES bundles (bundle_id),
    CONSTRAINT chk_bundle_access CHECK (access_level IN ('free', 'paid'))
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_bin;

CREATE TABLE IF NOT EXISTS bundle_decks (
    catalog_revision BIGINT UNSIGNED NOT NULL,
    bundle_id VARCHAR(100) NOT NULL,
    position INT UNSIGNED NOT NULL,
    deck_id VARCHAR(100) NOT NULL,
    PRIMARY KEY (catalog_revision, bundle_id, position),
    UNIQUE KEY uq_bundle_deck_member (catalog_revision, bundle_id, deck_id),
    CONSTRAINT fk_bundle_deck_revision FOREIGN KEY (catalog_revision, bundle_id)
        REFERENCES bundle_revisions (catalog_revision, bundle_id) ON DELETE CASCADE,
    CONSTRAINT fk_bundle_deck_deck FOREIGN KEY (deck_id)
        REFERENCES decks (deck_id)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_bin;

CREATE TABLE IF NOT EXISTS media_assets (
    asset_hash CHAR(64) CHARACTER SET ascii COLLATE ascii_bin NOT NULL PRIMARY KEY,
    asset_type VARCHAR(20) CHARACTER SET ascii COLLATE ascii_bin NOT NULL,
    mime_type VARCHAR(100) CHARACTER SET ascii COLLATE ascii_bin NOT NULL,
    byte_size BIGINT UNSIGNED NOT NULL,
    width INT UNSIGNED NULL,
    height INT UNSIGNED NULL,
    source_path VARCHAR(512) NOT NULL,
    created_at TIMESTAMP(6) NOT NULL DEFAULT CURRENT_TIMESTAMP(6),
    CONSTRAINT chk_media_type CHECK (asset_type IN ('cover', 'thumbnail', 'deck_content'))
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_bin;
