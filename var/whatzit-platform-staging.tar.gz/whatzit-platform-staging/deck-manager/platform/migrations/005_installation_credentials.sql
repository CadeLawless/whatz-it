ALTER TABLE app_installations
    ADD COLUMN credential_hash CHAR(64) CHARACTER SET ascii COLLATE ascii_bin NULL AFTER app_account_token,
    ADD UNIQUE KEY uq_app_installation_credential_hash (credential_hash);

