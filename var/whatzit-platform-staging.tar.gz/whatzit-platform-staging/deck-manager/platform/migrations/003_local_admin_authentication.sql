CREATE TABLE IF NOT EXISTS admin_users (
    admin_id TINYINT UNSIGNED NOT NULL DEFAULT 1,
    username VARCHAR(64) CHARACTER SET ascii COLLATE ascii_bin NOT NULL,
    password_hash VARCHAR(255) CHARACTER SET ascii COLLATE ascii_bin NOT NULL,
    enabled TINYINT(1) NOT NULL DEFAULT 1,
    password_changed_at TIMESTAMP(6) NOT NULL DEFAULT CURRENT_TIMESTAMP(6),
    created_at TIMESTAMP(6) NOT NULL DEFAULT CURRENT_TIMESTAMP(6),
    updated_at TIMESTAMP(6) NOT NULL DEFAULT CURRENT_TIMESTAMP(6) ON UPDATE CURRENT_TIMESTAMP(6),
    PRIMARY KEY (admin_id),
    UNIQUE KEY uq_admin_users_username (username),
    CONSTRAINT chk_admin_users_singleton CHECK (admin_id = 1),
    CONSTRAINT chk_admin_users_enabled CHECK (enabled IN (0, 1))
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_bin;

CREATE TABLE IF NOT EXISTS admin_login_attempts (
    attempt_id BIGINT UNSIGNED NOT NULL AUTO_INCREMENT,
    username_hash CHAR(64) CHARACTER SET ascii COLLATE ascii_bin NOT NULL,
    network_hash CHAR(64) CHARACTER SET ascii COLLATE ascii_bin NOT NULL,
    succeeded TINYINT(1) NOT NULL DEFAULT 0,
    attempted_at TIMESTAMP(6) NOT NULL DEFAULT CURRENT_TIMESTAMP(6),
    PRIMARY KEY (attempt_id),
    KEY idx_admin_login_username_time (username_hash, attempted_at),
    KEY idx_admin_login_network_time (network_hash, attempted_at),
    KEY idx_admin_login_cleanup (attempted_at),
    CONSTRAINT chk_admin_login_succeeded CHECK (succeeded IN (0, 1))
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_bin;
