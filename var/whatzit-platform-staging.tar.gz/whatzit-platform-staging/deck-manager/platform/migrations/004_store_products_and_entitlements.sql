CREATE TABLE IF NOT EXISTS store_products (
    store_product_pk BIGINT UNSIGNED NOT NULL AUTO_INCREMENT,
    platform VARCHAR(10) CHARACTER SET ascii COLLATE ascii_bin NOT NULL,
    store_product_id VARCHAR(100) CHARACTER SET ascii COLLATE ascii_bin NOT NULL,
    product_type VARCHAR(24) CHARACTER SET ascii COLLATE ascii_bin NOT NULL DEFAULT 'non_consumable',
    deck_id VARCHAR(100) NULL,
    bundle_id VARCHAR(100) NULL,
    lifecycle_status VARCHAR(20) CHARACTER SET ascii COLLATE ascii_bin NOT NULL DEFAULT 'draft',
    bundle_membership_policy VARCHAR(32) CHARACTER SET ascii COLLATE ascii_bin NULL,
    created_at TIMESTAMP(6) NOT NULL DEFAULT CURRENT_TIMESTAMP(6),
    updated_at TIMESTAMP(6) NOT NULL DEFAULT CURRENT_TIMESTAMP(6) ON UPDATE CURRENT_TIMESTAMP(6),
    PRIMARY KEY (store_product_pk),
    UNIQUE KEY uq_store_product_identity (platform, store_product_id),
    KEY idx_store_product_deck (deck_id, platform, lifecycle_status),
    KEY idx_store_product_bundle (bundle_id, platform, lifecycle_status),
    CONSTRAINT fk_store_product_deck FOREIGN KEY (deck_id)
        REFERENCES decks (deck_id),
    CONSTRAINT fk_store_product_bundle FOREIGN KEY (bundle_id)
        REFERENCES bundles (bundle_id),
    CONSTRAINT chk_store_product_platform CHECK (platform IN ('apple', 'google')),
    CONSTRAINT chk_store_product_type CHECK (product_type = 'non_consumable'),
    CONSTRAINT chk_store_product_target CHECK (
        (deck_id IS NOT NULL AND bundle_id IS NULL)
        OR (deck_id IS NULL AND bundle_id IS NOT NULL)
    ),
    CONSTRAINT chk_store_product_lifecycle CHECK (lifecycle_status IN ('draft', 'active', 'retired')),
    CONSTRAINT chk_store_product_bundle_policy CHECK (
        (deck_id IS NOT NULL AND bundle_membership_policy IS NULL)
        OR (bundle_id IS NOT NULL AND bundle_membership_policy IN ('current_membership', 'purchase_snapshot'))
    )
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_bin;

CREATE TABLE IF NOT EXISTS catalog_store_products (
    catalog_revision BIGINT UNSIGNED NOT NULL,
    store_product_pk BIGINT UNSIGNED NOT NULL,
    availability_status VARCHAR(20) CHARACTER SET ascii COLLATE ascii_bin NOT NULL DEFAULT 'draft',
    PRIMARY KEY (catalog_revision, store_product_pk),
    KEY idx_catalog_store_product_product (store_product_pk, catalog_revision),
    CONSTRAINT fk_catalog_store_product_catalog FOREIGN KEY (catalog_revision)
        REFERENCES catalog_revisions (revision) ON DELETE CASCADE,
    CONSTRAINT fk_catalog_store_product_product FOREIGN KEY (store_product_pk)
        REFERENCES store_products (store_product_pk),
    CONSTRAINT chk_catalog_store_product_availability CHECK (
        availability_status IN ('draft', 'available', 'retired')
    )
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_bin;

CREATE TABLE IF NOT EXISTS app_installations (
    installation_id CHAR(36) CHARACTER SET ascii COLLATE ascii_bin NOT NULL,
    platform VARCHAR(10) CHARACTER SET ascii COLLATE ascii_bin NOT NULL,
    app_account_token CHAR(36) CHARACTER SET ascii COLLATE ascii_bin NOT NULL,
    status VARCHAR(20) CHARACTER SET ascii COLLATE ascii_bin NOT NULL DEFAULT 'active',
    created_at TIMESTAMP(6) NOT NULL DEFAULT CURRENT_TIMESTAMP(6),
    last_seen_at TIMESTAMP(6) NOT NULL DEFAULT CURRENT_TIMESTAMP(6),
    PRIMARY KEY (installation_id),
    UNIQUE KEY uq_app_installation_account_token (app_account_token),
    KEY idx_app_installation_platform_status (platform, status),
    CONSTRAINT chk_app_installation_platform CHECK (platform IN ('apple', 'google')),
    CONSTRAINT chk_app_installation_status CHECK (status IN ('active', 'disabled'))
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_bin;

CREATE TABLE IF NOT EXISTS store_transactions (
    store_transaction_pk BIGINT UNSIGNED NOT NULL AUTO_INCREMENT,
    platform VARCHAR(10) CHARACTER SET ascii COLLATE ascii_bin NOT NULL,
    store_product_pk BIGINT UNSIGNED NOT NULL,
    installation_id CHAR(36) CHARACTER SET ascii COLLATE ascii_bin NULL,
    store_transaction_id VARCHAR(190) CHARACTER SET ascii COLLATE ascii_bin NULL,
    original_store_transaction_id VARCHAR(190) CHARACTER SET ascii COLLATE ascii_bin NULL,
    purchase_token_hash CHAR(64) CHARACTER SET ascii COLLATE ascii_bin NULL,
    store_environment VARCHAR(12) CHARACTER SET ascii COLLATE ascii_bin NOT NULL,
    transaction_state VARCHAR(20) CHARACTER SET ascii COLLATE ascii_bin NOT NULL,
    verification_code VARCHAR(64) CHARACTER SET ascii COLLATE ascii_bin NOT NULL,
    signed_payload_hash CHAR(64) CHARACTER SET ascii COLLATE ascii_bin NULL,
    purchased_at TIMESTAMP(6) NULL,
    revoked_at TIMESTAMP(6) NULL,
    verified_at TIMESTAMP(6) NOT NULL DEFAULT CURRENT_TIMESTAMP(6),
    created_at TIMESTAMP(6) NOT NULL DEFAULT CURRENT_TIMESTAMP(6),
    updated_at TIMESTAMP(6) NOT NULL DEFAULT CURRENT_TIMESTAMP(6) ON UPDATE CURRENT_TIMESTAMP(6),
    PRIMARY KEY (store_transaction_pk),
    UNIQUE KEY uq_store_transaction_id (platform, store_transaction_id),
    UNIQUE KEY uq_store_purchase_token_hash (platform, purchase_token_hash),
    KEY idx_store_transaction_product (store_product_pk, transaction_state),
    KEY idx_store_transaction_installation (installation_id, verified_at),
    KEY idx_store_transaction_original (platform, original_store_transaction_id),
    CONSTRAINT fk_store_transaction_product FOREIGN KEY (store_product_pk)
        REFERENCES store_products (store_product_pk),
    CONSTRAINT fk_store_transaction_installation FOREIGN KEY (installation_id)
        REFERENCES app_installations (installation_id),
    CONSTRAINT chk_store_transaction_platform CHECK (platform IN ('apple', 'google')),
    CONSTRAINT chk_store_transaction_environment CHECK (store_environment IN ('sandbox', 'production')),
    CONSTRAINT chk_store_transaction_state CHECK (
        transaction_state IN ('pending', 'verified', 'refunded', 'revoked')
    ),
    CONSTRAINT chk_store_transaction_identity CHECK (
        (platform = 'apple' AND store_transaction_id IS NOT NULL AND purchase_token_hash IS NULL)
        OR (platform = 'google' AND store_transaction_id IS NULL AND purchase_token_hash IS NOT NULL)
    )
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_bin;

CREATE TABLE IF NOT EXISTS entitlements (
    entitlement_id BIGINT UNSIGNED NOT NULL AUTO_INCREMENT,
    installation_id CHAR(36) CHARACTER SET ascii COLLATE ascii_bin NOT NULL,
    store_product_pk BIGINT UNSIGNED NOT NULL,
    source_transaction_pk BIGINT UNSIGNED NOT NULL,
    entitlement_state VARCHAR(20) CHARACTER SET ascii COLLATE ascii_bin NOT NULL,
    grant_reason VARCHAR(20) CHARACTER SET ascii COLLATE ascii_bin NOT NULL,
    granted_at TIMESTAMP(6) NOT NULL DEFAULT CURRENT_TIMESTAMP(6),
    last_verified_at TIMESTAMP(6) NOT NULL DEFAULT CURRENT_TIMESTAMP(6),
    revoked_at TIMESTAMP(6) NULL,
    created_at TIMESTAMP(6) NOT NULL DEFAULT CURRENT_TIMESTAMP(6),
    updated_at TIMESTAMP(6) NOT NULL DEFAULT CURRENT_TIMESTAMP(6) ON UPDATE CURRENT_TIMESTAMP(6),
    PRIMARY KEY (entitlement_id),
    UNIQUE KEY uq_entitlement_installation_product (installation_id, store_product_pk),
    KEY idx_entitlement_product_state (store_product_pk, entitlement_state),
    KEY idx_entitlement_source_transaction (source_transaction_pk),
    CONSTRAINT fk_entitlement_installation FOREIGN KEY (installation_id)
        REFERENCES app_installations (installation_id),
    CONSTRAINT fk_entitlement_product FOREIGN KEY (store_product_pk)
        REFERENCES store_products (store_product_pk),
    CONSTRAINT fk_entitlement_source_transaction FOREIGN KEY (source_transaction_pk)
        REFERENCES store_transactions (store_transaction_pk),
    CONSTRAINT chk_entitlement_state CHECK (entitlement_state IN ('active', 'revoked')),
    CONSTRAINT chk_entitlement_grant_reason CHECK (grant_reason IN ('purchase', 'restore', 'reconciliation'))
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_bin;

CREATE TABLE IF NOT EXISTS entitlement_events (
    entitlement_event_id BIGINT UNSIGNED NOT NULL AUTO_INCREMENT,
    entitlement_id BIGINT UNSIGNED NOT NULL,
    store_transaction_pk BIGINT UNSIGNED NULL,
    event_type VARCHAR(20) CHARACTER SET ascii COLLATE ascii_bin NOT NULL,
    reason_code VARCHAR(64) CHARACTER SET ascii COLLATE ascii_bin NOT NULL,
    details_json LONGTEXT NULL,
    occurred_at TIMESTAMP(6) NOT NULL DEFAULT CURRENT_TIMESTAMP(6),
    PRIMARY KEY (entitlement_event_id),
    KEY idx_entitlement_event_entitlement (entitlement_id, occurred_at),
    KEY idx_entitlement_event_transaction (store_transaction_pk),
    CONSTRAINT fk_entitlement_event_entitlement FOREIGN KEY (entitlement_id)
        REFERENCES entitlements (entitlement_id),
    CONSTRAINT fk_entitlement_event_transaction FOREIGN KEY (store_transaction_pk)
        REFERENCES store_transactions (store_transaction_pk),
    CONSTRAINT chk_entitlement_event_type CHECK (
        event_type IN ('grant', 'restore', 'reconcile', 'refund', 'revoke')
    )
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_bin;
