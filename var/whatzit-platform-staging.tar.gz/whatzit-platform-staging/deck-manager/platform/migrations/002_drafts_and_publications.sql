CREATE TABLE IF NOT EXISTS catalog_drafts (
    draft_id BIGINT UNSIGNED NOT NULL AUTO_INCREMENT PRIMARY KEY,
    active_slot TINYINT UNSIGNED NULL,
    status VARCHAR(20) CHARACTER SET ascii COLLATE ascii_bin NOT NULL,
    base_revision BIGINT UNSIGNED NOT NULL,
    draft_version BIGINT UNSIGNED NOT NULL DEFAULT 1,
    catalog_json LONGTEXT NOT NULL,
    created_by VARCHAR(100) NOT NULL,
    updated_by VARCHAR(100) NOT NULL,
    created_at TIMESTAMP(6) NOT NULL DEFAULT CURRENT_TIMESTAMP(6),
    updated_at TIMESTAMP(6) NOT NULL DEFAULT CURRENT_TIMESTAMP(6) ON UPDATE CURRENT_TIMESTAMP(6),
    UNIQUE KEY uq_single_active_catalog_draft (active_slot),
    CONSTRAINT fk_catalog_draft_base_revision FOREIGN KEY (base_revision)
        REFERENCES catalog_revisions (revision),
    CONSTRAINT chk_catalog_draft_active_slot CHECK (active_slot IS NULL OR active_slot = 1),
    CONSTRAINT chk_catalog_draft_status CHECK (status IN ('active', 'published', 'discarded'))
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_bin;

CREATE TABLE IF NOT EXISTS publication_preparations (
    preparation_id CHAR(32) CHARACTER SET ascii COLLATE ascii_bin NOT NULL PRIMARY KEY,
    draft_id BIGINT UNSIGNED NULL,
    draft_version BIGINT UNSIGNED NULL,
    base_revision BIGINT UNSIGNED NOT NULL,
    target_revision BIGINT UNSIGNED NOT NULL,
    state VARCHAR(30) CHARACTER SET ascii COLLATE ascii_bin NOT NULL,
    manifest_hash CHAR(64) CHARACTER SET ascii COLLATE ascii_bin NULL,
    error_code VARCHAR(100) CHARACTER SET ascii COLLATE ascii_bin NULL,
    created_at TIMESTAMP(6) NOT NULL DEFAULT CURRENT_TIMESTAMP(6),
    updated_at TIMESTAMP(6) NOT NULL DEFAULT CURRENT_TIMESTAMP(6) ON UPDATE CURRENT_TIMESTAMP(6),
    KEY ix_preparation_target_revision (target_revision),
    CONSTRAINT fk_publication_preparation_draft FOREIGN KEY (draft_id)
        REFERENCES catalog_drafts (draft_id),
    CONSTRAINT fk_publication_preparation_base_revision FOREIGN KEY (base_revision)
        REFERENCES catalog_revisions (revision),
    CONSTRAINT chk_publication_preparation_state CHECK (
        state IN ('preparing', 'artifacts_ready', 'database_active', 'active', 'failed')
    )
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_bin;

CREATE TABLE IF NOT EXISTS publication_events (
    event_id BIGINT UNSIGNED NOT NULL AUTO_INCREMENT PRIMARY KEY,
    catalog_revision BIGINT UNSIGNED NOT NULL,
    event_type VARCHAR(20) CHARACTER SET ascii COLLATE ascii_bin NOT NULL,
    source_revision BIGINT UNSIGNED NOT NULL,
    rollback_of_revision BIGINT UNSIGNED NULL,
    administrator VARCHAR(100) NOT NULL,
    summary_json LONGTEXT NOT NULL,
    manifest_hash CHAR(64) CHARACTER SET ascii COLLATE ascii_bin NOT NULL,
    created_at TIMESTAMP(6) NOT NULL DEFAULT CURRENT_TIMESTAMP(6),
    UNIQUE KEY uq_publication_event_revision (catalog_revision),
    CONSTRAINT fk_publication_event_catalog FOREIGN KEY (catalog_revision)
        REFERENCES catalog_revisions (revision),
    CONSTRAINT fk_publication_event_source FOREIGN KEY (source_revision)
        REFERENCES catalog_revisions (revision),
    CONSTRAINT fk_publication_event_rollback FOREIGN KEY (rollback_of_revision)
        REFERENCES catalog_revisions (revision),
    CONSTRAINT chk_publication_event_type CHECK (event_type IN ('publish', 'rollback', 'initial_import'))
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_bin;
