# Database catalog foundation

This directory contains the database catalog, publication, commerce,
development-preview, recovery, and health subsystems used by the standalone
Deck Platform service.

## Configuration and safety

Copy only placeholder keys from `config.example.php`; keep real
values in environment variables or the existing external configuration file.
Production API/content URLs must use HTTPS and `WHATZIT_ARTIFACT_ROOT` must be
absolute. Database tests require `WHATZIT_PLATFORM_ENV=test` and a database
name containing an explicit `_test` segment.

Database values are `WHATZIT_DB_HOST`, `WHATZIT_DB_PORT`, `WHATZIT_DB_NAME`,
`WHATZIT_DB_USER`, and `WHATZIT_DB_PASSWORD`. Read-service values are
`WHATZIT_PUBLIC_API_BASE_URL`, `WHATZIT_CONTENT_BASE_URL`, and the absolute
`WHATZIT_ARTIFACT_ROOT`. Database authoring additionally requires the absolute
private `WHATZIT_MEDIA_ROOT` containing the catalog's source-relative cover
paths. Unresolved production values are in `DECISIONS.md`.

Configuration lookup follows the existing Deck Manager pattern: an absolute
`WHATZIT_CONFIG_PATH` wins, local development may use the ignored
`config.local.php`, and Hostinger auto-discovers
`<domain-root>/whatzit-secrets/deck-platform-config.php`. The hosted file stays
outside `public_html` and is not replaced by Git deployment.

## Initial local import

Provision an empty local MySQL/MariaDB database and least-privilege user, then:

```powershell
php platform/bin/platform.php migrate
php platform/bin/platform.php import --catalog=C:/dev/whatz-it/src/data/bundles.ts --media-root=C:/dev/whatz-it
php platform/bin/platform.php export --output=var/catalog-export.json
php platform/bin/platform.php artifacts --media-root=C:/dev/whatz-it
```

`bootstrap` performs those steps in order. Import is initial-only. Re-running
identical content is a no-op; different content at the same revision or any
already-active catalog is rejected. It never writes to the mobile repository.

The export must match the schema-5 source exactly. Artifact generation writes
immutable covers, thumbnails, and free card payloads before atomically replacing
`manifest.json`.

## Catalog and commerce routes

- `GET /api/v1/catalog/manifest` with `ETag` / `If-None-Match`
- `GET /api/v1/decks/{deckId}/content/{version}` publicly for free decks and
  with installation authorization for entitled paid decks
- `GET /content/covers/{hash}.webp`
- `GET /content/thumbnails/{hash}.webp`
- `POST /api/v1/installations/apple`
- `POST /api/v1/purchases/apple/verify`
- `POST /api/v1/purchases/apple/restore`
- `GET /api/v1/entitlements`
- `POST /api/v1/testing/reset-purchases` (test environment only)

Paid artifacts remain undiscoverable from the manifest and require a verified,
hashed per-installation bearer credential. The app submits StoreKit 2's signed
transaction JWS, but the server grants ownership only after an authenticated
App Store Server API lookup. Production is checked first and Apple's not-found
response falls back to sandbox for development builds.

Fresh Apple-signed transactions may briefly precede their availability through
the App Store Server API. The verifier prefers the server lookup, but can use a
fully certificate-verified JWS for at most 15 minutes after its signed date when
both Apple environments return `4040010`. Test-only sandbox deployments allow
24 hours so a manual staging drill can complete. Older or environment-less
payloads remain rejected.

The reset route revokes only the authenticated installation's active sandbox
entitlements, preserves transaction rows, and appends audit events. Production
returns `404` for this route.

Apple verification additionally requires `WHATZIT_APPLE_BUNDLE_ID`,
`WHATZIT_APPLE_IAP_KEY_ID`, `WHATZIT_APPLE_IAP_ISSUER_ID`, and an absolute
`WHATZIT_APPLE_IAP_PRIVATE_KEY_PATH`. The `.p8` file must remain outside
`public_html`, source control, deployment archives, and API responses.

## Read-only artifact retention report

Inventory the private artifact root without deleting or modifying anything:

```powershell
php deck-manager/platform/bin/platform.php retention-report --output=artifact-retention-report.json
```

The report protects the active revision, the latest ten rollback revisions,
and revisions inside the 12-month app-compatibility window. Referenced
artifacts receive an additional 90-day safety period. It verifies
content-addressed filenames, lists missing references, and labels files as
`protected`, `eligible_review`, or `unresolved`. Historical thumbnails without
stored revision metadata remain unresolved. `eligible_review` is an inventory
classification only; this command has no deletion mode.

## Read-only recovery readiness report

Before taking a coordinated database and media backup, fingerprint the active
database export and verify that the active database revision, manifest, and
immutable artifacts describe the same snapshot:

```powershell
php deck-manager/platform/bin/platform.php recovery-readiness --output=recovery-readiness.json
```

`readyForBackup` must be `true` before capturing the database dump and artifact
directory. The report is read-only, contains no credentials or internal paths,
and does not replace the required restore into a separate disposable database
and media root. The complete guarded procedure is in
[`RECOVERY_DRILL.md`](RECOVERY_DRILL.md), including the `recovery-verify`
comparison that refuses targets not explicitly named as disposable.

## Read-only operational health report

Check active catalog/manifest parity, deployed migrations, interrupted
publications, entitlement invariants, development-preview parity, recent
publication failures, pending commerce, and artifact filesystem capacity:

```powershell
php deck-manager/platform/bin/platform.php health-report --output=platform-health.json
```

The command writes a sanitized report containing no cards, credentials,
installation IDs, or transaction IDs. It exits nonzero for critical production
failures; advisory findings produce a warning report without declaring the
public catalog unhealthy. Deployment, scheduling, public-edge checks, and
manual response boundaries are documented in
[`OPERATIONS_MONITORING.md`](OPERATIONS_MONITORING.md).

## Verification

```powershell
php deck-manager/platform/tests/platform.php
php deck-manager/platform/tests/publication.php
php deck-manager/platform/tests/retention.php
php deck-manager/platform/tests/recovery.php
php deck-manager/platform/tests/health.php
php deck-manager/tests/lint.php
node deck-manager/tests/run.js
php deck-manager/tests/github.php
```

The platform test always checks deterministic artifacts and source parity. For
the real database round trip, supply `WHATZIT_TEST_DB_HOST` and the related
`WHATZIT_TEST_DB_*` values. The dedicated database must already exist and
include `_test` in its name. Never use production credentials.

## Hostinger staging deployment

The Hostinger package keeps application code, generated artifacts, and
`config.local.php` outside `public_html`. Only the small front controller and
rewrite rules are copied into the `api-staging` document root.

Build the ignored deployment archive from the landing-page repository:

```powershell
powershell -ExecutionPolicy Bypass -File platform/deploy/build-hostinger-staging.ps1
```

The `.tar.gz` archive contains `whatzit-platform-staging/` for the domain
directory, `api-staging-public/` for the read-service document root, and
`manager-staging-public/` for a separate protected admin document root. Copy
`deck-manager/config.example.php` to the external auto-discovered
`whatzit-secrets/deck-platform-staging-config.php`, replace every placeholder there,
and set mode `600` before running the migration. Never place that configuration
file in `public_html`.

For the controlled database-browser drill, point
`manager-staging.playwhatzit.com` at its own document root, extract the contents
of `manager-staging-public/` there, and copy the packaged
`manager-staging-config.example.php` to the mode-600 external
`whatzit-secrets/deck-manager-staging-config.php`. That combined file selects
database storage and local single-administrator authentication plus the
platform/database settings. Generate a unique rate-limit secret, run migration
003, and provision or reset the only administrator from SSH with
`php platform/bin/platform.php set-admin --username=<login>`. The command
prompts for the password without accepting it as a shell argument. Do not reuse
the production Deck Manager document root or change its storage flag for this
drill.

## Hostinger production candidate

Production is packaged into new paths so preparing it cannot overwrite the
staging service or the legacy production Deck Manager:

```powershell
powershell -ExecutionPolicy Bypass -File platform/deploy/build-hostinger-production-candidate.ps1
```

The ignored archive contains `whatzit-platform-production/`,
`api-production-public/`, and `manager-production-public/`. Its wrappers select
the separate mode-600 secrets
`whatzit-secrets/deck-platform-production-config.php` and
`whatzit-secrets/deck-manager-production-config.php`. Create a production-only
database/user and rate-limit secret; never reuse the staging database or its
credentials. The Apple private key may remain in the shared external secrets
directory, but its key ID, issuer ID, and absolute path must be present in both
production configuration files.

Building or extracting this archive does not switch traffic. Keep the existing
production API/manager document roots unchanged while the new database is
migrated, initialized from a reviewed active-catalog export, and exercised at
parallel candidate hostnames. Point `api.playwhatzit.com` and
`manager.playwhatzit.com` to the new public roots only after manifest parity,
publication, rollback, commerce, authentication, and recovery checks pass.
Retain the prior document roots and configuration for rollback through the
post-cutover observation window.

Create the reviewed catalog-plus-cover promotion bundle from the active staging
service before initializing the empty production database:

```bash
php platform/bin/platform.php export-bootstrap --output=/home/ACCOUNT/whatzit-production-bootstrap-REVISION
```

The command requires a new output directory and atomically writes
`catalog.json`, `media/`, and integrity metadata. Every active logical cover is
copied from its hash-verified immutable staging artifact. Transfer that complete
directory to the production service, then pass `catalog.json` and `media/` to
`bootstrap`. Do not substitute the package's potentially older mobile seed.

After production becomes the catalog source of truth, refresh staging only in
that direction with the manually triggered **Refresh Staging Catalog** GitHub
workflow and its explicit confirmation box. The underlying guarded CLI command
is:

```bash
WHATZIT_CONFIG_PATH=/absolute/deck-platform-staging-config.php \
php platform/bin/platform.php refresh-staging \
  --source-config=/absolute/deck-platform-production-config.php \
  --administrator=production-sync
```

The target must be an explicitly named test database with the staging API URL;
the source must be a different production database with the production API URL.
The operation copies active catalog fields and verified cover bytes through a
normal staging publication. It refuses to erase an unpublished staging draft
and does not copy authentication or commerce tables.

## Phase 2 rollout boundary

`WHATZIT_DECK_MANAGER_STORAGE` defaults to `github`. Leave it on that value in
every deployed environment until the database-backed admin routes and browser
workflow have passed parity and rollback testing. The current Phase 2A code
adds draft, automatic-version, publication-preparation, immutable-promotion,
and audit foundations; it does not switch the existing Deck Manager write
path. The session response exposes the configured backend so later rollout UI
can make the active path visible to administrators.

### Guarded publication operations

The Phase 2 CLI operations are intended for staging drills and recovery before
the database-backed browser workflow is enabled:

```bash
php platform/bin/platform.php publication-status
php platform/bin/platform.php publish-draft --administrator=LOGIN
php platform/bin/platform.php resume-publication --preparation-id=32_HEX_CHARACTERS
php platform/bin/platform.php rollback --revision=OLD_REVISION --administrator=LOGIN
```

`publish-draft` requires an already-persisted active draft and never creates an
empty one implicitly. If database activation succeeds but manifest activation
is interrupted, the preparation remains `database_active`; public filesystem
routes continue serving the previous manifest until `resume-publication`
validates and atomically activates the prepared manifest. Rollback copies a
published historical snapshot into a new draft and publishes it as a new,
forward-moving revision. It never moves the revision counter backward.

## Database admin API rollout

When `WHATZIT_DECK_MANAGER_STORAGE=database`, the authenticated Deck Manager
API routes state loading, draft save/discard/validation, publish, history,
export, rollback, and cover reads through MySQL and private platform storage.
GitHub OAuth remains the administrator identity provider, but repository App
installation credentials are not required by database mode. The default is
still `github`, and the original GitHub dispatcher is unchanged.

Database mode requires `WHATZIT_MEDIA_ROOT` in the external platform
configuration. Cover add/replace/rename/remove operations are projected in a
private, ephemeral preparation directory and validated before the draft or
active revision changes. Publication writes immutable cover artifacts; rollback
reconstructs historical covers by their recorded hashes, including a prior
image that used the same filename. The configured seed media directory is a
read-only fallback and is never mutated. Keep database mode disabled in the
production browser. The isolated manager-staging browser provides debounced
server draft autosave, visible pending/saved/error state, optimistic conflict
recovery, durable device-local catalog/media stashes with conflict-aware restore,
an unmistakable autosave-failure dialog, a combined **Save My Work & Get Latest**
action, and a blocking restore-or-discard decision whenever saved work exists,
publication history, and guarded forward rollback for parity testing before any
production switch.

## Protected Expo development preview

Database mode can expose a deliberate shared authoring preview without
publishing the production catalog. Configure the same 64-character lowercase
hex `WHATZIT_DEV_PREVIEW_KEY` in the external platform API and Deck Manager
configuration files. **Update Test App** snapshots the currently saved
draft and any browser-held media into `artifacts/dev-preview/revisions/`, then
atomically replaces only `artifacts/dev-preview/manifest.json`. It does not
advance `active_catalog_revision`, retire a production revision, or clear the
draft. A successful production publish or forward rollback also refreshes Dev
Preview automatically from the newly active catalog. Preview refresh is a
separate post-activation step: if it fails, the production publication remains
successful and the guarded header or floating **Update Test App** action can
retry it.

Every `/api/v1/dev-preview/` request requires the key in the
`X-Whatzit-Dev-Preview-Key` header. The key must not appear in a URL, committed
environment file, EAS release environment, or production app binary. Expo
development uses a separate SQLite filename for this feed, so draft cards and
preview-only paid access cannot contaminate the normal production cache.

## Commerce and bundle snapshots

### App Store Connect publication gate

Deck Manager can fail closed before **Update Test App**, **Publish Changes**, CLI
`publish-draft`, or a forward rollback exposes a catalog containing Apple
products marked `available`. It lists the app's in-app purchases through the App
Store Connect API and requires every available deck, bundle, and configured
discount tier to exist as a non-consumable product. Missing products, the wrong
product type, `MISSING_METADATA`, `REJECTED`, removal from sale, and developer
action-required states block the operation and identify each catalog record.
Draft and retired mappings do not block publication.

This uses an App Store Connect **Team API key**, which is different from the
In-App Purchase key used by the App Store Server API for transaction
verification. Keep both `.p8` files outside `public_html`. Add these values to
the external Deck Manager configuration only:

```php
'WHATZIT_APPLE_CATALOG_VALIDATION' => 'required',
'WHATZIT_ASC_APP_ID' => 'NUMERIC_APP_STORE_CONNECT_APP_ID',
'WHATZIT_ASC_KEY_ID' => 'ASC_KEY_ID',
'WHATZIT_ASC_ISSUER_ID' => 'ASC_ISSUER_UUID',
'WHATZIT_ASC_PRIVATE_KEY_PATH' => '/absolute/secret/path/AuthKey_ASC_KEY_ID.p8',
```

Use `disabled` only for a local editor that must operate without Apple network
access. A required check also blocks on Apple/network/authentication failure;
it never treats an unavailable verification service as success. The check
proves that the product exists in Apple's catalog with a usable type/state. It
does not prove StoreKit propagation to every sandbox device or storefront, so a
sandbox purchase remains the final end-to-end test.

#### Staging/test database rollout

1. In App Store Connect, open **Users and Access → Integrations → App Store
   Connect API**, create a Team key with **App Manager** access, record its key
   ID and issuer ID, and download `AuthKey_<KEY_ID>.p8` (Apple allows one
   download). Do not use the key from **In-App Purchase → Manage** for this
   catalog check.
2. Open the app in App Store Connect and copy its numeric Apple ID from App
   Information. This is `WHATZIT_ASC_APP_ID`, not the bundle ID.
3. Put the `.p8` file under
   `/home/ACCOUNT/domains/playwhatzit.com/whatzit-secrets/`, outside every web
   root, and set it to mode `600`.
4. Add the five settings above to
   `whatzit-secrets/deck-manager-staging-config.php`, using staging's existing
   `WHATZIT_PLATFORM_ENV=test` and staging database credentials. Do not add the
   private key contents to source control.
5. Build and deploy the staging archive. The guarded deploy runs
   `php platform/bin/platform.php migrate` against the test database; migration
   `008_bundle_purchase_snapshots_and_discount_tiers.sql` is additive and will
   be applied once if it is not already recorded.
6. In Deck Manager, open each paid bundle. Copy the newline-separated Apple IDs
   from **Apple bundle product IDs**. Create one non-consumable IAP for the full
   price and each discount scenario you intend to sell. The list is dynamic:
   an N-deck bundle shows the full ID plus `owned_1` through `owned_(N-1)`.
7. Keep each new mapping `draft` until its matching IAP exists and its metadata
   is complete. Then mark the full product and only the discount tiers you
   actually created as `available`.
8. Click **Update Test App**. As a negative test, temporarily mark one nonexistent
   mapping available and confirm the operation fails with that exact ID. Restore
   it to `draft`, then update again and run a sandbox purchase/restore on a fresh
   install for every ownership tier.
9. Click **Publish Changes** only after the preview and sandbox checks pass.

#### Production database rollout

1. Reuse the same App Store Connect app catalog, but place the Team API
   credentials in the production-only
   `whatzit-secrets/deck-manager-production-config.php`; keep the staging and
   production database credentials separate. The Team key file may be shared
   read-only from the external secrets directory.
2. Create/finish every production IAP first. Product IDs are permanent, so paste
   them exactly from the bundle form. Verify type **Non-Consumable**, pricing,
   localization, tax category, availability, and review metadata in App Store
   Connect.
3. Take the normal production database/filesystem backup, build the production
   candidate, and run the guarded production deploy. It validates the manager's
   App Store Connect settings before activation and runs all pending migrations,
   including 008, against the production database.
4. Open production Deck Manager and compare every `available` Apple mapping with
   App Store Connect. Publish a no-risk metadata change or the prepared catalog;
   the server performs a fresh Apple lookup before the database revision or
   development preview changes.
5. Confirm the discovery manifest contains the intended full and discount
   product IDs, then test the released/TestFlight build's localized prices,
   purchase, cancellation, and restore flows. Keep mappings `draft` until they
   are meant to be exposed; never bypass the gate by marking a missing product
   retired unless it truly should not be sold.

Migration 004 is additive: it creates versioned store-product mappings,
installation identities, idempotent Apple/Google transaction identities,
effective entitlements, and append-only entitlement events. It does not expose
raw signed receipts or change the manager's production routing. Migration 005
adds only a unique SHA-256 credential hash to installation rows; the random
credential itself exists only in the device keychain. The additive Apple API
can grant ownership only after server-side store verification and can serve a
paid immutable artifact only to an installation with an effective entitlement.

Commerce uses non-consumable products on Apple and Google Play. Deck Manager
derives permanent Apple product IDs from stable catalog IDs:

- `com.cadelawless.whatzit.deck.<deck_id>`
- `com.cadelawless.whatzit.bundle.<bundle_id>`

App Store Connect's live IAP form accepts letters, numbers, periods, and
underscores but rejects hyphens. Manager therefore replaces hyphens in the
stable catalog ID with underscores when deriving the permanent Apple ID.
Existing underscores are doubled first so two different stable IDs cannot
collapse to the same store identifier.

For a paid deck or bundle, keep a mapping **Draft** while store metadata is
incomplete, mark it **Available** only after sandbox lookup works, or **Retired**
when it must never be sold again. Product IDs are not prices: the app displays
the selected store product's localized price.

Migration 008 adds `owned_deck_count` mappings for arbitrary bundle discount
tiers and `purchase_deck_grants`, the immutable deck-membership snapshot for an
original transaction. Apply it before deploying the matching API. Configure
Google verification with `WHATZIT_GOOGLE_PACKAGE_NAME` and an absolute
`WHATZIT_GOOGLE_SERVICE_ACCOUNT_PATH`; the service-account JSON must remain
outside `public_html`, source control, and deployment archives. The API exposes
platform-specific registration plus Apple and Google purchase/restore routes.
