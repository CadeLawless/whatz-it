# Production database and media recovery drill

This drill proves that a coordinated WHATZ IT? database and immutable-artifact
snapshot can be restored without touching the live database, live artifact
root, or public document roots.

## Safety boundary

- Do not publish, roll back, or update Dev Preview while capturing the source
  snapshot.
- Create a new disposable Hostinger database whose name contains `restore`,
  `drill`, or `test`.
- Use one of those complete marker words. Abbreviations such as `rest` are
  intentionally rejected by the verification safety guard.
- Restore files only beneath a new private directory whose path contains
  `restore`, `drill`, or `test` and remains outside `public_html`.
- Create a separate mode-600 configuration file for the restored targets.
- Do not point a public hostname, Deck Manager, or mobile build at the restored
  targets.
- Keep production configuration, database credentials, and Apple private keys
  out of the evidence files and archives.

## 1. Capture the source fingerprint

On Hostinger, with the production service configuration selected:

```bash
DOMAIN=/home/u673240131/domains/playwhatzit.com
SERVICE="$DOMAIN/whatzit-platform-production"
CONFIG="$DOMAIN/whatzit-secrets/deck-platform-production-config.php"
EVIDENCE=/home/u673240131/whatzit-recovery-evidence

mkdir -p "$EVIDENCE"
chmod 700 "$EVIDENCE"
cd "$SERVICE/deck-manager"

WHATZIT_CONFIG_PATH="$CONFIG" php platform/bin/platform.php recovery-readiness \
  --output="$EVIDENCE/source-readiness.json"
chmod 600 "$EVIDENCE/source-readiness.json"
```

Open the report and continue only when `readyForBackup` is `true`. Keep the
publishing pause in place until both components below have been captured.

## 2. Capture matching database and artifacts

Export the production database from phpMyAdmin as SQL without changing it. Save
the downloaded file with the catalog revision in its name.

Archive the complete private production artifact directory on Hostinger:

```bash
ARTIFACT_ROOT="$SERVICE/artifacts"
REVISION=$(php -r '
$r = json_decode(file_get_contents($argv[1]), true, 512, JSON_THROW_ON_ERROR);
echo $r["activeRevision"];
' "$EVIDENCE/source-readiness.json")
ARTIFACT_ARCHIVE="$EVIDENCE/production-artifacts-revision-$REVISION.tar.gz"

tar -czf "$ARTIFACT_ARCHIVE" -C "$ARTIFACT_ROOT" .
sha256sum "$ARTIFACT_ARCHIVE" > "$ARTIFACT_ARCHIVE.sha256"
chmod 600 "$ARTIFACT_ARCHIVE" "$ARTIFACT_ARCHIVE.sha256"
```

Publishing may resume after the SQL export and artifact archive both finish.
Store the SQL export, artifact archive, archive checksum, and
`source-readiness.json` together as one recovery set.

## 3. Restore only into disposable targets

Create a new Hostinger database and database user for the drill. The database
name must contain the complete word `restore`, `drill`, or `test`. Before
importing, set the empty database to the same binary collation used by the
platform schema:

```sql
ALTER DATABASE `REPLACE_WITH_DISPOSABLE_DATABASE_NAME`
    CHARACTER SET utf8mb4
    COLLATE utf8mb4_bin;
```

Verify `DEFAULT_COLLATION_NAME` is `utf8mb4_bin` in
`information_schema.SCHEMATA`, then import the captured SQL file through
phpMyAdmin. Hostinger otherwise defaults a new database to
`utf8mb4_unicode_ci`; that changes inherited identifier-column collations and
causes the SQL import to fail when it restores foreign keys.

Create and populate a new private artifact root:

```bash
RESTORE_ROOT="$DOMAIN/whatzit-restore-drill/artifacts"
mkdir -p "$RESTORE_ROOT"
chmod 700 "$DOMAIN/whatzit-restore-drill" "$RESTORE_ROOT"
sha256sum -c "$ARTIFACT_ARCHIVE.sha256"
tar -xzf "$ARTIFACT_ARCHIVE" -C "$RESTORE_ROOT"
```

Copy the production platform configuration to a new external file such as
`$DOMAIN/whatzit-secrets/deck-platform-restore-drill-config.php`. Edit only the
environment label, disposable database connection, and `WHATZIT_ARTIFACT_ROOT`
so they point at the restored targets. Keep permissions at `600` and validate
the PHP syntax.

## 4. Compare the restored snapshot

Run the guarded verification command. Both confirmation values must exactly
match the disposable targets configured in the restore-drill configuration,
and both names must visibly contain `restore`, `drill`, or `test`.

```bash
RESTORE_CONFIG="$DOMAIN/whatzit-secrets/deck-platform-restore-drill-config.php"
RESTORE_DATABASE=REPLACE_WITH_DISPOSABLE_DATABASE_NAME
VERIFY_REPORT="$EVIDENCE/restored-verification.json"

cd "$SERVICE/deck-manager"
WHATZIT_CONFIG_PATH="$RESTORE_CONFIG" php platform/bin/platform.php recovery-verify \
  --baseline="$EVIDENCE/source-readiness.json" \
  --disposable-database="$RESTORE_DATABASE" \
  --disposable-artifact-root="$RESTORE_ROOT" \
  --output="$VERIFY_REPORT"
chmod 600 "$VERIFY_REPORT"
```

The command exits successfully only when `matched` is `true` and the restored
database revision, deterministic database-export hash, manifest hash, artifact
count, byte count, and full path/size/SHA-256 inventory exactly match the source
fingerprint.

## 5. Record and retain evidence

Retain these items with the drill date and administrator:

- `source-readiness.json`;
- database export filename and SHA-256;
- artifact archive filename and SHA-256;
- `restored-verification.json`;
- the disposable database and private artifact-root names;
- start/end timestamps and any recovery problems encountered.

The disposable targets may be removed later through Hostinger after the
evidence has been reviewed. Removal is deliberately outside the CLI so this
read-only verification cannot delete production or drill data.
