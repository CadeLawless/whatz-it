# Production operations monitoring

This runbook monitors the database-backed WHATZ IT? catalog without exposing
card content, credentials, installation identifiers, store transaction IDs, or
purchase payloads. Monitoring is read-only and never publishes, rolls back,
repairs, deletes, or retries work automatically.

## Health report

Run with the external production configuration:

```bash
DOMAIN=/home/u673240131/domains/playwhatzit.com
SERVICE="$DOMAIN/whatzit-platform-production"
CONFIG="$DOMAIN/whatzit-secrets/deck-platform-production-config.php"
REPORT=/home/u673240131/whatzit-production-health.json

cd "$SERVICE/deck-manager"
WHATZIT_CONFIG_PATH="$CONFIG" php platform/bin/platform.php health-report \
  --output="$REPORT"
chmod 600 "$REPORT"
```

The command exits nonzero only when a critical check fails. Advisory findings
produce `status: warning` while leaving `healthy: true`, so a safely contained
publication failure or an optional development-preview problem does not claim
that the public production catalog is down.

Critical checks cover:

- the active database catalog and revision state;
- readable, valid, revision-matched, hash-matched public manifest artifacts;
- the exact ordered migration set deployed with the service;
- publication preparations left incomplete for at least 15 minutes; and
- active entitlements whose source transaction is no longer verified.

Advisory checks cover:

- development-preview database/artifact parity;
- failed publication attempts during the preceding 24 hours;
- transactions left pending for more than 24 hours; and
- whether filesystem-capacity values can be read.

The report also includes sanitized counts, the latest successful publication,
active draft metadata, current preview revision, and artifact filesystem free
space. It deliberately omits card data and purchase or installation identities.

## Public smoke check

The health report proves database/filesystem parity from inside Hostinger. Also
check the public edge after a deployment or publication:

```bash
curl --fail --silent --show-error \
  https://api.playwhatzit.com/api/v1/catalog/manifest \
  | php -r '
$manifest = json_decode(stream_get_contents(STDIN), true, 512, JSON_THROW_ON_ERROR);
echo "Public revision: ", $manifest["catalogRevision"], PHP_EOL;
echo "Decks: ", count($manifest["decks"]), PHP_EOL;
echo "Bundles: ", count($manifest["bundles"]), PHP_EOL;
'
```

Compare the public revision with `catalog.activeRevision` in the health report.
Do not use monitoring to request protected card payloads or store credentials.

## Cadence

- Run `health-report` after every production publish, rollback, migration, or
  service deployment.
- Run it every 15 minutes as a Hostinger scheduled job once failed-run
  notification delivery has been tested.
- Run `recovery-readiness` daily or before every coordinated backup; it performs
  the more expensive complete artifact inventory and hash validation.
- Review the Hostinger PHP error log and the report's advisory findings daily
  while production rollout is young.
- Repeat the disposable database-and-artifact recovery drill after schema or
  storage changes and at least quarterly once production usage begins.

## Response boundaries

### Critical catalog or manifest check

Pause publishing. Preserve the current report and PHP error log. Run
`publication-status`. A `database_active` preparation may be resumed only with
the existing guarded `resume-publication` operation after confirming its target
revision and manifest hash. Do not regenerate or overwrite active artifacts by
hand.

### Migration mismatch

Pause manager writes and confirm that the service code and intended deployment
archive match. Apply only reviewed ordered migrations through
`platform.php migrate`; never repair production schema manually in phpMyAdmin.

### Entitlement invariant failure

Preserve the report and relevant server log timestamps, pause purchase testing,
and investigate the affected aggregate state through private database tooling.
The health report intentionally does not expose installation or transaction
identities and does not revoke or grant anything.

### Advisory warning

Production remains available. Review the named advisory section. A failed
publication that never became active is expected to remain auditable; a newer
successful publication can clear the operational concern without deleting its
history.

## Evidence retention

Keep mode-600 reports for incident and rollout review. Do not place reports,
database exports, artifacts, error logs, or external configurations under
`public_html` or in source control.
