<?php

declare(strict_types=1);

namespace WhatzIt\DeckPlatform;

use WhatzIt\DeckManager\ApiException;

final class MediaProjection
{
    /**
     * @param array<string,array{deckId:string,path:string,hash:string}> $baseSources
     * @param array<string,array{deckId:string,path:string,hash:string}> $currentSources
     * @return array{mediaRoot:string,changedDeckIds:list<string>}
     */
    public function create(
        array $currentCatalog,
        array $targetCatalog,
        array $baseSources,
        array $currentSources,
        array $operations,
        array $uploads,
        string $artifactRoot,
        string $fallbackMediaRoot,
        string $workspaceRoot,
    ): array {
        if (!is_array($operations)) {
            throw new ApiException('Image operations are invalid.');
        }
        self::ensurePrivateWorkspace($workspaceRoot);
        $projected = $baseSources;
        $targeted = [];
        $totalBytes = 0;
        foreach ($operations as $operation) {
            if (!is_array($operation)) {
                throw new ApiException('An image operation is invalid.');
            }
            $type = (string) ($operation['type'] ?? '');
            if ($type === 'add' || $type === 'replace') {
                $filename = self::safeWebpFilename((string) ($operation['filename'] ?? ''));
                $key = strtolower($filename);
                self::targetOnce($targeted, $key, $filename);
                if ($type === 'add' && isset($projected[$key])) {
                    throw new PublicationConflict("Image $filename already exists.");
                }
                if ($type === 'replace') {
                    $existing = $projected[$key] ?? null;
                    if ($existing === null) {
                        throw new PublicationConflict("Image $filename no longer exists.");
                    }
                    self::assertExpectedHash($operation, $existing['hash'], $filename);
                }
                $uploadKey = (string) ($operation['uploadKey'] ?? '');
                $uploaded = self::validatedUpload($uploads[$uploadKey] ?? null, $filename);
                $totalBytes += strlen($uploaded['bytes']);
                if ($totalBytes > 50 * 1024 * 1024) {
                    throw new ApiException('A single publish may include at most 50 MB of new image data.');
                }
                if (isset($operation['hash']) && !hash_equals((string) $operation['hash'], $uploaded['hash'])) {
                    throw new ApiException("The staged hash for $filename does not match its upload.");
                }
                $projected[$key] = [
                    'deckId' => (string) (($existing ?? [])['deckId'] ?? ''),
                    'path' => 'assets/images/decks/' . $filename,
                    'hash' => $uploaded['hash'],
                    'bytes' => $uploaded['bytes'],
                ];
            } elseif ($type === 'rename') {
                $from = self::safeWebpFilename((string) ($operation['from'] ?? ''));
                $to = self::safeWebpFilename((string) ($operation['to'] ?? ''));
                $fromKey = strtolower($from);
                $toKey = strtolower($to);
                self::targetOnce($targeted, $fromKey, $from);
                self::targetOnce($targeted, $toKey, $to);
                $existing = $projected[$fromKey] ?? null;
                if ($existing === null || isset($projected[$toKey])) {
                    throw new PublicationConflict('An image rename conflicts with the current database media.');
                }
                self::assertExpectedHash($operation, $existing['hash'], $from);
                unset($projected[$fromKey]);
                $existing['path'] = 'assets/images/decks/' . $to;
                $projected[$toKey] = $existing;
            } elseif ($type === 'remove') {
                $filename = self::safeWebpFilename((string) ($operation['filename'] ?? ''));
                $key = strtolower($filename);
                self::targetOnce($targeted, $key, $filename);
                $existing = $projected[$key] ?? null;
                if ($existing === null) {
                    throw new PublicationConflict("Image $filename no longer exists.");
                }
                self::assertExpectedHash($operation, $existing['hash'], $filename);
                unset($projected[$key]);
            } else {
                throw new ApiException('An image operation has an unsupported type.');
            }
        }

        $targetDecks = self::decksById($targetCatalog);
        $currentDecks = self::decksById($currentCatalog);
        $changed = [];
        foreach ($targetDecks as $deckId => $deck) {
            $path = self::safeCoverPath((string) ($deck['coverImage'] ?? ''));
            if ($path === '') {
                if (($currentDecks[$deckId]['coverImage'] ?? '') !== '') {
                    $changed[] = $deckId;
                }
                continue;
            }
            $key = strtolower(basename($path));
            $source = $projected[$key] ?? null;
            if ($source === null) {
                throw new ApiException('Referenced deck images are missing.', 422, [[
                    'path' => "decks.$deckId.coverImage",
                    'message' => $path,
                ]]);
            }
            $destination = $workspaceRoot . DIRECTORY_SEPARATOR
                . str_replace('/', DIRECTORY_SEPARATOR, $path);
            self::writeProjectedSource($source, $destination, $artifactRoot, $fallbackMediaRoot);
            $currentPath = (string) ($currentDecks[$deckId]['coverImage'] ?? '');
            $currentSource = $currentPath === ''
                ? null
                : ($currentSources[strtolower(basename(str_replace('\\', '/', $currentPath)))] ?? null);
            if ($currentPath !== $path
                || $currentSource === null
                || !hash_equals((string) $currentSource['hash'], (string) $source['hash'])) {
                $changed[] = $deckId;
            }
        }
        sort($changed, SORT_STRING);
        return ['mediaRoot' => $workspaceRoot, 'changedDeckIds' => array_values(array_unique($changed))];
    }

    public static function removeWorkspace(string $workspaceRoot): void
    {
        if (!is_dir($workspaceRoot)) {
            return;
        }
        $name = basename($workspaceRoot);
        if (!str_starts_with($name, 'media-')) {
            throw new PlatformException('Refusing to remove an unexpected media workspace.');
        }
        $iterator = new \RecursiveIteratorIterator(
            new \RecursiveDirectoryIterator($workspaceRoot, \FilesystemIterator::SKIP_DOTS),
            \RecursiveIteratorIterator::CHILD_FIRST,
        );
        foreach ($iterator as $item) {
            $item->isDir() ? rmdir($item->getPathname()) : unlink($item->getPathname());
        }
        rmdir($workspaceRoot);
    }

    private static function writeProjectedSource(
        array $source,
        string $destination,
        string $artifactRoot,
        string $fallbackMediaRoot,
    ): void {
        $bytes = $source['bytes'] ?? null;
        if (!is_string($bytes)) {
            $hash = (string) $source['hash'];
            $immutable = rtrim($artifactRoot, '/\\') . DIRECTORY_SEPARATOR . 'covers'
                . DIRECTORY_SEPARATOR . $hash . '.webp';
            $fallback = rtrim($fallbackMediaRoot, '/\\') . DIRECTORY_SEPARATOR
                . str_replace('/', DIRECTORY_SEPARATOR, (string) $source['path']);
            $path = is_readable($immutable) ? $immutable : $fallback;
            $bytes = is_readable($path) ? file_get_contents($path) : false;
            if (!is_string($bytes) || !hash_equals($hash, hash('sha256', $bytes))) {
                throw new PlatformException('A referenced source cover is unavailable or corrupt.');
            }
        }
        self::ensureDirectory(dirname($destination));
        if (file_put_contents($destination, $bytes, LOCK_EX) !== strlen($bytes)) {
            throw new PlatformException('A projected source cover could not be written.');
        }
    }

    private static function validatedUpload(mixed $upload, string $filename): array
    {
        if (!is_array($upload) || ($upload['error'] ?? UPLOAD_ERR_NO_FILE) !== UPLOAD_ERR_OK) {
            throw new ApiException("The staged upload for $filename is missing.");
        }
        $size = (int) ($upload['size'] ?? 0);
        $temporary = (string) ($upload['tmp_name'] ?? '');
        if ($size < 1 || $size > 10 * 1024 * 1024
            || (!is_uploaded_file($temporary) && !is_file($temporary))) {
            throw new ApiException("The staged upload for $filename is invalid.");
        }
        $bytes = file_get_contents($temporary);
        if (!is_string($bytes) || strlen($bytes) !== $size) {
            throw new ApiException("The staged upload size for $filename is invalid.");
        }
        $dimensions = is_string($bytes) ? getimagesizefromstring($bytes) : false;
        if (!is_string($bytes) || substr($bytes, 0, 4) !== 'RIFF' || substr($bytes, 8, 4) !== 'WEBP'
            || !is_array($dimensions) || ($dimensions['mime'] ?? '') !== 'image/webp') {
            throw new ApiException("The staged upload for $filename is not a valid WebP image.");
        }
        if ((int) $dimensions[0] > 6000 || (int) $dimensions[1] > 6000) {
            throw new ApiException("The staged upload for $filename exceeds the image dimension limit.");
        }
        return ['bytes' => $bytes, 'hash' => hash('sha256', $bytes)];
    }

    private static function assertExpectedHash(array $operation, string $actual, string $filename): void
    {
        $expected = (string) ($operation['expectedHash'] ?? '');
        if (preg_match('/^[a-f0-9]{64}$/', $expected) !== 1 || !hash_equals($actual, $expected)) {
            throw new PublicationConflict("Image $filename changed after it was loaded.");
        }
    }

    private static function targetOnce(array &$targeted, string $key, string $filename): void
    {
        if (isset($targeted[$key])) {
            throw new ApiException("Image $filename is targeted more than once.");
        }
        $targeted[$key] = true;
    }

    private static function safeWebpFilename(string $filename): string
    {
        $filename = trim($filename);
        if (preg_match('/^[A-Za-z0-9][A-Za-z0-9_-]*\.webp$/i', $filename) !== 1) {
            throw new ApiException('Database cover filenames must be safe WebP filenames.');
        }
        return $filename;
    }

    private static function safeCoverPath(string $path): string
    {
        if ($path === '') {
            return '';
        }
        if (preg_match('#^assets/images/decks/[A-Za-z0-9][A-Za-z0-9_-]*\.webp$#i', $path) !== 1) {
            throw new ApiException('Database cover references must use assets/images/decks/*.webp.');
        }
        return $path;
    }

    private static function decksById(array $catalog): array
    {
        $result = [];
        foreach ($catalog['decks'] ?? [] as $deck) {
            if (is_array($deck) && is_string($deck['id'] ?? null)) {
                $result[$deck['id']] = $deck;
            }
        }
        return $result;
    }

    private static function ensurePrivateWorkspace(string $workspaceRoot): void
    {
        self::ensureDirectory($workspaceRoot);
        @chmod($workspaceRoot, 0700);
    }

    private static function ensureDirectory(string $directory): void
    {
        if (!is_dir($directory) && !mkdir($directory, 0700, true) && !is_dir($directory)) {
            throw new PlatformException('A private media workspace could not be created.');
        }
    }
}
