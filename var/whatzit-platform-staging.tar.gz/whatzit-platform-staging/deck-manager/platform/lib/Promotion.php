<?php

declare(strict_types=1);

namespace WhatzIt\DeckPlatform;

final class ProductionBootstrapExporter
{
    /**
     * @param array<string,mixed> $catalog
     * @param array<string,array{deckId:string,path:string,hash:string}> $coverSources
     * @return array{revision:int,catalogHash:string,coverCount:int,output:string}
     */
    public static function export(
        array $catalog,
        array $coverSources,
        string $artifactRoot,
        string $outputRoot,
    ): array {
        $outputRoot = rtrim($outputRoot, '/\\');
        if ($outputRoot === '' || file_exists($outputRoot)) {
            throw new PlatformException('Promotion output must be a new, nonexistent directory.');
        }
        $parent = dirname($outputRoot);
        if (!is_dir($parent) && !mkdir($parent, 0775, true) && !is_dir($parent)) {
            throw new PlatformException("Promotion output parent could not be created: $parent");
        }
        $workspace = $outputRoot . '.tmp-' . bin2hex(random_bytes(8));
        if (!mkdir($workspace, 0775)) {
            throw new PlatformException('Promotion workspace could not be created.');
        }

        try {
            $catalogJson = CatalogCodec::encode($catalog, true);
            self::write($workspace . DIRECTORY_SEPARATOR . 'catalog.json', $catalogJson);
            $coverCount = 0;
            foreach ($catalog['decks'] ?? [] as $deck) {
                if (!is_array($deck)) continue;
                $coverPath = (string) ($deck['coverImage'] ?? '');
                if ($coverPath === '') continue;
                self::assertSafeCoverPath($coverPath);
                $source = $coverSources[strtolower(basename(str_replace('\\', '/', $coverPath)))] ?? null;
                if (!is_array($source) || (string) $source['path'] !== $coverPath) {
                    throw new PlatformException("Active cover reference is not indexed: $coverPath");
                }
                $hash = (string) $source['hash'];
                if (preg_match('/^[a-f0-9]{64}$/', $hash) !== 1) {
                    throw new PlatformException("Active cover hash is invalid: $coverPath");
                }
                $immutable = rtrim($artifactRoot, '/\\') . DIRECTORY_SEPARATOR
                    . 'covers' . DIRECTORY_SEPARATOR . $hash . '.webp';
                $bytes = is_readable($immutable) ? file_get_contents($immutable) : false;
                if (!is_string($bytes) || !hash_equals($hash, hash('sha256', $bytes))) {
                    throw new PlatformException("Active immutable cover is unavailable or corrupt: $coverPath");
                }
                $destination = $workspace . DIRECTORY_SEPARATOR . 'media' . DIRECTORY_SEPARATOR
                    . str_replace('/', DIRECTORY_SEPARATOR, $coverPath);
                self::write($destination, $bytes);
                $coverCount++;
            }
            $metadata = CatalogCodec::encode([
                'catalogRevision' => (int) ($catalog['revision'] ?? 0),
                'catalogHash' => CatalogCodec::hash($catalog),
                'coverCount' => $coverCount,
                'createdAt' => gmdate('Y-m-d\TH:i:s\Z'),
            ], true);
            self::write($workspace . DIRECTORY_SEPARATOR . 'EXPORT.json', $metadata);
            if (!rename($workspace, $outputRoot)) {
                throw new PlatformException('Promotion output could not be activated.');
            }
            return [
                'revision' => (int) ($catalog['revision'] ?? 0),
                'catalogHash' => CatalogCodec::hash($catalog),
                'coverCount' => $coverCount,
                'output' => $outputRoot,
            ];
        } catch (\Throwable $error) {
            self::removeWorkspace($workspace, $outputRoot);
            throw $error;
        }
    }

    private static function assertSafeCoverPath(string $path): void
    {
        if (preg_match('#^assets/images/decks/[a-z0-9][a-z0-9._-]*\.webp$#', $path) !== 1) {
            throw new PlatformException("Active cover path is unsafe: $path");
        }
    }

    private static function write(string $path, string $bytes): void
    {
        $directory = dirname($path);
        if (!is_dir($directory) && !mkdir($directory, 0775, true) && !is_dir($directory)) {
            throw new PlatformException("Promotion directory could not be created: $directory");
        }
        if (file_put_contents($path, $bytes, LOCK_EX) !== strlen($bytes)) {
            throw new PlatformException("Promotion file could not be written: $path");
        }
    }

    private static function removeWorkspace(string $workspace, string $outputRoot): void
    {
        $expectedPrefix = $outputRoot . '.tmp-';
        if (!is_dir($workspace) || !str_starts_with($workspace, $expectedPrefix)) return;
        $iterator = new \RecursiveIteratorIterator(
            new \RecursiveDirectoryIterator($workspace, \FilesystemIterator::SKIP_DOTS),
            \RecursiveIteratorIterator::CHILD_FIRST,
        );
        foreach ($iterator as $item) {
            $item->isDir() ? rmdir($item->getPathname()) : unlink($item->getPathname());
        }
        rmdir($workspace);
    }
}
