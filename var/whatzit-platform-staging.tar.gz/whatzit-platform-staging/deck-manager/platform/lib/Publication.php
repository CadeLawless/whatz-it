<?php

declare(strict_types=1);

namespace WhatzIt\DeckPlatform;

use Throwable;

final class PublicationConflict extends PlatformException
{
}

final class VersionPlanner
{
    /**
     * @param array{decks?:array<string,array{deckVersion:int,cardContentVersion:int}>,bundles?:array<string,array{bundleVersion:int}>} $currentVersions
     * @return array{catalog:array,versions:array,summary:array}
     */
    public static function plan(
        array $current,
        array $draft,
        array $currentVersions,
        string $publishedAt,
        array $mediaChangedDeckIds = [],
    ): array {
        $errors = \WhatzIt\DeckManager\CatalogValidator::validate($draft);
        if ($errors !== []) {
            throw new PlatformException('Draft validation failed: ' . json_encode($errors, JSON_UNESCAPED_SLASHES));
        }
        if (($draft['schemaVersion'] ?? null) !== ($current['schemaVersion'] ?? null)) {
            throw new PlatformException('A publication cannot change the catalog schema version.');
        }
        if (($draft['revision'] ?? null) !== ($current['revision'] ?? null)) {
            throw new PublicationConflict('The draft is not based on the active catalog revision.');
        }
        if (preg_match('/^\d{4}-\d{2}-\d{2}T\d{2}:\d{2}:\d{2}Z$/', $publishedAt) !== 1) {
            throw new PlatformException('The publication timestamp must be UTC with whole-second precision.');
        }

        $currentDecks = self::indexById($current['decks']);
        $draftDecks = self::indexById($draft['decks']);
        $currentBundles = self::indexById($current['bundles']);
        $draftBundles = self::indexById($draft['bundles']);
        $versions = ['decks' => [], 'bundles' => []];
        $mediaChanged = array_fill_keys(array_map('strval', $mediaChangedDeckIds), true);
        $summary = [
            'decksAdded' => [],
            'decksRemoved' => [],
            'deckMetadataChanged' => [],
            'deckCardsChanged' => [],
            'bundlesAdded' => [],
            'bundlesRemoved' => [],
            'bundlesChanged' => [],
            'deckOrdersChanged' => $current['deckOrders'] !== $draft['deckOrders'],
        ];

        foreach ($draft['decks'] as $deck) {
            $id = (string) $deck['id'];
            $before = $currentDecks[$id] ?? null;
            if ($before === null) {
                $known = $currentVersions['decks'][$id] ?? null;
                $versions['decks'][$id] = $known === null
                    ? ['deckVersion' => 1, 'cardContentVersion' => 1]
                    : [
                        'deckVersion' => (int) $known['deckVersion'] + 1,
                        'cardContentVersion' => (int) $known['cardContentVersion'] + 1,
                    ];
                $summary['decksAdded'][] = $id;
                continue;
            }
            $known = $currentVersions['decks'][$id] ?? [
                'deckVersion' => (int) $before['version'],
                'cardContentVersion' => (int) $before['version'],
            ];
            $cardsChanged = $before['cards'] !== $deck['cards'];
            $metadataChanged = self::deckMetadata($before) !== self::deckMetadata($deck)
                || isset($mediaChanged[$id]);
            $deckVersion = (int) $known['deckVersion'];
            $cardVersion = (int) $known['cardContentVersion'];
            if ($cardsChanged) {
                $cardVersion++;
                $summary['deckCardsChanged'][] = $id;
            }
            if ($metadataChanged) {
                $summary['deckMetadataChanged'][] = $id;
            }
            if ($cardsChanged || $metadataChanged) {
                $deckVersion++;
            }
            $versions['decks'][$id] = [
                'deckVersion' => $deckVersion,
                'cardContentVersion' => $cardVersion,
            ];
        }
        foreach (array_keys($currentDecks) as $id) {
            if (!isset($draftDecks[$id])) {
                $summary['decksRemoved'][] = $id;
            }
        }

        foreach ($draft['bundles'] as $bundle) {
            $id = (string) $bundle['id'];
            $before = $currentBundles[$id] ?? null;
            if ($before === null) {
                $known = $currentVersions['bundles'][$id] ?? null;
                $versions['bundles'][$id] = [
                    'bundleVersion' => $known === null ? 1 : (int) $known['bundleVersion'] + 1,
                ];
                $summary['bundlesAdded'][] = $id;
                continue;
            }
            $known = $currentVersions['bundles'][$id] ?? ['bundleVersion' => 1];
            $changed = self::bundleMetadata($before) !== self::bundleMetadata($bundle);
            $versions['bundles'][$id] = [
                'bundleVersion' => (int) $known['bundleVersion'] + ($changed ? 1 : 0),
            ];
            if ($changed) {
                $summary['bundlesChanged'][] = $id;
            }
        }
        foreach (array_keys($currentBundles) as $id) {
            if (!isset($draftBundles[$id])) {
                $summary['bundlesRemoved'][] = $id;
            }
        }

        $changed = $summary['deckOrdersChanged'];
        foreach ($summary as $key => $value) {
            if ($key !== 'deckOrdersChanged' && is_array($value) && $value !== []) {
                $changed = true;
            }
        }
        if (!$changed) {
            throw new PlatformException('The draft contains no publishable changes.');
        }

        $catalog = $draft;
        $catalog['revision'] = (int) $current['revision'] + 1;
        $catalog['updatedAt'] = $publishedAt;
        foreach ($catalog['decks'] as &$deck) {
            $deck['version'] = $versions['decks'][(string) $deck['id']]['deckVersion'];
        }
        unset($deck);

        return ['catalog' => $catalog, 'versions' => $versions, 'summary' => $summary];
    }

    /** @return array<string,array> */
    private static function indexById(array $items): array
    {
        $indexed = [];
        foreach ($items as $item) {
            $indexed[(string) $item['id']] = $item;
        }
        return $indexed;
    }

    private static function deckMetadata(array $deck): array
    {
        unset($deck['cards'], $deck['version'], $deck['cardContentVersion'], $deck['cardCount']);
        return $deck;
    }

    private static function bundleMetadata(array $bundle): array
    {
        unset($bundle['version']);
        return $bundle;
    }
}

final class DraftRepository
{
    public function __construct(
        private readonly Database $database,
        private readonly CatalogStore $catalogs,
    ) {
    }

    /** @return array{draftId:int,draftVersion:int,baseRevision:int,catalog:array,createdBy:string,updatedBy:string} */
    public function loadActive(): array
    {
        $rows = $this->database->rows(
            "SELECT draft_id, draft_version, base_revision, catalog_json, created_by, updated_by "
            . "FROM catalog_drafts WHERE active_slot = 1 AND status = 'active'",
        );
        if ($rows === []) {
            throw new PlatformException('No active draft exists.');
        }
        return self::hydrate($rows[0]);
    }

    /** @return array{draftId:int,draftVersion:int,baseRevision:int,catalog:array,createdBy:string,updatedBy:string} */
    public function loadOrCreate(string $administrator): array
    {
        self::assertAdministrator($administrator);
        $rows = $this->database->rows(
            "SELECT draft_id, draft_version, base_revision, catalog_json, created_by, updated_by "
            . "FROM catalog_drafts WHERE active_slot = 1 AND status = 'active'",
        );
        if ($rows !== []) {
            return $this->loadActive();
        }
        $catalog = $this->catalogs->exportActive();
        $json = CatalogCodec::encode($catalog);
        try {
            $this->database->execute(
                "INSERT INTO catalog_drafts "
                . "(active_slot, status, base_revision, draft_version, catalog_json, created_by, updated_by) "
                . "VALUES (1, 'active', ?, 1, ?, ?, ?)",
                'isss',
                [(int) $catalog['revision'], $json, $administrator, $administrator],
            );
        } catch (\mysqli_sql_exception $error) {
            // Another request may have created the singleton draft first.
            if ($error->getCode() !== 1062) {
                throw $error;
            }
        }
        $rows = $this->database->rows(
            "SELECT draft_id, draft_version, base_revision, catalog_json, created_by, updated_by "
            . "FROM catalog_drafts WHERE active_slot = 1 AND status = 'active'",
        );
        if ($rows === []) {
            throw new PlatformException('The active draft could not be created.');
        }
        return $this->loadActive();
    }

    /** @return array{draftId:int,draftVersion:int,baseRevision:int,catalog:array,createdBy:string,updatedBy:string} */
    public function save(
        int $draftId,
        int $expectedVersion,
        array $catalog,
        string $administrator,
    ): array {
        self::assertAdministrator($administrator);
        $errors = \WhatzIt\DeckManager\CatalogValidator::validate($catalog);
        if ($errors !== []) {
            throw new PlatformException('Draft validation failed: ' . json_encode($errors, JSON_UNESCAPED_SLASHES));
        }
        $catalogJson = CatalogCodec::encode($catalog);
        $statement = $this->database->execute(
            "UPDATE catalog_drafts SET catalog_json = ?, draft_version = draft_version + 1, updated_by = ? "
            . "WHERE draft_id = ? AND draft_version = ? AND active_slot = 1 AND status = 'active' "
            . "AND base_revision = ? AND BINARY catalog_json <> BINARY ?",
            'ssiiis',
            [$catalogJson, $administrator, $draftId, $expectedVersion, (int) $catalog['revision'], $catalogJson],
        );
        $rows = $this->database->rows(
            'SELECT draft_id, draft_version, base_revision, catalog_json, created_by, updated_by '
            . "FROM catalog_drafts WHERE draft_id = ? AND active_slot = 1 AND status = 'active'",
            'i',
            [$draftId],
        );
        if (
            $statement->affected_rows !== 1
            && (
                $rows === []
                || (int) $rows[0]['base_revision'] !== (int) $catalog['revision']
                || !hash_equals((string) $rows[0]['catalog_json'], $catalogJson)
            )
        ) {
            throw new PublicationConflict('The draft changed or its base revision is no longer active.');
        }
        if ($rows === []) {
            throw new PlatformException('The saved draft could not be reloaded.');
        }
        return self::hydrate($rows[0]);
    }

    /** @return array{draftId:int,draftVersion:int,baseRevision:int,catalog:array,createdBy:string,updatedBy:string} */
    public function createFromRevision(int $sourceRevision, string $administrator): array
    {
        self::assertAdministrator($administrator);
        if ($this->database->scalar(
            "SELECT draft_id FROM catalog_drafts WHERE active_slot = 1 AND status = 'active'",
        ) !== null) {
            throw new PublicationConflict('Discard the active draft before preparing a rollback.');
        }
        $active = $this->catalogs->exportActive();
        $catalog = $this->catalogs->exportRevision($sourceRevision);
        if ((int) $active['revision'] === $sourceRevision) {
            throw new PlatformException('The active catalog revision cannot be rolled back to itself.');
        }
        $catalog['revision'] = (int) $active['revision'];
        $catalog['updatedAt'] = (string) $active['updatedAt'];
        try {
            $this->database->execute(
                "INSERT INTO catalog_drafts "
                . "(active_slot, status, base_revision, draft_version, catalog_json, created_by, updated_by) "
                . "VALUES (1, 'active', ?, 1, ?, ?, ?)",
                'isss',
                [
                    (int) $active['revision'],
                    CatalogCodec::encode($catalog),
                    $administrator,
                    $administrator,
                ],
            );
        } catch (\mysqli_sql_exception $error) {
            if ($error->getCode() === 1062) {
                throw new PublicationConflict('Another draft was created while the rollback was prepared.', 0, $error);
            }
            throw $error;
        }
        $rows = $this->database->rows(
            "SELECT draft_id, draft_version, base_revision, catalog_json, created_by, updated_by "
            . "FROM catalog_drafts WHERE active_slot = 1 AND status = 'active'",
        );
        if ($rows === []) {
            throw new PlatformException('The rollback draft could not be created.');
        }
        return self::hydrate($rows[0]);
    }

    public function discard(int $draftId, int $expectedVersion, string $administrator): void
    {
        self::assertAdministrator($administrator);
        $statement = $this->database->execute(
            "UPDATE catalog_drafts SET status = 'discarded', active_slot = NULL, "
            . "draft_version = draft_version + 1, updated_by = ? "
            . "WHERE draft_id = ? AND draft_version = ? AND active_slot = 1 AND status = 'active'",
            'sii',
            [$administrator, $draftId, $expectedVersion],
        );
        if ($statement->affected_rows !== 1) {
            throw new PublicationConflict('The draft changed before it could be discarded.');
        }
    }

    private static function hydrate(array $row): array
    {
        $catalog = json_decode((string) $row['catalog_json'], true, 512, JSON_THROW_ON_ERROR);
        if (!is_array($catalog)) {
            throw new PlatformException('Stored draft JSON is invalid.');
        }
        return [
            'draftId' => (int) $row['draft_id'],
            'draftVersion' => (int) $row['draft_version'],
            'baseRevision' => (int) $row['base_revision'],
            'catalog' => $catalog,
            'createdBy' => (string) $row['created_by'],
            'updatedBy' => (string) $row['updated_by'],
        ];
    }

    private static function assertAdministrator(string $administrator): void
    {
        if (preg_match('/^[A-Za-z0-9-]{1,100}$/', $administrator) !== 1) {
            throw new PlatformException('The administrator identity is invalid.');
        }
    }
}

final class ArtifactPromoter
{
    public function promoteImmutable(string $preparationRoot, string $artifactRoot): void
    {
        foreach (['decks', 'covers', 'thumbnails'] as $directory) {
            $sourceRoot = rtrim($preparationRoot, '/\\') . DIRECTORY_SEPARATOR . $directory;
            if (!is_dir($sourceRoot)) {
                continue;
            }
            $iterator = new \RecursiveIteratorIterator(
                new \RecursiveDirectoryIterator($sourceRoot, \FilesystemIterator::SKIP_DOTS),
            );
            foreach ($iterator as $source) {
                if (!$source->isFile()) {
                    continue;
                }
                $relative = substr($source->getPathname(), strlen($sourceRoot) + 1);
                $destination = rtrim($artifactRoot, '/\\') . DIRECTORY_SEPARATOR . $directory
                    . DIRECTORY_SEPARATOR . $relative;
                self::copyImmutable($source->getPathname(), $destination);
            }
        }
    }

    public function activateManifest(
        string $preparationRoot,
        string $artifactRoot,
        string $expectedHash,
    ): void {
        $source = rtrim($preparationRoot, '/\\') . DIRECTORY_SEPARATOR . 'manifest.json';
        $bytes = is_file($source) ? file_get_contents($source) : false;
        if (!is_string($bytes) || !hash_equals($expectedHash, hash('sha256', $bytes))) {
            throw new PlatformException('The prepared manifest failed integrity validation.');
        }
        self::ensureDirectory($artifactRoot);
        $destination = rtrim($artifactRoot, '/\\') . DIRECTORY_SEPARATOR . 'manifest.json';
        $temporary = $destination . '.tmp-' . bin2hex(random_bytes(8));
        if (file_put_contents($temporary, $bytes, LOCK_EX) !== strlen($bytes)) {
            @unlink($temporary);
            throw new PlatformException('The prepared manifest could not be staged for activation.');
        }
        if (DIRECTORY_SEPARATOR === '\\' && is_file($destination) && !unlink($destination)) {
            @unlink($temporary);
            throw new PlatformException('The active manifest could not be replaced.');
        }
        if (!rename($temporary, $destination)) {
            @unlink($temporary);
            throw new PlatformException('The prepared manifest could not be activated.');
        }
    }

    private static function copyImmutable(string $source, string $destination): void
    {
        self::ensureDirectory(dirname($destination));
        $sourceHash = hash_file('sha256', $source);
        if (!is_string($sourceHash)) {
            throw new PlatformException('A prepared artifact could not be hashed.');
        }
        if (is_file($destination)) {
            $destinationHash = hash_file('sha256', $destination);
            if (!is_string($destinationHash) || !hash_equals($sourceHash, $destinationHash)) {
                throw new PlatformException('An immutable artifact collision was detected.');
            }
            return;
        }
        $bytes = file_get_contents($source);
        if (!is_string($bytes)) {
            throw new PlatformException('A prepared artifact could not be read.');
        }
        $handle = @fopen($destination, 'x+b');
        if ($handle === false) {
            throw new PlatformException('An immutable artifact could not be created.');
        }
        try {
            if (fwrite($handle, $bytes) !== strlen($bytes) || !fflush($handle)) {
                throw new PlatformException('An immutable artifact could not be written completely.');
            }
        } finally {
            fclose($handle);
        }
    }

    private static function ensureDirectory(string $directory): void
    {
        if (!is_dir($directory) && !mkdir($directory, 0775, true) && !is_dir($directory)) {
            throw new PlatformException('An artifact directory could not be created.');
        }
    }
}

final class PublicationEngine
{
    public function __construct(
        private readonly Database $database,
        private readonly CatalogStore $catalogs,
        private readonly ArtifactBuilder $artifacts = new ArtifactBuilder(),
        private readonly ArtifactPromoter $promoter = new ArtifactPromoter(),
    ) {
    }

    /**
     * @param array{draftId:int,draftVersion:int,baseRevision:int,catalog:array} $draft
     * @return array{preparationId:string,catalog:array,versions:array,summary:array,manifestHash:string}
     */
    public function publish(
        array $draft,
        string $administrator,
        string $mediaRoot,
        string $artifactRoot,
        string $apiBaseUrl,
        string $contentBaseUrl,
        ?int $rollbackOfRevision = null,
        ?string $publishedAt = null,
        array $mediaChangedDeckIds = [],
    ): array {
        if (preg_match('/^[A-Za-z0-9-]{1,100}$/', $administrator) !== 1) {
            throw new PlatformException('The administrator identity is invalid.');
        }
        $current = $this->catalogs->exportActive();
        if ((int) $draft['baseRevision'] !== (int) $current['revision']) {
            throw new PublicationConflict('The draft base is no longer the active catalog revision.');
        }
        $plan = VersionPlanner::plan(
            $current,
            $draft['catalog'],
            $this->catalogs->publishedVersions(),
            $publishedAt ?? gmdate('Y-m-d\TH:i:s\Z'),
            $mediaChangedDeckIds,
        );
        $preparationId = bin2hex(random_bytes(16));
        $targetRevision = (int) $plan['catalog']['revision'];
        $preparationRoot = rtrim($artifactRoot, '/\\') . DIRECTORY_SEPARATOR
            . '.preparations' . DIRECTORY_SEPARATOR . $preparationId;
        $this->database->execute(
            'INSERT INTO publication_preparations '
            . '(preparation_id, draft_id, draft_version, base_revision, target_revision, state) '
            . "VALUES (?, ?, ?, ?, ?, 'preparing')",
            'siiii',
            [
                $preparationId,
                (int) $draft['draftId'],
                (int) $draft['draftVersion'],
                (int) $draft['baseRevision'],
                $targetRevision,
            ],
        );

        try {
            $artifact = $this->artifacts->build(
                $plan['catalog'],
                $mediaRoot,
                $preparationRoot,
                $apiBaseUrl,
                $contentBaseUrl,
                $plan['versions'],
            );
            $this->catalogs->preparePublication(
                $plan['catalog'],
                $plan['versions'],
                $mediaRoot,
                CatalogCodec::hash($plan['catalog']),
                (string) $artifact['etag'],
            );
            $this->database->execute(
                "UPDATE publication_preparations SET state = 'artifacts_ready', manifest_hash = ? "
                . "WHERE preparation_id = ? AND state = 'preparing'",
                'ss',
                [(string) $artifact['etag'], $preparationId],
            );
            $this->promoter->promoteImmutable($preparationRoot, $artifactRoot);
            $this->catalogs->activatePublication(
                $preparationId,
                (int) $draft['draftId'],
                (int) $draft['draftVersion'],
                $targetRevision,
                $administrator,
                $plan['summary'],
                $rollbackOfRevision,
            );
            $this->promoter->activateManifest(
                $preparationRoot,
                $artifactRoot,
                (string) $artifact['etag'],
            );
            $this->database->execute(
                "UPDATE publication_preparations SET state = 'active' "
                . "WHERE preparation_id = ? AND state = 'database_active'",
                's',
                [$preparationId],
            );
        } catch (Throwable $error) {
            $state = $this->database->scalar(
                'SELECT state FROM publication_preparations WHERE preparation_id = ?',
                's',
                [$preparationId],
            );
            if ($state !== 'database_active') {
                $this->catalogs->abandonPreparedPublication($targetRevision);
            }
            $this->database->execute(
                "UPDATE publication_preparations SET "
                . "state = CASE WHEN state = 'database_active' THEN state ELSE 'failed' END, "
                . "error_code = 'publication_failed' WHERE preparation_id = ?",
                's',
                [$preparationId],
            );
            throw $error;
        }

        return [
            'preparationId' => $preparationId,
            'catalog' => $plan['catalog'],
            'versions' => $plan['versions'],
            'summary' => $plan['summary'],
            'manifestHash' => (string) $artifact['etag'],
        ];
    }

    /** @return list<array{preparationId:string,targetRevision:int,state:string,manifestHash:?string,errorCode:?string}> */
    public function operationalStatus(): array
    {
        return array_map(
            static fn (array $row): array => [
                'preparationId' => (string) $row['preparation_id'],
                'targetRevision' => (int) $row['target_revision'],
                'state' => (string) $row['state'],
                'manifestHash' => $row['manifest_hash'] === null ? null : (string) $row['manifest_hash'],
                'errorCode' => $row['error_code'] === null ? null : (string) $row['error_code'],
            ],
            $this->database->rows(
                "SELECT preparation_id, target_revision, state, manifest_hash, error_code "
                . "FROM publication_preparations "
                . "WHERE state IN ('preparing', 'artifacts_ready', 'database_active', 'failed') "
                . 'ORDER BY created_at DESC',
            ),
        );
    }

    public function resumeManifestActivation(string $preparationId, string $artifactRoot): void
    {
        if (preg_match('/^[a-f0-9]{32}$/', $preparationId) !== 1) {
            throw new PlatformException('The publication preparation ID is invalid.');
        }
        $rows = $this->database->rows(
            'SELECT target_revision, state, manifest_hash FROM publication_preparations WHERE preparation_id = ?',
            's',
            [$preparationId],
        );
        if ($rows === []) {
            throw new PlatformException('The publication preparation does not exist.');
        }
        $state = (string) $rows[0]['state'];
        if ($state === 'active') {
            return;
        }
        if ($state !== 'database_active') {
            throw new PlatformException('Only a database-active publication can resume manifest activation.');
        }
        $targetRevision = (int) $rows[0]['target_revision'];
        $activeRevision = $this->database->scalar(
            'SELECT revision FROM active_catalog_revision WHERE singleton_id = 1',
        );
        if ((int) $activeRevision !== $targetRevision) {
            throw new PublicationConflict('The database-active preparation is no longer the active catalog revision.');
        }
        $manifestHash = (string) ($rows[0]['manifest_hash'] ?? '');
        if (preg_match('/^[a-f0-9]{64}$/', $manifestHash) !== 1) {
            throw new PlatformException('The database-active preparation has no valid manifest hash.');
        }
        $preparationRoot = rtrim($artifactRoot, '/\\') . DIRECTORY_SEPARATOR
            . '.preparations' . DIRECTORY_SEPARATOR . $preparationId;
        $this->promoter->activateManifest($preparationRoot, $artifactRoot, $manifestHash);
        $statement = $this->database->execute(
            "UPDATE publication_preparations SET state = 'active', error_code = NULL "
            . "WHERE preparation_id = ? AND state = 'database_active'",
            's',
            [$preparationId],
        );
        if ($statement->affected_rows !== 1) {
            $finalState = $this->database->scalar(
                'SELECT state FROM publication_preparations WHERE preparation_id = ?',
                's',
                [$preparationId],
            );
            if ($finalState !== 'active') {
                throw new PublicationConflict('The publication state changed while manifest activation resumed.');
            }
        }
    }

    /** @return array{preparationId:string,catalog:array,versions:array,summary:array,manifestHash:string} */
    public function rollback(
        int $sourceRevision,
        string $administrator,
        string $mediaRoot,
        string $artifactRoot,
        string $apiBaseUrl,
        string $contentBaseUrl,
        ?string $publishedAt = null,
    ): array {
        $drafts = new DraftRepository($this->database, $this->catalogs);
        $draft = $drafts->createFromRevision($sourceRevision, $administrator);
        return $this->publish(
            $draft,
            $administrator,
            $mediaRoot,
            $artifactRoot,
            $apiBaseUrl,
            $contentBaseUrl,
            $sourceRevision,
            $publishedAt,
        );
    }
}
