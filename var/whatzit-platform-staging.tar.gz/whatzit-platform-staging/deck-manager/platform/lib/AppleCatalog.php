<?php

declare(strict_types=1);

namespace WhatzIt\DeckPlatform;

use JsonException;

final class AppStoreConnectCatalogClient
{
    /** @var null|callable(string,string):array{status:int,body:string} */
    private $transport;

    public function __construct(
        private readonly PlatformConfig $config,
        ?callable $transport = null,
    ) {
        $this->transport = $transport;
    }

    /** @return array<string,array{productId:string,inAppPurchaseType:string,state:string}> */
    public function products(): array
    {
        $problems = $this->config->appleCatalogProblems();
        if ($problems !== []) throw new PlatformException(implode(' ', $problems));
        $jwt = $this->authorizationToken();
        $url = 'https://api.appstoreconnect.apple.com/v1/apps/'
            . rawurlencode($this->config->appStoreConnectAppId)
            . '/inAppPurchasesV2?limit=50';
        $products = [];
        for ($page = 0; $url !== null && $page < 100; $page++) {
            self::assertAppleUrl($url);
            $response = $this->request($url, $jwt);
            if ($response['status'] !== 200) {
                throw new PlatformException(
                    'App Store Connect product validation failed (HTTP '
                    . ($response['status'] ?: 'unavailable')
                    . '). Confirm the app ID and that the App Store Connect API key has App Manager access.',
                );
            }
            try {
                $body = json_decode($response['body'], true, 128, JSON_THROW_ON_ERROR);
            } catch (JsonException) {
                throw new PlatformException('App Store Connect returned an invalid product catalog response.');
            }
            if (!is_array($body) || !is_array($body['data'] ?? null)) {
                throw new PlatformException('App Store Connect returned an incomplete product catalog response.');
            }
            foreach ($body['data'] as $item) {
                $attributes = is_array($item) ? ($item['attributes'] ?? null) : null;
                if (!is_array($attributes)) continue;
                $productId = $attributes['productId'] ?? null;
                if (!is_string($productId) || $productId === '') continue;
                $products[$productId] = [
                    'productId' => $productId,
                    'inAppPurchaseType' => is_string($attributes['inAppPurchaseType'] ?? null)
                        ? $attributes['inAppPurchaseType'] : '',
                    'state' => is_string($attributes['state'] ?? null) ? $attributes['state'] : '',
                ];
            }
            $next = is_array($body['links'] ?? null) ? ($body['links']['next'] ?? null) : null;
            $url = is_string($next) && $next !== '' ? $next : null;
        }
        if ($url !== null) throw new PlatformException('App Store Connect returned too many product catalog pages.');
        return $products;
    }

    private function authorizationToken(): string
    {
        $now = time();
        $header = self::base64UrlEncode((string) json_encode([
            'alg' => 'ES256',
            'kid' => $this->config->appStoreConnectKeyId,
            'typ' => 'JWT',
        ], JSON_THROW_ON_ERROR | JSON_UNESCAPED_SLASHES));
        $payload = self::base64UrlEncode((string) json_encode([
            'iss' => $this->config->appStoreConnectIssuerId,
            'iat' => $now,
            'exp' => $now + 300,
            'aud' => 'appstoreconnect-v1',
        ], JSON_THROW_ON_ERROR | JSON_UNESCAPED_SLASHES));
        $input = $header . '.' . $payload;
        $keyBytes = file_get_contents($this->config->appStoreConnectPrivateKeyPath);
        $key = is_string($keyBytes) ? openssl_pkey_get_private($keyBytes) : false;
        if ($key === false || !openssl_sign($input, $derSignature, $key, OPENSSL_ALGO_SHA256)) {
            throw new PlatformException('The App Store Connect authorization token could not be signed.');
        }
        return $input . '.' . self::base64UrlEncode(self::derToJose($derSignature));
    }

    /** @return array{status:int,body:string} */
    private function request(string $url, string $jwt): array
    {
        if ($this->transport !== null) return ($this->transport)($url, $jwt);
        $context = stream_context_create(['http' => [
            'method' => 'GET',
            'header' => "Authorization: Bearer $jwt\r\nAccept: application/json\r\n",
            'ignore_errors' => true,
            'timeout' => 15,
        ]]);
        $body = @file_get_contents($url, false, $context);
        $headers = $http_response_header ?? [];
        $status = 0;
        if (isset($headers[0]) && preg_match('/\s(\d{3})\s/', $headers[0], $matches) === 1) {
            $status = (int) $matches[1];
        }
        return ['status' => $status, 'body' => is_string($body) ? $body : ''];
    }

    private static function assertAppleUrl(string $url): void
    {
        $parts = parse_url($url);
        if (($parts['scheme'] ?? null) !== 'https'
            || ($parts['host'] ?? null) !== 'api.appstoreconnect.apple.com'
            || !str_starts_with((string) ($parts['path'] ?? ''), '/v1/')) {
            throw new PlatformException('App Store Connect returned an unsafe pagination URL.');
        }
    }

    private static function base64UrlEncode(string $bytes): string
    {
        return rtrim(strtr(base64_encode($bytes), '+/', '-_'), '=');
    }

    private static function derToJose(string $der): string
    {
        $offset = 0;
        if (ord($der[$offset++] ?? "\0") !== 0x30) {
            throw new PlatformException('App Store Connect JWT signing returned an invalid signature.');
        }
        self::readDerLength($der, $offset);
        $r = self::readDerInteger($der, $offset);
        $s = self::readDerInteger($der, $offset);
        return str_pad(ltrim($r, "\0"), 32, "\0", STR_PAD_LEFT)
            . str_pad(ltrim($s, "\0"), 32, "\0", STR_PAD_LEFT);
    }

    private static function readDerInteger(string $der, int &$offset): string
    {
        if (ord($der[$offset++] ?? "\0") !== 0x02) {
            throw new PlatformException('App Store Connect JWT signing returned an invalid integer.');
        }
        $length = self::readDerLength($der, $offset);
        $value = substr($der, $offset, $length);
        $offset += $length;
        if ($value === false || strlen(ltrim($value, "\0")) > 32) {
            throw new PlatformException('App Store Connect JWT signature is out of range.');
        }
        return $value;
    }

    private static function readDerLength(string $der, int &$offset): int
    {
        $length = ord($der[$offset++] ?? "\0");
        if (($length & 0x80) === 0) return $length;
        $bytes = $length & 0x7f;
        if ($bytes < 1 || $bytes > 2) {
            throw new PlatformException('App Store Connect JWT signature length is invalid.');
        }
        $length = 0;
        for ($index = 0; $index < $bytes; $index++) {
            $length = ($length << 8) | ord($der[$offset++] ?? "\0");
        }
        return $length;
    }
}

final class AppleCatalogPublicationGate
{
    private const UNUSABLE_STATES = [
        'MISSING_METADATA',
        'DEVELOPER_ACTION_NEEDED',
        'DEVELOPER_REMOVED_FROM_SALE',
        'REMOVED_FROM_SALE',
        'REJECTED',
    ];

    public function __construct(
        private readonly PlatformConfig $config,
        private readonly AppStoreConnectCatalogClient $client,
    ) {
    }

    public function assertPublishable(array $catalog): void
    {
        if ($this->config->appleCatalogValidation !== 'required') return;
        $expected = self::availableProducts($catalog);
        if ($expected === []) return;
        $actual = $this->client->products();
        $missing = [];
        $wrongType = [];
        $unusable = [];
        foreach ($expected as $productId => $labels) {
            $product = $actual[$productId] ?? null;
            $label = $productId . ' (' . implode(', ', $labels) . ')';
            if ($product === null) {
                $missing[] = $label;
            } elseif ($product['inAppPurchaseType'] !== 'NON_CONSUMABLE') {
                $wrongType[] = $label . ': ' . ($product['inAppPurchaseType'] ?: 'unknown type');
            } elseif (in_array($product['state'], self::UNUSABLE_STATES, true)) {
                $unusable[] = $label . ': ' . $product['state'];
            }
        }
        $details = [];
        if ($missing !== []) $details[] = 'Missing: ' . implode('; ', $missing) . '.';
        if ($wrongType !== []) $details[] = 'Must be non-consumable: ' . implode('; ', $wrongType) . '.';
        if ($unusable !== []) $details[] = 'Not usable at Apple: ' . implode('; ', $unusable) . '.';
        if ($details !== []) {
            throw new PlatformException(
                'Apple product validation blocked this action. ' . implode(' ', $details)
                . ' Create or repair these products in App Store Connect, then try again.',
            );
        }
    }

    /** @return array<string,list<string>> */
    public static function availableProducts(array $catalog): array
    {
        $expected = [];
        foreach (['decks' => 'deck', 'bundles' => 'bundle'] as $collection => $type) {
            foreach (is_array($catalog[$collection] ?? null) ? $catalog[$collection] : [] as $item) {
                if (!is_array($item)) continue;
                $mapping = $item['storeProducts']['apple'] ?? null;
                if (!is_array($mapping)) continue;
                $id = is_string($item['id'] ?? null) ? $item['id'] : 'unknown';
                self::addExpected($expected, $mapping, "$type $id");
                if ($type !== 'bundle') continue;
                foreach (is_array($mapping['ownedDeckCountProducts'] ?? null)
                    ? $mapping['ownedDeckCountProducts'] : [] as $ownedCount => $tier) {
                    if (is_array($tier)) self::addExpected($expected, $tier, "$type $id owns $ownedCount");
                }
            }
        }
        ksort($expected, SORT_STRING);
        return $expected;
    }

    /** @param array<string,list<string>> $expected */
    private static function addExpected(array &$expected, array $mapping, string $label): void
    {
        $productId = $mapping['productId'] ?? null;
        if (($mapping['status'] ?? null) !== 'available' || !is_string($productId) || $productId === '') return;
        $expected[$productId] ??= [];
        $expected[$productId][] = $label;
    }
}
