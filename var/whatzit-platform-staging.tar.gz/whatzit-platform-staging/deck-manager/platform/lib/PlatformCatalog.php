<?php

declare(strict_types=1);

namespace WhatzIt\DeckPlatform;

use JsonException;
use mysqli;
use mysqli_result;
use mysqli_stmt;
use RuntimeException;
use Throwable;

class PlatformException extends RuntimeException
{
}

final class PublicRoute
{
    public static function normalizePath(string $path): string
    {
        // A subdirectory deployment may prefix the public route. Select the
        // first API/content boundary: deck routes themselves also contain a
        // later `/content/` segment, which must not win.
        $route = preg_replace('#^.*?(?=/(?:api/v1|content)(?:/|$))#', '', $path, 1);
        return is_string($route) ? $route : $path;
    }
}

final class PlatformConfig
{
    public readonly string $environment;
    public readonly string $dbHost;
    public readonly int $dbPort;
    public readonly string $dbName;
    public readonly string $dbUser;
    public readonly string $dbPassword;
    public readonly string $apiBaseUrl;
    public readonly string $contentBaseUrl;
    public readonly string $artifactRoot;
    public readonly string $mediaRoot;
    public readonly string $appleBundleId;
    public readonly string $appleKeyId;
    public readonly string $appleIssuerId;
    public readonly string $applePrivateKeyPath;
    public readonly string $appleCatalogValidation;
    public readonly string $appStoreConnectAppId;
    public readonly string $appStoreConnectKeyId;
    public readonly string $appStoreConnectIssuerId;
    public readonly string $appStoreConnectPrivateKeyPath;
    public readonly string $googlePackageName;
    public readonly string $googleServiceAccountPath;
    public readonly string $devPreviewKey;

    public function __construct(?array $values = null)
    {
        $values ??= self::runtimeValues();
        $read = static function (string $key) use ($values): string {
            $value = $values[$key] ?? getenv($key);
            return is_scalar($value) ? trim((string) $value) : '';
        };
        $this->environment = strtolower($read('WHATZIT_PLATFORM_ENV') ?: 'development');
        $this->dbHost = $read('WHATZIT_DB_HOST') ?: '127.0.0.1';
        $this->dbPort = max(1, (int) ($read('WHATZIT_DB_PORT') ?: '3306'));
        $this->dbName = $read('WHATZIT_DB_NAME');
        $this->dbUser = $read('WHATZIT_DB_USER');
        $this->dbPassword = $read('WHATZIT_DB_PASSWORD');
        $this->apiBaseUrl = rtrim($read('WHATZIT_PUBLIC_API_BASE_URL'), '/');
        $this->contentBaseUrl = rtrim($read('WHATZIT_CONTENT_BASE_URL'), '/');
        $this->artifactRoot = rtrim($read('WHATZIT_ARTIFACT_ROOT'), '/\\');
        $this->mediaRoot = rtrim($read('WHATZIT_MEDIA_ROOT'), '/\\');
        $this->appleBundleId = $read('WHATZIT_APPLE_BUNDLE_ID') ?: 'com.cadelawless.whatzit';
        $this->appleKeyId = $read('WHATZIT_APPLE_IAP_KEY_ID');
        $this->appleIssuerId = $read('WHATZIT_APPLE_IAP_ISSUER_ID');
        $this->applePrivateKeyPath = rtrim($read('WHATZIT_APPLE_IAP_PRIVATE_KEY_PATH'), '/\\');
        $this->appleCatalogValidation = strtolower($read('WHATZIT_APPLE_CATALOG_VALIDATION') ?: 'disabled');
        $this->appStoreConnectAppId = $read('WHATZIT_ASC_APP_ID');
        $this->appStoreConnectKeyId = $read('WHATZIT_ASC_KEY_ID');
        $this->appStoreConnectIssuerId = $read('WHATZIT_ASC_ISSUER_ID');
        $this->appStoreConnectPrivateKeyPath = rtrim($read('WHATZIT_ASC_PRIVATE_KEY_PATH'), '/\\');
        $this->googlePackageName = $read('WHATZIT_GOOGLE_PACKAGE_NAME') ?: 'com.cadelawless.whatzit';
        $this->googleServiceAccountPath = rtrim($read('WHATZIT_GOOGLE_SERVICE_ACCOUNT_PATH'), '/\\');
        $this->devPreviewKey = strtolower($read('WHATZIT_DEV_PREVIEW_KEY'));
    }

    /** @return list<string> */
    public function problems(
        bool $database = true,
        bool $artifacts = false,
        bool $artifactRoot = true,
        bool $mediaRoot = false,
    ): array
    {
        $problems = [];
        if (!in_array($this->environment, ['development', 'test', 'production'], true)) {
            $problems[] = 'WHATZIT_PLATFORM_ENV must be development, test, or production.';
        }
        if (!in_array($this->appleCatalogValidation, ['disabled', 'required'], true)) {
            $problems[] = 'WHATZIT_APPLE_CATALOG_VALIDATION must be disabled or required.';
        }
        if ($database) {
            if ($this->dbName === '') {
                $problems[] = 'WHATZIT_DB_NAME is not configured.';
            }
            if ($this->dbUser === '') {
                $problems[] = 'WHATZIT_DB_USER is not configured.';
            }
            if (!extension_loaded('mysqli')) {
                $problems[] = 'The PHP mysqli extension is required.';
            }
        }
        if ($artifacts) {
            foreach (['API' => $this->apiBaseUrl, 'content' => $this->contentBaseUrl] as $label => $url) {
                if ($url === '') {
                    $problems[] = "The $label base URL is not configured.";
                } elseif ($this->environment === 'production' && !str_starts_with(strtolower($url), 'https://')) {
                    $problems[] = "The production $label base URL must use HTTPS.";
                } elseif (!filter_var($url, FILTER_VALIDATE_URL)) {
                    $problems[] = "The $label base URL is invalid.";
                }
            }
        }
        if ($artifacts && $artifactRoot && ($this->artifactRoot === '' || !self::isAbsolutePath($this->artifactRoot))) {
            $problems[] = 'WHATZIT_ARTIFACT_ROOT must be an absolute filesystem path.';
        }
        if ($mediaRoot && ($this->mediaRoot === '' || !self::isAbsolutePath($this->mediaRoot))) {
            $problems[] = 'WHATZIT_MEDIA_ROOT must be an absolute filesystem path.';
        }
        return $problems;
    }

    /** @return list<string> */
    public function commerceProblems(): array
    {
        $problems = $this->problems(database: true);
        if (preg_match('/^[A-Za-z0-9.-]+$/', $this->appleBundleId) !== 1) {
            $problems[] = 'WHATZIT_APPLE_BUNDLE_ID is invalid.';
        }
        if (preg_match('/^[A-Z0-9]{10}$/', $this->appleKeyId) !== 1) {
            $problems[] = 'WHATZIT_APPLE_IAP_KEY_ID must be a 10-character Apple key ID.';
        }
        if (preg_match('/^[a-f0-9-]{36}$/i', $this->appleIssuerId) !== 1) {
            $problems[] = 'WHATZIT_APPLE_IAP_ISSUER_ID must be an Apple issuer UUID.';
        }
        if ($this->applePrivateKeyPath === '' || !self::isAbsolutePath($this->applePrivateKeyPath)) {
            $problems[] = 'WHATZIT_APPLE_IAP_PRIVATE_KEY_PATH must be an absolute filesystem path.';
        } elseif (!is_readable($this->applePrivateKeyPath)) {
            $problems[] = 'The configured Apple In-App Purchase private key is not readable.';
        }
        if (!extension_loaded('openssl')) {
            $problems[] = 'The PHP OpenSSL extension is required for Apple commerce.';
        }
        return $problems;
    }

    /** @return list<string> */
    public function appleCatalogProblems(): array
    {
        if ($this->appleCatalogValidation !== 'required') return [];
        $problems = [];
        if (preg_match('/^[1-9][0-9]{0,19}$/', $this->appStoreConnectAppId) !== 1) {
            $problems[] = 'WHATZIT_ASC_APP_ID must be the numeric App Store Connect app ID.';
        }
        if (preg_match('/^[A-Z0-9]{10}$/', $this->appStoreConnectKeyId) !== 1) {
            $problems[] = 'WHATZIT_ASC_KEY_ID must be a 10-character App Store Connect API key ID.';
        }
        if (preg_match('/^[a-f0-9-]{36}$/i', $this->appStoreConnectIssuerId) !== 1) {
            $problems[] = 'WHATZIT_ASC_ISSUER_ID must be an App Store Connect issuer UUID.';
        }
        if ($this->appStoreConnectPrivateKeyPath === '' || !self::isAbsolutePath($this->appStoreConnectPrivateKeyPath)) {
            $problems[] = 'WHATZIT_ASC_PRIVATE_KEY_PATH must be an absolute filesystem path.';
        } elseif (!is_readable($this->appStoreConnectPrivateKeyPath)) {
            $problems[] = 'The configured App Store Connect API private key is not readable.';
        }
        if (!extension_loaded('openssl')) {
            $problems[] = 'The PHP OpenSSL extension is required for App Store Connect validation.';
        }
        return $problems;
    }

    /** @return list<string> */
    public function devPreviewProblems(): array
    {
        $problems = $this->problems(database: true, artifacts: true, mediaRoot: true);
        if (preg_match('/^[a-f0-9]{64}$/', $this->devPreviewKey) !== 1) {
            $problems[] = 'WHATZIT_DEV_PREVIEW_KEY must be 64 lowercase hexadecimal characters.';
        }
        return $problems;
    }

    public function assertReady(
        bool $database = true,
        bool $artifacts = false,
        bool $artifactRoot = true,
        bool $mediaRoot = false,
    ): void
    {
        $problems = $this->problems($database, $artifacts, $artifactRoot, $mediaRoot);
        if ($problems !== []) {
            throw new PlatformException(implode(' ', $problems));
        }
    }

    public function assertTestDatabase(): void
    {
        if ($this->environment !== 'test'
            || preg_match('/(?:^|_)test(?:_|$)/i', $this->dbName) !== 1) {
            throw new PlatformException(
                'Database integration tests require WHATZIT_PLATFORM_ENV=test and an explicitly named *_test database.',
            );
        }
    }

    private static function runtimeValues(): array
    {
        $runtime = array_merge($_ENV, $_SERVER);
        $pathValue = $runtime['WHATZIT_CONFIG_PATH'] ?? getenv('WHATZIT_CONFIG_PATH');
        $configuredPath = is_scalar($pathValue) ? trim((string) $pathValue) : '';
        $local = dirname(__DIR__, 2) . '/config.local.php';
        $documentRoot = is_scalar($_SERVER['DOCUMENT_ROOT'] ?? null)
            ? rtrim((string) $_SERVER['DOCUMENT_ROOT'], '/\\')
            : '';
        $hosted = self::hostedConfigurationPath($documentRoot);
        $path = $configuredPath !== ''
            ? $configuredPath
            : (is_file($local) ? $local : $hosted);
        if ($configuredPath !== '' && !self::isAbsolutePath($configuredPath)) {
            throw new PlatformException('WHATZIT_CONFIG_PATH must be an absolute filesystem path.');
        }
        if ($path === '') {
            return $runtime;
        }
        if (!self::isAbsolutePath($path) || ($configuredPath !== '' && !is_readable($path))) {
            throw new PlatformException('WHATZIT_CONFIG_PATH must identify a readable absolute PHP configuration file.');
        }
        if (!is_readable($path)) {
            return $runtime;
        }
        $loaded = require $path;
        if (!is_array($loaded)) {
            throw new PlatformException('The platform configuration file must return an array.');
        }
        return array_merge($runtime, $loaded);
    }

    private static function hostedConfigurationPath(string $documentRoot): string
    {
        if ($documentRoot === '') {
            return '';
        }
        $normalized = str_replace('\\', '/', $documentRoot);
        $publicHtml = stripos($normalized, '/public_html');
        $hostingRoot = $publicHtml === false ? dirname($documentRoot) : substr($normalized, 0, $publicHtml);
        if ($hostingRoot === '') {
            $hostingRoot = dirname($documentRoot);
        }
        return rtrim($hostingRoot, '/\\') . '/whatzit-secrets/deck-platform-config.php';
    }

    private static function isAbsolutePath(string $path): bool
    {
        return str_starts_with($path, '/')
            || str_starts_with($path, '\\\\')
            || preg_match('/^[A-Za-z]:[\\\\\/]/', $path) === 1;
    }
}

final class Database
{
    private readonly mysqli $connection;

    public function __construct(PlatformConfig $config)
    {
        $config->assertReady(database: true);
        mysqli_report(MYSQLI_REPORT_ERROR | MYSQLI_REPORT_STRICT);
        $this->connection = new mysqli(
            $config->dbHost,
            $config->dbUser,
            $config->dbPassword,
            $config->dbName,
            $config->dbPort,
        );
        $this->connection->set_charset('utf8mb4');
        $this->connection->query("SET SESSION time_zone = '+00:00'");
        $this->connection->query("SET SESSION sql_mode = 'STRICT_ALL_TABLES,ERROR_FOR_DIVISION_BY_ZERO,NO_ENGINE_SUBSTITUTION'");
    }

    public function begin(): void
    {
        $this->connection->begin_transaction();
    }

    public function commit(): void
    {
        $this->connection->commit();
    }

    public function rollback(): void
    {
        $this->connection->rollback();
    }

    public function execute(string $sql, string $types = '', array $values = []): mysqli_stmt
    {
        $statement = $this->connection->prepare($sql);
        if ($types !== '') {
            $statement->bind_param($types, ...$values);
        }
        $statement->execute();
        return $statement;
    }

    /** @return list<array<string,mixed>> */
    public function rows(string $sql, string $types = '', array $values = []): array
    {
        $result = $this->execute($sql, $types, $values)->get_result();
        if (!$result instanceof mysqli_result) {
            return [];
        }
        return $result->fetch_all(MYSQLI_ASSOC);
    }

    public function scalar(string $sql, string $types = '', array $values = []): mixed
    {
        $rows = $this->rows($sql, $types, $values);
        return $rows === [] ? null : array_values($rows[0])[0];
    }

    public function multiQuery(string $sql): void
    {
        $this->connection->multi_query($sql);
        do {
            $result = $this->connection->store_result();
            if ($result instanceof mysqli_result) {
                $result->free();
            }
        } while ($this->connection->more_results() && $this->connection->next_result());
    }
}

final class Migrator
{
    public function __construct(
        private readonly Database $database,
        private readonly string $directory,
    ) {
    }

    /** @return list<int> */
    public function migrate(): array
    {
        $this->database->multiQuery(
            'CREATE TABLE IF NOT EXISTS schema_migrations ('
            . 'version INT UNSIGNED NOT NULL PRIMARY KEY, '
            . 'name VARCHAR(190) NOT NULL, '
            . 'checksum CHAR(64) CHARACTER SET ascii COLLATE ascii_bin NOT NULL, '
            . 'applied_at TIMESTAMP(6) NOT NULL DEFAULT CURRENT_TIMESTAMP(6)'
            . ') ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_bin',
        );
        $files = glob(rtrim($this->directory, '/\\') . '/*.sql') ?: [];
        sort($files, SORT_STRING);
        $applied = [];
        foreach ($files as $file) {
            $name = basename($file);
            if (preg_match('/^(\d+)_.*\.sql$/', $name, $matches) !== 1) {
                throw new PlatformException("Invalid migration filename: $name");
            }
            $version = (int) $matches[1];
            $sql = file_get_contents($file);
            if (!is_string($sql)) {
                throw new PlatformException("Migration could not be read: $name");
            }
            $checksum = self::checksum($sql);
            $existing = $this->database->rows(
                'SELECT checksum FROM schema_migrations WHERE version = ?',
                'i',
                [$version],
            );
            if ($existing !== []) {
                if (!hash_equals((string) $existing[0]['checksum'], $checksum)) {
                    throw new PlatformException("Applied migration $version has been modified.");
                }
                continue;
            }
            $this->database->multiQuery($sql);
            $this->database->execute(
                'INSERT INTO schema_migrations (version, name, checksum) VALUES (?, ?, ?)',
                'iss',
                [$version, $name, $checksum],
            );
            $applied[] = $version;
        }
        return $applied;
    }

    public static function checksum(string $sql): string
    {
        // Git may materialize text files with CRLF on Windows and LF on the
        // server. Migration integrity is about the SQL, not checkout-specific
        // line endings, so use one canonical representation everywhere.
        return hash('sha256', str_replace(["\r\n", "\r"], "\n", $sql));
    }
}

final class CatalogCodec
{
    public static function encode(array $value, bool $pretty = false): string
    {
        $flags = JSON_UNESCAPED_SLASHES | JSON_UNESCAPED_UNICODE | JSON_PRESERVE_ZERO_FRACTION | JSON_THROW_ON_ERROR;
        if ($pretty) {
            $flags |= JSON_PRETTY_PRINT;
        }
        return json_encode($value, $flags) . "\n";
    }

    public static function hash(array $value): string
    {
        return hash('sha256', self::encode($value));
    }

    public static function readCatalog(string $path): array
    {
        if (!is_file($path) || !is_readable($path)) {
            throw new PlatformException("Catalog source is not readable: $path");
        }
        $source = file_get_contents($path);
        if (!is_string($source)) {
            throw new PlatformException("Catalog source could not be read: $path");
        }
        return \WhatzIt\DeckManager\CatalogDocument::parse($source, $path);
    }

    public static function deckContentPayload(array $deck, ?int $cardContentVersion = null): array
    {
        return [
            'schemaVersion' => 1,
            'deckId' => $deck['id'],
            'cardContentVersion' => $cardContentVersion ?? $deck['version'],
            'cards' => $deck['cards'],
        ];
    }
}

final class CatalogStore
{
    public function __construct(private readonly Database $database)
    {
    }

    public function importInitial(array $catalog, string $mediaRoot): bool
    {
        $validation = \WhatzIt\DeckManager\CatalogValidator::validate($catalog);
        if ($validation !== []) {
            throw new PlatformException('Catalog validation failed: ' . json_encode($validation, JSON_UNESCAPED_SLASHES));
        }
        if (!is_dir($mediaRoot)) {
            throw new PlatformException("Media root is not a directory: $mediaRoot");
        }
        $revision = (int) $catalog['revision'];
        $sourceHash = CatalogCodec::hash($catalog);
        $existing = $this->database->rows(
            'SELECT source_hash FROM catalog_revisions WHERE revision = ?',
            'i',
            [$revision],
        );
        if ($existing !== []) {
            if (!hash_equals((string) $existing[0]['source_hash'], $sourceHash)) {
                throw new PlatformException("Catalog revision $revision already exists with different content.");
            }
            return false;
        }
        if ($this->database->scalar('SELECT revision FROM active_catalog_revision WHERE singleton_id = 1') !== null) {
            throw new PlatformException('Initial import refuses to replace an active database catalog.');
        }

        $this->database->begin();
        try {
            $this->database->execute(
                'INSERT INTO catalog_revisions '
                . '(revision, schema_version, state, source_updated_at, source_hash) VALUES (?, ?, ?, ?, ?)',
                'iisss',
                [$revision, (int) $catalog['schemaVersion'], 'preparing', (string) $catalog['updatedAt'], $sourceHash],
            );
            foreach ($catalog['decks'] as $deck) {
                $this->importDeck($revision, $deck, $mediaRoot);
            }
            foreach ($catalog['deckOrders'] as $scope => $deckIds) {
                foreach ($deckIds as $position => $deckId) {
                    $this->database->execute(
                        'INSERT INTO deck_orders (catalog_revision, access_level, position, deck_id) VALUES (?, ?, ?, ?)',
                        'isis',
                        [$revision, $scope, $position + 1, $deckId],
                    );
                }
            }
            foreach ($catalog['bundles'] as $bundle) {
                $this->importBundle($revision, $bundle);
            }
            $this->importStoreProducts($revision, $catalog);
            $this->database->execute(
                "UPDATE catalog_revisions SET state = 'active' WHERE revision = ?",
                'i',
                [$revision],
            );
            $this->database->execute(
                'INSERT INTO active_catalog_revision (singleton_id, revision) VALUES (1, ?)',
                'i',
                [$revision],
            );
            $this->database->commit();
        } catch (Throwable $error) {
            $this->database->rollback();
            throw $error;
        }
        return true;
    }

    public function exportActive(): array
    {
        $revision = $this->database->scalar(
            'SELECT r.revision '
            . 'FROM active_catalog_revision a JOIN catalog_revisions r ON r.revision = a.revision '
            . "WHERE a.singleton_id = 1 AND r.state = 'active'",
        );
        if ($revision === null) {
            throw new PlatformException('No active catalog revision exists.');
        }
        return $this->exportRevision((int) $revision);
    }

    public function exportRevision(int $revision): array
    {
        if ($revision < 1) {
            throw new PlatformException('A positive catalog revision is required.');
        }
        $revisionRows = $this->database->rows(
            "SELECT revision, schema_version, source_updated_at FROM catalog_revisions "
            . "WHERE revision = ? AND state IN ('active', 'retired')",
            'i',
            [$revision],
        );
        if ($revisionRows === []) {
            throw new PlatformException("Published catalog revision $revision does not exist.");
        }
        $catalog = [
            'schemaVersion' => (int) $revisionRows[0]['schema_version'],
            'revision' => $revision,
            'updatedAt' => (string) $revisionRows[0]['source_updated_at'],
            'decks' => [],
            'bundles' => [],
            'deckOrders' => ['free' => [], 'paid' => []],
        ];
        foreach ($this->database->rows(
            'SELECT * FROM deck_revisions WHERE catalog_revision = ? ORDER BY catalog_order',
            'i',
            [$revision],
        ) as $row) {
            $deck = [
                'id' => (string) $row['deck_id'],
                'order' => (int) $row['catalog_order'],
                'title' => (string) $row['title'],
                'description' => (string) $row['description'],
                'coverImage' => (string) $row['cover_path'],
                'version' => (int) $row['deck_version'],
                'cardContentVersion' => (int) $row['card_content_version'],
                'cardCount' => (int) $row['card_count'],
                'tags' => self::decodeArray((string) $row['tags_json']),
                'access' => (string) $row['access_level'],
            ];
            if ($row['price_cents'] !== null) {
                $deck['price'] = ((int) $row['price_cents']) / 100;
            }
            $deck['cards'] = [];
            foreach ($this->database->rows(
                'SELECT card_id, featured_order, text_value, has_byline, byline FROM cards '
                . 'WHERE catalog_revision = ? AND deck_id = ? ORDER BY card_order',
                'is',
                [$revision, $row['deck_id']],
            ) as $cardRow) {
                $card = ['id' => (string) $cardRow['card_id'], 'text' => (string) $cardRow['text_value']];
                if ((int) $cardRow['has_byline'] === 1) {
                    $card['byline'] = (string) $cardRow['byline'];
                }
                if ($cardRow['featured_order'] !== null) {
                    $card['featuredOrder'] = (int) $cardRow['featured_order'];
                }
                $deck['cards'][] = $card;
            }
            $catalog['decks'][] = $deck;
        }
        foreach ($this->database->rows(
            'SELECT * FROM bundle_revisions WHERE catalog_revision = ? ORDER BY catalog_order',
            'i',
            [$revision],
        ) as $row) {
            $bundle = [
                'id' => (string) $row['bundle_id'],
                'order' => (int) $row['catalog_order'],
                'title' => (string) $row['title'],
                'version' => (int) $row['bundle_version'],
            ];
            if ((int) $row['has_description'] === 1) {
                $bundle['description'] = (string) $row['description'];
            }
            $bundle['access'] = (string) $row['access_level'];
            if ($row['price_cents'] !== null) {
                $bundle['price'] = ((int) $row['price_cents']) / 100;
            }
            $bundle['deckIds'] = array_map(
                static fn (array $member): string => (string) $member['deck_id'],
                $this->database->rows(
                    'SELECT deck_id FROM bundle_decks WHERE catalog_revision = ? AND bundle_id = ? ORDER BY position',
                    'is',
                    [$revision, $row['bundle_id']],
                ),
            );
            $catalog['bundles'][] = $bundle;
        }
        foreach ($this->database->rows(
            'SELECT access_level, deck_id FROM deck_orders WHERE catalog_revision = ? ORDER BY access_level, position',
            'i',
            [$revision],
        ) as $row) {
            $catalog['deckOrders'][(string) $row['access_level']][] = (string) $row['deck_id'];
        }
        $this->attachStoreProducts($catalog, $revision);
        return $catalog;
    }

    /** @return array{decks:array<string,array{deckVersion:int,cardContentVersion:int}>,bundles:array<string,array{bundleVersion:int}>} */
    public function publishedVersions(): array
    {
        $versions = ['decks' => [], 'bundles' => []];
        foreach ($this->database->rows(
            'SELECT d.deck_id, MAX(d.deck_version) AS deck_version, '
            . 'MAX(d.card_content_version) AS card_content_version '
            . 'FROM deck_revisions d INNER JOIN catalog_revisions c ON c.revision = d.catalog_revision '
            . "WHERE c.state IN ('active', 'retired') GROUP BY d.deck_id",
        ) as $row) {
            $versions['decks'][(string) $row['deck_id']] = [
                'deckVersion' => (int) $row['deck_version'],
                'cardContentVersion' => (int) $row['card_content_version'],
            ];
        }
        foreach ($this->database->rows(
            'SELECT b.bundle_id, MAX(b.bundle_version) AS bundle_version '
            . 'FROM bundle_revisions b INNER JOIN catalog_revisions c ON c.revision = b.catalog_revision '
            . "WHERE c.state IN ('active', 'retired') GROUP BY b.bundle_id",
        ) as $row) {
            $versions['bundles'][(string) $row['bundle_id']] = [
                'bundleVersion' => (int) $row['bundle_version'],
            ];
        }
        return $versions;
    }

    /** @return array<string,array{deckId:string,path:string,hash:string}> */
    public function coverSources(int $revision): array
    {
        $sources = [];
        foreach ($this->database->rows(
            "SELECT d.deck_id, d.cover_path, d.cover_hash FROM deck_revisions d "
            . "INNER JOIN catalog_revisions c ON c.revision = d.catalog_revision "
            . "WHERE d.catalog_revision = ? AND c.state IN ('active', 'retired') "
            . "AND d.cover_path <> '' AND d.cover_hash IS NOT NULL",
            'i',
            [$revision],
        ) as $row) {
            $path = (string) $row['cover_path'];
            $sources[strtolower(basename(str_replace('\\', '/', $path)))] = [
                'deckId' => (string) $row['deck_id'],
                'path' => $path,
                'hash' => (string) $row['cover_hash'],
            ];
        }
        return $sources;
    }

    public function preparePublication(
        array $catalog,
        array $versions,
        string $mediaRoot,
        string $sourceHash,
        string $manifestHash,
    ): void {
        $validation = \WhatzIt\DeckManager\CatalogValidator::validate($catalog);
        if ($validation !== []) {
            throw new PlatformException('Catalog validation failed: ' . json_encode($validation, JSON_UNESCAPED_SLASHES));
        }
        $revision = (int) $catalog['revision'];
        if ($this->database->scalar('SELECT revision FROM catalog_revisions WHERE revision = ?', 'i', [$revision]) !== null) {
            throw new PlatformException("Catalog revision $revision already exists.");
        }
        $this->database->begin();
        try {
            $this->database->execute(
                'INSERT INTO catalog_revisions '
                . '(revision, schema_version, state, source_updated_at, source_hash, manifest_hash) '
                . 'VALUES (?, ?, ?, ?, ?, ?)',
                'iissss',
                [
                    $revision,
                    (int) $catalog['schemaVersion'],
                    'preparing',
                    (string) $catalog['updatedAt'],
                    $sourceHash,
                    $manifestHash,
                ],
            );
            foreach ($catalog['decks'] as $deck) {
                $this->importDeck(
                    $revision,
                    $deck,
                    $mediaRoot,
                    $versions['decks'][(string) $deck['id']] ?? null,
                    false,
                );
            }
            foreach ($catalog['deckOrders'] as $scope => $deckIds) {
                foreach ($deckIds as $position => $deckId) {
                    $this->database->execute(
                        'INSERT INTO deck_orders (catalog_revision, access_level, position, deck_id) VALUES (?, ?, ?, ?)',
                        'isis',
                        [$revision, $scope, $position + 1, $deckId],
                    );
                }
            }
            foreach ($catalog['bundles'] as $bundle) {
                $this->importBundle(
                    $revision,
                    $bundle,
                    $versions['bundles'][(string) $bundle['id']] ?? null,
                    false,
                );
            }
            $this->importStoreProducts($revision, $catalog);
            $this->database->commit();
        } catch (Throwable $error) {
            $this->database->rollback();
            throw $error;
        }
    }

    public function activatePublication(
        string $preparationId,
        int $draftId,
        int $expectedDraftVersion,
        int $targetRevision,
        string $administrator,
        array $summary,
        ?int $rollbackOfRevision = null,
    ): void {
        $this->database->begin();
        try {
            $preparations = $this->database->rows(
                "SELECT base_revision, manifest_hash FROM publication_preparations "
                . "WHERE preparation_id = ? AND draft_id = ? AND draft_version = ? AND target_revision = ? "
                . "AND state = 'artifacts_ready' FOR UPDATE",
                'siii',
                [$preparationId, $draftId, $expectedDraftVersion, $targetRevision],
            );
            if ($preparations === []) {
                throw new PlatformException('The publication preparation is not ready for activation.');
            }
            $baseRevision = (int) $preparations[0]['base_revision'];
            $activeRevision = $this->database->scalar(
                'SELECT revision FROM active_catalog_revision WHERE singleton_id = 1 FOR UPDATE',
            );
            if ((int) $activeRevision !== $baseRevision) {
                throw new PlatformException('The active catalog changed while publication artifacts were prepared.');
            }
            $state = $this->database->scalar(
                'SELECT state FROM catalog_revisions WHERE revision = ? FOR UPDATE',
                'i',
                [$targetRevision],
            );
            if ($state !== 'preparing') {
                throw new PlatformException('The target catalog revision is not preparing.');
            }
            $this->database->execute(
                "UPDATE catalog_revisions SET state = 'retired' WHERE revision = ? AND state = 'active'",
                'i',
                [$baseRevision],
            );
            $this->database->execute(
                "UPDATE catalog_revisions SET state = 'active' WHERE revision = ? AND state = 'preparing'",
                'i',
                [$targetRevision],
            );
            $this->database->execute(
                'UPDATE active_catalog_revision SET revision = ? WHERE singleton_id = 1',
                'i',
                [$targetRevision],
            );
            $this->database->execute("UPDATE decks SET lifecycle_status = 'retired'");
            $this->database->execute(
                "UPDATE decks d INNER JOIN deck_revisions r ON r.deck_id = d.deck_id "
                . "SET d.lifecycle_status = 'active' WHERE r.catalog_revision = ?",
                'i',
                [$targetRevision],
            );
            $this->database->execute("UPDATE bundles SET lifecycle_status = 'retired'");
            $this->database->execute(
                "UPDATE bundles b INNER JOIN bundle_revisions r ON r.bundle_id = b.bundle_id "
                . "SET b.lifecycle_status = 'active' WHERE r.catalog_revision = ?",
                'i',
                [$targetRevision],
            );
            $draftStatement = $this->database->execute(
                "UPDATE catalog_drafts SET status = 'published', active_slot = NULL, "
                . "draft_version = draft_version + 1, updated_by = ? "
                . "WHERE draft_id = ? AND draft_version = ? AND status = 'active' "
                . "AND active_slot = 1 AND base_revision = ?",
                'siii',
                [$administrator, $draftId, $expectedDraftVersion, $baseRevision],
            );
            if ($draftStatement->affected_rows !== 1) {
                throw new PlatformException('The draft changed while publication artifacts were prepared.');
            }
            $this->database->execute(
                'INSERT INTO publication_events '
                . '(catalog_revision, event_type, source_revision, rollback_of_revision, administrator, summary_json, manifest_hash) '
                . 'VALUES (?, ?, ?, ?, ?, ?, ?)',
                'isiisss',
                [
                    $targetRevision,
                    $rollbackOfRevision === null ? 'publish' : 'rollback',
                    $baseRevision,
                    $rollbackOfRevision,
                    $administrator,
                    CatalogCodec::encode($summary),
                    (string) $preparations[0]['manifest_hash'],
                ],
            );
            $this->database->execute(
                "UPDATE publication_preparations SET state = 'database_active' WHERE preparation_id = ?",
                's',
                [$preparationId],
            );
            $this->database->commit();
        } catch (Throwable $error) {
            $this->database->rollback();
            throw $error;
        }
    }

    public function abandonPreparedPublication(int $revision): void
    {
        $statement = $this->database->execute(
            "DELETE FROM catalog_revisions WHERE revision = ? AND state = 'preparing'",
            'i',
            [$revision],
        );
        if ($statement->affected_rows > 1) {
            throw new PlatformException('More than one prepared catalog revision was removed unexpectedly.');
        }
    }

    private function importDeck(
        int $revision,
        array $deck,
        string $mediaRoot,
        ?array $assigned = null,
        bool $activateIdentity = true,
    ): void
    {
        $id = (string) $deck['id'];
        if ($activateIdentity) {
            $this->database->execute(
                "INSERT INTO decks (deck_id, lifecycle_status) VALUES (?, 'active') "
                . "ON DUPLICATE KEY UPDATE lifecycle_status = 'active'",
                's',
                [$id],
            );
        } else {
            $this->database->execute(
                "INSERT INTO decks (deck_id, lifecycle_status) VALUES (?, 'retired') "
                . 'ON DUPLICATE KEY UPDATE deck_id = VALUES(deck_id)',
                's',
                [$id],
            );
        }
        $coverHash = null;
        $coverBytes = null;
        $coverPath = (string) ($deck['coverImage'] ?? '');
        if ($coverPath !== '') {
            $absoluteCover = rtrim($mediaRoot, '/\\') . DIRECTORY_SEPARATOR . str_replace('/', DIRECTORY_SEPARATOR, $coverPath);
            if (!is_file($absoluteCover) || !is_readable($absoluteCover)) {
                throw new PlatformException("Referenced cover is not readable: $coverPath");
            }
            $coverHash = hash_file('sha256', $absoluteCover);
            $coverBytes = filesize($absoluteCover);
            if (!is_string($coverHash) || $coverBytes === false) {
                throw new PlatformException("Referenced cover could not be hashed: $coverPath");
            }
            $dimensions = getimagesize($absoluteCover);
            $this->database->execute(
                'INSERT IGNORE INTO media_assets '
                . '(asset_hash, asset_type, mime_type, byte_size, width, height, source_path) VALUES (?, ?, ?, ?, ?, ?, ?)',
                'sssiiis',
                [
                    $coverHash,
                    'cover',
                    is_array($dimensions) ? (string) ($dimensions['mime'] ?? 'image/webp') : 'image/webp',
                    (int) $coverBytes,
                    is_array($dimensions) ? (int) $dimensions[0] : null,
                    is_array($dimensions) ? (int) $dimensions[1] : null,
                    $coverPath,
                ],
            );
        }
        $assigned ??= [
            'deckVersion' => (int) $deck['version'],
            'cardContentVersion' => (int) ($deck['cardContentVersion'] ?? $deck['version']),
        ];
        $payload = CatalogCodec::deckContentPayload($deck, (int) $assigned['cardContentVersion']);
        $contentBytes = CatalogCodec::encode($payload);
        $priceCents = array_key_exists('price', $deck) ? (int) round(((float) $deck['price']) * 100) : null;
        $this->database->execute(
            'INSERT INTO deck_revisions '
            . '(catalog_revision, deck_id, deck_version, card_content_version, catalog_order, title, description, '
            . 'cover_path, cover_hash, cover_bytes, tags_json, access_level, price_cents, card_count, content_hash, content_bytes) '
            . 'VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?)',
            'isiiissssissiisi',
            [
                $revision,
                $id,
                (int) $assigned['deckVersion'],
                (int) $assigned['cardContentVersion'],
                (int) $deck['order'],
                (string) $deck['title'],
                (string) $deck['description'],
                $coverPath,
                $coverHash,
                $coverBytes === null ? null : (int) $coverBytes,
                json_encode($deck['tags'], JSON_UNESCAPED_SLASHES | JSON_UNESCAPED_UNICODE | JSON_THROW_ON_ERROR),
                (string) $deck['access'],
                $priceCents,
                count($deck['cards']),
                hash('sha256', $contentBytes),
                strlen($contentBytes),
            ],
        );
        foreach ($deck['cards'] as $position => $card) {
            $hasByline = array_key_exists('byline', $card) ? 1 : 0;
            $this->database->execute(
                'INSERT INTO cards '
                . '(catalog_revision, deck_id, card_id, card_order, featured_order, text_value, has_byline, byline) VALUES (?, ?, ?, ?, ?, ?, ?, ?)',
                'issiisis',
                [
                    $revision,
                    $id,
                    (string) $card['id'],
                    $position + 1,
                    array_key_exists('featuredOrder', $card) ? (int) $card['featuredOrder'] : null,
                    (string) $card['text'],
                    $hasByline,
                    $hasByline === 1 ? (string) $card['byline'] : null,
                ],
            );
        }
    }

    private function importBundle(
        int $revision,
        array $bundle,
        ?array $assigned = null,
        bool $activateIdentity = true,
    ): void
    {
        $id = (string) $bundle['id'];
        if ($activateIdentity) {
            $this->database->execute(
                "INSERT INTO bundles (bundle_id, lifecycle_status) VALUES (?, 'active') "
                . "ON DUPLICATE KEY UPDATE lifecycle_status = 'active'",
                's',
                [$id],
            );
        } else {
            $this->database->execute(
                "INSERT INTO bundles (bundle_id, lifecycle_status) VALUES (?, 'retired') "
                . 'ON DUPLICATE KEY UPDATE bundle_id = VALUES(bundle_id)',
                's',
                [$id],
            );
        }
        $hasDescription = array_key_exists('description', $bundle) ? 1 : 0;
        $priceCents = array_key_exists('price', $bundle) ? (int) round(((float) $bundle['price']) * 100) : null;
        $assigned ??= ['bundleVersion' => (int) ($bundle['version'] ?? 1)];
        $this->database->execute(
            'INSERT INTO bundle_revisions '
            . '(catalog_revision, bundle_id, bundle_version, catalog_order, title, has_description, description, access_level, price_cents) '
            . 'VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?)',
            'isiisissi',
            [
                $revision,
                $id,
                (int) $assigned['bundleVersion'],
                (int) $bundle['order'],
                (string) $bundle['title'],
                $hasDescription,
                $hasDescription === 1 ? (string) $bundle['description'] : null,
                (string) $bundle['access'],
                $priceCents,
            ],
        );
        foreach ($bundle['deckIds'] as $position => $deckId) {
            $this->database->execute(
                'INSERT INTO bundle_decks (catalog_revision, bundle_id, position, deck_id) VALUES (?, ?, ?, ?)',
                'isis',
                [$revision, $id, $position + 1, $deckId],
            );
        }
    }

    private static function decodeArray(string $json): array
    {
        try {
            $value = json_decode($json, true, 512, JSON_THROW_ON_ERROR);
        } catch (JsonException $error) {
            throw new PlatformException('Stored catalog JSON is invalid.', previous: $error);
        }
        if (!is_array($value) || !array_is_list($value)) {
            throw new PlatformException('Stored catalog JSON must be an array.');
        }
        return $value;
    }

    private function attachStoreProducts(array &$catalog, int $revision): void
    {
        $decks = [];
        foreach ($catalog['decks'] as $index => $deck) {
            $decks[(string) $deck['id']] = $index;
        }
        $bundles = [];
        foreach ($catalog['bundles'] as $index => $bundle) {
            $bundles[(string) $bundle['id']] = $index;
        }
        foreach ($this->database->rows(
            'SELECT p.platform, p.store_product_id, p.deck_id, p.bundle_id, p.owned_deck_count, c.availability_status '
            . 'FROM catalog_store_products c INNER JOIN store_products p '
            . 'ON p.store_product_pk = c.store_product_pk WHERE c.catalog_revision = ? '
            . 'ORDER BY p.platform, p.store_product_id',
            'i',
            [$revision],
        ) as $row) {
            $mapping = [
                'productId' => (string) $row['store_product_id'],
                'status' => (string) $row['availability_status'],
            ];
            $platform = (string) $row['platform'];
            if ($row['deck_id'] !== null && isset($decks[(string) $row['deck_id']])) {
                $catalog['decks'][$decks[(string) $row['deck_id']]]['storeProducts'][$platform] = $mapping;
            } elseif ($row['bundle_id'] !== null && isset($bundles[(string) $row['bundle_id']])) {
                $bundleIndex = $bundles[(string) $row['bundle_id']];
                if ($row['owned_deck_count'] === null) {
                    $catalog['bundles'][$bundleIndex]['storeProducts'][$platform] = $mapping;
                } else {
                    $catalog['bundles'][$bundleIndex]['storeProducts'][$platform]
                        ['ownedDeckCountProducts'][(string) $row['owned_deck_count']] = $mapping;
                }
            }
        }
    }

    private function importStoreProducts(int $revision, array $catalog): void
    {
        foreach ([['deck', $catalog['decks']], ['bundle', $catalog['bundles']]] as [$targetType, $items]) {
            foreach ($items as $item) {
                foreach (($item['storeProducts'] ?? []) as $platform => $mapping) {
                    $targetId = (string) $item['id'];
                    $productMappings = [[null, $mapping]];
                    if ($targetType === 'bundle') {
                        foreach (($mapping['ownedDeckCountProducts'] ?? []) as $ownedCount => $tierMapping) {
                            $productMappings[] = [(int) $ownedCount, $tierMapping];
                        }
                    }
                    foreach ($productMappings as [$ownedDeckCount, $productMapping]) {
                        $productId = (string) $productMapping['productId'];
                        $status = (string) $productMapping['status'];
                        $rows = $this->database->rows(
                            'SELECT store_product_pk, deck_id, bundle_id, lifecycle_status, owned_deck_count '
                            . 'FROM store_products WHERE platform = ? AND store_product_id = ? FOR UPDATE',
                            'ss',
                            [$platform, $productId],
                        );
                        if ($rows === []) {
                            $this->database->execute(
                                'INSERT INTO store_products '
                                . '(platform, store_product_id, product_type, deck_id, bundle_id, lifecycle_status, bundle_membership_policy, owned_deck_count) '
                                . 'VALUES (?, ?, ?, ?, ?, ?, ?, ?)',
                                'sssssssi',
                                [
                                    $platform,
                                    $productId,
                                    'non_consumable',
                                    $targetType === 'deck' ? $targetId : null,
                                    $targetType === 'bundle' ? $targetId : null,
                                    $status === 'available' ? 'active' : $status,
                                    $targetType === 'bundle' ? 'purchase_snapshot' : null,
                                    $ownedDeckCount,
                                ],
                            );
                            $productPk = (int) $this->database->scalar('SELECT LAST_INSERT_ID()');
                        } else {
                            $row = $rows[0];
                            $sameTarget = $targetType === 'deck'
                                ? (string) $row['deck_id'] === $targetId && $row['bundle_id'] === null
                                : (string) $row['bundle_id'] === $targetId && $row['deck_id'] === null;
                            $sameTier = $row['owned_deck_count'] === null
                                ? $ownedDeckCount === null
                                : (int) $row['owned_deck_count'] === $ownedDeckCount;
                            if (!$sameTarget || !$sameTier) {
                                throw new PlatformException('A store product ID is already assigned to another target or discount tier.');
                            }
                            if ((string) $row['lifecycle_status'] === 'retired' && $status !== 'retired') {
                                throw new PlatformException('A retired store product cannot be reactivated.');
                            }
                            $productPk = (int) $row['store_product_pk'];
                            if ($status === 'retired') {
                                $this->database->execute(
                                    "UPDATE store_products SET lifecycle_status = 'retired' WHERE store_product_pk = ?",
                                    'i',
                                    [$productPk],
                                );
                            } elseif ($status === 'available' && (string) $row['lifecycle_status'] === 'draft') {
                                $this->database->execute(
                                    "UPDATE store_products SET lifecycle_status = 'active' WHERE store_product_pk = ?",
                                    'i',
                                    [$productPk],
                                );
                            }
                        }
                        $this->database->execute(
                            'INSERT INTO catalog_store_products '
                            . '(catalog_revision, store_product_pk, availability_status) VALUES (?, ?, ?)',
                            'iis',
                            [$revision, $productPk, $status],
                        );
                    }
                }
            }
        }
    }
}

final class ArtifactBuilder
{
    public function build(
        array $catalog,
        string $mediaRoot,
        string $outputRoot,
        string $apiBaseUrl,
        string $contentBaseUrl,
        ?array $versions = null,
        bool $developmentPreview = false,
        string $deckContentPathPrefix = '/api/v1/decks',
    ): array {
        $validation = \WhatzIt\DeckManager\CatalogValidator::validate($catalog);
        if ($validation !== []) {
            throw new PlatformException('Cannot generate artifacts from an invalid catalog.');
        }
        if (!is_dir($mediaRoot)) {
            throw new PlatformException("Media root is not a directory: $mediaRoot");
        }
        self::ensureDirectory($outputRoot);
        foreach (['decks', 'covers', 'thumbnails'] as $directory) {
            self::ensureDirectory($outputRoot . DIRECTORY_SEPARATOR . $directory);
        }

        $manifestDecks = [];
        foreach ($catalog['decks'] as $deck) {
            $assignedDeck = $versions['decks'][(string) $deck['id']] ?? [
                'deckVersion' => (int) $deck['version'],
                'cardContentVersion' => (int) ($deck['cardContentVersion'] ?? $deck['version']),
            ];
            $contentVersion = (int) $assignedDeck['cardContentVersion'];
            $contentPayload = CatalogCodec::deckContentPayload($deck, $contentVersion);
            $contentJson = CatalogCodec::encode($contentPayload);
            $contentHash = hash('sha256', $contentJson);
            $contentRelative = 'decks/' . rawurlencode((string) $deck['id']) . '/'
                . $contentVersion . '/' . $contentHash . '.json';
            // The artifact root is private storage, not a public web directory.
            // Paid content must exist here so the authenticated API controller
            // can serve it after an entitlement check. Discovery still exposes
            // a URL only for free decks below.
            self::writeImmutable(
                $outputRoot . DIRECTORY_SEPARATOR . str_replace('/', DIRECTORY_SEPARATOR, $contentRelative),
                $contentJson,
            );
            $cover = $this->buildCover($deck, $mediaRoot, $outputRoot, $contentBaseUrl);
            $manifestDecks[] = [
                'id' => $deck['id'],
                'order' => $deck['order'],
                'title' => $deck['title'],
                'description' => $deck['description'],
                'tags' => $deck['tags'],
                'access' => $deck['access'],
                'price' => $deck['price'] ?? null,
                'status' => 'active',
                'deckVersion' => (int) $assignedDeck['deckVersion'],
                'cardContentVersion' => $contentVersion,
                'cardCount' => count($deck['cards']),
                'featuredCards' => self::featuredCards($deck['cards']),
                'content' => [
                    'hash' => $contentHash,
                    'bytes' => strlen($contentJson),
                    'url' => $deck['access'] === 'free' || $developmentPreview
                        ? $apiBaseUrl . $deckContentPathPrefix . '/' . rawurlencode((string) $deck['id'])
                            . '/content/' . $contentVersion
                        : null,
                    'protected' => $deck['access'] !== 'free' && !$developmentPreview,
                ],
                'cover' => $cover['cover'],
                'thumbnail' => $cover['thumbnail'],
                'productIds' => self::availableProductIds($deck),
            ];
        }
        $manifestBundles = [];
        foreach ($catalog['bundles'] as $bundle) {
            $assignedBundle = $versions['bundles'][(string) $bundle['id']] ?? ['bundleVersion' => 1];
            $item = [
                'id' => $bundle['id'],
                'order' => $bundle['order'],
                'title' => $bundle['title'],
                'description' => $bundle['description'] ?? '',
                'access' => $bundle['access'],
                'price' => $bundle['price'] ?? null,
                'status' => 'active',
                'bundleVersion' => (int) $assignedBundle['bundleVersion'],
                'deckIds' => $bundle['deckIds'],
                'productIds' => self::availableProductIds($bundle),
                'discountProductIds' => self::availableDiscountProductIds($bundle),
            ];
            $manifestBundles[] = $item;
        }
        $manifest = [
            'schemaVersion' => 1,
            'catalogSchemaVersion' => $catalog['schemaVersion'],
            'catalogRevision' => $catalog['revision'],
            'updatedAt' => $catalog['updatedAt'],
            'minimumAppVersion' => null,
            'supportedContentSchemaVersions' => [1],
            'decks' => $manifestDecks,
            'bundles' => $manifestBundles,
            'deckOrders' => $catalog['deckOrders'],
        ];
        $manifestJson = CatalogCodec::encode($manifest);
        self::writeReplace($outputRoot . DIRECTORY_SEPARATOR . 'manifest.json', $manifestJson);
        return [
            'manifest' => $manifest,
            'etag' => hash('sha256', $manifestJson),
            'bytes' => strlen($manifestJson),
        ];
    }

    private function buildCover(array $deck, string $mediaRoot, string $outputRoot, string $contentBaseUrl): array
    {
        $coverPath = (string) ($deck['coverImage'] ?? '');
        if ($coverPath === '') {
            return ['cover' => null, 'thumbnail' => null];
        }
        $source = rtrim($mediaRoot, '/\\') . DIRECTORY_SEPARATOR . str_replace('/', DIRECTORY_SEPARATOR, $coverPath);
        if (!is_file($source) || !is_readable($source)) {
            throw new PlatformException("Referenced cover is not readable: $coverPath");
        }
        $bytes = file_get_contents($source);
        if (!is_string($bytes)) {
            throw new PlatformException("Referenced cover could not be read: $coverPath");
        }
        $image = @imagecreatefromstring($bytes);
        if ($image === false) {
            throw new PlatformException("Referenced cover is not a supported image: $coverPath");
        }
        $sourceInfo = getimagesizefromstring($bytes);
        if (!is_array($sourceInfo) || ($sourceInfo['mime'] ?? '') !== 'image/webp') {
            imagedestroy($image);
            throw new PlatformException("Published covers must be WebP before artifact generation: $coverPath");
        }
        $coverHash = hash('sha256', $bytes);
        $coverFile = $outputRoot . DIRECTORY_SEPARATOR . 'covers' . DIRECTORY_SEPARATOR . $coverHash . '.webp';
        self::writeImmutable($coverFile, $bytes);
        $width = imagesx($image);
        $height = imagesy($image);
        $thumbWidth = min(160, $width);
        $thumbHeight = max(1, (int) round($height * ($thumbWidth / $width)));
        $thumbnail = imagecreatetruecolor($thumbWidth, $thumbHeight);
        imagealphablending($thumbnail, false);
        imagesavealpha($thumbnail, true);
        imagecopyresampled($thumbnail, $image, 0, 0, 0, 0, $thumbWidth, $thumbHeight, $width, $height);
        ob_start();
        $encoded = imagewebp($thumbnail, null, 82);
        $thumbnailBytes = ob_get_clean();
        imagedestroy($thumbnail);
        imagedestroy($image);
        if (!$encoded || !is_string($thumbnailBytes)) {
            throw new PlatformException("Thumbnail generation failed: $coverPath");
        }
        $thumbnailHash = hash('sha256', $thumbnailBytes);
        self::writeImmutable(
            $outputRoot . DIRECTORY_SEPARATOR . 'thumbnails' . DIRECTORY_SEPARATOR . $thumbnailHash . '.webp',
            $thumbnailBytes,
        );
        return [
            'cover' => [
                'hash' => $coverHash,
                'bytes' => strlen($bytes),
                'width' => $width,
                'height' => $height,
                'url' => $contentBaseUrl . '/covers/' . $coverHash . '.webp',
            ],
            'thumbnail' => [
                'hash' => $thumbnailHash,
                'bytes' => strlen($thumbnailBytes),
                'width' => $thumbWidth,
                'height' => $thumbHeight,
                'url' => $contentBaseUrl . '/thumbnails/' . $thumbnailHash . '.webp',
            ],
        ];
    }

    /** @return list<array{id:string,text:string,byline?:string}> */
    private static function featuredCards(array $cards): array
    {
        $featured = array_values(array_filter(
            $cards,
            static fn (array $card): bool => array_key_exists('featuredOrder', $card),
        ));
        usort(
            $featured,
            static fn (array $left, array $right): int => (int) $left['featuredOrder'] <=> (int) $right['featuredOrder'],
        );
        return array_map(static function (array $card): array {
            $preview = ['id' => (string) $card['id'], 'text' => (string) $card['text']];
            if (array_key_exists('byline', $card) && (string) $card['byline'] !== '') {
                $preview['byline'] = (string) $card['byline'];
            }
            return $preview;
        }, $featured);
    }

    /** @return list<string> */
    public function googleCommerceProblems(): array
    {
        $problems = $this->problems(database: true);
        if (preg_match('/^[A-Za-z0-9._]+$/', $this->googlePackageName) !== 1) {
            $problems[] = 'WHATZIT_GOOGLE_PACKAGE_NAME is invalid.';
        }
        if ($this->googleServiceAccountPath === '' || !self::isAbsolutePath($this->googleServiceAccountPath)) {
            $problems[] = 'WHATZIT_GOOGLE_SERVICE_ACCOUNT_PATH must be an absolute filesystem path.';
        } elseif (!is_readable($this->googleServiceAccountPath)) {
            $problems[] = 'The configured Google Play service-account file is not readable.';
        }
        if (!extension_loaded('openssl')) {
            $problems[] = 'The PHP OpenSSL extension is required for Google Play commerce.';
        }
        return $problems;
    }

    /** @return array{apple:?string,google:?string} */
    private static function availableProductIds(array $item): array
    {
        $result = ['apple' => null, 'google' => null];
        foreach ($result as $platform => $_) {
            $mapping = $item['storeProducts'][$platform] ?? null;
            if (is_array($mapping) && ($mapping['status'] ?? null) === 'available') {
                $result[$platform] = (string) $mapping['productId'];
            }
        }
        return $result;
    }

    /** @return array{apple:array<string,string>,google:array<string,string>} */
    private static function availableDiscountProductIds(array $item): array
    {
        $result = ['apple' => [], 'google' => []];
        foreach ($result as $platform => $_) {
            foreach (($item['storeProducts'][$platform]['ownedDeckCountProducts'] ?? []) as $count => $mapping) {
                if (is_array($mapping) && ($mapping['status'] ?? null) === 'available') {
                    $result[$platform][(string) $count] = (string) $mapping['productId'];
                }
            }
        }
        return $result;
    }

    private static function writeImmutable(string $path, string $bytes): void
    {
        self::ensureDirectory(dirname($path));
        if (is_file($path)) {
            $existing = hash_file('sha256', $path);
            if (!is_string($existing) || !hash_equals($existing, hash('sha256', $bytes))) {
                throw new PlatformException("Immutable artifact collision: $path");
            }
            return;
        }
        self::writeExclusive($path, $bytes);
    }

    private static function writeReplace(string $path, string $bytes): void
    {
        self::ensureDirectory(dirname($path));
        $temporary = $path . '.tmp-' . bin2hex(random_bytes(8));
        self::writeExclusive($temporary, $bytes);
        if (DIRECTORY_SEPARATOR === '\\' && is_file($path) && !unlink($path)) {
            @unlink($temporary);
            throw new PlatformException("Existing manifest could not be replaced: $path");
        }
        if (!rename($temporary, $path)) {
            @unlink($temporary);
            throw new PlatformException("Manifest could not be activated: $path");
        }
    }

    private static function writeExclusive(string $path, string $bytes): void
    {
        $handle = @fopen($path, 'x+b');
        if ($handle === false) {
            throw new PlatformException("Artifact could not be created: $path");
        }
        try {
            if (fwrite($handle, $bytes) !== strlen($bytes) || !fflush($handle)) {
                throw new PlatformException("Artifact could not be written completely: $path");
            }
        } finally {
            fclose($handle);
        }
    }

    private static function ensureDirectory(string $directory): void
    {
        if (!is_dir($directory) && !mkdir($directory, 0775, true) && !is_dir($directory)) {
            throw new PlatformException("Artifact directory could not be created: $directory");
        }
    }
}
