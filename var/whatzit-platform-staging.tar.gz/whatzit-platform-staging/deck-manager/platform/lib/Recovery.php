<?php

declare(strict_types=1);

namespace WhatzIt\DeckPlatform;

final class RecoveryReadinessReporter
{
    public function __construct(
        private readonly Database $database,
        private readonly string $artifactRoot,
    ) {
    }

    public function generate(): array
    {
        $revision = $this->database->rows(
            'SELECT r.revision, r.manifest_hash '
            . 'FROM catalog_revisions r INNER JOIN active_catalog_revision a '
            . 'ON a.revision = r.revision WHERE a.singleton_id = 1',
        )[0] ?? null;
        if (!is_array($revision)) {
            throw new PlatformException('No active catalog revision exists for recovery reporting.');
        }

        $manifestPath = rtrim($this->artifactRoot, '/\\') . DIRECTORY_SEPARATOR . 'manifest.json';
        $manifestBytes = is_readable($manifestPath) ? file_get_contents($manifestPath) : false;
        if (!is_string($manifestBytes)) {
            throw new PlatformException('The active manifest is not readable for recovery reporting.');
        }
        $manifest = json_decode($manifestBytes, true, 512, JSON_THROW_ON_ERROR);
        $catalog = (new CatalogStore($this->database))->exportActive();
        $retention = (new ArtifactRetentionReporter($this->database, $this->artifactRoot))->generate();

        return self::buildReport(
            (int) $revision['revision'],
            (string) ($revision['manifest_hash'] ?? ''),
            hash('sha256', $manifestBytes),
            (int) ($manifest['catalogRevision'] ?? 0),
            CatalogCodec::hash($catalog),
            $retention,
        );
    }

    public static function buildReport(
        int $activeRevision,
        string $databaseManifestHash,
        string $artifactManifestHash,
        int $artifactManifestRevision,
        string $exportedCatalogHash,
        array $retention,
    ): array {
        $checks = [
            'manifestRevisionMatchesDatabase' => $artifactManifestRevision === $activeRevision,
            'manifestHashMatchesDatabase' => $databaseManifestHash !== ''
                && hash_equals($databaseManifestHash, $artifactManifestHash),
            'artifactReferencesComplete' => ($retention['missingReferences'] ?? []) === [],
            'artifactFilenamesValid' => !self::hasFilenameHashMismatch($retention['artifacts'] ?? []),
        ];
        $artifacts = $retention['artifacts'] ?? [];
        $artifactFiles = count($artifacts);
        $artifactBytes = 0;
        foreach ($artifacts as $artifact) {
            $artifactBytes += (int) ($artifact['bytes'] ?? 0);
        }
        $artifactInventoryHash = self::artifactInventoryHash($artifacts);

        return [
            'mode' => 'read-only',
            'readyForBackup' => !in_array(false, $checks, true),
            'activeRevision' => $activeRevision,
            'manifestHash' => $artifactManifestHash,
            'catalogHash' => $exportedCatalogHash,
            'artifactFiles' => $artifactFiles,
            'artifactBytes' => $artifactBytes,
            'artifactInventoryHash' => $artifactInventoryHash,
            'checks' => $checks,
            'requiredRestoreComponents' => [
                'database dump from the same snapshot window',
                'complete immutable artifact directory',
                'external configuration and private keys from secure storage',
            ],
            'restoreDrillStillRequired' => true,
        ];
    }

    public static function compareReports(array $baseline, array $restored): array
    {
        $fields = [
            'activeRevision',
            'manifestHash',
            'catalogHash',
            'artifactFiles',
            'artifactBytes',
            'artifactInventoryHash',
        ];
        $checks = [
            'baselineWasReady' => ($baseline['readyForBackup'] ?? false) === true,
            'restoredSnapshotIsInternallyConsistent' => ($restored['readyForBackup'] ?? false) === true,
        ];
        foreach ($fields as $field) {
            $checks[$field . 'Matches'] = array_key_exists($field, $baseline)
                && array_key_exists($field, $restored)
                && $baseline[$field] === $restored[$field];
        }

        return [
            'mode' => 'read-only',
            'matched' => !in_array(false, $checks, true),
            'checks' => $checks,
            'baseline' => self::summary($baseline),
            'restored' => self::summary($restored),
        ];
    }

    public static function isDisposableTarget(
        string $configuredDatabase,
        string $confirmedDatabase,
        string $configuredArtifactRoot,
        string $confirmedArtifactRoot,
    ): bool {
        return hash_equals($configuredDatabase, $confirmedDatabase)
            && preg_match('/(?:restore|drill|test)/i', $configuredDatabase) === 1
            && hash_equals($configuredArtifactRoot, $confirmedArtifactRoot)
            && preg_match(
                '/(?:restore|drill|test)/i',
                str_replace('\\', '/', $configuredArtifactRoot),
            ) === 1;
    }

    private static function hasFilenameHashMismatch(array $artifacts): bool
    {
        foreach ($artifacts as $artifact) {
            if (in_array('filename-hash-mismatch', $artifact['reasons'] ?? [], true)) {
                return true;
            }
        }
        return false;
    }

    private static function artifactInventoryHash(array $artifacts): string
    {
        $inventory = [];
        foreach ($artifacts as $artifact) {
            $inventory[] = [
                'path' => (string) ($artifact['path'] ?? ''),
                'bytes' => (int) ($artifact['bytes'] ?? 0),
                'sha256' => (string) ($artifact['actualHash'] ?? ''),
            ];
        }
        usort($inventory, static fn (array $left, array $right): int => strcmp($left['path'], $right['path']));
        return hash('sha256', json_encode($inventory, JSON_UNESCAPED_SLASHES | JSON_THROW_ON_ERROR));
    }

    private static function summary(array $report): array
    {
        return array_intersect_key($report, array_flip([
            'readyForBackup',
            'activeRevision',
            'manifestHash',
            'catalogHash',
            'artifactFiles',
            'artifactBytes',
            'artifactInventoryHash',
        ]));
    }
}
