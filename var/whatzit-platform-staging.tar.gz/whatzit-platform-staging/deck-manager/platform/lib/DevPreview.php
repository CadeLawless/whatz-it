<?php

declare(strict_types=1);

namespace WhatzIt\DeckPlatform;

final class DevPreviewEngine
{
    public function __construct(
        private readonly Database $database,
        private readonly CatalogStore $catalogs,
        private readonly PlatformConfig $config,
    ) {
    }

    /** @return array{previewRevision:int,draftId:int,draftVersion:int,draftHash:string,manifestHash:string,updatedAt:string} */
    public function update(
        array $draft,
        string $administrator,
        string $mediaRoot,
        array $mediaChangedDeckIds = [],
    ): array {
        $problems = $this->config->devPreviewProblems();
        if ($problems !== []) throw new PlatformException(implode(' ', $problems));
        $draftHash = CatalogCodec::hash($draft['catalog']);
        $latest = $this->latest();
        if ($latest !== null
            && hash_equals((string) $latest['draftHash'], $draftHash)
            && $mediaChangedDeckIds === []) {
            return $latest;
        }

        $active = $this->catalogs->exportActive();
        $comparison = $latest === null ? $active : $latest['catalog'];
        $comparison['revision'] = (int) $draft['catalog']['revision'];
        $versions = self::versions($comparison);
        foreach ($this->catalogs->publishedVersions() as $kind => $items) {
            foreach ($items as $id => $version) {
                if (!isset($versions[$kind][$id])) $versions[$kind][$id] = $version;
                foreach ($version as $key => $value) {
                    $versions[$kind][$id][$key] = max(
                        (int) ($versions[$kind][$id][$key] ?? 0),
                        (int) $value,
                    );
                }
            }
        }
        $updatedAt = gmdate('Y-m-d\TH:i:s\Z');
        if ($latest === null
            && $mediaChangedDeckIds === []
            && hash_equals(CatalogCodec::hash($active), $draftHash)) {
            $catalog = $draft['catalog'];
            $catalog['updatedAt'] = $updatedAt;
            $plan = ['catalog' => $catalog, 'versions' => $versions, 'summary' => []];
        } else {
            $plan = VersionPlanner::plan(
                $comparison,
                $draft['catalog'],
                $versions,
                $updatedAt,
                $mediaChangedDeckIds,
            );
        }
        $previewRevision = max(
            (int) $active['revision'],
            (int) ($latest['previewRevision'] ?? 0),
        ) + 1;
        $plan['catalog']['revision'] = $previewRevision;
        $previewRoot = $this->config->artifactRoot . DIRECTORY_SEPARATOR . 'dev-preview';
        $revisionRoot = $previewRoot . DIRECTORY_SEPARATOR . 'revisions'
            . DIRECTORY_SEPARATOR . $previewRevision;
        if (file_exists($revisionRoot)) {
            throw new PlatformException('The development preview revision already exists.');
        }
        $preparationRoot = $previewRoot . DIRECTORY_SEPARATOR . '.preparations'
            . DIRECTORY_SEPARATOR . bin2hex(random_bytes(16));
        $previewBase = $this->config->apiBaseUrl . '/api/v1/dev-preview/revisions/' . $previewRevision;
        try {
            $artifact = (new ArtifactBuilder())->build(
                $plan['catalog'],
                $mediaRoot,
                $preparationRoot,
                $this->config->apiBaseUrl,
                $previewBase . '/content',
                $plan['versions'],
                true,
                '/api/v1/dev-preview/revisions/' . $previewRevision . '/decks',
            );
            self::ensureDirectory(dirname($revisionRoot));
            if (!rename($preparationRoot, $revisionRoot)) {
                throw new PlatformException('The development preview artifacts could not be promoted.');
            }
            $catalogJson = CatalogCodec::encode($plan['catalog']);
            $this->database->execute(
                "INSERT INTO development_previews "
                . "(preview_revision, state, draft_id, draft_version, draft_hash, catalog_json, manifest_hash, created_by) "
                . "VALUES (?, 'prepared', ?, ?, ?, ?, ?, ?)",
                'iiissss',
                [$previewRevision, (int) $draft['draftId'], (int) $draft['draftVersion'],
                    $draftHash, $catalogJson, $artifact['etag'], $administrator],
            );
            (new ArtifactPromoter())->activateManifest($revisionRoot, $previewRoot, $artifact['etag']);
            $this->database->begin();
            try {
                $this->database->execute(
                    "UPDATE development_previews SET state = 'retired' WHERE state = 'active'",
                );
                $this->database->execute(
                    "UPDATE development_previews SET state = 'active', activated_at = CURRENT_TIMESTAMP(6) "
                    . "WHERE preview_revision = ? AND state = 'prepared'",
                    'i',
                    [$previewRevision],
                );
                $this->database->commit();
            } catch (\Throwable $error) {
                $this->database->rollback();
                throw $error;
            }
        } catch (\Throwable $error) {
            if (is_dir($preparationRoot)) MediaProjection::removeWorkspace($preparationRoot);
            if (is_dir($revisionRoot)) MediaProjection::removeWorkspace($revisionRoot);
            throw $error;
        }
        return $this->latest() ?? throw new PlatformException('The development preview could not be activated.');
    }

    /** @return null|array{previewRevision:int,draftId:int,draftVersion:int,draftHash:string,manifestHash:string,updatedAt:string,catalog:array} */
    public function latest(): ?array
    {
        $rows = $this->database->rows(
            "SELECT preview_revision, draft_id, draft_version, draft_hash, catalog_json, manifest_hash, activated_at "
            . "FROM development_previews WHERE state = 'active' ORDER BY preview_revision DESC LIMIT 1",
        );
        if ($rows === []) return null;
        $catalog = json_decode((string) $rows[0]['catalog_json'], true, 512, JSON_THROW_ON_ERROR);
        if (!is_array($catalog)) throw new PlatformException('The development preview catalog is invalid.');
        return [
            'previewRevision' => (int) $rows[0]['preview_revision'],
            'draftId' => (int) $rows[0]['draft_id'],
            'draftVersion' => (int) $rows[0]['draft_version'],
            'draftHash' => (string) $rows[0]['draft_hash'],
            'manifestHash' => (string) $rows[0]['manifest_hash'],
            'updatedAt' => (string) $rows[0]['activated_at'],
            'catalog' => $catalog,
        ];
    }

    private static function versions(array $catalog): array
    {
        $versions = ['decks' => [], 'bundles' => []];
        foreach ($catalog['decks'] ?? [] as $deck) {
            $versions['decks'][(string) $deck['id']] = [
                'deckVersion' => (int) ($deck['version'] ?? 1),
                'cardContentVersion' => (int) ($deck['cardContentVersion'] ?? $deck['version'] ?? 1),
            ];
        }
        foreach ($catalog['bundles'] ?? [] as $bundle) {
            $versions['bundles'][(string) $bundle['id']] = [
                'bundleVersion' => (int) ($bundle['version'] ?? 1),
            ];
        }
        return $versions;
    }

    private static function ensureDirectory(string $path): void
    {
        if (!is_dir($path) && !mkdir($path, 0775, true) && !is_dir($path)) {
            throw new PlatformException("Development preview directory could not be created: $path");
        }
    }
}
