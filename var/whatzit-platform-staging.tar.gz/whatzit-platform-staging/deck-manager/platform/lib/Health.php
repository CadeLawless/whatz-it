<?php

declare(strict_types=1);

namespace WhatzIt\DeckPlatform;

final class OperationalHealthReporter
{
    private const INTERRUPTED_AFTER_SECONDS = 900;
    private const RECENT_WINDOW_HOURS = 24;

    public function __construct(
        private readonly Database $database,
        private readonly string $artifactRoot,
        private readonly string $migrationRoot,
    ) {
    }

    public function generate(?\DateTimeImmutable $now = null): array
    {
        $now ??= new \DateTimeImmutable('now', new \DateTimeZone('UTC'));
        $active = $this->database->rows(
            'SELECT r.revision, r.state, r.manifest_hash '
            . 'FROM active_catalog_revision a INNER JOIN catalog_revisions r '
            . 'ON r.revision = a.revision WHERE a.singleton_id = 1',
        )[0] ?? null;

        $manifestPath = rtrim($this->artifactRoot, '/\\') . DIRECTORY_SEPARATOR . 'manifest.json';
        $manifestBytes = is_readable($manifestPath) ? file_get_contents($manifestPath) : false;
        $manifest = null;
        if (is_string($manifestBytes)) {
            try {
                $decoded = json_decode($manifestBytes, true, 512, JSON_THROW_ON_ERROR);
                if (is_array($decoded)) $manifest = $decoded;
            } catch (\JsonException) {
                $manifest = null;
            }
        }

        $activeRevision = is_array($active) ? (int) $active['revision'] : 0;
        $databaseManifestHash = is_array($active) ? (string) ($active['manifest_hash'] ?? '') : '';
        $artifactManifestHash = is_string($manifestBytes) ? hash('sha256', $manifestBytes) : '';
        $artifactManifestRevision = is_array($manifest) ? (int) ($manifest['catalogRevision'] ?? 0) : 0;

        $migration = $this->migrationStatus();
        $preparations = array_map(
            static fn (array $row): array => [
                'preparationId' => (string) $row['preparation_id'],
                'targetRevision' => (int) $row['target_revision'],
                'state' => (string) $row['state'],
                'ageSeconds' => max(0, (int) $row['age_seconds']),
            ],
            $this->database->rows(
                "SELECT preparation_id, target_revision, state, "
                . 'TIMESTAMPDIFF(SECOND, updated_at, CURRENT_TIMESTAMP(6)) AS age_seconds '
                . "FROM publication_preparations WHERE state IN "
                . "('preparing', 'artifacts_ready', 'database_active') ORDER BY created_at DESC",
            ),
        );
        $interrupted = array_values(array_filter(
            $preparations,
            static fn (array $row): bool => $row['ageSeconds'] >= self::INTERRUPTED_AFTER_SECONDS,
        ));
        $recentFailures = array_map(
            static fn (array $row): array => [
                'preparationId' => (string) $row['preparation_id'],
                'targetRevision' => (int) $row['target_revision'],
                'errorCode' => (string) ($row['error_code'] ?? 'unknown'),
                'updatedAt' => self::utc((string) $row['updated_at']),
            ],
            $this->database->rows(
                "SELECT preparation_id, target_revision, error_code, updated_at "
                . "FROM publication_preparations WHERE state = 'failed' "
                . 'AND updated_at >= DATE_SUB(CURRENT_TIMESTAMP(6), INTERVAL '
                . self::RECENT_WINDOW_HOURS . ' HOUR) ORDER BY updated_at DESC LIMIT 20',
            ),
        );
        $lastPublication = $this->database->rows(
            'SELECT catalog_revision, event_type, source_revision, administrator, created_at '
            . 'FROM publication_events ORDER BY event_id DESC LIMIT 1',
        )[0] ?? null;

        $activeDraft = $this->database->rows(
            "SELECT draft_id, base_revision, draft_version, updated_by, updated_at "
            . "FROM catalog_drafts WHERE active_slot = 1 AND status = 'active' LIMIT 1",
        )[0] ?? null;

        $preview = $this->developmentPreviewStatus();
        $commerce = $this->commerceStatus();
        $freeBytes = disk_free_space($this->artifactRoot);
        $totalBytes = disk_total_space($this->artifactRoot);

        $criticalChecks = [
            'activeCatalogExists' => is_array($active),
            'activeCatalogStateIsActive' => is_array($active) && (string) $active['state'] === 'active',
            'activeManifestReadable' => is_string($manifestBytes),
            'activeManifestJsonValid' => is_array($manifest),
            'manifestRevisionMatchesDatabase' => $activeRevision > 0
                && $artifactManifestRevision === $activeRevision,
            'manifestHashMatchesDatabase' => $databaseManifestHash !== ''
                && $artifactManifestHash !== ''
                && hash_equals($databaseManifestHash, $artifactManifestHash),
            'migrationSetCurrent' => $migration['current'],
            'noInterruptedPublications' => $interrupted === [],
            'activeEntitlementInvariantsHold' => $commerce['activeEntitlementViolations'] === 0,
        ];
        $advisoryChecks = [
            'developmentPreviewConsistent' => $preview['consistent'],
            'noRecentPublicationFailures' => $recentFailures === [],
            'noLongPendingTransactions' => $commerce['longPendingTransactions'] === 0,
            'artifactFilesystemCapacityReadable' => is_float($freeBytes) && is_float($totalBytes),
        ];

        return self::buildReport(
            $now,
            $criticalChecks,
            $advisoryChecks,
            [
                'catalog' => [
                    'activeRevision' => $activeRevision,
                    'databaseManifestHash' => $databaseManifestHash,
                    'artifactManifestHash' => $artifactManifestHash,
                    'artifactManifestRevision' => $artifactManifestRevision,
                ],
                'schema' => $migration,
                'publications' => [
                    'inProgress' => $preparations,
                    'interrupted' => $interrupted,
                    'recentFailures' => $recentFailures,
                    'lastSuccessful' => self::publicationSummary($lastPublication),
                    'interruptedAfterSeconds' => self::INTERRUPTED_AFTER_SECONDS,
                ],
                'authoring' => ['activeDraft' => self::draftSummary($activeDraft)],
                'developmentPreview' => $preview,
                'commerce' => $commerce,
                'storage' => [
                    'artifactRoot' => $this->artifactRoot,
                    'freeBytes' => is_float($freeBytes) ? (int) $freeBytes : null,
                    'totalBytes' => is_float($totalBytes) ? (int) $totalBytes : null,
                ],
            ],
        );
    }

    public static function buildReport(
        \DateTimeImmutable $now,
        array $criticalChecks,
        array $advisoryChecks,
        array $sections,
    ): array {
        $critical = in_array(false, $criticalChecks, true);
        $warning = in_array(false, $advisoryChecks, true);
        return [
            'mode' => 'read-only',
            'status' => $critical ? 'critical' : ($warning ? 'warning' : 'healthy'),
            'healthy' => !$critical,
            'generatedAt' => $now->setTimezone(new \DateTimeZone('UTC'))->format('Y-m-d\TH:i:s\Z'),
            'checks' => [
                'critical' => $criticalChecks,
                'advisory' => $advisoryChecks,
            ],
        ] + $sections;
    }

    private function migrationStatus(): array
    {
        $expected = [];
        foreach (glob(rtrim($this->migrationRoot, '/\\') . DIRECTORY_SEPARATOR . '*.sql') ?: [] as $path) {
            $name = basename($path);
            if (preg_match('/^(\d+)_.*\.sql$/', $name, $matches) === 1) {
                $expected[(int) $matches[1]] = $name;
            }
        }
        ksort($expected, SORT_NUMERIC);
        $applied = [];
        foreach ($this->database->rows('SELECT version, name FROM schema_migrations ORDER BY version') as $row) {
            $applied[(int) $row['version']] = (string) $row['name'];
        }
        ksort($applied, SORT_NUMERIC);
        return [
            'current' => $expected !== [] && $expected === $applied,
            'expected' => array_values($expected),
            'applied' => array_values($applied),
        ];
    }

    private function developmentPreviewStatus(): array
    {
        $rows = $this->database->rows(
            "SELECT preview_revision, manifest_hash, activated_at FROM development_previews "
            . "WHERE state = 'active' ORDER BY preview_revision DESC",
        );
        if ($rows === []) {
            return [
                'activeCount' => 0,
                'activeRevision' => null,
                'manifestHash' => null,
                'artifactManifestHash' => null,
                'consistent' => true,
            ];
        }
        $row = $rows[0];
        $path = rtrim($this->artifactRoot, '/\\') . DIRECTORY_SEPARATOR
            . 'dev-preview' . DIRECTORY_SEPARATOR . 'manifest.json';
        $bytes = is_readable($path) ? file_get_contents($path) : false;
        $manifest = null;
        if (is_string($bytes)) {
            try {
                $decoded = json_decode($bytes, true, 512, JSON_THROW_ON_ERROR);
                if (is_array($decoded)) $manifest = $decoded;
            } catch (\JsonException) {
                $manifest = null;
            }
        }
        $artifactHash = is_string($bytes) ? hash('sha256', $bytes) : null;
        $databaseHash = (string) $row['manifest_hash'];
        $revision = (int) $row['preview_revision'];
        $activatedAt = (string) ($row['activated_at'] ?? '');
        return [
            'activeCount' => count($rows),
            'activeRevision' => $revision,
            'manifestHash' => $databaseHash,
            'artifactManifestHash' => $artifactHash,
            'activatedAt' => $activatedAt === '' ? null : self::utc($activatedAt),
            'consistent' => count($rows) === 1
                && $activatedAt !== ''
                && is_array($manifest)
                && (int) ($manifest['catalogRevision'] ?? 0) === $revision
                && is_string($artifactHash)
                && hash_equals($databaseHash, $artifactHash),
        ];
    }

    private function commerceStatus(): array
    {
        return [
            'activeInstallations' => (int) $this->database->scalar(
                "SELECT COUNT(*) FROM app_installations WHERE status = 'active'",
            ),
            'transactionsLast24Hours' => (int) $this->database->scalar(
                'SELECT COUNT(*) FROM store_transactions '
                . 'WHERE verified_at >= DATE_SUB(CURRENT_TIMESTAMP(6), INTERVAL 24 HOUR)',
            ),
            'activeEntitlements' => (int) $this->database->scalar(
                "SELECT COUNT(*) FROM entitlements WHERE entitlement_state = 'active'",
            ),
            'activeEntitlementViolations' => (int) $this->database->scalar(
                "SELECT COUNT(*) FROM entitlements e INNER JOIN store_transactions t "
                . 'ON t.store_transaction_pk = e.source_transaction_pk '
                . "WHERE e.entitlement_state = 'active' "
                . "AND (t.transaction_state <> 'verified' OR t.revoked_at IS NOT NULL)",
            ),
            'longPendingTransactions' => (int) $this->database->scalar(
                "SELECT COUNT(*) FROM store_transactions WHERE transaction_state = 'pending' "
                . 'AND verified_at < DATE_SUB(CURRENT_TIMESTAMP(6), INTERVAL 24 HOUR)',
            ),
        ];
    }

    private static function publicationSummary(?array $row): ?array
    {
        if (!is_array($row)) return null;
        return [
            'catalogRevision' => (int) $row['catalog_revision'],
            'eventType' => (string) $row['event_type'],
            'sourceRevision' => (int) $row['source_revision'],
            'administrator' => (string) $row['administrator'],
            'createdAt' => self::utc((string) $row['created_at']),
        ];
    }

    private static function draftSummary(?array $row): ?array
    {
        if (!is_array($row)) return null;
        return [
            'draftId' => (int) $row['draft_id'],
            'baseRevision' => (int) $row['base_revision'],
            'draftVersion' => (int) $row['draft_version'],
            'updatedBy' => (string) $row['updated_by'],
            'updatedAt' => self::utc((string) $row['updated_at']),
        ];
    }

    private static function utc(string $value): string
    {
        return (new \DateTimeImmutable($value, new \DateTimeZone('UTC')))
            ->setTimezone(new \DateTimeZone('UTC'))
            ->format('Y-m-d\TH:i:s\Z');
    }
}
