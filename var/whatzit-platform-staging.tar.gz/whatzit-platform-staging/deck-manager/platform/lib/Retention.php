<?php

declare(strict_types=1);

namespace WhatzIt\DeckPlatform;

final class ArtifactRetentionReporter
{
    private const SUPPORTED_DAYS = 365;
    private const SAFETY_DAYS = 90;
    private const ROLLBACK_REVISIONS = 10;

    public function __construct(
        private readonly Database $database,
        private readonly string $artifactRoot,
    ) {
    }

    public function generate(?\DateTimeImmutable $now = null): array
    {
        $now ??= new \DateTimeImmutable('now', new \DateTimeZone('UTC'));
        $revisions = $this->database->rows(
            "SELECT revision, state, imported_at FROM catalog_revisions "
            . "WHERE state IN ('active', 'retired') ORDER BY revision DESC",
        );
        $activeRevision = (int) ($this->database->scalar(
            'SELECT revision FROM active_catalog_revision WHERE singleton_id = 1',
        ) ?? 0);
        if ($activeRevision < 1) {
            throw new PlatformException('No active catalog revision exists for retention reporting.');
        }

        $revisionTimes = [];
        foreach ($revisions as &$revision) {
            $revision['revision'] = (int) $revision['revision'];
            $revision['importedAt'] = self::utc((string) $revision['imported_at']);
            $revisionTimes[$revision['revision']] = $revision['importedAt'];
            unset($revision['imported_at']);
        }
        unset($revision);

        $references = [];
        foreach ($this->database->rows(
            "SELECT d.catalog_revision, d.deck_id, d.card_content_version, "
            . "d.content_hash, d.cover_hash "
            . "FROM deck_revisions d INNER JOIN catalog_revisions r "
            . "ON r.revision = d.catalog_revision "
            . "WHERE r.state IN ('active', 'retired')",
        ) as $row) {
            $revision = (int) $row['catalog_revision'];
            $referencedAt = $revisionTimes[$revision] ?? null;
            if ($referencedAt === null) {
                throw new PlatformException("Revision $revision has no retention timestamp.");
            }
            $references[] = [
                'path' => 'decks/' . rawurlencode((string) $row['deck_id']) . '/'
                    . (int) $row['card_content_version'] . '/'
                    . (string) $row['content_hash'] . '.json',
                'revision' => $revision,
                'referencedAt' => $referencedAt,
            ];
            $coverHash = (string) ($row['cover_hash'] ?? '');
            if ($coverHash !== '') {
                $references[] = [
                    'path' => 'covers/' . $coverHash . '.webp',
                    'revision' => $revision,
                    'referencedAt' => $referencedAt,
                ];
            }
        }

        $manifestPath = rtrim($this->artifactRoot, '/\\') . DIRECTORY_SEPARATOR . 'manifest.json';
        $manifestBytes = is_readable($manifestPath) ? file_get_contents($manifestPath) : false;
        if (!is_string($manifestBytes)) {
            throw new PlatformException('The active manifest is not readable for retention reporting.');
        }
        $manifest = json_decode($manifestBytes, true, 512, JSON_THROW_ON_ERROR);
        if (!is_array($manifest) || (int) ($manifest['catalogRevision'] ?? 0) !== $activeRevision) {
            throw new PlatformException('The active manifest does not match the active database revision.');
        }
        $activeReferencedAt = $revisionTimes[$activeRevision] ?? self::utc($now->format('Y-m-d H:i:s'));
        foreach (($manifest['decks'] ?? []) as $deck) {
            if (!is_array($deck)) {
                throw new PlatformException('The active manifest contains an invalid deck.');
            }
            foreach (['cover', 'thumbnail'] as $kind) {
                $reference = $deck[$kind] ?? null;
                if (!is_array($reference) || !is_string($reference['hash'] ?? null)) {
                    continue;
                }
                $references[] = [
                    'path' => ($kind === 'cover' ? 'covers/' : 'thumbnails/')
                        . $reference['hash'] . '.webp',
                    'revision' => $activeRevision,
                    'referencedAt' => $activeReferencedAt,
                ];
            }
        }

        return self::buildReport(
            self::scanFiles($this->artifactRoot),
            $revisions,
            $references,
            $activeRevision,
            $now,
        );
    }

    /**
     * @param list<array{path:string,bytes:int,modifiedAt:string,actualHash:string,expectedHash:?string}> $files
     * @param list<array{revision:int,state:string,importedAt:string}> $revisions
     * @param list<array{path:string,revision:int,referencedAt:string}> $references
     */
    public static function buildReport(
        array $files,
        array $revisions,
        array $references,
        int $activeRevision,
        \DateTimeImmutable $now,
    ): array {
        $supportedCutoff = $now->modify('-' . self::SUPPORTED_DAYS . ' days');
        $eligibilityCutoff = $now->modify('-' . (self::SUPPORTED_DAYS + self::SAFETY_DAYS) . ' days');
        $protectedRevisions = [];
        foreach ($revisions as $index => $revision) {
            $number = (int) $revision['revision'];
            $reasons = [];
            if ($number === $activeRevision) {
                $reasons[] = 'active';
            }
            if ($index < self::ROLLBACK_REVISIONS) {
                $reasons[] = 'rollback-window';
            }
            if (new \DateTimeImmutable($revision['importedAt']) >= $supportedCutoff) {
                $reasons[] = 'supported-app-window';
            }
            if ($reasons !== []) {
                $protectedRevisions[$number] = array_values(array_unique($reasons));
            }
        }

        $referencesByPath = [];
        foreach ($references as $reference) {
            $referencesByPath[$reference['path']][] = $reference;
        }
        $filePaths = array_fill_keys(array_column($files, 'path'), true);
        $artifacts = [];
        $summary = [
            'protected' => ['files' => 0, 'bytes' => 0],
            'eligibleReview' => ['files' => 0, 'bytes' => 0],
            'unresolved' => ['files' => 0, 'bytes' => 0],
        ];

        foreach ($files as $file) {
            $path = $file['path'];
            $pathReferences = $referencesByPath[$path] ?? [];
            $reasons = [];
            $referencedRevisions = [];
            $latestReference = null;
            foreach ($pathReferences as $reference) {
                $revision = (int) $reference['revision'];
                $referencedRevisions[$revision] = true;
                $referenceTime = new \DateTimeImmutable($reference['referencedAt']);
                if ($latestReference === null || $referenceTime > $latestReference) {
                    $latestReference = $referenceTime;
                }
                foreach ($protectedRevisions[$revision] ?? [] as $reason) {
                    $reasons[] = "revision-$revision:$reason";
                }
            }

            if ($reasons !== []) {
                $classification = 'protected';
            } elseif ($pathReferences === []) {
                $classification = 'unresolved';
                $reasons[] = str_starts_with($path, 'thumbnails/')
                    ? 'historical-thumbnail-references-not-indexed'
                    : 'no-published-revision-reference';
            } elseif ($latestReference !== null && $latestReference < $eligibilityCutoff) {
                $classification = 'eligible_review';
                $reasons[] = 'outside-supported-and-safety-windows';
            } else {
                $classification = 'protected';
                $reasons[] = 'artifact-safety-window';
            }

            if ($file['expectedHash'] !== null && !hash_equals($file['expectedHash'], $file['actualHash'])) {
                $classification = 'unresolved';
                $reasons[] = 'filename-hash-mismatch';
            }
            $summaryKey = match ($classification) {
                'protected' => 'protected',
                'eligible_review' => 'eligibleReview',
                default => 'unresolved',
            };
            $summary[$summaryKey]['files']++;
            $summary[$summaryKey]['bytes'] += $file['bytes'];
            $artifacts[] = $file + [
                'classification' => $classification,
                'reasons' => array_values(array_unique($reasons)),
                'referencedRevisions' => array_map('intval', array_keys($referencedRevisions)),
            ];
        }

        $missingReferences = [];
        foreach (array_keys($referencesByPath) as $path) {
            if (!isset($filePaths[$path])) {
                $missingReferences[] = $path;
            }
        }
        sort($missingReferences);
        usort($artifacts, static fn (array $left, array $right): int => strcmp($left['path'], $right['path']));

        return [
            'mode' => 'read-only',
            'generatedAt' => $now->setTimezone(new \DateTimeZone('UTC'))->format('Y-m-d\TH:i:s\Z'),
            'policy' => [
                'supportedDays' => self::SUPPORTED_DAYS,
                'safetyDays' => self::SAFETY_DAYS,
                'rollbackRevisions' => self::ROLLBACK_REVISIONS,
                'deletionEnabled' => false,
            ],
            'activeRevision' => $activeRevision,
            'protectedRevisions' => $protectedRevisions,
            'summary' => $summary,
            'missingReferences' => $missingReferences,
            'artifacts' => $artifacts,
        ];
    }

    private static function scanFiles(string $artifactRoot): array
    {
        if (!is_dir($artifactRoot) || !is_readable($artifactRoot)) {
            throw new PlatformException('The artifact root is not readable for retention reporting.');
        }
        $files = [];
        foreach (['decks', 'covers', 'thumbnails'] as $directory) {
            $root = rtrim($artifactRoot, '/\\') . DIRECTORY_SEPARATOR . $directory;
            if (!is_dir($root)) {
                continue;
            }
            $iterator = new \RecursiveIteratorIterator(
                new \RecursiveDirectoryIterator($root, \FilesystemIterator::SKIP_DOTS),
            );
            foreach ($iterator as $file) {
                if (!$file->isFile() || $file->isLink()) {
                    continue;
                }
                $relative = $directory . '/' . str_replace('\\', '/', substr($file->getPathname(), strlen($root) + 1));
                $hash = hash_file('sha256', $file->getPathname());
                if (!is_string($hash)) {
                    throw new PlatformException("Artifact could not be hashed: $relative");
                }
                $filename = $file->getBasename();
                $expected = preg_match('/^([a-f0-9]{64})\.(?:json|webp)$/', $filename, $matches) === 1
                    ? $matches[1]
                    : null;
                $files[] = [
                    'path' => $relative,
                    'bytes' => $file->getSize(),
                    'modifiedAt' => gmdate('Y-m-d\TH:i:s\Z', $file->getMTime()),
                    'actualHash' => $hash,
                    'expectedHash' => $expected,
                ];
            }
        }
        return $files;
    }

    private static function utc(string $value): string
    {
        return (new \DateTimeImmutable($value, new \DateTimeZone('UTC')))
            ->setTimezone(new \DateTimeZone('UTC'))
            ->format('Y-m-d\TH:i:s\Z');
    }
}
