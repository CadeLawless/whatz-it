<?php

declare(strict_types=1);

namespace WhatzIt\DeckPlatform;

use WhatzIt\DeckManager\ApiException;
use WhatzIt\DeckManager\CatalogValidator;

final class DatabaseDeckManager
{
    private readonly CatalogStore $catalogs;
    private readonly DraftRepository $drafts;
    private readonly PublicationEngine $publications;
    private readonly DevPreviewEngine $devPreview;
    private readonly AppleCatalogPublicationGate $appleCatalogGate;

    public function __construct(
        private readonly Database $database,
        private readonly PlatformConfig $config,
        ?AppleCatalogPublicationGate $appleCatalogGate = null,
    ) {
        $this->catalogs = new CatalogStore($database);
        $this->drafts = new DraftRepository($database, $this->catalogs);
        $this->publications = new PublicationEngine($database, $this->catalogs);
        $this->devPreview = new DevPreviewEngine($database, $this->catalogs, $config);
        $this->appleCatalogGate = $appleCatalogGate
            ?? new AppleCatalogPublicationGate($config, new AppStoreConnectCatalogClient($config));
    }

    public function loadState(string $administrator, bool $createDraft = true): array
    {
        $draft = $createDraft
            ? $this->drafts->loadOrCreate($administrator)
            : $this->drafts->loadActive();
        $catalog = $draft['catalog'];
        $publishedCatalog = $this->catalogs->exportActive();
        $validation = CatalogValidator::validate($catalog);
        return [
            'source' => CatalogCodec::encode($catalog, true),
            'publishedSource' => CatalogCodec::encode($publishedCatalog, true),
            'snapshot' => [
                'storage' => 'database',
                'draftId' => $draft['draftId'],
                'draftVersion' => $draft['draftVersion'],
                'baseRevision' => $draft['baseRevision'],
                'updatedBy' => $draft['updatedBy'],
            ],
            'images' => $this->images($catalog),
            'history' => $this->history(),
            'devPreview' => $this->devPreviewStatus($draft),
            'connection' => [
                'appRoot' => 'WHATZ IT? catalog database',
                'jsonPath' => 'catalog.json',
                'imageDirectory' => 'content-addressed media',
                'branch' => 'database',
                'errors' => [],
                'warnings' => $validation === [] ? [] : ['The active draft has validation errors.'],
            ],
        ];
    }

    public function saveDraft(array $input, string $administrator): array
    {
        $catalog = $this->catalogInput($input);
        $snapshot = $this->snapshotInput($input);
        $saved = $this->drafts->save(
            $snapshot['draftId'],
            $snapshot['draftVersion'],
            $catalog,
            $administrator,
        );
        return [
            'storage' => 'database',
            'draftId' => $saved['draftId'],
            'draftVersion' => $saved['draftVersion'],
            'baseRevision' => $saved['baseRevision'],
            'updatedBy' => $saved['updatedBy'],
        ];
    }

    public function discardDraft(array $input, string $administrator): array
    {
        $snapshot = $this->snapshotInput($input);
        $this->drafts->discard($snapshot['draftId'], $snapshot['draftVersion'], $administrator);
        return $this->loadState($administrator);
    }

    public function validateDraft(array $input): array
    {
        $errors = CatalogValidator::validate($this->catalogInput($input));
        return ['valid' => $errors === [], 'errors' => $errors];
    }

    public function publish(array $input, array $uploads, string $administrator): array
    {
        $catalog = $this->catalogInput($input);
        $this->appleCatalogGate->assertPublishable($catalog);
        $snapshot = $this->snapshotInput($input);
        $current = $this->catalogs->exportActive();
        $currentSources = $this->catalogs->coverSources((int) $current['revision']);
        $workspace = $this->mediaWorkspace();
        try {
            $projection = (new MediaProjection())->create(
                $current,
                $catalog,
                $currentSources,
                $currentSources,
                $input['imageOperations'] ?? [],
                $uploads,
                $this->config->artifactRoot,
                $this->config->mediaRoot,
                $workspace,
            );
            $saved = $this->drafts->save(
                $snapshot['draftId'],
                $snapshot['draftVersion'],
                $catalog,
                $administrator,
            );
            $draft = $this->drafts->loadActive();
            if ($draft['draftId'] !== $saved['draftId'] || $draft['draftVersion'] !== $saved['draftVersion']) {
                throw new PublicationConflict('The saved draft changed before publication began.');
            }
            $publication = $this->publications->publish(
                $draft,
                $administrator,
                $projection['mediaRoot'],
                $this->config->artifactRoot,
                $this->config->apiBaseUrl,
                $this->config->contentBaseUrl,
                null,
                null,
                $projection['changedDeckIds'],
            );
            return $this->refreshDevelopmentPreviewAfterPublication(
                $publication,
                $administrator,
                $projection['mediaRoot'],
            );
        } finally {
            MediaProjection::removeWorkspace($workspace);
        }
    }

    public function publishActive(string $administrator): array
    {
        $draft = $this->drafts->loadActive();
        $this->appleCatalogGate->assertPublishable($draft['catalog']);
        $current = $this->catalogs->exportActive();
        $currentSources = $this->catalogs->coverSources((int) $current['revision']);
        $workspace = $this->mediaWorkspace();
        try {
            $projection = (new MediaProjection())->create(
                $current,
                $draft['catalog'],
                $currentSources,
                $currentSources,
                [],
                [],
                $this->config->artifactRoot,
                $this->config->mediaRoot,
                $workspace,
            );
            $publication = $this->publications->publish(
                $draft,
                $administrator,
                $projection['mediaRoot'],
                $this->config->artifactRoot,
                $this->config->apiBaseUrl,
                $this->config->contentBaseUrl,
                null,
                null,
                $projection['changedDeckIds'],
            );
            return $this->refreshDevelopmentPreviewAfterPublication(
                $publication,
                $administrator,
                $projection['mediaRoot'],
            );
        } finally {
            MediaProjection::removeWorkspace($workspace);
        }
    }

    public function updateDevPreview(array $input, array $uploads, string $administrator): array
    {
        $catalog = $this->catalogInput($input);
        $this->appleCatalogGate->assertPublishable($catalog);
        $snapshot = $this->snapshotInput($input);
        $current = $this->catalogs->exportActive();
        $currentSources = $this->catalogs->coverSources((int) $current['revision']);
        $workspace = $this->mediaWorkspace();
        try {
            $projection = (new MediaProjection())->create(
                $current,
                $catalog,
                $currentSources,
                $currentSources,
                $input['imageOperations'] ?? [],
                $uploads,
                $this->config->artifactRoot,
                $this->config->mediaRoot,
                $workspace,
            );
            $saved = $this->drafts->save(
                $snapshot['draftId'],
                $snapshot['draftVersion'],
                $catalog,
                $administrator,
            );
            $draft = $this->drafts->loadActive();
            if ($draft['draftId'] !== $saved['draftId'] || $draft['draftVersion'] !== $saved['draftVersion']) {
                throw new PublicationConflict('The saved draft changed before the development preview began.');
            }
            $preview = $this->devPreview->update(
                $draft,
                $administrator,
                $projection['mediaRoot'],
                $projection['changedDeckIds'],
            );
            unset($preview['catalog'], $preview['draftHash']);
            $preview['current'] = true;
            return $preview;
        } finally {
            MediaProjection::removeWorkspace($workspace);
        }
    }

    public function rollback(int $revision, string $administrator, ?array $expectedSnapshot = null): array
    {
        $current = $this->catalogs->exportActive();
        $historical = $this->catalogs->exportRevision($revision);
        $this->appleCatalogGate->assertPublishable($historical);
        $draft = null;
        if ($expectedSnapshot !== null) {
            $snapshot = $this->snapshotInput(['baseSnapshot' => $expectedSnapshot]);
            $draft = $this->drafts->loadActive();
            if ($draft['draftId'] !== $snapshot['draftId']
                || $draft['draftVersion'] !== $snapshot['draftVersion']) {
                throw new PublicationConflict('The database draft changed before rollback began. Get Latest and try again.');
            }
        } elseif ($this->database->scalar(
            "SELECT draft_id FROM catalog_drafts WHERE active_slot = 1 AND status = 'active'",
        ) !== null) {
            // Loading the manager creates a pristine working draft. CLI recovery
            // should discard it just as the browser rollback path does, while
            // still refusing to erase any unpublished catalog changes.
            $draft = $this->drafts->loadActive();
        }
        if ($draft !== null) {
            if (CatalogCodec::hash($draft['catalog']) !== CatalogCodec::hash($current)) {
                throw new PublicationConflict('Discard the unpublished database draft before rolling back history.');
            }
            $this->drafts->discard(
                $draft['draftId'],
                $draft['draftVersion'],
                $administrator,
            );
        }
        $currentSources = $this->catalogs->coverSources((int) $current['revision']);
        $historicalSources = $this->catalogs->coverSources($revision);
        $workspace = $this->mediaWorkspace();
        try {
            $projection = (new MediaProjection())->create(
                $current,
                $historical,
                $historicalSources,
                $currentSources,
                [],
                [],
                $this->config->artifactRoot,
                $this->config->mediaRoot,
                $workspace,
            );
            $draft = $this->drafts->createFromRevision($revision, $administrator);
            $publication = $this->publications->publish(
                $draft,
                $administrator,
                $projection['mediaRoot'],
                $this->config->artifactRoot,
                $this->config->apiBaseUrl,
                $this->config->contentBaseUrl,
                $revision,
                null,
                $projection['changedDeckIds'],
            );
            return $this->refreshDevelopmentPreviewAfterPublication(
                $publication,
                $administrator,
                $projection['mediaRoot'],
            );
        } finally {
            MediaProjection::removeWorkspace($workspace);
        }
    }

    public function export(?int $revision = null): array
    {
        return $revision === null
            ? $this->catalogs->exportActive()
            : $this->catalogs->exportRevision($revision);
    }

    private function devPreviewStatus(array $draft): ?array
    {
        $preview = $this->devPreview->latest();
        if ($preview === null) return null;
        unset($preview['catalog'], $preview['draftHash']);
        $preview['current'] = $preview['draftId'] === $draft['draftId']
            && $preview['draftVersion'] === $draft['draftVersion'];
        return $preview;
    }

    private function refreshDevelopmentPreviewAfterPublication(
        array $publication,
        string $administrator,
        string $mediaRoot,
    ): array {
        if ($this->config->devPreviewProblems() !== []) {
            $publication['devPreviewUpdated'] = false;
            $publication['devPreviewErrorCode'] = 'not_configured';
            return $publication;
        }
        try {
            // Publication retires the submitted draft. Start the next pristine
            // draft from the newly active catalog so the preview status and the
            // editor both point at the exact production state.
            $draft = $this->drafts->loadOrCreate($administrator);
            $preview = $this->devPreview->update(
                $draft,
                $administrator,
                $mediaRoot,
            );
            unset($preview['catalog'], $preview['draftHash']);
            $preview['current'] = true;
            $publication['devPreviewUpdated'] = true;
            $publication['devPreview'] = $preview;
        } catch (\Throwable $error) {
            error_log(
                'Automatic development preview refresh failed after catalog publication: '
                . $error->getMessage(),
            );
            $publication['devPreviewUpdated'] = false;
            $publication['devPreviewErrorCode'] = 'refresh_failed';
        }
        return $publication;
    }

    public function image(string $type, string $hash): array
    {
        if (!in_array($type, ['covers', 'thumbnails'], true)
            || preg_match('/^[a-f0-9]{64}$/', $hash) !== 1) {
            throw new ApiException('Invalid database image request.', 400);
        }
        $path = $this->config->artifactRoot . DIRECTORY_SEPARATOR . $type
            . DIRECTORY_SEPARATOR . $hash . '.webp';
        $bytes = is_file($path) && is_readable($path) ? file_get_contents($path) : false;
        if (!is_string($bytes)) {
            throw new ApiException('The requested database image does not exist.', 404);
        }
        if (!hash_equals($hash, hash('sha256', $bytes))) {
            throw new ApiException('The requested database image failed integrity validation.', 503);
        }
        return ['body' => $bytes, 'mime' => 'image/webp', 'etag' => $hash];
    }

    public function history(): array
    {
        return array_map(
            static function (array $row): array {
                $summary = json_decode((string) $row['summary_json'], true);
                return [
                    'id' => 'revision-' . (int) $row['catalog_revision'],
                    'createdAt' => self::isoUtcTimestamp((string) $row['created_at']),
                    'revision' => (int) $row['catalog_revision'],
                    'summary' => is_array($summary) ? $summary : [],
                    'sourceJson' => 'revision ' . (int) $row['source_revision'],
                    'url' => '',
                    'eventType' => (string) $row['event_type'],
                    'rollbackOfRevision' => $row['rollback_of_revision'] === null
                        ? null
                        : (int) $row['rollback_of_revision'],
                    'administrator' => (string) $row['administrator'],
                ];
            },
            $this->database->rows(
                'SELECT catalog_revision, event_type, source_revision, rollback_of_revision, '
                . 'administrator, summary_json, created_at FROM publication_events '
                . 'ORDER BY catalog_revision DESC LIMIT 15',
            ),
        );
    }

    public static function isoUtcTimestamp(string $value): string
    {
        if (preg_match('/^\d{4}-\d{2}-\d{2} \d{2}:\d{2}:\d{2}(?:\.\d{1,6})?$/', $value) !== 1) {
            return $value;
        }
        return str_replace(' ', 'T', $value) . 'Z';
    }

    private function images(array $catalog): array
    {
        $manifestPath = $this->config->artifactRoot . DIRECTORY_SEPARATOR . 'manifest.json';
        $bytes = is_file($manifestPath) ? file_get_contents($manifestPath) : false;
        $manifest = is_string($bytes) ? json_decode($bytes, true) : null;
        $manifestDecks = [];
        foreach (is_array($manifest) ? ($manifest['decks'] ?? []) : [] as $deck) {
            if (is_array($deck) && is_string($deck['id'] ?? null)) {
                $manifestDecks[$deck['id']] = $deck;
            }
        }
        $images = [];
        foreach ($catalog['decks'] ?? [] as $deck) {
            $coverPath = (string) ($deck['coverImage'] ?? '');
            $cover = $manifestDecks[(string) ($deck['id'] ?? '')]['cover'] ?? null;
            if ($coverPath === '' || !is_array($cover)) {
                continue;
            }
            $hash = (string) ($cover['hash'] ?? '');
            if (preg_match('/^[a-f0-9]{64}$/', $hash) !== 1) {
                continue;
            }
            $images[] = [
                'filename' => basename(str_replace('\\', '/', $coverPath)),
                'relativePath' => $coverPath,
                'size' => (int) ($cover['bytes'] ?? 0),
                'hash' => $hash,
                'previewUrl' => 'api.php?action=database_image&type=covers&hash=' . rawurlencode($hash),
                'references' => [],
                'orphaned' => false,
            ];
        }
        usort($images, static fn (array $a, array $b): int => strcasecmp($a['filename'], $b['filename']));
        return $images;
    }

    private function catalogInput(array $input): array
    {
        $catalog = $input['catalog'] ?? null;
        if (!is_array($catalog)) {
            throw new ApiException('The catalog payload is invalid.');
        }
        $snapshot = $this->snapshotInput($input);
        $catalog['schemaVersion'] = 5;
        $catalog['revision'] = $snapshot['baseRevision'];
        foreach ($catalog['decks'] ?? [] as $index => &$deck) {
            if (is_array($deck)) {
                $deck['order'] = $index + 1;
            }
        }
        unset($deck);
        foreach ($catalog['bundles'] ?? [] as $index => &$bundle) {
            if (is_array($bundle)) {
                $bundle['order'] = $index + 1;
            }
        }
        unset($bundle);
        return $catalog;
    }

    /** @return array{draftId:int,draftVersion:int,baseRevision:int} */
    private function snapshotInput(array $input): array
    {
        $snapshot = $input['baseSnapshot'] ?? null;
        $draftId = is_array($snapshot) ? (int) ($snapshot['draftId'] ?? 0) : 0;
        $draftVersion = is_array($snapshot) ? (int) ($snapshot['draftVersion'] ?? 0) : 0;
        $baseRevision = is_array($snapshot) ? (int) ($snapshot['baseRevision'] ?? 0) : 0;
        if (!is_array($snapshot) || ($snapshot['storage'] ?? null) !== 'database'
            || $draftId < 1 || $draftVersion < 1 || $baseRevision < 1) {
            throw new ApiException(
                'The loaded database draft is unavailable. Get latest changes before saving.',
                409,
                [],
                true,
            );
        }
        return compact('draftId', 'draftVersion', 'baseRevision');
    }

    private function mediaWorkspace(): string
    {
        return $this->config->artifactRoot . DIRECTORY_SEPARATOR . '.media-preparations'
            . DIRECTORY_SEPARATOR . 'media-' . bin2hex(random_bytes(16));
    }
}
