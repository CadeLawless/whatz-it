<?php

declare(strict_types=1);

namespace WhatzIt\DeckPlatform;

final class CatalogEnvironmentRefresher
{
    public function __construct(
        private readonly Database $targetDatabase,
        private readonly PlatformConfig $targetConfig,
    ) {
    }

    /**
     * @return array{refreshed:bool,sourceRevision:int,sourceCatalogHash:string,targetRevision:int,manifestHash:?string,preparationId:?string}
     */
    public function refresh(PlatformConfig $sourceConfig, string $administrator): array
    {
        self::assertTopology($sourceConfig, $this->targetConfig);
        $sourceProblems = $sourceConfig->problems(
            database: true,
            artifacts: true,
            mediaRoot: true,
        );
        $targetProblems = $this->targetConfig->problems(
            database: true,
            artifacts: true,
            mediaRoot: true,
        );
        if ($sourceProblems !== [] || $targetProblems !== []) {
            throw new PlatformException(implode(' ', array_unique([
                ...$sourceProblems,
                ...$targetProblems,
            ])));
        }

        $sourceStore = new CatalogStore(new Database($sourceConfig));
        $targetStore = new CatalogStore($this->targetDatabase);
        $drafts = new DraftRepository($this->targetDatabase, $targetStore);
        $current = $targetStore->exportActive();
        $source = $sourceStore->exportActive();
        $sourceRevision = (int) $source['revision'];
        $sourceHash = CatalogCodec::hash($source);

        $existingDraftId = $this->targetDatabase->scalar(
            "SELECT draft_id FROM catalog_drafts WHERE active_slot = 1 AND status = 'active'",
        );
        $draft = $existingDraftId === null
            ? $drafts->loadOrCreate($administrator)
            : $drafts->loadActive();
        if (!hash_equals(CatalogCodec::hash($current), CatalogCodec::hash($draft['catalog']))) {
            throw new PublicationConflict(
                'Discard or publish the unpublished staging draft before refreshing from production.',
            );
        }

        // A staging publication owns its local revision lineage. Preserve the
        // target base while copying every author-managed production field.
        $target = $source;
        $target['revision'] = (int) $current['revision'];
        $target['updatedAt'] = (string) $current['updatedAt'];
        $workspace = $this->targetConfig->artifactRoot . DIRECTORY_SEPARATOR
            . '.media-preparations' . DIRECTORY_SEPARATOR
            . 'media-' . bin2hex(random_bytes(16));

        try {
            $projection = (new MediaProjection())->create(
                $current,
                $target,
                $sourceStore->coverSources($sourceRevision),
                $targetStore->coverSources((int) $current['revision']),
                [],
                [],
                $sourceConfig->artifactRoot,
                $sourceConfig->mediaRoot,
                $workspace,
            );
            if (!self::catalogsDiffer($current, $target)
                && $projection['changedDeckIds'] === []) {
                return [
                    'refreshed' => false,
                    'sourceRevision' => $sourceRevision,
                    'sourceCatalogHash' => $sourceHash,
                    'targetRevision' => (int) $current['revision'],
                    'manifestHash' => null,
                    'preparationId' => null,
                ];
            }

            $saved = $drafts->save(
                $draft['draftId'],
                $draft['draftVersion'],
                $target,
                $administrator,
            );
            $publication = (new PublicationEngine($this->targetDatabase, $targetStore))->publish(
                $saved,
                $administrator,
                $projection['mediaRoot'],
                $this->targetConfig->artifactRoot,
                $this->targetConfig->apiBaseUrl,
                $this->targetConfig->contentBaseUrl,
                null,
                null,
                $projection['changedDeckIds'],
            );
            return [
                'refreshed' => true,
                'sourceRevision' => $sourceRevision,
                'sourceCatalogHash' => $sourceHash,
                'targetRevision' => (int) $publication['catalog']['revision'],
                'manifestHash' => (string) $publication['manifestHash'],
                'preparationId' => (string) $publication['preparationId'],
            ];
        } finally {
            MediaProjection::removeWorkspace($workspace);
        }
    }

    public static function assertTopology(
        PlatformConfig $source,
        PlatformConfig $target,
    ): void {
        $target->assertTestDatabase();
        if ($source->environment !== 'production'
            || $source->apiBaseUrl !== 'https://api.playwhatzit.com') {
            throw new PlatformException('The refresh source must be the production catalog service.');
        }
        if ($target->apiBaseUrl !== 'https://api-staging.playwhatzit.com') {
            throw new PlatformException('The refresh target must be the staging catalog service.');
        }
        if ($source->dbName === '' || hash_equals($source->dbName, $target->dbName)) {
            throw new PlatformException('Production and staging must use different databases.');
        }
    }

    public static function catalogsDiffer(array $current, array $target): bool
    {
        return !hash_equals(
            CatalogCodec::encode(self::publishableCatalog($current)),
            CatalogCodec::encode(self::publishableCatalog($target)),
        );
    }

    private static function publishableCatalog(array $catalog): array
    {
        unset($catalog['revision'], $catalog['updatedAt']);
        if (is_array($catalog['decks'] ?? null)) {
            foreach ($catalog['decks'] as &$deck) {
                unset($deck['version'], $deck['cardContentVersion'], $deck['cardCount']);
            }
            unset($deck);
        }
        if (is_array($catalog['bundles'] ?? null)) {
            foreach ($catalog['bundles'] as &$bundle) {
                unset($bundle['version']);
            }
            unset($bundle);
        }
        return $catalog;
    }
}
