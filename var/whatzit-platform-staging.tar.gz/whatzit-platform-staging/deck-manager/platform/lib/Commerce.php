<?php

declare(strict_types=1);

namespace WhatzIt\DeckPlatform;

final class StoreProductIdentity
{
    public const APPLE_NAMESPACE = 'com.cadelawless.whatzit';

    public static function suggestedAppleId(string $targetType, string $targetId): string
    {
        self::assertTarget($targetType, $targetId);
        // App Store Connect's live IAP form rejects hyphens even though the
        // current help page still lists them as supported. Preserve the stable
        // catalog identity while using the character set accepted by the form.
        $storeTargetId = str_replace(['_', '-'], ['__', '_'], $targetId);
        $productId = self::APPLE_NAMESPACE . '.' . $targetType . '.' . $storeTargetId;
        self::assertAppleId($productId);
        return $productId;
    }

    public static function assertAppleId(string $productId): void
    {
        if (
            $productId === ''
            || strlen($productId) > 100
            || preg_match('/^[A-Za-z0-9._]+$/', $productId) !== 1
        ) {
            throw new PlatformException(
                'An Apple product ID must contain at most 100 letters, numbers, periods, or underscores.',
            );
        }
    }

    public static function assertTarget(string $targetType, string $targetId): void
    {
        if (!in_array($targetType, ['deck', 'bundle'], true)) {
            throw new PlatformException('A store product target must be a deck or bundle.');
        }
        if (preg_match('/^[A-Za-z0-9][A-Za-z0-9_-]{0,99}$/', $targetId) !== 1) {
            throw new PlatformException('A store product target must use a valid stable catalog ID.');
        }
    }
}

class CommerceUnauthorized extends PlatformException
{
}

class CommerceConflict extends PlatformException
{
}

class PurchaseRestoreRequired extends CommerceConflict
{
}

class StoreVerificationUnavailable extends PlatformException
{
}

class AppleTransactionNotFound extends CommerceConflict
{
}

final class AppleServerApiClient
{
    private const APPLE_ROOT_SHA256 = [
        'b0b1730ecbc7ff4505142c49f1295e6eda6bcaed7e2c68c5be91b5a11001f024',
        'c2b9b042dd57830e7d117dac55ac8ae19407d38e41d88f3215bc3a890444a050',
        '63343abfb89a6a03ebb57e9b3f5fa7be7c4f5c756f3017b3a8c488c3653e9179',
    ];
    /** @var null|callable(string,string):array{status:int,body:string} */
    private $transport;

    public function __construct(
        private readonly PlatformConfig $config,
        ?callable $transport = null,
    ) {
        $this->transport = $transport;
    }

    /** @return array{environment:string,payload:array<string,mixed>,signedTransaction:string} */
    public function transaction(string $transactionId): array
    {
        if (preg_match('/^[0-9]{1,30}$/', $transactionId) !== 1) {
            throw new CommerceConflict('Apple returned an invalid transaction identifier.');
        }
        $jwt = $this->authorizationToken();
        foreach ([
            'production' => 'https://api.storekit.apple.com',
            'sandbox' => 'https://api.storekit-sandbox.apple.com',
        ] as $environment => $baseUrl) {
            $response = $this->request(
                $baseUrl . '/inApps/v1/transactions/' . rawurlencode($transactionId),
                $jwt,
            );
            if ($response['status'] === 404) {
                $error = self::jsonObject($response['body'], 'Apple transaction error');
                if ((int) ($error['errorCode'] ?? 0) === 4040010) {
                    if ($environment === 'production') continue;
                    throw new AppleTransactionNotFound('Apple could not find this transaction.');
                }
            }
            if ($response['status'] !== 200) {
                throw new StoreVerificationUnavailable(
                    'Apple transaction verification is temporarily unavailable.',
                );
            }
            $body = self::jsonObject($response['body'], 'Apple transaction response');
            $signed = $body['signedTransactionInfo'] ?? null;
            if (!is_string($signed) || strlen($signed) > 32768) {
                throw new StoreVerificationUnavailable('Apple returned an invalid transaction response.');
            }
            $payload = self::decodeJwsPayload($signed);
            if ((string) ($payload['transactionId'] ?? '') !== $transactionId) {
                throw new StoreVerificationUnavailable('Apple returned a mismatched transaction.');
            }
            return [
                'environment' => $environment,
                'payload' => $payload,
                'signedTransaction' => $signed,
            ];
        }
        throw new AppleTransactionNotFound('Apple could not find this transaction.');
    }

    /** @return array{environment:string,payload:array<string,mixed>,signedTransaction:string} */
    public function verifyRecentTransaction(string $clientJws): array
    {
        $payload = self::verifyJwsPayload($clientJws);
        return $this->transactionOrRecentVerifiedPayload($payload, $clientJws);
    }

    /** @return array{environment:string,payload:array<string,mixed>,signedTransaction:string} */
    private function transactionOrRecentVerifiedPayload(array $payload, string $clientJws): array
    {
        $transactionId = (string) ($payload['transactionId'] ?? '');
        try {
            return $this->transaction($transactionId);
        } catch (AppleTransactionNotFound $error) {
            $environment = match (strtolower((string) ($payload['environment'] ?? ''))) {
                'sandbox' => 'sandbox',
                'production' => 'production',
                default => throw new CommerceConflict('The Apple transaction environment is invalid.'),
            };
            $signedDate = $payload['signedDate'] ?? null;
            $maximumAgeSeconds = $this->config->environment === 'test' && $environment === 'sandbox'
                ? 24 * 60 * 60
                : 15 * 60;
            if (!is_numeric($signedDate)
                || abs((time() * 1000) - (int) $signedDate) > $maximumAgeSeconds * 1000) {
                throw $error;
            }
            return [
                'environment' => $environment,
                'payload' => $payload,
                'signedTransaction' => $clientJws,
            ];
        }
    }

    /** @return array<string,mixed> */
    public static function decodeJwsPayload(string $jws): array
    {
        $parts = explode('.', $jws);
        if (count($parts) !== 3) {
            throw new CommerceConflict('The Apple transaction payload is malformed.');
        }
        $json = self::base64UrlDecode($parts[1]);
        return self::jsonObject($json, 'Apple transaction payload');
    }

    /** @return array<string,mixed> */
    public static function verifyJwsPayload(string $jws): array
    {
        $parts = explode('.', $jws);
        if (count($parts) !== 3) {
            throw new CommerceConflict('The Apple transaction payload is malformed.');
        }
        $header = self::jsonObject(self::base64UrlDecode($parts[0]), 'Apple transaction header');
        $payload = self::decodeJwsPayload($jws);
        $chain = $header['x5c'] ?? null;
        if (($header['alg'] ?? null) !== 'ES256' || !is_array($chain) || count($chain) < 3) {
            throw new CommerceConflict('The Apple transaction signature is invalid.');
        }
        $certificates = [];
        $certificateBytes = [];
        foreach ($chain as $encoded) {
            if (!is_string($encoded) || strlen($encoded) > 8192) {
                throw new CommerceConflict('The Apple certificate chain is invalid.');
            }
            $der = base64_decode($encoded, true);
            if (!is_string($der)) throw new CommerceConflict('The Apple certificate chain is invalid.');
            $pem = "-----BEGIN CERTIFICATE-----\n"
                . chunk_split(base64_encode($der), 64, "\n")
                . "-----END CERTIFICATE-----\n";
            if (openssl_x509_read($pem) === false) {
                throw new CommerceConflict('The Apple certificate chain is invalid.');
            }
            $certificates[] = $pem;
            $certificateBytes[] = $der;
        }
        $rootIndex = count($certificates) - 1;
        if (!in_array(hash('sha256', $certificateBytes[$rootIndex]), self::APPLE_ROOT_SHA256, true)) {
            throw new CommerceConflict('The Apple transaction chain has an untrusted root.');
        }
        $verificationTime = isset($payload['signedDate']) && is_numeric($payload['signedDate'])
            ? (int) floor(((int) $payload['signedDate']) / 1000)
            : time();
        foreach ($certificates as $index => $certificate) {
            $details = openssl_x509_parse($certificate);
            if (!is_array($details)
                || $verificationTime < (int) ($details['validFrom_time_t'] ?? PHP_INT_MAX)
                || $verificationTime > (int) ($details['validTo_time_t'] ?? 0)) {
                throw new CommerceConflict('The Apple transaction certificate is not valid at signing time.');
            }
            $issuer = $certificates[min($index + 1, $rootIndex)];
            $issuerKey = openssl_pkey_get_public($issuer);
            if ($issuerKey === false || openssl_x509_verify($certificate, $issuerKey) !== 1) {
                throw new CommerceConflict('The Apple transaction certificate chain is invalid.');
            }
        }
        $leafKey = openssl_pkey_get_public($certificates[0]);
        $signature = self::base64UrlDecode($parts[2]);
        if ($leafKey === false
            || strlen($signature) !== 64
            || openssl_verify(
                $parts[0] . '.' . $parts[1],
                self::joseToDer($signature),
                $leafKey,
                OPENSSL_ALGO_SHA256,
            ) !== 1) {
            throw new CommerceConflict('The Apple transaction signature is invalid.');
        }
        return $payload;
    }

    private function authorizationToken(): string
    {
        $problems = $this->config->commerceProblems();
        if ($problems !== []) {
            throw new StoreVerificationUnavailable(implode(' ', $problems));
        }
        $now = time();
        $header = self::base64UrlEncode((string) json_encode([
            'alg' => 'ES256',
            'kid' => $this->config->appleKeyId,
            'typ' => 'JWT',
        ], JSON_THROW_ON_ERROR | JSON_UNESCAPED_SLASHES));
        $payload = self::base64UrlEncode((string) json_encode([
            'iss' => $this->config->appleIssuerId,
            'iat' => $now,
            'exp' => $now + 300,
            'aud' => 'appstoreconnect-v1',
            'bid' => $this->config->appleBundleId,
        ], JSON_THROW_ON_ERROR | JSON_UNESCAPED_SLASHES));
        $input = $header . '.' . $payload;
        $keyBytes = file_get_contents($this->config->applePrivateKeyPath);
        $key = is_string($keyBytes) ? openssl_pkey_get_private($keyBytes) : false;
        if ($key === false || !openssl_sign($input, $derSignature, $key, OPENSSL_ALGO_SHA256)) {
            throw new StoreVerificationUnavailable('The Apple authorization token could not be signed.');
        }
        return $input . '.' . self::base64UrlEncode(self::derToJose($derSignature));
    }

    /** @return array{status:int,body:string} */
    private function request(string $url, string $jwt): array
    {
        if ($this->transport !== null) {
            return ($this->transport)($url, $jwt);
        }
        $context = stream_context_create(['http' => [
            'method' => 'GET',
            'header' => "Authorization: Bearer $jwt\r\nAccept: application/json\r\n",
            'ignore_errors' => true,
            'timeout' => 15,
        ]]);
        $body = @file_get_contents($url, false, $context);
        $headers = $http_response_header ?? [];
        $status = 0;
        if (isset($headers[0]) && preg_match('/\s(\d{3})\s/', $headers[0], $matches) === 1) {
            $status = (int) $matches[1];
        }
        return ['status' => $status, 'body' => is_string($body) ? $body : ''];
    }

    private static function derToJose(string $der): string
    {
        $offset = 0;
        if (ord($der[$offset++] ?? "\0") !== 0x30) {
            throw new StoreVerificationUnavailable('Apple JWT signing returned an invalid signature.');
        }
        self::readDerLength($der, $offset);
        $r = self::readDerInteger($der, $offset);
        $s = self::readDerInteger($der, $offset);
        return str_pad(ltrim($r, "\0"), 32, "\0", STR_PAD_LEFT)
            . str_pad(ltrim($s, "\0"), 32, "\0", STR_PAD_LEFT);
    }

    private static function joseToDer(string $signature): string
    {
        $encodeInteger = static function (string $value): string {
            $value = ltrim($value, "\0") ?: "\0";
            if ((ord($value[0]) & 0x80) !== 0) $value = "\0" . $value;
            return "\x02" . chr(strlen($value)) . $value;
        };
        $sequence = $encodeInteger(substr($signature, 0, 32))
            . $encodeInteger(substr($signature, 32, 32));
        return "\x30" . chr(strlen($sequence)) . $sequence;
    }

    private static function readDerInteger(string $der, int &$offset): string
    {
        if (ord($der[$offset++] ?? "\0") !== 0x02) {
            throw new StoreVerificationUnavailable('Apple JWT signing returned an invalid integer.');
        }
        $length = self::readDerLength($der, $offset);
        $value = substr($der, $offset, $length);
        $offset += $length;
        if ($value === false || strlen(ltrim($value, "\0")) > 32) {
            throw new StoreVerificationUnavailable('Apple JWT signature is out of range.');
        }
        return $value;
    }

    private static function readDerLength(string $der, int &$offset): int
    {
        $length = ord($der[$offset++] ?? "\0");
        if (($length & 0x80) === 0) return $length;
        $bytes = $length & 0x7f;
        if ($bytes < 1 || $bytes > 2) {
            throw new StoreVerificationUnavailable('Apple JWT signature has an invalid length.');
        }
        $length = 0;
        for ($index = 0; $index < $bytes; $index++) {
            $length = ($length << 8) | ord($der[$offset++] ?? "\0");
        }
        return $length;
    }

    private static function base64UrlEncode(string $value): string
    {
        return rtrim(strtr(base64_encode($value), '+/', '-_'), '=');
    }

    private static function base64UrlDecode(string $value): string
    {
        $decoded = base64_decode(strtr($value, '-_', '+/'), true);
        if (!is_string($decoded)) {
            throw new CommerceConflict('The Apple transaction encoding is invalid.');
        }
        return $decoded;
    }

    /** @return array<string,mixed> */
    private static function jsonObject(string $json, string $label): array
    {
        try {
            $value = json_decode($json, true, 64, JSON_THROW_ON_ERROR);
        } catch (\JsonException $error) {
            throw new CommerceConflict("$label is invalid.", previous: $error);
        }
        if (!is_array($value) || array_is_list($value)) {
            throw new CommerceConflict("$label must be an object.");
        }
        return $value;
    }
}

final class GooglePlayApiClient
{
    private ?string $accessToken = null;

    public function __construct(private readonly PlatformConfig $config)
    {
    }

    /** @return array{environment:string,payload:array<string,mixed>} */
    public function verify(string $packageName, string $productId, string $purchaseToken): array
    {
        if ($packageName !== $this->config->googlePackageName
            || preg_match('/^[a-z0-9][a-z0-9._]{0,39}$/', $productId) !== 1
            || $purchaseToken === '' || strlen($purchaseToken) > 4096) {
            throw new CommerceConflict('The Google Play purchase request is invalid.');
        }
        $url = 'https://androidpublisher.googleapis.com/androidpublisher/v3/applications/'
            . rawurlencode($packageName) . '/purchases/productsv2/tokens/' . rawurlencode($purchaseToken);
        $response = $this->request('GET', $url);
        if ($response['status'] !== 200) {
            throw new StoreVerificationUnavailable('Google Play purchase verification is temporarily unavailable.');
        }
        $payload = self::jsonObject($response['body'], 'Google Play purchase response');
        if (($payload['purchaseStateContext']['purchaseState'] ?? null) !== 'PURCHASED') {
            throw new CommerceConflict('The Google Play purchase is not completed.');
        }
        $lineItems = $payload['productLineItem'] ?? null;
        if (!is_array($lineItems) || !in_array($productId, array_map(
            static fn (mixed $item): mixed => is_array($item) ? ($item['productId'] ?? null) : null,
            $lineItems,
        ), true)) {
            throw new CommerceConflict('The Google Play purchase is for a different product.');
        }
        return [
            'environment' => isset($payload['testPurchaseContext']) ? 'sandbox' : 'production',
            'payload' => $payload,
        ];
    }

    public function acknowledge(string $packageName, string $productId, string $purchaseToken): void
    {
        $url = 'https://androidpublisher.googleapis.com/androidpublisher/v3/applications/'
            . rawurlencode($packageName) . '/purchases/products/' . rawurlencode($productId)
            . '/tokens/' . rawurlencode($purchaseToken) . ':acknowledge';
        $response = $this->request('POST', $url, '{}');
        if ($response['status'] < 200 || $response['status'] >= 300) {
            throw new StoreVerificationUnavailable('Google Play purchase acknowledgement failed.');
        }
    }

    /** @return array{status:int,body:string} */
    private function request(string $method, string $url, ?string $body = null): array
    {
        $headers = "Authorization: Bearer {$this->token()}\r\nAccept: application/json\r\n";
        if ($body !== null) $headers .= "Content-Type: application/json\r\n";
        $context = stream_context_create(['http' => [
            'method' => $method,
            'header' => $headers,
            'content' => $body ?? '',
            'ignore_errors' => true,
            'timeout' => 15,
        ]]);
        $responseBody = @file_get_contents($url, false, $context);
        $responseHeaders = $http_response_header ?? [];
        $status = 0;
        if (isset($responseHeaders[0]) && preg_match('/\s(\d{3})\s/', $responseHeaders[0], $matches) === 1) {
            $status = (int) $matches[1];
        }
        return ['status' => $status, 'body' => is_string($responseBody) ? $responseBody : ''];
    }

    private function token(): string
    {
        if ($this->accessToken !== null) return $this->accessToken;
        $problems = $this->config->googleCommerceProblems();
        if ($problems !== []) throw new StoreVerificationUnavailable(implode(' ', $problems));
        $credentials = self::jsonObject(
            (string) file_get_contents($this->config->googleServiceAccountPath),
            'Google service-account credentials',
        );
        $email = $credentials['client_email'] ?? null;
        $privateKey = $credentials['private_key'] ?? null;
        if (!is_string($email) || !is_string($privateKey)) {
            throw new StoreVerificationUnavailable('Google service-account credentials are incomplete.');
        }
        $now = time();
        $header = self::base64Url((string) json_encode(['alg' => 'RS256', 'typ' => 'JWT'], JSON_THROW_ON_ERROR));
        $claims = self::base64Url((string) json_encode([
            'iss' => $email,
            'scope' => 'https://www.googleapis.com/auth/androidpublisher',
            'aud' => 'https://oauth2.googleapis.com/token',
            'iat' => $now,
            'exp' => $now + 3600,
        ], JSON_THROW_ON_ERROR | JSON_UNESCAPED_SLASHES));
        $input = $header . '.' . $claims;
        $key = openssl_pkey_get_private($privateKey);
        if ($key === false || !openssl_sign($input, $signature, $key, OPENSSL_ALGO_SHA256)) {
            throw new StoreVerificationUnavailable('Google service-account token signing failed.');
        }
        $assertion = $input . '.' . self::base64Url($signature);
        $context = stream_context_create(['http' => [
            'method' => 'POST',
            'header' => "Content-Type: application/x-www-form-urlencoded\r\n",
            'content' => http_build_query([
                'grant_type' => 'urn:ietf:params:oauth:grant-type:jwt-bearer',
                'assertion' => $assertion,
            ]),
            'ignore_errors' => true,
            'timeout' => 15,
        ]]);
        $body = @file_get_contents('https://oauth2.googleapis.com/token', false, $context);
        $payload = self::jsonObject(is_string($body) ? $body : '', 'Google OAuth response');
        $token = $payload['access_token'] ?? null;
        if (!is_string($token) || $token === '') {
            throw new StoreVerificationUnavailable('Google OAuth did not return an access token.');
        }
        return $this->accessToken = $token;
    }

    private static function base64Url(string $value): string
    {
        return rtrim(strtr(base64_encode($value), '+/', '-_'), '=');
    }

    /** @return array<string,mixed> */
    private static function jsonObject(string $json, string $label): array
    {
        try {
            $value = json_decode($json, true, 32, JSON_THROW_ON_ERROR);
        } catch (\JsonException $error) {
            throw new StoreVerificationUnavailable("$label is invalid.", previous: $error);
        }
        if (!is_array($value) || array_is_list($value)) {
            throw new StoreVerificationUnavailable("$label must be an object.");
        }
        return $value;
    }
}

final class PurchaseGrantPolicy
{
    /**
     * @param list<string> $currentBundleDeckIds
     * @param list<string> $existingSnapshotDeckIds
     * @return list<string>
     */
    public static function snapshotDeckIds(
        ?string $directDeckId,
        array $currentBundleDeckIds,
        array $existingSnapshotDeckIds,
    ): array {
        $deckIds = $existingSnapshotDeckIds !== []
            ? $existingSnapshotDeckIds
            : ($directDeckId !== null ? [$directDeckId] : $currentBundleDeckIds);
        return array_values(array_unique(array_map('strval', $deckIds)));
    }
}

final class CommerceService
{
    public function __construct(
        private readonly Database $database,
        private readonly PlatformConfig $config,
        private readonly AppleServerApiClient $apple,
        private readonly GooglePlayApiClient $google,
    ) {
    }

    public function registerInstallation(
        string $installationId,
        string $appAccountToken,
        string $credential,
        string $platform = 'apple',
    ): array
    {
        self::assertUuid($installationId, 'installation ID');
        self::assertUuid($appAccountToken, 'app account token');
        self::assertCredential($credential);
        if (!in_array($platform, ['apple', 'google'], true)) {
            throw new CommerceConflict('The installation platform is invalid.');
        }
        $hash = hash('sha256', $credential);
        $rows = $this->database->rows(
            'SELECT installation_id, app_account_token, credential_hash, status FROM app_installations '
            . 'WHERE installation_id = ? OR app_account_token = ? OR credential_hash = ? FOR UPDATE',
            'sss',
            [$installationId, $appAccountToken, $hash],
        );
        if ($rows === []) {
            $this->database->execute(
                'INSERT INTO app_installations '
                . '(installation_id, platform, app_account_token, credential_hash, status) '
                . "VALUES (?, ?, ?, ?, 'active')",
                'ssss',
                [$installationId, $platform, $appAccountToken, $hash],
            );
        } elseif (count($rows) !== 1
            || (string) $rows[0]['installation_id'] !== $installationId
            || (string) $rows[0]['app_account_token'] !== $appAccountToken
            || !hash_equals((string) $rows[0]['credential_hash'], $hash)) {
            throw new CommerceConflict('The installation identity is already registered differently.');
        } elseif ((string) $rows[0]['status'] !== 'active') {
            throw new CommerceUnauthorized('This installation is disabled.');
        }
        $this->database->execute(
            'UPDATE app_installations SET last_seen_at = CURRENT_TIMESTAMP(6) WHERE installation_id = ?',
            's',
            [$installationId],
        );
        return ['installationId' => $installationId, 'appAccountToken' => $appAccountToken];
    }

    public function authenticate(string $installationId, string $credential): array
    {
        self::assertUuid($installationId, 'installation ID');
        self::assertCredential($credential);
        $rows = $this->database->rows(
            "SELECT installation_id, app_account_token, platform FROM app_installations "
            . "WHERE installation_id = ? AND status = 'active' AND credential_hash = ?",
            'ss',
            [$installationId, hash('sha256', $credential)],
        );
        if ($rows === []) throw new CommerceUnauthorized('Installation authentication failed.');
        $this->database->execute(
            'UPDATE app_installations SET last_seen_at = CURRENT_TIMESTAMP(6) WHERE installation_id = ?',
            's',
            [$installationId],
        );
        return $rows[0];
    }

    public function verifyApple(array $installation, string $clientJws, string $reason): array
    {
        if (($installation['platform'] ?? null) !== 'apple') {
            throw new CommerceConflict('The installation is registered for a different store.');
        }
        if (!in_array($reason, ['purchase', 'restore'], true) || strlen($clientJws) > 32768) {
            throw new CommerceConflict('The purchase verification request is invalid.');
        }
        $verified = $this->apple->verifyRecentTransaction($clientJws);
        $payload = $verified['payload'];
        $transactionId = (string) ($payload['transactionId'] ?? '');
        $productId = (string) ($payload['productId'] ?? '');
        if ((string) ($payload['bundleId'] ?? '') !== $this->config->appleBundleId
            || !in_array((string) ($payload['type'] ?? ''), ['Non-Consumable', 'NON_CONSUMABLE'], true)) {
            throw new CommerceConflict('The Apple transaction is for a different app or product type.');
        }
        if ($reason === 'purchase'
            && strtolower((string) ($payload['appAccountToken'] ?? '')) !== strtolower((string) $installation['app_account_token'])) {
            throw new PurchaseRestoreRequired(
                'This Apple purchase belongs to an earlier installation and must be restored.',
            );
        }
        $products = $this->database->rows(
            'SELECT p.store_product_pk, p.deck_id, p.bundle_id, p.owned_deck_count FROM store_products p '
            . 'LEFT JOIN catalog_store_products c ON c.store_product_pk = p.store_product_pk '
            . 'AND c.catalog_revision = (SELECT revision FROM active_catalog_revision WHERE singleton_id = 1) '
            . "WHERE p.platform = 'apple' AND p.store_product_id = ? "
            . "AND ((p.lifecycle_status = 'active' AND c.availability_status = 'available') "
            . "OR EXISTS (SELECT 1 FROM store_transactions t WHERE t.platform = 'apple' "
            . 'AND t.store_transaction_id = ? AND t.store_product_pk = p.store_product_pk))',
            'ss',
            [$productId, $transactionId],
        );
        if ($products === []) throw new CommerceConflict('The Apple product is not active in this catalog.');
        $product = $products[0];
        $revokedAt = self::millisecondsToMysql($payload['revocationDate'] ?? null);
        $state = $revokedAt === null ? 'verified' : 'revoked';
        $purchasedAt = self::millisecondsToMysql($payload['purchaseDate'] ?? null);
        $originalId = (string) ($payload['originalTransactionId'] ?? $transactionId);
        $installationId = (string) $installation['installation_id'];

        $this->database->begin();
        try {
            $existing = $this->database->rows(
                "SELECT store_transaction_pk, transaction_state FROM store_transactions "
                . "WHERE platform = 'apple' AND store_transaction_id = ? FOR UPDATE",
                's',
                [$transactionId],
            );
            if ($existing === []) {
                $this->assertBundlePurchaseEligibility(
                    $this->purchaseOwnerInstallationId(
                        (string) ($payload['appAccountToken'] ?? ''),
                        $installationId,
                    ),
                    $product,
                );
                $this->database->execute(
                    'INSERT INTO store_transactions '
                    . '(platform, store_product_pk, installation_id, store_transaction_id, '
                    . 'original_store_transaction_id, store_environment, transaction_state, '
                    . 'verification_code, signed_payload_hash, purchased_at, revoked_at) '
                    . "VALUES ('apple', ?, ?, ?, ?, ?, ?, 'apple_server_api', ?, ?, ?)",
                    'issssssss',
                    [(int) $product['store_product_pk'], $installationId, $transactionId, $originalId,
                        $verified['environment'], $state, hash('sha256', $verified['signedTransaction']),
                        $purchasedAt, $revokedAt],
                );
                $transactionPk = (int) $this->database->scalar('SELECT LAST_INSERT_ID()');
            } else {
                $transactionPk = (int) $existing[0]['store_transaction_pk'];
                $this->database->execute(
                    'UPDATE store_transactions SET transaction_state = ?, revoked_at = ?, '
                    . 'verified_at = CURRENT_TIMESTAMP(6), updated_at = CURRENT_TIMESTAMP(6) '
                    . 'WHERE store_transaction_pk = ?',
                    'ssi',
                    [$state, $revokedAt, $transactionPk],
                );
            }
            $this->ensurePurchaseDeckGrants(
                'apple',
                $originalId,
                $transactionPk,
                $product,
            );
            $entitlements = $this->database->rows(
                'SELECT entitlement_id, entitlement_state FROM entitlements '
                . 'WHERE installation_id = ? AND store_product_pk = ? FOR UPDATE',
                'si',
                [$installationId, (int) $product['store_product_pk']],
            );
            $entitlementState = $state === 'verified' ? 'active' : 'revoked';
            if ($entitlements === []) {
                $this->database->execute(
                    'INSERT INTO entitlements '
                    . '(installation_id, store_product_pk, source_transaction_pk, entitlement_state, '
                    . 'grant_reason, revoked_at) VALUES (?, ?, ?, ?, ?, ?)',
                    'siisss',
                    [$installationId, (int) $product['store_product_pk'], $transactionPk,
                        $entitlementState, $reason, $revokedAt],
                );
                $entitlementId = (int) $this->database->scalar('SELECT LAST_INSERT_ID()');
                $this->database->execute(
                    'INSERT INTO entitlement_events '
                    . '(entitlement_id, store_transaction_pk, event_type, reason_code) VALUES (?, ?, ?, ?)',
                    'iiss',
                    [$entitlementId, $transactionPk, $reason === 'restore' ? 'restore' : 'grant', 'apple_verified'],
                );
            } else {
                $entitlementId = (int) $entitlements[0]['entitlement_id'];
                $previousEntitlementState = (string) $entitlements[0]['entitlement_state'];
                $this->database->execute(
                    'UPDATE entitlements SET source_transaction_pk = ?, entitlement_state = ?, '
                    . 'last_verified_at = CURRENT_TIMESTAMP(6), revoked_at = ? WHERE entitlement_id = ?',
                    'issi',
                    [$transactionPk, $entitlementState, $revokedAt, $entitlementId],
                );
                if ($previousEntitlementState !== $entitlementState) {
                    $this->database->execute(
                        'INSERT INTO entitlement_events '
                        . '(entitlement_id, store_transaction_pk, event_type, reason_code) VALUES (?, ?, ?, ?)',
                        'iiss',
                        [$entitlementId, $transactionPk,
                            $entitlementState === 'active'
                                ? ($reason === 'restore' ? 'restore' : 'grant')
                                : 'revoke',
                            'apple_verified'],
                    );
                }
            }
            $this->database->commit();
        } catch (\Throwable $error) {
            $this->database->rollback();
            throw $error;
        }
        return $this->entitlements($installationId);
    }

    public function verifyGoogle(
        array $installation,
        string $packageName,
        string $productId,
        string $purchaseToken,
        string $reason,
    ): array {
        if (($installation['platform'] ?? null) !== 'google') {
            throw new CommerceConflict('The installation is registered for a different store.');
        }
        if (!in_array($reason, ['purchase', 'restore'], true)) {
            throw new CommerceConflict('The purchase verification request is invalid.');
        }
        $verified = $this->google->verify($packageName, $productId, $purchaseToken);
        $payload = $verified['payload'];
        $accountId = (string) ($payload['obfuscatedExternalAccountId'] ?? '');
        if ($reason === 'purchase'
            && strtolower($accountId) !== strtolower((string) $installation['app_account_token'])) {
            throw new PurchaseRestoreRequired(
                'This Google Play purchase belongs to an earlier installation and must be restored.',
            );
        }
        $tokenHash = hash('sha256', $purchaseToken);
        $products = $this->database->rows(
            'SELECT p.store_product_pk, p.deck_id, p.bundle_id, p.owned_deck_count FROM store_products p '
            . 'LEFT JOIN catalog_store_products c ON c.store_product_pk = p.store_product_pk '
            . 'AND c.catalog_revision = (SELECT revision FROM active_catalog_revision WHERE singleton_id = 1) '
            . "WHERE p.platform = 'google' AND p.store_product_id = ? "
            . "AND ((p.lifecycle_status = 'active' AND c.availability_status = 'available') "
            . "OR EXISTS (SELECT 1 FROM store_transactions t WHERE t.platform = 'google' "
            . 'AND t.purchase_token_hash = ? AND t.store_product_pk = p.store_product_pk))',
            'ss',
            [$productId, $tokenHash],
        );
        if ($products === []) throw new CommerceConflict('The Google Play product is not active in this catalog.');
        $product = $products[0];
        $installationId = (string) $installation['installation_id'];
        $purchasedAt = self::rfc3339ToMysql($payload['purchaseCompletionTime'] ?? null);

        $this->database->begin();
        try {
            $existing = $this->database->rows(
                "SELECT store_transaction_pk FROM store_transactions "
                . "WHERE platform = 'google' AND purchase_token_hash = ? FOR UPDATE",
                's',
                [$tokenHash],
            );
            if ($existing === []) {
                $this->assertBundlePurchaseEligibility(
                    $this->purchaseOwnerInstallationId($accountId, $installationId),
                    $product,
                );
                $this->database->execute(
                    'INSERT INTO store_transactions '
                    . '(platform, store_product_pk, installation_id, store_transaction_id, '
                    . 'original_store_transaction_id, purchase_token_hash, store_environment, '
                    . 'transaction_state, verification_code, purchased_at) '
                    . "VALUES ('google', ?, ?, NULL, ?, ?, ?, 'verified', 'google_play_api', ?)",
                    'isssss',
                    [(int) $product['store_product_pk'], $installationId, $tokenHash, $tokenHash,
                        $verified['environment'], $purchasedAt],
                );
                $transactionPk = (int) $this->database->scalar('SELECT LAST_INSERT_ID()');
            } else {
                $transactionPk = (int) $existing[0]['store_transaction_pk'];
                $this->database->execute(
                    "UPDATE store_transactions SET transaction_state = 'verified', "
                    . 'verified_at = CURRENT_TIMESTAMP(6), updated_at = CURRENT_TIMESTAMP(6) '
                    . 'WHERE store_transaction_pk = ?',
                    'i',
                    [$transactionPk],
                );
            }
            $this->ensurePurchaseDeckGrants('google', $tokenHash, $transactionPk, $product);
            $entitlements = $this->database->rows(
                'SELECT entitlement_id, entitlement_state FROM entitlements '
                . 'WHERE installation_id = ? AND store_product_pk = ? FOR UPDATE',
                'si',
                [$installationId, (int) $product['store_product_pk']],
            );
            if ($entitlements === []) {
                $this->database->execute(
                    'INSERT INTO entitlements '
                    . '(installation_id, store_product_pk, source_transaction_pk, entitlement_state, grant_reason) '
                    . "VALUES (?, ?, ?, 'active', ?)",
                    'siis',
                    [$installationId, (int) $product['store_product_pk'], $transactionPk, $reason],
                );
                $entitlementId = (int) $this->database->scalar('SELECT LAST_INSERT_ID()');
                $this->database->execute(
                    'INSERT INTO entitlement_events '
                    . '(entitlement_id, store_transaction_pk, event_type, reason_code) VALUES (?, ?, ?, ?)',
                    'iiss',
                    [$entitlementId, $transactionPk, $reason === 'restore' ? 'restore' : 'grant', 'google_verified'],
                );
            } else {
                $entitlementId = (int) $entitlements[0]['entitlement_id'];
                $wasActive = (string) $entitlements[0]['entitlement_state'] === 'active';
                $this->database->execute(
                    "UPDATE entitlements SET source_transaction_pk = ?, entitlement_state = 'active', "
                    . 'last_verified_at = CURRENT_TIMESTAMP(6), revoked_at = NULL WHERE entitlement_id = ?',
                    'ii',
                    [$transactionPk, $entitlementId],
                );
                if (!$wasActive) {
                    $this->database->execute(
                        'INSERT INTO entitlement_events '
                        . '(entitlement_id, store_transaction_pk, event_type, reason_code) VALUES (?, ?, ?, ?)',
                        'iiss',
                        [$entitlementId, $transactionPk, $reason === 'restore' ? 'restore' : 'grant', 'google_verified'],
                    );
                }
            }
            $this->database->commit();
        } catch (\Throwable $error) {
            $this->database->rollback();
            throw $error;
        }

        if (($payload['acknowledgementState'] ?? null) !== 'ACKNOWLEDGEMENT_STATE_ACKNOWLEDGED') {
            $this->google->acknowledge($packageName, $productId, $purchaseToken);
        }
        return $this->entitlements($installationId);
    }

    public function entitlements(string $installationId): array
    {
        $rows = $this->database->rows(
            "SELECT p.store_product_id, p.deck_id, p.bundle_id, e.grant_reason "
            . 'FROM entitlements e INNER JOIN store_products p ON p.store_product_pk = e.store_product_pk '
            . "WHERE e.installation_id = ? AND e.entitlement_state = 'active' "
            . 'ORDER BY p.store_product_id',
            's',
            [$installationId],
        );
        $products = [];
        foreach ($rows as $row) {
            $products[] = [
                'productId' => (string) $row['store_product_id'],
                'kind' => $row['deck_id'] !== null ? 'deck' : 'bundle',
                'targetId' => (string) ($row['deck_id'] ?? $row['bundle_id']),
            ];
        }
        $deckIds = array_map(
            static fn (array $row): string => (string) $row['deck_id'],
            $this->database->rows(
                'SELECT DISTINCT g.deck_id FROM entitlements e '
                . 'INNER JOIN store_transactions t ON t.store_transaction_pk = e.source_transaction_pk '
                . 'INNER JOIN purchase_deck_grants g ON g.platform = t.platform '
                . 'AND g.original_store_transaction_id = t.original_store_transaction_id '
                . "WHERE e.installation_id = ? AND e.entitlement_state = 'active' ORDER BY g.deck_id",
                's',
                [$installationId],
            ),
        );
        return [
            'installationId' => $installationId,
            'products' => $products,
            'deckIds' => $deckIds,
            'verifiedAt' => gmdate('Y-m-d\\TH:i:s\\Z'),
        ];
    }

    /** @return array<string,mixed> */
    public function resetSandboxEntitlements(string $installationId): array
    {
        if ($this->config->environment !== 'test') {
            throw new CommerceConflict('Sandbox purchase reset is unavailable in this environment.');
        }

        $this->database->begin();
        try {
            $entitlements = $this->database->rows(
                "SELECT e.entitlement_id, e.source_transaction_pk "
                . 'FROM entitlements e INNER JOIN store_transactions t '
                . 'ON t.store_transaction_pk = e.source_transaction_pk '
                . "WHERE e.installation_id = ? AND e.entitlement_state = 'active' "
                . "AND t.store_environment = 'sandbox' FOR UPDATE",
                's',
                [$installationId],
            );
            foreach ($entitlements as $entitlement) {
                $this->database->execute(
                    "UPDATE entitlements SET entitlement_state = 'revoked', "
                    . 'last_verified_at = CURRENT_TIMESTAMP(6), revoked_at = CURRENT_TIMESTAMP(6) '
                    . 'WHERE entitlement_id = ?',
                    'i',
                    [(int) $entitlement['entitlement_id']],
                );
                $this->database->execute(
                    'INSERT INTO entitlement_events '
                    . '(entitlement_id, store_transaction_pk, event_type, reason_code) '
                    . "VALUES (?, ?, 'revoke', 'sandbox_test_reset')",
                    'ii',
                    [(int) $entitlement['entitlement_id'], (int) $entitlement['source_transaction_pk']],
                );
            }
            $this->database->commit();
        } catch (\Throwable $error) {
            $this->database->rollback();
            throw $error;
        }

        return [
            'installationId' => $installationId,
            'revokedEntitlementCount' => count($entitlements),
            'resetAt' => gmdate('Y-m-d\\TH:i:s\\Z'),
        ];
    }

    public function canAccessDeck(string $installationId, string $deckId): bool
    {
        return (int) $this->database->scalar(
            "SELECT COUNT(*) FROM entitlements e "
            . 'INNER JOIN store_transactions t ON t.store_transaction_pk = e.source_transaction_pk '
            . 'INNER JOIN purchase_deck_grants g ON g.platform = t.platform '
            . 'AND g.original_store_transaction_id = t.original_store_transaction_id '
            . "WHERE e.installation_id = ? AND e.entitlement_state = 'active' "
            . 'AND g.deck_id = ?',
            'ss',
            [$installationId, $deckId],
        ) > 0;
    }

    /** @param array{deck_id:mixed,bundle_id:mixed,owned_deck_count:mixed} $product */
    private function assertBundlePurchaseEligibility(string $installationId, array $product): void
    {
        if ($product['bundle_id'] === null) return;

        $this->database->rows(
            'SELECT installation_id FROM app_installations WHERE installation_id = ? FOR UPDATE',
            's',
            [$installationId],
        );
        $activeRevision = (int) $this->database->scalar(
            'SELECT revision FROM active_catalog_revision WHERE singleton_id = 1',
        );
        $bundleId = (string) $product['bundle_id'];
        $totalDeckCount = (int) $this->database->scalar(
            'SELECT COUNT(*) FROM bundle_decks WHERE catalog_revision = ? AND bundle_id = ?',
            'is',
            [$activeRevision, $bundleId],
        );
        $ownedDeckCount = (int) $this->database->scalar(
            'SELECT COUNT(DISTINCT bd.deck_id) FROM bundle_decks bd '
            . 'INNER JOIN purchase_deck_grants g ON g.deck_id = bd.deck_id '
            . 'INNER JOIN store_transactions t ON t.platform = g.platform '
            . 'AND t.original_store_transaction_id = g.original_store_transaction_id '
            . 'INNER JOIN entitlements e ON e.source_transaction_pk = t.store_transaction_pk '
            . 'WHERE bd.catalog_revision = ? AND bd.bundle_id = ? '
            . "AND e.installation_id = ? AND e.entitlement_state = 'active'",
            'iss',
            [$activeRevision, $bundleId, $installationId],
        );
        if ($totalDeckCount === 0 || $ownedDeckCount >= $totalDeckCount) {
            throw new CommerceConflict('This bundle has no remaining decks to purchase.');
        }
        if ($product['owned_deck_count'] !== null
            && $ownedDeckCount !== (int) $product['owned_deck_count']) {
            throw new CommerceConflict('This discounted bundle product is not eligible for this installation.');
        }
    }

    private function purchaseOwnerInstallationId(
        string $storeAccountToken,
        string $fallbackInstallationId,
    ): string {
        if ($storeAccountToken === '') return $fallbackInstallationId;
        $rows = $this->database->rows(
            "SELECT installation_id FROM app_installations WHERE app_account_token = ? AND status = 'active' FOR UPDATE",
            's',
            [strtolower($storeAccountToken)],
        );
        if ($rows === []) {
            throw new CommerceConflict('The purchase owner could not be verified for bundle discount eligibility.');
        }
        return (string) $rows[0]['installation_id'];
    }

    /** @param array{deck_id:mixed,bundle_id:mixed,owned_deck_count?:mixed} $product */
    private function ensurePurchaseDeckGrants(
        string $platform,
        string $originalTransactionId,
        int $transactionPk,
        array $product,
    ): void {
        $existingDeckIds = array_map(
            static fn (array $row): string => (string) $row['deck_id'],
            $this->database->rows(
                'SELECT deck_id FROM purchase_deck_grants '
                . 'WHERE platform = ? AND original_store_transaction_id = ?',
                'ss',
                [$platform, $originalTransactionId],
            ),
        );

        if ($product['deck_id'] !== null) {
            $currentDeckIds = [];
        } else {
            $activeRevision = (int) $this->database->scalar(
                'SELECT revision FROM active_catalog_revision WHERE singleton_id = 1',
            );
            $currentDeckIds = array_map(
                static fn (array $row): string => (string) $row['deck_id'],
                $this->database->rows(
                    'SELECT deck_id FROM bundle_decks '
                    . 'WHERE catalog_revision = ? AND bundle_id = ? ORDER BY position',
                    'is',
                    [$activeRevision, (string) $product['bundle_id']],
                ),
            );
        }
        $deckIds = PurchaseGrantPolicy::snapshotDeckIds(
            $product['deck_id'] !== null ? (string) $product['deck_id'] : null,
            $currentDeckIds,
            $existingDeckIds,
        );
        if ($existingDeckIds !== []) return;
        foreach ($deckIds as $deckId) {
            $this->database->execute(
                'INSERT IGNORE INTO purchase_deck_grants '
                . '(platform, original_store_transaction_id, deck_id, source_transaction_pk) '
                . 'VALUES (?, ?, ?, ?)',
                'sssi',
                [$platform, $originalTransactionId, $deckId, $transactionPk],
            );
        }
    }

    private static function assertUuid(string $value, string $label): void
    {
        if (preg_match('/^[a-f0-9]{8}-[a-f0-9]{4}-4[a-f0-9]{3}-[89ab][a-f0-9]{3}-[a-f0-9]{12}$/i', $value) !== 1) {
            throw new CommerceConflict("The $label must be a version-4 UUID.");
        }
    }

    private static function assertCredential(string $credential): void
    {
        if (preg_match('/^[a-f0-9]{64}$/', $credential) !== 1) {
            throw new CommerceUnauthorized('The installation credential is invalid.');
        }
    }

    private static function millisecondsToMysql(mixed $value): ?string
    {
        if ($value === null) return null;
        if (!is_int($value) && !(is_string($value) && ctype_digit($value))) {
            throw new CommerceConflict('Apple returned an invalid transaction timestamp.');
        }
        return gmdate('Y-m-d H:i:s', (int) floor(((int) $value) / 1000));
    }

    private static function rfc3339ToMysql(mixed $value): ?string
    {
        if (!is_string($value) || $value === '') return null;
        try {
            return (new \DateTimeImmutable($value))
                ->setTimezone(new \DateTimeZone('UTC'))
                ->format('Y-m-d H:i:s');
        } catch (\Exception $error) {
            throw new CommerceConflict('Google Play returned an invalid purchase timestamp.', previous: $error);
        }
    }
}
