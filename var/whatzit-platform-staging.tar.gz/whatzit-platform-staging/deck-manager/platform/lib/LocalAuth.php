<?php

declare(strict_types=1);

namespace WhatzIt\DeckPlatform;

use WhatzIt\DeckManager\ApiException;

final class LocalAdminAuth
{
    private const WINDOW_MINUTES = 15;
    private const USER_FAILURE_LIMIT = 5;
    private const NETWORK_FAILURE_LIMIT = 10;

    public function __construct(
        private readonly Database $database,
        private readonly string $rateLimitSecret,
    ) {
        if (strlen($rateLimitSecret) < 32) {
            throw new PlatformException('The local authentication secret must contain at least 32 characters.');
        }
    }

    public static function normalizeUsername(string $username): string
    {
        $normalized = strtolower(trim($username));
        if (preg_match('/^[a-z0-9][a-z0-9._-]{2,63}$/', $normalized) !== 1) {
            throw new ApiException('Username must contain 3–64 letters, numbers, periods, underscores, or hyphens.');
        }
        return $normalized;
    }

    public static function validatePassword(string $password): void
    {
        $length = strlen($password);
        if ($length < 12 || $length > 128) {
            throw new ApiException('Password must contain between 12 and 128 characters.');
        }
    }

    public function setAdmin(string $username, string $password): string
    {
        $username = self::normalizeUsername($username);
        self::validatePassword($password);
        $hash = password_hash($password, PASSWORD_DEFAULT);
        if (!is_string($hash)) {
            throw new PlatformException('The administrator password could not be hashed.');
        }
        $this->database->execute(
            'INSERT INTO admin_users (admin_id, username, password_hash, enabled) VALUES (1, ?, ?, 1) '
            . 'ON DUPLICATE KEY UPDATE username = VALUES(username), password_hash = VALUES(password_hash), '
            . 'enabled = 1, password_changed_at = CURRENT_TIMESTAMP(6)',
            'ss',
            [$username, $hash],
        );
        return $username;
    }

    public function authenticate(string $username, string $password, string $network): string
    {
        $candidate = strtolower(trim($username));
        $usernameHash = $this->identifierHash('username', $candidate);
        $networkHash = $this->identifierHash('network', $network);
        if ($this->failureCount('username_hash', $usernameHash) >= self::USER_FAILURE_LIMIT
            || $this->failureCount('network_hash', $networkHash) >= self::NETWORK_FAILURE_LIMIT) {
            throw new ApiException('Too many sign-in attempts. Wait 15 minutes and try again.', 429);
        }

        $rows = $this->database->rows(
            'SELECT username, password_hash, enabled FROM admin_users WHERE admin_id = 1 LIMIT 1',
        );
        $admin = $rows[0] ?? null;
        $storedHash = is_array($admin) ? (string) ($admin['password_hash'] ?? '') : '';
        $dummyHash = '$2y$10$wJfZLhJbVXnL/gFKRvjYB.NjJH0JqTYKO4jGehcYLsVwXETTwOS5K';
        $verified = password_verify($password, $storedHash !== '' ? $storedHash : $dummyHash);
        $storedUsername = is_array($admin) ? (string) ($admin['username'] ?? '') : '';
        $accepted = $verified
            && (int) ($admin['enabled'] ?? 0) === 1
            && $storedUsername !== ''
            && hash_equals($storedUsername, $candidate);

        $this->database->execute(
            'INSERT INTO admin_login_attempts (username_hash, network_hash, succeeded) VALUES (?, ?, ?)',
            'ssi',
            [$usernameHash, $networkHash, $accepted ? 1 : 0],
        );
        $this->database->execute(
            'DELETE FROM admin_login_attempts WHERE attempted_at < UTC_TIMESTAMP(6) - INTERVAL 1 DAY',
        );
        if (!$accepted) {
            throw new ApiException('The username or password is incorrect.', 401);
        }
        $this->database->execute(
            'DELETE FROM admin_login_attempts WHERE succeeded = 0 AND (username_hash = ? OR network_hash = ?)',
            'ss',
            [$usernameHash, $networkHash],
        );
        if (password_needs_rehash($storedHash, PASSWORD_DEFAULT)) {
            $replacement = password_hash($password, PASSWORD_DEFAULT);
            if (is_string($replacement)) {
                $this->database->execute(
                    'UPDATE admin_users SET password_hash = ?, password_changed_at = CURRENT_TIMESTAMP(6) WHERE admin_id = 1',
                    's',
                    [$replacement],
                );
            }
        }
        return $storedUsername;
    }

    private function failureCount(string $column, string $hash): int
    {
        return (int) $this->database->scalar(
            "SELECT COUNT(*) FROM admin_login_attempts WHERE $column = ? AND succeeded = 0 "
            . 'AND attempted_at >= UTC_TIMESTAMP(6) - INTERVAL ' . self::WINDOW_MINUTES . ' MINUTE',
            's',
            [$hash],
        );
    }

    private function identifierHash(string $scope, string $value): string
    {
        return hash_hmac('sha256', $scope . "\0" . $value, $this->rateLimitSecret);
    }
}
