<?php

declare(strict_types=1);

$favicon = dirname(__DIR__, 2)
    . DIRECTORY_SEPARATOR . 'assets'
    . DIRECTORY_SEPARATOR . 'favicon.png';

if (!is_file($favicon) || !is_readable($favicon)) {
    http_response_code(404);
    exit;
}

$size = filesize($favicon);
$modified = filemtime($favicon);

header('Content-Type: image/png');
header('X-Content-Type-Options: nosniff');
header('Cache-Control: public, max-age=31536000, immutable');
if ($size !== false) {
    header('Content-Length: ' . $size);
}
if ($modified !== false) {
    header('Last-Modified: ' . gmdate('D, d M Y H:i:s', $modified) . ' GMT');
}

readfile($favicon);
