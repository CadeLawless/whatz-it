<?php

declare(strict_types=1);

use WhatzIt\DeckManager\ApiException;
use WhatzIt\DeckManager\Config;
use WhatzIt\DeckManager\DeckRepository;
use WhatzIt\DeckManager\GitHubClient;
use WhatzIt\DeckPlatform\DatabaseDeckManager;
use WhatzIt\DeckPlatform\LocalAdminAuth;
use WhatzIt\DeckPlatform\PlatformConfig;
use WhatzIt\DeckPlatform\PlatformException;
use WhatzIt\DeckPlatform\PublicationConflict;

require dirname(__DIR__) . '/lib/GitHubDeckManager.php';
require dirname(__DIR__) . '/platform/lib/PlatformCatalog.php';
require dirname(__DIR__) . '/platform/lib/AppleCatalog.php';
require dirname(__DIR__) . '/platform/lib/Publication.php';
require dirname(__DIR__) . '/platform/lib/MediaPublication.php';
require dirname(__DIR__) . '/platform/lib/DatabaseDeckManager.php';
require dirname(__DIR__) . '/platform/lib/LocalAuth.php';
require dirname(__DIR__) . '/platform/lib/DevPreview.php';

ini_set('session.use_strict_mode', '1');
ini_set('session.use_only_cookies', '1');
session_name('whatzit_deck_manager');
session_set_cookie_params([
    'httponly' => true,
    'secure' => (!empty($_SERVER['HTTPS']) && $_SERVER['HTTPS'] !== 'off'),
    'samesite' => 'Lax',
    'path' => '/',
]);
session_start();

header('Cache-Control: no-store');
header('X-Content-Type-Options: nosniff');
header('Referrer-Policy: no-referrer');

$action = (string) ($_GET['action'] ?? '');
$config = new Config();

try {
    if ($action === 'session') {
        $authenticated = isset($_SESSION['admin_login'])
            && (int) ($_SESSION['authenticated_at'] ?? 0) >= time() - 12 * 60 * 60;
        if (!$authenticated) {
            clearAuthenticationSession();
            if ($config->authBackend === 'local' && !isset($_SESSION['login_csrf_token'])) {
                $_SESSION['login_csrf_token'] = bin2hex(random_bytes(32));
            }
        }
        $problems = $config->problems();
        $developmentPreviewConfigured = false;
        if ($config->storageBackend === 'database') {
            try {
                $platformConfig = new PlatformConfig();
                $problems = array_merge(
                    $problems,
                    $platformConfig->problems(database: true, artifacts: true, mediaRoot: true),
                );
                $developmentPreviewConfigured = preg_match(
                    '/^[a-f0-9]{64}$/',
                    $platformConfig->devPreviewKey,
                ) === 1;
            } catch (Throwable) {
                $problems[] = 'The database platform configuration could not be loaded.';
            }
        }
        respondJson([
            'ok' => true,
            'configured' => $problems === [],
            'configurationProblems' => $problems,
            'authenticated' => $authenticated,
            'user' => $authenticated ? [
                'login' => $_SESSION['admin_login'],
                'avatarUrl' => $_SESSION['admin_avatar'] ?? '',
            ] : null,
            'csrfToken' => $authenticated
                ? ($_SESSION['csrf_token'] ?? null)
                : ($_SESSION['login_csrf_token'] ?? null),
            'authBackend' => $config->authBackend,
            'loginUrl' => $config->authBackend === 'github' ? 'api.php?action=login' : null,
            'repository' => Config::OWNER . '/' . Config::REPOSITORY,
            'storageBackend' => $config->storageBackend,
            'developmentPreviewConfigured' => $developmentPreviewConfigured,
        ]);
    }

    $config->assertReady();

    if ($action === 'login') {
        if ($config->authBackend !== 'github') {
            throw new ApiException('GitHub sign-in is not enabled for this Deck Manager.', 404);
        }
        $state = bin2hex(random_bytes(24));
        $_SESSION['oauth_state'] = $state;
        $_SESSION['oauth_started'] = time();
        $query = http_build_query([
            'client_id' => $config->clientId,
            'redirect_uri' => $config->callbackUrl(),
            'state' => $state,
        ], '', '&', PHP_QUERY_RFC3986);
        header('Location: https://github.com/login/oauth/authorize?' . $query, true, 302);
        exit;
    }

    if ($action === 'callback') {
        if ($config->authBackend !== 'github') {
            throw new ApiException('GitHub sign-in is not enabled for this Deck Manager.', 404);
        }
        $state = (string) ($_GET['state'] ?? '');
        $code = (string) ($_GET['code'] ?? '');
        $expected = (string) ($_SESSION['oauth_state'] ?? '');
        $started = (int) ($_SESSION['oauth_started'] ?? 0);
        unset($_SESSION['oauth_state'], $_SESSION['oauth_started']);
        if ($state === '' || $expected === '' || !hash_equals($expected, $state) || $code === '' || time() - $started > 600) {
            throw new ApiException('The GitHub sign-in request expired or could not be verified.', 401);
        }
        $github = new GitHubClient($config);
        $user = $github->authenticatedUser($github->exchangeOAuthCode($code));
        $login = strtolower((string) ($user['login'] ?? ''));
        if ($login === '' || !in_array($login, $config->adminLogins, true)) {
            session_regenerate_id(true);
            $_SESSION = [];
            throw new ApiException('This GitHub account is not authorized to use Deck Manager.', 403);
        }
        session_regenerate_id(true);
        clearAuthenticationSession();
        $_SESSION['admin_login'] = (string) $user['login'];
        $_SESSION['admin_avatar'] = (string) ($user['avatar_url'] ?? '');
        $_SESSION['auth_method'] = 'github';
        $_SESSION['authenticated_at'] = time();
        $_SESSION['csrf_token'] = bin2hex(random_bytes(32));
        header('Location: ' . $config->baseUrl . '/decks', true, 302);
        exit;
    }

    if ($action === 'local_login' && $_SERVER['REQUEST_METHOD'] === 'POST') {
        if ($config->authBackend !== 'local' || $config->storageBackend !== 'database') {
            throw new ApiException('Local administrator sign-in is not enabled.', 404);
        }
        requireLoginCsrf();
        $payload = requestPayload();
        $platformConfig = new PlatformConfig();
        $platformConfig->assertReady(database: true, artifacts: true, mediaRoot: true);
        $auth = new LocalAdminAuth(
            new \WhatzIt\DeckPlatform\Database($platformConfig),
            $config->authRateLimitSecret,
        );
        $administrator = $auth->authenticate(
            is_scalar($payload['username'] ?? null) ? (string) $payload['username'] : '',
            is_scalar($payload['password'] ?? null) ? (string) $payload['password'] : '',
            (string) ($_SERVER['REMOTE_ADDR'] ?? 'unknown'),
        );
        session_regenerate_id(true);
        clearAuthenticationSession();
        $_SESSION['admin_login'] = $administrator;
        $_SESSION['admin_avatar'] = '';
        $_SESSION['auth_method'] = 'local';
        $_SESSION['authenticated_at'] = time();
        $_SESSION['csrf_token'] = bin2hex(random_bytes(32));
        respondJson(['ok' => true]);
    }

    requireAdmin();
    if ($action === 'logout' && $_SERVER['REQUEST_METHOD'] === 'POST') {
        requireCsrf();
        $_SESSION = [];
        if (ini_get('session.use_cookies')) {
            $parameters = session_get_cookie_params();
            setcookie(session_name(), '', time() - 42000, $parameters['path'], '', $parameters['secure'], $parameters['httponly']);
        }
        session_destroy();
        respondJson(['ok' => true]);
    }

    if ($action === 'stage_upload' && $_SERVER['REQUEST_METHOD'] === 'POST') {
        requireCsrf();
        $repository = new DeckRepository($config, new GitHubClient($config), 'local-image-conversion');
        respondJson([
            'ok' => true,
            'staged' => $repository->stageUpload(
                $_FILES['image'] ?? null,
                (string) ($_POST['filename'] ?? ''),
            ),
        ]);
    }

    if ($config->storageBackend === 'database') {
        $platformConfig = new PlatformConfig();
        $platformConfig->assertReady(database: true, artifacts: true, mediaRoot: true);
        $manager = new DatabaseDeckManager(
            new \WhatzIt\DeckPlatform\Database($platformConfig),
            $platformConfig,
        );
        $administrator = (string) $_SESSION['admin_login'];
        session_write_close();

        if ($action === 'state' && $_SERVER['REQUEST_METHOD'] === 'GET') {
            respondJson(['ok' => true, 'state' => $manager->loadState($administrator)]);
        }
        if ($action === 'database_image' && $_SERVER['REQUEST_METHOD'] === 'GET') {
            $image = $manager->image(
                (string) ($_GET['type'] ?? ''),
                (string) ($_GET['hash'] ?? ''),
            );
            header('Content-Type: ' . $image['mime']);
            header('Content-Length: ' . strlen($image['body']));
            header('ETag: "' . $image['etag'] . '"');
            header("Content-Security-Policy: default-src 'none'");
            header('Cache-Control: private, max-age=31536000, immutable');
            echo $image['body'];
            exit;
        }
        if ($action === 'save_draft' && $_SERVER['REQUEST_METHOD'] === 'POST') {
            requireCsrf();
            respondJson(['ok' => true, 'snapshot' => $manager->saveDraft(requestPayload(), $administrator)]);
        }
        if ($action === 'discard_draft' && $_SERVER['REQUEST_METHOD'] === 'POST') {
            requireCsrf();
            respondJson(['ok' => true, 'state' => $manager->discardDraft(requestPayload(), $administrator)]);
        }
        if ($action === 'validate_draft' && $_SERVER['REQUEST_METHOD'] === 'POST') {
            requireCsrf();
            respondJson(['ok' => true, ...$manager->validateDraft(requestPayload())]);
        }
        if ($action === 'history' && $_SERVER['REQUEST_METHOD'] === 'GET') {
            respondJson(['ok' => true, 'history' => $manager->history()]);
        }
        if ($action === 'export' && $_SERVER['REQUEST_METHOD'] === 'GET') {
            $revision = isset($_GET['revision']) ? positiveInteger($_GET['revision'], 'revision') : null;
            respondJson(['ok' => true, 'catalog' => $manager->export($revision)]);
        }
        if ($action === 'rollback' && $_SERVER['REQUEST_METHOD'] === 'POST') {
            requireCsrf();
            $payload = requestPayload();
            if (($payload['confirm'] ?? false) !== true) {
                throw new ApiException('Rollback confirmation is required.');
            }
            $result = $manager->rollback(
                positiveInteger($payload['revision'] ?? null, 'revision'),
                $administrator,
                is_array($payload['baseSnapshot'] ?? null) ? $payload['baseSnapshot'] : null,
            );
            respondJson([
                'ok' => true,
                'message' => 'The historical catalog was restored as a new database revision.',
                'result' => $result,
                'state' => $manager->loadState($administrator),
            ]);
        }
        if ($action === 'publish' && $_SERVER['REQUEST_METHOD'] === 'POST') {
            requireCsrf();
            $payload = requestPayload();
            if (($payload['confirm'] ?? false) !== true) {
                throw new ApiException('Publish confirmation is required.');
            }
            $result = $manager->publish($payload, $_FILES, $administrator);
            $message = ($result['devPreviewUpdated'] ?? false) === true
                ? 'Changes were published atomically and Dev Preview was updated automatically.'
                : (($result['devPreviewErrorCode'] ?? null) === 'refresh_failed'
                    ? 'Changes were published atomically, but Dev Preview needs to be updated again.'
                    : 'Changes were published atomically to the catalog database.');
            respondJson([
                'ok' => true,
                'message' => $message,
                'result' => $result,
                'state' => $manager->loadState($administrator),
            ]);
        }
        if ($action === 'publish_preview' && $_SERVER['REQUEST_METHOD'] === 'POST') {
            requireCsrf();
            $payload = requestPayload();
            $result = $manager->updateDevPreview($payload, $_FILES, $administrator);
            respondJson([
                'ok' => true,
                'message' => 'The saved draft is now available in Expo development.',
                'result' => $result,
            ]);
        }

        throw new ApiException('Unknown database Deck Manager action.', 404);
    }

    $github = new GitHubClient($config);
    $installationToken = (string) ($_SESSION['github_installation_token'] ?? '');
    $installationTokenExpires = (int) ($_SESSION['github_installation_token_expires'] ?? 0);
    if ($installationToken === '' || $installationTokenExpires < time() + 300) {
        $installationToken = $github->installationToken();
        $_SESSION['github_installation_token'] = $installationToken;
        $_SESSION['github_installation_token_expires'] = time() + 55 * 60;
    }
    $repository = new DeckRepository($config, $github, $installationToken);
    // GitHub image requests arrive in parallel. Release PHP's per-session file
    // lock before network I/O so one thumbnail cannot block the rest.
    session_write_close();

    if ($action === 'state' && $_SERVER['REQUEST_METHOD'] === 'GET') {
        respondJson(['ok' => true, 'state' => $repository->loadState()]);
    }

    if ($action === 'image' && $_SERVER['REQUEST_METHOD'] === 'GET') {
        $image = $repository->image(
            (string) ($_GET['path'] ?? ''),
            (string) ($_GET['blob'] ?? ''),
            (string) ($_GET['sig'] ?? ''),
        );
        header('Content-Type: ' . $image['mime']);
        header('Content-Length: ' . strlen($image['body']));
        header('ETag: "' . $image['etag'] . '"');
        header('Content-Security-Policy: default-src \'none\'');
        header('Cache-Control: private, max-age=31536000, immutable');
        echo $image['body'];
        exit;
    }

    if ($action === 'publish' && $_SERVER['REQUEST_METHOD'] === 'POST') {
        requireCsrf();
        $payloadText = (string) ($_POST['payload'] ?? '');
        try {
            $payload = json_decode($payloadText, true, 512, JSON_THROW_ON_ERROR);
        } catch (JsonException) {
            throw new ApiException('The publish payload is invalid.');
        }
        if (!is_array($payload) || ($payload['confirm'] ?? false) !== true) {
            throw new ApiException('Publish confirmation is required.');
        }
        $result = $repository->publish($payload, $_FILES, (string) $_SESSION['admin_login']);
        respondJson([
            'ok' => true,
            'message' => 'Changes were published to GitHub in one commit.',
            'result' => $result,
            'state' => $repository->loadState(),
        ]);
    }

    throw new ApiException('Unknown Deck Manager action.', 404);
} catch (ApiException $error) {
    if ($action === 'callback') {
        header('Content-Type: text/plain; charset=utf-8');
        http_response_code($error->httpStatus);
        echo $error->getMessage();
        exit;
    }
    respondJson([
        'ok' => false,
        'message' => $error->getMessage(),
        'validationErrors' => $error->details,
        'conflict' => $error->conflict,
    ], $error->httpStatus);
} catch (PublicationConflict $error) {
    respondJson(['ok' => false, 'message' => $error->getMessage(), 'validationErrors' => [], 'conflict' => true], 409);
} catch (PlatformException $error) {
    error_log($error->getMessage());
    respondJson(['ok' => false, 'message' => $error->getMessage(), 'validationErrors' => [], 'conflict' => false], 422);
} catch (Throwable $error) {
    error_log((string) $error);
    respondJson(['ok' => false, 'message' => 'Deck Manager encountered an unexpected server error.'], 500);
}

function requestPayload(): array
{
    $payloadText = (string) ($_POST['payload'] ?? '');
    if ($payloadText === '' && str_contains(strtolower((string) ($_SERVER['CONTENT_TYPE'] ?? '')), 'application/json')) {
        $body = file_get_contents('php://input');
        $payloadText = is_string($body) ? $body : '';
    }
    try {
        $payload = json_decode($payloadText, true, 512, JSON_THROW_ON_ERROR);
    } catch (JsonException) {
        throw new ApiException('The request payload is invalid.');
    }
    if (!is_array($payload)) {
        throw new ApiException('The request payload is invalid.');
    }
    return $payload;
}

function positiveInteger(mixed $value, string $name): int
{
    $text = is_scalar($value) ? (string) $value : '';
    if (preg_match('/^[1-9]\d*$/', $text) !== 1) {
        throw new ApiException("$name must be a positive integer.");
    }
    return (int) $text;
}

function requireAdmin(): void
{
    $authenticatedAt = (int) ($_SESSION['authenticated_at'] ?? 0);
    if (!isset($_SESSION['admin_login']) || $authenticatedAt < time() - 12 * 60 * 60) {
        clearAuthenticationSession();
        throw new ApiException('Sign in with the administrator account first.', 401);
    }
}

function requireLoginCsrf(): void
{
    $expected = (string) ($_SESSION['login_csrf_token'] ?? '');
    $actual = (string) ($_SERVER['HTTP_X_CSRF_TOKEN'] ?? '');
    if ($expected === '' || $actual === '' || !hash_equals($expected, $actual)) {
        throw new ApiException('The sign-in page expired. Reload it and try again.', 403);
    }
}

function clearAuthenticationSession(): void
{
    unset(
        $_SESSION['admin_login'],
        $_SESSION['admin_avatar'],
        $_SESSION['auth_method'],
        $_SESSION['authenticated_at'],
        $_SESSION['csrf_token'],
        $_SESSION['login_csrf_token'],
        $_SESSION['github_login'],
        $_SESSION['github_avatar'],
        $_SESSION['github_installation_token'],
        $_SESSION['github_installation_token_expires'],
    );
}

function requireCsrf(): void
{
    $expected = (string) ($_SESSION['csrf_token'] ?? '');
    $actual = (string) ($_SERVER['HTTP_X_CSRF_TOKEN'] ?? '');
    if ($expected === '' || $actual === '' || !hash_equals($expected, $actual)) {
        throw new ApiException('The security token expired. Reload Deck Manager and try again.', 403);
    }
}

function respondJson(array $payload, int $status = 200): never
{
    http_response_code($status);
    header('Content-Type: application/json; charset=utf-8');
    echo json_encode($payload, JSON_UNESCAPED_SLASHES | JSON_UNESCAPED_UNICODE | JSON_THROW_ON_ERROR);
    exit;
}
