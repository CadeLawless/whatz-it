<?php
declare(strict_types=1);

header("Content-Security-Policy: default-src 'self'; img-src 'self' data: blob:; style-src 'self'; script-src 'self'; connect-src 'self'; base-uri 'none'; frame-ancestors 'none'; form-action 'self'");
header('X-Content-Type-Options: nosniff');
header('X-Frame-Options: DENY');
header('Referrer-Policy: no-referrer');
header('Permissions-Policy: camera=(), microphone=(), geolocation=()');
header('Cache-Control: no-store');
?>
<!doctype html>
<html lang="en">
<head>
  <meta charset="utf-8">
  <meta name="viewport" content="width=device-width, initial-scale=1">
  <meta name="robots" content="noindex, nofollow, noarchive">
  <title>WHATZ IT? Deck Manager</title>
  <link rel="icon" type="image/png" href="/favicon.php?v=<?= rawurlencode((string) filemtime(dirname(__DIR__, 2) . '/assets/favicon.png')) ?>">
  <link rel="stylesheet" href="assets/app.css?v=<?= rawurlencode((string) filemtime(__DIR__ . '/assets/app.css')) ?>">
</head>
<body>
  <div id="app">
    <header class="connection-bar" id="connection-bar" hidden>
      <div class="connection-brand">
        <div class="brand-mark">
          <img src="/assets/albert-headshot.png" alt="WHATZ IT? Logo" />
        </div>
        <div><strong>WHATZ IT?</strong><small>Deck Manager</small></div>
      </div>
      <div class="connection-paths">
        <span><small id="storage-location-label">GitHub repository</small><strong id="connected-app">CadeLawless/whatz-it</strong></span>
        <span><small id="storage-backend-label">Branch</small><strong id="connected-json">Loading…</strong></span>
        <span><small>Signed in</small><strong id="connected-images">—</strong></span>
      </div>
      <div class="connection-status">
        <span class="status-pill" id="connection-status">Unconnected</span>
        <span class="dirty-pill" id="dirty-status">No unsaved changes</span>
        <small id="revision-status">Revision —</small>
      </div>
      <div class="connection-actions">
        <button type="button" class="button subtle" id="logout" hidden>Sign out</button>
        <button type="button" class="button subtle" id="discard-draft" hidden>Discard Draft</button>
        <button type="button" class="button subtle" id="reload-disk" aria-label="Get the latest shared changes" title="Get the latest shared changes" disabled>&#8635; Get Latest Changes</button>
      </div>
    </header>

    <section id="repository-loader" class="repository-loader" aria-live="polite" aria-busy="true" hidden>
      <div class="repository-loader-card">
        <div class="loading-deck-stack" aria-hidden="true">
          <span></span><span></span><span></span>
          <i></i><i></i><i></i>
        </div>
        <p class="eyebrow" id="loader-storage-label">Protected content sync</p>
        <h1 id="repository-loader-title">Getting the latest decks.</h1>
        <p id="repository-loader-message">Connecting securely to the WHATZ IT? repository…</p>
        <div class="loading-progress" id="repository-loading-progress" role="progressbar" aria-label="Repository loading progress">
          <span></span>
        </div>
        <small id="repository-loader-count">This can take a moment on the first visit.</small>
      </div>
    </section>

    <main id="auth-gate" class="auth-gate">
      <section class="auth-card">
        <span class="brand-mark">
          <img src="/assets/albert-headshot.png" alt="" />
        </span>
        <p class="eyebrow">Protected content editor</p>
        <h1>Manage decks securely.</h1>
        <p id="auth-message">Checking your access…</p>
        <ul id="configuration-problems" class="configuration-problems" hidden></ul>
        <form id="local-login-form" class="local-login-form" hidden>
          <label>Username<input name="username" type="text" autocomplete="username" maxlength="64" required></label>
          <label>Password<input name="password" type="password" autocomplete="current-password" maxlength="128" required></label>
          <button class="button primary" type="submit">Sign in</button>
          <p id="login-error" class="login-error" role="alert" hidden></p>
        </form>
        <a class="button primary" id="github-login" href="api.php?action=login" hidden>Sign in with GitHub</a>
      </section>
    </main>

    <main id="workspace" class="workspace" hidden>
      <section class="hero-panel">
        <div>
          <p class="eyebrow">Build-time content editor</p>
          <h1>Make game night<br><em>more fun.</em></h1>
          <p id="editor-storage-copy">Edit decks, bundles, cards, ordering, prices, and cover art from the protected WHATZ IT? repository. Nothing reaches GitHub until you review and publish.</p>
        </div>
        <div class="hero-actions">
          <button type="button" class="button primary" id="save-catalog" data-publish-action disabled>Publish Changes Live</button>
          <button type="button" class="button accent" id="update-dev-preview" disabled hidden>Update Test App</button>
          <button type="button" class="button" id="validate-catalog" disabled>Validate changes</button>
          <span class="preview-status" id="dev-preview-status" hidden></span>
        </div>
      </section>

      <section id="notice-area" class="notice-area" aria-live="polite"></section>

      <nav class="tabs" aria-label="Deck Manager sections">
        <a class="tab active" data-tab="decks" href="decks" aria-controls="panel-decks" aria-current="page">Decks <span id="deck-count">0</span></a>
        <a class="tab" data-tab="bundles" href="bundles" aria-controls="panel-bundles">Bundles <span id="bundle-count">0</span></a>
        <a class="tab" data-tab="cards" href="cards" aria-controls="panel-cards">Cards <span id="card-count">0</span></a>
        <a class="tab" data-tab="backups" href="backups" aria-controls="panel-backups">History <span id="backup-count">0</span></a>
      </nav>

      <section class="tab-panel active" id="panel-decks">
        <div class="panel-heading">
          <div><p class="kicker">Deck library</p><h2>All decks</h2><p class="panel-context">Free decks appear first. Drag within Free or Paid to set each app-page order independently.</p></div>
          <button type="button" class="button accent icon-button add-deck" aria-label="Add deck" title="Add deck" disabled>&#43;</button>
        </div>
        <div class="filter-row">
          <input id="deck-search" type="search" placeholder="Search decks…" disabled>
          <span id="deck-filter-count" class="filter-count">0 decks</span>
        </div>
        <div id="deck-grid" class="deck-grid empty-state">
          <div><strong>Loading GitHub content</strong><p>The protected catalog will appear here after the latest commit is loaded.</p></div>
        </div>
      </section>

      <section class="tab-panel" id="panel-bundles">
        <div class="panel-heading">
          <div><p class="kicker">Merchandising</p><h2>Bundles</h2><p class="panel-context">Drag decks to reorder a bundle or move them between bundles. Use Add Deck to intentionally reuse a deck in multiple bundles.</p></div>
          <button type="button" class="button accent icon-button" id="add-bundle" aria-label="Add bundle" title="Add bundle" disabled>&#43;</button>
        </div>
        <div class="filter-row pack-search-row">
          <input id="bundle-search" type="search" placeholder="Search bundles or decks..." disabled>
          <span id="bundle-filter-count" class="filter-count">0 bundles</span>
        </div>
        <div id="bundle-list" class="pack-list empty-state">
          <div><strong>No bundles yet</strong><p>Add a bundle, then choose any decks from the library.</p></div>
        </div>
      </section>

      <section class="tab-panel" id="panel-cards">
        <div class="panel-heading">
          <div><p class="kicker">Card editor</p><h2 id="cards-heading">Choose a deck</h2></div>
          <div class="inline-actions">
            <button type="button" class="button" id="bulk-import" aria-label="Bulk import cards" title="Bulk import" disabled>&#8681; Bulk Import</button>
            <button type="button" class="button accent icon-button" id="add-card" aria-label="Add card" title="Add card" disabled>&#43;</button>
          </div>
        </div>
        <div class="filter-row">
          <div class="card-deck-picker" id="card-deck-picker">
            <button type="button" class="card-deck-picker-trigger" id="card-deck-picker-trigger" aria-haspopup="listbox" aria-expanded="false" aria-controls="card-deck-picker-results" disabled>Choose a deck</button>
            <div class="card-deck-picker-popup" id="card-deck-picker-popup" hidden>
              <input id="card-deck-picker-search" type="search" placeholder="Search decks…" aria-label="Search decks">
              <div id="card-deck-picker-results" class="card-deck-picker-results" role="listbox" aria-label="Decks"></div>
            </div>
          </div>
          <input id="card-search" type="search" placeholder="Search card text or byline…" disabled>
        </div>
        <div class="card-bulk-actions" id="card-bulk-actions" hidden aria-live="polite">
          <span id="selected-card-count">0 selected</span>
          <button type="button" class="button subtle" id="select-all-cards">Select all cards</button>
          <button type="button" class="button subtle" id="copy-selected-cards" disabled>Copy selected</button>
          <button type="button" class="button danger" id="remove-selected-cards" disabled>Delete selected</button>
        </div>
        <section id="featured-card-section" class="featured-card-section" hidden aria-labelledby="featured-cards-heading">
          <div class="featured-card-heading">
            <div><p class="kicker">App preview</p><h3 id="featured-cards-heading">Featured cards</h3></div>
            <p>Drag by the handle to set the preview order.</p>
          </div>
          <div id="featured-card-list" class="featured-card-list" aria-live="polite"></div>
        </section>
        <div id="duplicate-warning" class="inline-warning" hidden></div>
        <div id="card-list" class="card-list empty-state"><div><strong>No deck selected</strong><p>Open a deck from the deck grid or select one above.</p></div></div>
      </section>

      <section class="tab-panel" id="panel-backups">
        <div class="panel-heading">
          <div><p class="kicker" id="history-storage-label">GitHub</p><h2>Publish history</h2><p class="panel-context" id="history-storage-copy">Every publish is an atomic GitHub commit and can be reviewed or reverted by a repository maintainer.</p></div>
        </div>
        <div id="backup-list" class="backup-list empty-state"><div><strong>No publishes yet</strong><p>Deck Manager commits will appear here.</p></div></div>
      </section>
    </main>

    <button type="button" class="button primary floating-publish" id="floating-publish" data-publish-action disabled hidden>
      <span aria-hidden="true">&#8593;</span> Publish Changes Live
    </button>
    <button type="button" class="button accent floating-dev-preview" id="floating-dev-preview" data-dev-preview-action disabled hidden>
      <span aria-hidden="true">&#8635;</span> Update Test App
    </button>

    <dialog id="bundle-dialog">
      <form method="dialog" class="dialog-card" id="bundle-form">
        <button type="button" class="dialog-close" aria-label="Close">×</button>
        <p class="kicker">Bundle details</p>
        <h2 id="bundle-dialog-title">Edit bundle</h2>
        <input type="hidden" name="originalId">
        <label>Title<input name="title" required maxlength="120"></label>
        <label>Description<textarea name="description" rows="3" maxlength="500" placeholder="A short summary shown with this bundle"></textarea></label>
        <div class="form-grid">
          <label>Access<select name="access"><option value="free">Free</option><option value="paid">Paid</option></select></label>
          <label id="bundle-price-field" hidden>Optional bundle price<input name="price" type="number" min="0" max="99999.99" step="0.01" placeholder="9.99"></label>
          <div class="full advanced-field store-product-field" id="bundle-apple-product-field" hidden>
            <label>Apple product status
              <select name="appleProductStatus">
                <option value="">Not configured</option>
                <option value="draft">Draft</option>
                <option value="available">Available</option>
                <option value="retired">Retired</option>
              </select>
            </label>
            <label>Apple product ID <small>Permanent after creation in App Store Connect</small><input name="appleProductId" readonly></label>
            <section class="apple-bundle-scenarios full" aria-labelledby="apple-bundle-scenarios-title">
              <div class="apple-bundle-scenarios-heading">
                <div>
                  <strong id="apple-bundle-scenarios-title">Apple bundle product IDs</strong>
                  <small id="apple-bundle-scenarios-summary">Add decks to see every discount scenario.</small>
                </div>
                <button type="button" class="mini-button" id="copy-all-apple-bundle-products">Copy all</button>
              </div>
              <div id="apple-bundle-scenarios-list" class="apple-bundle-scenarios-list"></div>
            </section>
          </div>
          <label class="full advanced-field">Stable ID <small>Changing an established ID can break purchase references.</small><input name="id" required pattern="[A-Za-z0-9][A-Za-z0-9_-]*"></label>
        </div>
        <div class="dialog-actions"><button class="button primary" value="submit">Apply bundle changes</button></div>
      </form>
    </dialog>

    <dialog id="deck-dialog" class="wide">
      <form method="dialog" class="dialog-card wide" id="deck-form">
        <button type="button" class="dialog-close" aria-label="Close">×</button>
        <p class="kicker">Deck details</p>
        <h2 id="deck-dialog-title">Edit deck</h2>
        <input type="hidden" name="index">
        <div class="form-grid">
          <label>Title<input name="title" required maxlength="120"></label>
          <label>Version<input name="version" type="number" min="1" step="1" required></label>
          <label class="full">Description<textarea name="description" rows="3"></textarea></label>
          <div class="full cover-field">
            <label>Cover filename <small>Must end in .webp; renames the current cover when you save</small><input name="coverImage" maxlength="120" pattern="[a-z0-9][a-z0-9_-]*\.webp" placeholder="my-deck-title.webp" autocomplete="off"></label>
            <label class="cover-drop-zone" id="deck-cover-drop-zone" tabindex="0">
              <strong>Drop an image here</strong>
              <span>or click to choose one</span>
              <small>At least 625×938px; converted to 625px-wide WebP</small>
              <input name="coverUpload" type="file" accept="image/*">
            </label>
            <div id="deck-cover-preview" class="deck-cover-preview"><span>No cover selected</span></div>
            <small>Uploads must be at least 625×938px. They are resized proportionally to 625px wide, converted by PHP, and staged as WebP. Changing the filename keeps the current cover and renames it when you save.</small>
          </div>
          <label>Tags <small>comma-separated</small><input name="tags"></label>
          <label>Access<select name="access"><option value="free">Free</option><option value="paid">Paid</option></select></label>
          <label id="deck-price-field" hidden>Optional price<input name="price" type="number" min="0" max="99999.99" step="0.01" placeholder="4.99"></label>
          <div class="full advanced-field store-product-field" id="deck-apple-product-field" hidden>
            <label>Apple product status
              <select name="appleProductStatus">
                <option value="">Not configured</option>
                <option value="draft">Draft</option>
                <option value="available">Available</option>
                <option value="retired">Retired</option>
              </select>
            </label>
            <label>Apple product ID <small>Permanent after creation in App Store Connect</small><input name="appleProductId" readonly></label>
          </div>
          <label class="full advanced-field">Stable ID <small>Changing an established ID can break app references.</small><input name="id" required pattern="[A-Za-z0-9][A-Za-z0-9_-]*"></label>
        </div>
        <div class="dialog-actions"><button class="button primary" value="submit">Apply deck changes</button></div>
      </form>
    </dialog>

    <dialog id="bundle-decks-dialog" class="wide">
      <form method="dialog" class="dialog-card wide" id="bundle-decks-form">
        <button type="button" class="dialog-close" aria-label="Close">&times;</button>
        <p class="kicker">Bundle contents</p>
        <h2 id="bundle-decks-title">Add decks</h2>
        <input type="hidden" name="bundleId">
        <input id="bundle-deck-search" type="search" placeholder="Search all decks...">
        <div id="bundle-deck-picker" class="bundle-deck-picker"></div>
        <div class="dialog-actions"><button class="button primary" value="submit">Apply deck selection</button></div>
      </form>
    </dialog>

    <dialog id="card-dialog">
      <form method="dialog" class="dialog-card" id="card-form">
        <button type="button" class="dialog-close" aria-label="Close">×</button>
        <p class="kicker">Card details</p>
        <h2 id="card-dialog-title">Edit card</h2>
        <input type="hidden" name="index">
        <label>Card text<textarea name="text" rows="3" required></textarea></label>
        <label>Optional byline<input name="byline"></label>
        <label class="check"><input type="checkbox" name="featured"> Featured in app preview</label>
        <label id="featured-order-field">Preview position <small>Controls the order shown in the app. There is no featured-card limit.</small><input name="featuredOrder" type="number" min="1" step="1"></label>
        <label class="advanced-field">Stable ID <small>Changing an established ID requires deliberate review.</small><input name="id" required pattern="[A-Za-z0-9][A-Za-z0-9_-]*"></label>
        <div class="dialog-actions"><button class="button primary" value="submit">Apply card changes</button></div>
      </form>
    </dialog>

    <dialog id="import-dialog" class="wide">
      <form method="dialog" class="dialog-card wide" id="import-form">
        <button type="button" class="dialog-close" aria-label="Close">×</button>
        <p class="kicker">Bulk card import</p>
        <h2>Preview before applying</h2>
        <div class="import-options">
          <label>Format<select name="format"><option value="plain">Plain text</option><option value="csv">CSV</option></select></label>
          <label>Apply mode<select name="mode"><option value="append">Append to existing cards</option><option value="replace">Replace existing cards</option></select></label>
          <label class="check"><input type="checkbox" name="delimiterEnabled" checked> Parse text byline delimiter</label>
          <label>Delimiter<input name="delimiter" value="|" maxlength="4"></label>
        </div>
        <label>Input<textarea name="input" rows="10" placeholder="Penguin | Optional byline&#10;Golden retriever"></textarea></label>
        <button type="button" class="button" id="preview-import">Parse and preview</button>
        <div id="import-preview" class="import-preview"></div>
        <div class="dialog-actions"><button type="button" class="button primary" id="apply-import" disabled>Apply to unsaved editor state</button></div>
      </form>
    </dialog>

    <dialog id="duplicates-dialog" class="wide">
      <form method="dialog" class="dialog-card wide" id="duplicates-form">
        <button type="button" class="dialog-close" aria-label="Close">×</button>
        <p class="kicker">Duplicate cards</p>
        <h2 id="duplicates-title">Review duplicates</h2>
        <p id="duplicates-summary" class="field-help"></p>
        <div id="duplicates-list" class="duplicates-list"></div>
        <div class="dialog-actions"><button type="button" class="button primary" id="close-duplicates">Done</button></div>
      </form>
    </dialog>

    <dialog id="save-dialog" class="wide">
      <form method="dialog" class="dialog-card wide">
        <button type="button" class="dialog-close" aria-label="Close">×</button>
        <p class="kicker">Final review</p>
        <h2 id="publish-dialog-title">Publish changes to GitHub?</h2>
        <div id="save-preview" class="save-preview"></div>
        <label id="commit-message-field">Commit message<input id="commit-message" maxlength="200" placeholder="Example: Add summer party deck" autocomplete="off"></label>
        <p class="field-help" id="publish-description">A detailed description of every published catalog and image change is added to the commit automatically.</p>
        <p class="warning-copy" id="publish-warning">Deck Manager will verify that nobody has published since you loaded the page, validate every path and cover reference, then create one atomic commit.</p>
        <div class="dialog-actions"><button type="button" class="button primary" id="confirm-save">Publish Changes Live</button></div>
      </form>
    </dialog>

    <dialog id="confirm-dialog">
      <form method="dialog" class="dialog-card">
        <button type="button" class="dialog-close" aria-label="Close">×</button>
        <p class="kicker">Please confirm</p>
        <h2 id="confirm-title">Confirm action</h2>
        <p id="confirm-message"></p>
        <div class="dialog-actions"><button class="button" value="cancel">Cancel</button><button class="button danger" value="confirm">Confirm</button></div>
      </form>
    </dialog>

    <dialog id="draft-save-error-dialog">
      <form method="dialog" class="dialog-card">
        <button type="button" class="dialog-close" aria-label="Close">×</button>
        <p class="kicker">Draft protection</p>
        <h2 id="draft-save-error-title">Draft did not save</h2>
        <p id="draft-save-error-message"></p>
        <p class="warning-copy">Your work is still in this browser. Save it on this device and load the latest shared version before continuing.</p>
        <div class="dialog-actions">
          <button type="button" class="button" id="dismiss-draft-save-error">Keep Editing</button>
          <button type="button" class="button primary" id="stash-draft-save-error">Save My Work &amp; Get Latest</button>
        </div>
      </form>
    </dialog>

    <dialog id="stash-resolution-dialog">
      <form class="dialog-card" id="stash-resolution-form">
        <p class="kicker">Saved work found</p>
        <h2>Finish recovering your work</h2>
        <p id="stash-resolution-message">Deck Manager found work saved on this device. Restore it onto the latest shared version or discard it before continuing.</p>
        <div class="warning-copy" id="stash-resolution-problem" hidden></div>
        <div class="dialog-actions">
          <button type="button" class="button danger" id="discard-stash">Discard Saved Work</button>
          <button type="button" class="button primary" id="restore-stash">Restore My Saved Work</button>
        </div>
      </form>
    </dialog>
  </div>
  <script src="assets/filesystem.js?v=<?= rawurlencode((string) filemtime(__DIR__ . '/assets/filesystem.js')) ?>" defer></script>
  <script src="assets/draft-sync.js?v=<?= rawurlencode((string) filemtime(__DIR__ . '/assets/draft-sync.js')) ?>" defer></script>
  <script src="assets/app.js?v=<?= rawurlencode((string) filemtime(__DIR__ . '/assets/app.js')) ?>" defer></script>
</body>
</html>
