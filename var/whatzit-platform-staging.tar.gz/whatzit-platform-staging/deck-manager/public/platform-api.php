<?php

declare(strict_types=1);

use WhatzIt\DeckPlatform\PlatformConfig;
use WhatzIt\DeckPlatform\PlatformException;
use WhatzIt\DeckPlatform\AppleServerApiClient;
use WhatzIt\DeckPlatform\CommerceConflict;
use WhatzIt\DeckPlatform\CommerceService;
use WhatzIt\DeckPlatform\CommerceUnauthorized;
use WhatzIt\DeckPlatform\Database;
use WhatzIt\DeckPlatform\GooglePlayApiClient;
use WhatzIt\DeckPlatform\PurchaseRestoreRequired;
use WhatzIt\DeckPlatform\StoreVerificationUnavailable;

require dirname(__DIR__) . '/platform/lib/PlatformCatalog.php';
require dirname(__DIR__) . '/platform/lib/Commerce.php';

header('X-Content-Type-Options: nosniff');
header('Referrer-Policy: no-referrer');
header("Content-Security-Policy: default-src 'none'; frame-ancestors 'none'");
header_remove('X-Powered-By');

try {
    $config = new PlatformConfig();
    $config->assertReady(database: false, artifacts: true);
    $root = $config->artifactRoot;
    $path = parse_url((string) ($_SERVER['REQUEST_URI'] ?? ''), PHP_URL_PATH) ?: '';
    $path = WhatzIt\DeckPlatform\PublicRoute::normalizePath($path);

    if ($path === '/api/v1/installations/apple' || $path === '/api/v1/installations/google') {
        requireMethod('POST');
        $body = requestJson();
        $service = commerceService($config);
        respondJson($service->registerInstallation(
            stringField($body, 'installationId'),
            stringField($body, 'appAccountToken'),
            stringField($body, 'credential'),
            str_ends_with($path, '/google') ? 'google' : 'apple',
        ), 201);
    }
    if ($path === '/api/v1/purchases/google/verify' || $path === '/api/v1/purchases/google/restore') {
        requireMethod('POST');
        $body = requestJson();
        [$installationId, $credential] = installationAuthorization();
        $service = commerceService($config);
        $installation = $service->authenticate($installationId, $credential);
        respondJson($service->verifyGoogle(
            $installation,
            stringField($body, 'packageName'),
            stringField($body, 'productId'),
            stringField($body, 'purchaseToken'),
            str_ends_with($path, '/restore') ? 'restore' : 'purchase',
        ));
    }
    if ($path === '/api/v1/purchases/apple/verify' || $path === '/api/v1/purchases/apple/restore') {
        requireMethod('POST');
        $body = requestJson();
        [$installationId, $credential] = installationAuthorization();
        $service = commerceService($config);
        $installation = $service->authenticate($installationId, $credential);
        respondJson($service->verifyApple(
            $installation,
            stringField($body, 'signedTransaction'),
            str_ends_with($path, '/restore') ? 'restore' : 'purchase',
        ));
    }
    if ($path === '/api/v1/entitlements') {
        requireMethod('GET');
        [$installationId, $credential] = installationAuthorization();
        $service = commerceService($config);
        $installation = $service->authenticate($installationId, $credential);
        respondJson($service->entitlements((string) $installation['installation_id']));
    }
    if ($path === '/api/v1/testing/reset-purchases') {
        requireMethod('POST');
        if ($config->environment !== 'test') {
            respondError('not_found', 'The requested catalog resource does not exist.', 404);
        }
        [$installationId, $credential] = installationAuthorization();
        $service = commerceService($config);
        $installation = $service->authenticate($installationId, $credential);
        respondJson($service->resetSandboxEntitlements(
            (string) $installation['installation_id'],
        ));
    }

    if ($path === '/api/v1/dev-preview/catalog/manifest') {
        requireMethod('GET');
        requireDevelopmentPreviewAuthorization($config);
        serveManifest(
            $root . DIRECTORY_SEPARATOR . 'dev-preview' . DIRECTORY_SEPARATOR . 'manifest.json',
            'private, no-store, max-age=0',
        );
    }
    if (preg_match(
        '#^/api/v1/dev-preview/revisions/(\d+)/content/(covers|thumbnails)/([a-f0-9]{64})\.webp$#',
        $path,
        $matches,
    ) === 1) {
        requireMethod('GET');
        requireDevelopmentPreviewAuthorization($config);
        $revisionRoot = developmentPreviewRevisionRoot($root, (int) $matches[1]);
        serveImmutable(
            $revisionRoot . DIRECTORY_SEPARATOR . $matches[2]
                . DIRECTORY_SEPARATOR . $matches[3] . '.webp',
            'image/webp',
            $matches[3],
            'private, max-age=31536000, immutable',
        );
    }
    if (preg_match(
        '#^/api/v1/dev-preview/revisions/(\d+)/decks/([A-Za-z0-9][A-Za-z0-9_-]{0,99})/content/(\d+)$#',
        $path,
        $matches,
    ) === 1) {
        requireMethod('GET');
        requireDevelopmentPreviewAuthorization($config);
        serveDevelopmentPreviewDeck(
            developmentPreviewRevisionRoot($root, (int) $matches[1]),
            $matches[2],
            (int) $matches[3],
        );
    }

    if ($path === '/api/v1/catalog/manifest') {
        serveManifest($root . DIRECTORY_SEPARATOR . 'manifest.json');
    }
    if (preg_match('#^/content/(covers|thumbnails)/([a-f0-9]{64})\.webp$#', $path, $matches) === 1) {
        serveImmutable(
            $root . DIRECTORY_SEPARATOR . $matches[1] . DIRECTORY_SEPARATOR . $matches[2] . '.webp',
            'image/webp',
            $matches[2],
        );
    }
    if (preg_match('#^/api/v1/decks/([A-Za-z0-9][A-Za-z0-9_-]{0,99})/content/(\d+)$#', $path, $matches) === 1) {
        serveDeck($config, $root, $matches[1], (int) $matches[2]);
    }
    respondError('not_found', 'The requested catalog resource does not exist.', 404);
} catch (CommerceUnauthorized $error) {
    error_log($error->getMessage());
    respondError('installation_unauthorized', 'Installation authentication failed.', 401);
} catch (PurchaseRestoreRequired $error) {
    error_log($error->getMessage());
    respondError('purchase_restore_required', $error->getMessage(), 409);
} catch (CommerceConflict $error) {
    error_log($error->getMessage());
    respondError('purchase_rejected', $error->getMessage(), 409);
} catch (StoreVerificationUnavailable $error) {
    error_log($error->getMessage());
    respondError('store_verification_unavailable', 'Purchase verification is temporarily unavailable.', 503);
} catch (PlatformException $error) {
    error_log($error->getMessage());
    respondError('catalog_unavailable', 'The catalog service is temporarily unavailable.', 503);
} catch (Throwable $error) {
    error_log((string) $error);
    respondError('internal_error', 'The catalog service encountered an unexpected error.', 500);
}

function commerceService(PlatformConfig $config): CommerceService
{
    $problems = $config->problems(database: true);
    if ($problems !== []) throw new StoreVerificationUnavailable(implode(' ', $problems));
    $database = new Database($config);
    return new CommerceService(
        $database,
        $config,
        new AppleServerApiClient($config),
        new GooglePlayApiClient($config),
    );
}

function requireMethod(string $method): void
{
    if (strtoupper((string) ($_SERVER['REQUEST_METHOD'] ?? 'GET')) !== $method) {
        header('Allow: ' . $method);
        respondError('method_not_allowed', 'This route does not support that HTTP method.', 405);
    }
}

/** @return array<string,mixed> */
function requestJson(): array
{
    $length = (int) ($_SERVER['CONTENT_LENGTH'] ?? 0);
    if ($length > 65536) respondError('request_too_large', 'The request body is too large.', 413);
    $bytes = file_get_contents('php://input', false, null, 0, 65537);
    if (!is_string($bytes) || strlen($bytes) > 65536) {
        respondError('request_too_large', 'The request body is too large.', 413);
    }
    try {
        $value = json_decode($bytes, true, 32, JSON_THROW_ON_ERROR);
    } catch (JsonException) {
        respondError('invalid_json', 'The request body must be valid JSON.', 400);
    }
    if (!is_array($value) || array_is_list($value)) {
        respondError('invalid_request', 'The request body must be a JSON object.', 400);
    }
    return $value;
}

function stringField(array $body, string $key): string
{
    $value = $body[$key] ?? null;
    if (!is_string($value) || $value === '') {
        respondError('invalid_request', "The $key field is required.", 400);
    }
    return $value;
}

/** @return array{string,string} */
function installationAuthorization(): array
{
    $installationId = trim((string) ($_SERVER['HTTP_X_WHATZIT_INSTALLATION_ID'] ?? ''));
    $authorization = trim((string) (
        $_SERVER['HTTP_AUTHORIZATION']
        ?? $_SERVER['REDIRECT_HTTP_AUTHORIZATION']
        ?? ''
    ));
    if ($installationId === '' || preg_match('/^Bearer ([a-f0-9]{64})$/', $authorization, $matches) !== 1) {
        throw new CommerceUnauthorized('Installation authorization headers are missing.');
    }
    return [$installationId, $matches[1]];
}

function respondJson(array $data, int $status = 200): never
{
    http_response_code($status);
    header('Content-Type: application/json; charset=utf-8');
    header('Cache-Control: no-store');
    echo json_encode(['ok' => true, 'data' => $data], JSON_UNESCAPED_SLASHES | JSON_THROW_ON_ERROR);
    exit;
}

function requireDevelopmentPreviewAuthorization(PlatformConfig $config): void
{
    $configured = $config->devPreviewKey;
    $presented = strtolower(trim((string) ($_SERVER['HTTP_X_WHATZIT_DEV_PREVIEW_KEY'] ?? '')));
    if (preg_match('/^[a-f0-9]{64}$/', $configured) !== 1) {
        throw new PlatformException('The development preview key is not configured.');
    }
    if (preg_match('/^[a-f0-9]{64}$/', $presented) !== 1 || !hash_equals($configured, $presented)) {
        respondError('preview_unauthorized', 'Development preview authentication failed.', 401);
    }
}

function developmentPreviewRevisionRoot(string $root, int $revision): string
{
    if ($revision < 1) respondError('not_found', 'The requested catalog resource does not exist.', 404);
    return $root . DIRECTORY_SEPARATOR . 'dev-preview' . DIRECTORY_SEPARATOR . 'revisions'
        . DIRECTORY_SEPARATOR . $revision;
}

function serveManifest(
    string $path,
    string $cacheControl = 'public, max-age=60, must-revalidate',
): never
{
    if (!is_file($path) || !is_readable($path)) {
        throw new PlatformException('No generated discovery manifest is available.');
    }
    $bytes = file_get_contents($path);
    if (!is_string($bytes)) {
        throw new PlatformException('The discovery manifest could not be read.');
    }
    $etag = hash('sha256', $bytes);
    if (requestEtagMatches($etag)) {
        http_response_code(304);
        header('ETag: "' . $etag . '"');
        header('Cache-Control: ' . $cacheControl);
        exit;
    }
    header('Content-Type: application/json; charset=utf-8');
    header('Content-Length: ' . strlen($bytes));
    header('ETag: "' . $etag . '"');
    header('Cache-Control: ' . $cacheControl);
    echo $bytes;
    exit;
}

function serveDevelopmentPreviewDeck(string $revisionRoot, string $deckId, int $version): never
{
    $manifestPath = $revisionRoot . DIRECTORY_SEPARATOR . 'manifest.json';
    $json = is_file($manifestPath) ? file_get_contents($manifestPath) : false;
    $manifest = is_string($json) ? json_decode($json, true) : null;
    if (!is_array($manifest)) {
        respondError('not_found', 'The requested development preview does not exist.', 404);
    }
    foreach ($manifest['decks'] ?? [] as $deck) {
        if (!is_array($deck)
            || ($deck['id'] ?? null) !== $deckId
            || (int) ($deck['cardContentVersion'] ?? 0) !== $version) {
            continue;
        }
        $hash = (string) ($deck['content']['hash'] ?? '');
        if (preg_match('/^[a-f0-9]{64}$/', $hash) !== 1) {
            throw new PlatformException('The development preview deck reference is invalid.');
        }
        $relative = 'decks/' . rawurlencode($deckId) . '/' . $version . '/' . $hash . '.json';
        serveImmutable(
            $revisionRoot . DIRECTORY_SEPARATOR . str_replace('/', DIRECTORY_SEPARATOR, $relative),
            'application/json; charset=utf-8',
            $hash,
            'private, max-age=31536000, immutable',
        );
    }
    respondError('not_found', 'The requested deck version does not exist.', 404);
}

function serveDeck(PlatformConfig $config, string $root, string $deckId, int $version): never
{
    $manifestPath = $root . DIRECTORY_SEPARATOR . 'manifest.json';
    $json = is_file($manifestPath) ? file_get_contents($manifestPath) : false;
    $manifest = is_string($json) ? json_decode($json, true) : null;
    if (!is_array($manifest)) {
        throw new PlatformException('The discovery manifest is unavailable or invalid.');
    }
    foreach ($manifest['decks'] ?? [] as $deck) {
        if (!is_array($deck) || ($deck['id'] ?? null) !== $deckId || (int) ($deck['cardContentVersion'] ?? 0) !== $version) {
            continue;
        }
        if (($deck['access'] ?? null) !== 'free' || ($deck['content']['protected'] ?? true) !== false) {
            [$installationId, $credential] = installationAuthorization();
            $service = commerceService($config);
            $installation = $service->authenticate($installationId, $credential);
            if (!$service->canAccessDeck((string) $installation['installation_id'], $deckId)) {
                respondError('entitlement_required', 'This deck content requires an entitlement.', 403);
            }
        }
        $hash = (string) ($deck['content']['hash'] ?? '');
        if (preg_match('/^[a-f0-9]{64}$/', $hash) !== 1) {
            throw new PlatformException('The deck artifact reference is invalid.');
        }
        $relative = 'decks/' . rawurlencode($deckId) . '/' . $version . '/' . $hash . '.json';
        serveImmutable(
            $root . DIRECTORY_SEPARATOR . str_replace('/', DIRECTORY_SEPARATOR, $relative),
            'application/json; charset=utf-8',
            $hash,
        );
    }
    respondError('not_found', 'The requested deck version does not exist.', 404);
}

function serveImmutable(
    string $path,
    string $contentType,
    string $etag,
    string $cacheControl = 'public, max-age=31536000, immutable',
): never
{
    if (!is_file($path) || !is_readable($path)) {
        respondError('not_found', 'The requested immutable artifact does not exist.', 404);
    }
    $bytes = file_get_contents($path);
    if (!is_string($bytes) || !hash_equals($etag, hash('sha256', $bytes))) {
        throw new PlatformException('An immutable artifact failed integrity validation.');
    }
    header('Content-Type: ' . $contentType);
    header('Content-Length: ' . strlen($bytes));
    header('ETag: "' . $etag . '"');
    header('Cache-Control: ' . $cacheControl);
    echo $bytes;
    exit;
}

function requestEtagMatches(string $etag): bool
{
    $header = (string) ($_SERVER['HTTP_IF_NONE_MATCH'] ?? '');
    foreach (explode(',', $header) as $candidate) {
        $candidate = trim($candidate);
        if (str_starts_with($candidate, 'W/')) {
            $candidate = substr($candidate, 2);
        }
        $candidate = trim($candidate, " \t\n\r\0\x0B\"");
        if ($candidate !== '' && hash_equals($etag, $candidate)) {
            return true;
        }
    }
    return false;
}

function respondError(string $code, string $message, int $status): never
{
    http_response_code($status);
    header('Content-Type: application/json; charset=utf-8');
    header('Cache-Control: no-store');
    echo json_encode(['ok' => false, 'error' => ['code' => $code, 'message' => $message]], JSON_UNESCAPED_SLASHES);
    exit;
}
