<?php

declare(strict_types=1);

// Deploy as the explicit staging configuration:
// /home/ACCOUNT/domains/playwhatzit.com/whatzit-secrets/deck-platform-staging-config.php
// The staging front controller selects this path so it cannot inherit the
// production platform fallback.
// Keep the file outside public_html and set its permissions to 600.
return [
    'WHATZIT_PLATFORM_ENV' => 'test',
    'WHATZIT_DB_HOST' => 'localhost',
    'WHATZIT_DB_PORT' => '3306',
    'WHATZIT_DB_NAME' => 'HOSTINGER_DATABASE_NAME',
    'WHATZIT_DB_USER' => 'HOSTINGER_DATABASE_USER',
    'WHATZIT_DB_PASSWORD' => 'HOSTINGER_DATABASE_PASSWORD',
    'WHATZIT_PUBLIC_API_BASE_URL' => 'https://api-staging.playwhatzit.com',
    'WHATZIT_CONTENT_BASE_URL' => 'https://api-staging.playwhatzit.com/content',
    'WHATZIT_ARTIFACT_ROOT' => '/home/ACCOUNT/domains/playwhatzit.com/whatzit-platform-staging/artifacts',
    'WHATZIT_MEDIA_ROOT' => '/home/ACCOUNT/domains/playwhatzit.com/whatzit-platform-staging/seed',
];
