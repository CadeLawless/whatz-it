<?php

declare(strict_types=1);

namespace WhatzIt\DeckManager;

use JsonException;
use RuntimeException;

final class ApiException extends RuntimeException
{
    public function __construct(
        string $message,
        public readonly int $httpStatus = 400,
        public readonly array $details = [],
        public readonly bool $conflict = false,
    ) {
        parent::__construct($message);
    }
}

final class Config
{
    public const OWNER = 'CadeLawless';
    public const REPOSITORY = 'whatz-it';
    public const IMAGE_DIRECTORY = 'assets/images/decks';

    public readonly string $appId;
    public readonly string $clientId;
    public readonly string $clientSecret;
    public readonly string $installationId;
    public readonly string $repositoryId;
    public readonly string $privateKey;
    public readonly string $baseUrl;
    public readonly string $branch;
    public readonly string $catalogPath;
    public readonly string $storageBackend;
    public readonly string $authBackend;
    public readonly string $authRateLimitSecret;
    /** @var list<string> */
    public readonly array $adminLogins;
    private readonly string $configurationFileProblem;

    public function __construct(?array $environment = null)
    {
        if ($environment === null) {
            $runtime = array_merge($_ENV, $_SERVER);
            $configuredPath = $runtime['WHATZIT_CONFIG_PATH'] ?? getenv('WHATZIT_CONFIG_PATH');
            $configuredPath = is_scalar($configuredPath) ? trim((string) $configuredPath) : '';
            $localFile = dirname(__DIR__) . '/config.local.php';
            $documentRoot = is_scalar($_SERVER['DOCUMENT_ROOT'] ?? null)
                ? rtrim((string) $_SERVER['DOCUMENT_ROOT'], '/\\')
                : '';
            $hostedFile = self::hostedConfigurationPath($documentRoot);
            $configurationFile = $configuredPath !== ''
                ? $configuredPath
                : (is_file($localFile) ? $localFile : $hostedFile);
            $loaded = [];
            $problem = '';
            if ($configuredPath !== '' && !self::isAbsoluteFilesystemPath($configuredPath)) {
                $problem = 'WHATZIT_CONFIG_PATH must be an absolute filesystem path.';
            } elseif ($configurationFile !== '' && is_file($configurationFile) && is_readable($configurationFile)) {
                try {
                    $candidate = require $configurationFile;
                    if (is_array($candidate)) {
                        $loaded = $candidate;
                    } else {
                        $problem = 'The Deck Manager configuration file must return a PHP array.';
                    }
                } catch (\Throwable) {
                    $problem = 'The Deck Manager configuration file could not be loaded.';
                }
            } elseif ($configuredPath !== '') {
                $problem = 'WHATZIT_CONFIG_PATH does not point to a readable file.';
            }
            $this->configurationFileProblem = $problem;
            $environment = array_merge($runtime, $loaded);
        } else {
            $this->configurationFileProblem = '';
        }
        $read = static function (string $name) use ($environment): string {
            $value = $environment[$name] ?? getenv($name);
            return is_scalar($value) ? trim((string) $value) : '';
        };

        $this->appId = $read('WHATZIT_GITHUB_APP_ID');
        $this->clientId = $read('WHATZIT_GITHUB_CLIENT_ID');
        $this->clientSecret = $read('WHATZIT_GITHUB_CLIENT_SECRET');
        $this->installationId = $read('WHATZIT_GITHUB_INSTALLATION_ID');
        $this->repositoryId = $read('WHATZIT_GITHUB_REPOSITORY_ID');
        $this->baseUrl = rtrim($read('WHATZIT_BASE_URL'), '/');
        $this->branch = $read('WHATZIT_GITHUB_BRANCH') ?: 'main';
        $this->catalogPath = $read('WHATZIT_CATALOG_PATH') ?: 'src/data/bundles.ts';
        $this->storageBackend = strtolower($read('WHATZIT_DECK_MANAGER_STORAGE') ?: 'github');
        $this->authBackend = strtolower($read('WHATZIT_DECK_MANAGER_AUTH') ?: 'github');
        $this->authRateLimitSecret = $read('WHATZIT_AUTH_RATE_LIMIT_SECRET');
        $this->adminLogins = array_values(array_filter(array_map(
            static fn (string $login): string => strtolower(trim($login)),
            explode(',', $read('WHATZIT_ADMIN_LOGINS')),
        )));

        $privateKey = $read('WHATZIT_GITHUB_PRIVATE_KEY');
        $privateKeyPath = $read('WHATZIT_GITHUB_PRIVATE_KEY_PATH');
        if ($privateKey === '' && $privateKeyPath !== '' && is_readable($privateKeyPath)) {
            $contents = file_get_contents($privateKeyPath);
            $privateKey = is_string($contents) ? trim($contents) : '';
        }
        if ($privateKey !== '' && !str_contains($privateKey, 'BEGIN')) {
            $decoded = base64_decode($privateKey, true);
            if (is_string($decoded) && str_contains($decoded, 'BEGIN')) {
                $privateKey = $decoded;
            }
        }
        $this->privateKey = str_replace('\n', "\n", $privateKey);
    }

    /** @return list<string> */
    public function problems(): array
    {
        $required = ['WHATZIT_BASE_URL' => $this->baseUrl];
        if ($this->authBackend === 'github') {
            $required += [
                'WHATZIT_GITHUB_CLIENT_ID' => $this->clientId,
                'WHATZIT_GITHUB_CLIENT_SECRET' => $this->clientSecret,
                'WHATZIT_ADMIN_LOGINS' => implode(',', $this->adminLogins),
            ];
        } else {
            $required['WHATZIT_AUTH_RATE_LIMIT_SECRET'] = $this->authRateLimitSecret;
        }
        if ($this->storageBackend === 'github') {
            $required = [
                'WHATZIT_GITHUB_APP_ID' => $this->appId,
                ...$required,
                'WHATZIT_GITHUB_INSTALLATION_ID' => $this->installationId,
                'WHATZIT_GITHUB_REPOSITORY_ID' => $this->repositoryId,
                'WHATZIT_GITHUB_PRIVATE_KEY or WHATZIT_GITHUB_PRIVATE_KEY_PATH' => $this->privateKey,
            ];
        }
        $problems = $this->configurationFileProblem === '' ? [] : [$this->configurationFileProblem];
        foreach ($required as $name => $value) {
            if ($value === '') {
                $problems[] = "$name is not configured.";
            }
        }
        if ($this->baseUrl !== '' && !preg_match('#^https://#i', $this->baseUrl)
            && !preg_match('#^http://(?:127\.0\.0\.1|localhost)(?::\d+)?$#i', $this->baseUrl)) {
            $problems[] = 'WHATZIT_BASE_URL must use HTTPS, except for localhost development.';
        }
        if (!preg_match('/^[A-Za-z0-9._\/-]+$/', $this->branch) || str_contains($this->branch, '..')) {
            $problems[] = 'WHATZIT_GITHUB_BRANCH is invalid.';
        }
        if (!self::safeRepositoryPath($this->catalogPath) || preg_match('/\.(?:ts|json)$/i', $this->catalogPath) !== 1) {
            $problems[] = 'WHATZIT_CATALOG_PATH must be a safe .ts or .json repository path.';
        }
        if (!in_array($this->storageBackend, ['github', 'database'], true)) {
            $problems[] = 'WHATZIT_DECK_MANAGER_STORAGE must be github or database.';
        }
        if (!in_array($this->authBackend, ['github', 'local'], true)) {
            $problems[] = 'WHATZIT_DECK_MANAGER_AUTH must be github or local.';
        }
        if ($this->storageBackend === 'database' && $this->authBackend !== 'local') {
            $problems[] = 'Database Deck Manager storage requires local authentication.';
        }
        if ($this->authBackend === 'local' && strlen($this->authRateLimitSecret) < 32) {
            $problems[] = 'WHATZIT_AUTH_RATE_LIMIT_SECRET must contain at least 32 characters.';
        }
        if (($this->storageBackend === 'github' || $this->authBackend === 'github') && !function_exists('curl_init')) {
            $problems[] = 'The PHP cURL extension is not enabled.';
        }
        if ($this->storageBackend === 'github' && !function_exists('openssl_sign')) {
            $problems[] = 'The PHP OpenSSL extension is not enabled.';
        }
        if (!function_exists('imagecreatefromstring') || !function_exists('imagewebp')) {
            $problems[] = 'PHP GD with WebP support is required for deck-cover conversion.';
        }
        return $problems;
    }

    private static function isAbsoluteFilesystemPath(string $path): bool
    {
        return str_starts_with($path, '/')
            || str_starts_with($path, '\\\\')
            || preg_match('/^[A-Za-z]:[\\\\\\/]/', $path) === 1;
    }

    private static function hostedConfigurationPath(string $documentRoot): string
    {
        if ($documentRoot === '') {
            return '';
        }
        $normalized = str_replace('\\', '/', $documentRoot);
        $publicHtml = stripos($normalized, '/public_html');
        $hostingRoot = $publicHtml === false ? dirname($documentRoot) : substr($normalized, 0, $publicHtml);
        if ($hostingRoot === '') {
            $hostingRoot = dirname($documentRoot);
        }
        return rtrim($hostingRoot, '/\\') . '/whatzit-secrets/deck-manager-config.php';
    }

    public function assertReady(): void
    {
        $problems = $this->problems();
        if ($problems !== []) {
            throw new ApiException('Deck Manager has not been configured yet.', 503, $problems);
        }
    }

    public function callbackUrl(): string
    {
        return $this->baseUrl . '/api.php?action=callback';
    }

    public static function safeRepositoryPath(string $path): bool
    {
        return $path !== ''
            && !str_starts_with($path, '/')
            && !str_contains($path, '\\')
            && !str_contains($path, '..')
            && preg_match('#^[A-Za-z0-9._/-]+$#', $path) === 1;
    }
}

interface HttpTransport
{
    /** @return array{status:int,headers:array<string,string>,body:string} */
    public function request(string $method, string $url, array $headers = [], ?string $body = null): array;
}

final class CurlTransport implements HttpTransport
{
    public function request(string $method, string $url, array $headers = [], ?string $body = null): array
    {
        if (!function_exists('curl_init')) {
            throw new ApiException('The PHP cURL extension is required.', 503);
        }
        $responseHeaders = [];
        $handle = curl_init($url);
        if ($handle === false) {
            throw new ApiException('The GitHub HTTP client could not be initialized.', 503);
        }
        $options = [
            CURLOPT_CUSTOMREQUEST => $method,
            CURLOPT_RETURNTRANSFER => true,
            CURLOPT_FOLLOWLOCATION => false,
            CURLOPT_CONNECTTIMEOUT => 10,
            CURLOPT_TIMEOUT => 45,
            CURLOPT_HTTPHEADER => $headers,
            CURLOPT_HEADERFUNCTION => static function ($curl, string $line) use (&$responseHeaders): int {
                $length = strlen($line);
                $parts = explode(':', $line, 2);
                if (count($parts) === 2) {
                    $responseHeaders[strtolower(trim($parts[0]))] = trim($parts[1]);
                }
                return $length;
            },
        ];
        $caBundle = self::configuredCaBundle();
        if ($caBundle !== null) {
            $options[CURLOPT_CAINFO] = $caBundle;
        }
        if ($body !== null) {
            $options[CURLOPT_POSTFIELDS] = $body;
        }
        curl_setopt_array($handle, $options);
        $responseBody = curl_exec($handle);
        if (!is_string($responseBody)) {
            $message = curl_error($handle);
            curl_close($handle);
            throw new ApiException("GitHub could not be reached: $message", 502);
        }
        $status = (int) curl_getinfo($handle, CURLINFO_RESPONSE_CODE);
        curl_close($handle);
        return ['status' => $status, 'headers' => $responseHeaders, 'body' => $responseBody];
    }

    private static function configuredCaBundle(): ?string
    {
        $configured = trim((string) ini_get('curl.cainfo'));
        if ($configured === '') {
            return null;
        }
        if (is_file($configured)) {
            return realpath($configured) ?: $configured;
        }
        $iniFile = php_ini_loaded_file();
        if ($iniFile === false || self::isAbsolutePath($configured)) {
            return null;
        }
        $nextToIni = dirname($iniFile) . DIRECTORY_SEPARATOR . $configured;
        return is_file($nextToIni) ? (realpath($nextToIni) ?: $nextToIni) : null;
    }

    private static function isAbsolutePath(string $path): bool
    {
        return str_starts_with($path, '/')
            || str_starts_with($path, '\\\\')
            || preg_match('/^[A-Za-z]:[\\\\\\/]/', $path) === 1;
    }
}

final class GitHubClient
{
    private const API = 'https://api.github.com';

    public function __construct(
        private readonly Config $config,
        private readonly HttpTransport $transport = new CurlTransport(),
    ) {
    }

    public function exchangeOAuthCode(string $code): string
    {
        $response = $this->transport->request('POST', 'https://github.com/login/oauth/access_token', [
            'Accept: application/json',
            'Content-Type: application/json',
            'User-Agent: Whatz-It-Deck-Manager',
        ], self::encode([
            'client_id' => $this->config->clientId,
            'client_secret' => $this->config->clientSecret,
            'code' => $code,
            'redirect_uri' => $this->config->callbackUrl(),
        ]));
        $data = $this->decodeResponse($response, [200], 'GitHub sign-in failed.');
        $token = $data['access_token'] ?? '';
        if (!is_string($token) || $token === '') {
            throw new ApiException('GitHub did not return a user access token.', 401);
        }
        return $token;
    }

    public function authenticatedUser(string $token): array
    {
        return $this->api('GET', '/user', $token);
    }

    public function installationToken(): string
    {
        $jwt = $this->appJwt();
        $data = $this->api(
            'POST',
            '/app/installations/' . rawurlencode($this->config->installationId) . '/access_tokens',
            $jwt,
            ['repositories' => [Config::REPOSITORY], 'permissions' => ['contents' => 'write', 'metadata' => 'read']],
        );
        $token = $data['token'] ?? '';
        if (!is_string($token) || $token === '') {
            throw new ApiException('GitHub did not return an installation token.', 502);
        }
        return $token;
    }

    public function api(string $method, string $path, string $token, ?array $json = null): array
    {
        $headers = [
            'Accept: application/vnd.github+json',
            'Authorization: Bearer ' . $token,
            'X-GitHub-Api-Version: 2026-03-10',
            'User-Agent: Whatz-It-Deck-Manager',
        ];
        $body = null;
        if ($json !== null) {
            $headers[] = 'Content-Type: application/json';
            $body = self::encode($json);
        }
        $response = $this->transport->request($method, self::API . $path, $headers, $body);
        return $this->decodeResponse($response, [200, 201], 'GitHub API request failed.');
    }

    /** @return array{status:int,headers:array<string,string>,body:string} */
    public function raw(string $path, string $token): array
    {
        $response = $this->transport->request('GET', self::API . $path, [
            'Accept: application/vnd.github.raw+json',
            'Authorization: Bearer ' . $token,
            'X-GitHub-Api-Version: 2026-03-10',
            'User-Agent: Whatz-It-Deck-Manager',
        ]);
        if ($response['status'] !== 200) {
            $this->decodeResponse($response, [200], 'GitHub file download failed.');
        }
        return $response;
    }

    private function appJwt(): string
    {
        $now = time();
        $header = self::base64Url(self::encode(['alg' => 'RS256', 'typ' => 'JWT']));
        $payload = self::base64Url(self::encode([
            'iat' => $now - 60,
            'exp' => $now + 540,
            'iss' => $this->config->appId,
        ]));
        $unsigned = "$header.$payload";
        $key = openssl_pkey_get_private($this->config->privateKey);
        if ($key === false) {
            throw new ApiException('The configured GitHub App private key is invalid.', 503);
        }
        $signature = '';
        if (!openssl_sign($unsigned, $signature, $key, OPENSSL_ALGO_SHA256)) {
            throw new ApiException('The GitHub App request could not be signed.', 503);
        }
        return $unsigned . '.' . self::base64Url($signature);
    }

    private function decodeResponse(array $response, array $accepted, string $fallback): array
    {
        try {
            $data = $response['body'] === '' ? [] : json_decode($response['body'], true, 512, JSON_THROW_ON_ERROR);
        } catch (JsonException) {
            $data = [];
        }
        if (!in_array($response['status'], $accepted, true)) {
            $message = is_array($data) && is_string($data['message'] ?? null) ? $data['message'] : $fallback;
            $status = $response['status'] === 422 ? 409 : ($response['status'] >= 400 && $response['status'] < 600 ? $response['status'] : 502);
            throw new ApiException($message, $status, [], $status === 409);
        }
        return is_array($data) ? $data : [];
    }

    private static function encode(array $value): string
    {
        return json_encode($value, JSON_THROW_ON_ERROR | JSON_UNESCAPED_SLASHES);
    }

    private static function base64Url(string $value): string
    {
        return rtrim(strtr(base64_encode($value), '+/', '-_'), '=');
    }
}

final class PublishChangeDescription
{
    public static function build(array $before, array $after, array $imageOperations): string
    {
        $changes = [[
            'label' => 'Catalog revision',
            'values' => [(string) ($before['revision'] ?? 0) . ' -> ' . (string) ($after['revision'] ?? 0)],
        ]];

        $beforeBundles = self::indexById($before['bundles'] ?? []);
        $afterBundles = self::indexById($after['bundles'] ?? []);
        self::addCollectionChanges($changes, 'Bundles', $beforeBundles, $afterBundles);

        foreach (['free', 'paid'] as $scope) {
            if (($before['deckOrders'][$scope] ?? []) !== ($after['deckOrders'][$scope] ?? [])) {
                self::add($changes, 'Deck orders changed', [$scope]);
            }
        }

        $beforeDecks = self::indexById($before['decks'] ?? []);
        $afterDecks = self::indexById($after['decks'] ?? []);
        $beforeDeckPositions = array_flip(array_keys($beforeDecks));
        $afterDeckPositions = array_flip(array_keys($afterDecks));
        self::add($changes, 'Decks added', array_keys(array_diff_key($afterDecks, $beforeDecks)));
        self::add($changes, 'Decks removed', array_keys(array_diff_key($beforeDecks, $afterDecks)));

        $decksEdited = [];
        $decksReordered = [];
        $imageReferencesUpdated = [];
        $cardsAdded = [];
        $cardsEdited = [];
        $cardsRemoved = [];
        foreach (array_intersect(array_keys($beforeDecks), array_keys($afterDecks)) as $deckId) {
            $oldDeck = $beforeDecks[$deckId];
            $newDeck = $afterDecks[$deckId];
            if (($beforeDeckPositions[$deckId] ?? null) !== ($afterDeckPositions[$deckId] ?? null)) {
                $decksReordered[] = $deckId;
            }
            $comparableOld = $oldDeck;
            $comparableNew = $newDeck;
            unset($comparableOld['order'], $comparableOld['cards'], $comparableNew['order'], $comparableNew['cards']);
            if ($comparableOld !== $comparableNew) {
                $decksEdited[] = $deckId;
            }
            if (($oldDeck['coverImage'] ?? '') !== ($newDeck['coverImage'] ?? '')) {
                $imageReferencesUpdated[] = $deckId;
            }

            $oldCards = self::indexById($oldDeck['cards'] ?? []);
            $newCards = self::indexById($newDeck['cards'] ?? []);
            foreach (array_keys(array_diff_key($newCards, $oldCards)) as $cardId) {
                $cardsAdded[] = "$deckId/$cardId";
            }
            foreach (array_keys(array_diff_key($oldCards, $newCards)) as $cardId) {
                $cardsRemoved[] = "$deckId/$cardId";
            }
            foreach (array_intersect(array_keys($oldCards), array_keys($newCards)) as $cardId) {
                if ($oldCards[$cardId] !== $newCards[$cardId]) {
                    $cardsEdited[] = "$deckId/$cardId";
                }
            }
        }
        foreach (array_keys(array_diff_key($afterDecks, $beforeDecks)) as $deckId) {
            foreach (self::indexById($afterDecks[$deckId]['cards'] ?? []) as $cardId => $_card) {
                $cardsAdded[] = "$deckId/$cardId";
            }
        }
        foreach (array_keys(array_diff_key($beforeDecks, $afterDecks)) as $deckId) {
            foreach (self::indexById($beforeDecks[$deckId]['cards'] ?? []) as $cardId => $_card) {
                $cardsRemoved[] = "$deckId/$cardId";
            }
        }

        self::add($changes, 'Decks edited', $decksEdited);
        self::add($changes, 'Decks reordered', $decksReordered);
        self::add($changes, 'Cards added', $cardsAdded);
        self::add($changes, 'Cards edited', $cardsEdited);
        self::add($changes, 'Cards removed', $cardsRemoved);

        $images = [
            'Images added' => [],
            'Images replaced' => [],
            'Images renamed' => [],
            'Images removed' => [],
        ];
        foreach ($imageOperations as $operation) {
            if (!is_array($operation)) {
                continue;
            }
            $type = (string) ($operation['type'] ?? '');
            if ($type === 'add') {
                $images['Images added'][] = (string) ($operation['filename'] ?? '');
            } elseif ($type === 'replace') {
                $images['Images replaced'][] = (string) ($operation['filename'] ?? '');
            } elseif ($type === 'rename') {
                $images['Images renamed'][] = (string) ($operation['from'] ?? '') . ' -> ' . (string) ($operation['to'] ?? '');
            } elseif ($type === 'remove') {
                $images['Images removed'][] = (string) ($operation['filename'] ?? '');
            }
        }
        foreach ($images as $label => $values) {
            self::add($changes, $label, $values);
        }
        self::add($changes, 'Image references updated', $imageReferencesUpdated);

        return "Automatic change summary:\n" . implode("\n", array_map(
            static fn (array $change): string => '- ' . $change['label'] . ': ' . implode(', ', $change['values']),
            $changes,
        ));
    }

    /** @return array<string,array> */
    private static function indexById(mixed $items): array
    {
        $indexed = [];
        if (!is_array($items)) {
            return $indexed;
        }
        foreach ($items as $item) {
            if (is_array($item) && is_string($item['id'] ?? null) && $item['id'] !== '') {
                $indexed[$item['id']] = $item;
            }
        }
        return $indexed;
    }

    private static function addCollectionChanges(array &$changes, string $name, array $before, array $after): void
    {
        self::add($changes, "$name added", array_keys(array_diff_key($after, $before)));
        $edited = [];
        foreach (array_intersect(array_keys($before), array_keys($after)) as $id) {
            if ($before[$id] !== $after[$id]) {
                $edited[] = $id;
            }
        }
        self::add($changes, "$name edited or reordered", $edited);
        self::add($changes, "$name removed", array_keys(array_diff_key($before, $after)));
    }

    private static function add(array &$changes, string $label, array $values): void
    {
        $values = array_values(array_filter(array_map(
            static fn (mixed $value): string => trim(preg_replace('/\s+/u', ' ', (string) $value) ?? ''),
            $values,
        ), static fn (string $value): bool => $value !== ''));
        if ($values !== []) {
            $changes[] = ['label' => $label, 'values' => $values];
        }
    }
}

final class DeckRepository
{
    private const COVER_WIDTH = 625;
    private const MINIMUM_COVER_HEIGHT = 938;

    private string $token;

    public function __construct(
        private readonly Config $config,
        private readonly GitHubClient $github,
        ?string $installationToken = null,
    ) {
        $this->token = $installationToken ?: $github->installationToken();
    }

    public function loadState(): array
    {
        $this->assertLockedRepository();
        $commitSha = $this->headSha();
        $catalog = $this->content($this->config->catalogPath, $commitSha);
        $commit = $this->github->api('GET', $this->repoPath() . '/git/commits/' . rawurlencode($commitSha), $this->token);
        $treeSha = (string) ($commit['tree']['sha'] ?? '');
        if (!preg_match('/^[0-9a-f]{40}$/', $treeSha)) {
            throw new ApiException('The GitHub repository tree could not be resolved.', 502);
        }
        $tree = $this->github->api('GET', $this->repoPath() . '/git/trees/' . rawurlencode($treeSha) . '?recursive=1', $this->token);
        if (($tree['truncated'] ?? false) === true) {
            throw new ApiException('The GitHub repository tree is too large to safely scan.', 502);
        }
        $images = [];
        foreach ($tree['tree'] ?? [] as $entry) {
            $path = $entry['path'] ?? '';
            if (($entry['type'] ?? '') !== 'blob'
                || !is_string($path)
                || !str_starts_with($path, Config::IMAGE_DIRECTORY . '/')
                || preg_match('/\.(webp|png|jpe?g)$/i', $path) !== 1) {
                continue;
            }
            $filename = basename($path);
            $blobSha = (string) ($entry['sha'] ?? '');
            $images[] = [
                'filename' => $filename,
                'relativePath' => $path,
                'size' => (int) ($entry['size'] ?? 0),
                'hash' => $blobSha,
                'previewUrl' => 'api.php?action=image&blob=' . rawurlencode($blobSha)
                    . '&path=' . rawurlencode($path)
                    . '&sig=' . rawurlencode($this->imageSignature($path, $blobSha)),
                'references' => [],
                'orphaned' => false,
            ];
        }
        usort($images, static fn (array $a, array $b): int => strcasecmp($a['filename'], $b['filename']));

        $history = $this->github->api(
            'GET',
            $this->repoPath() . '/commits?sha=' . rawurlencode($this->config->branch)
                . '&path=' . rawurlencode($this->config->catalogPath) . '&per_page=15',
            $this->token,
        );

        return [
            'source' => $catalog['source'],
            'snapshot' => [
                'commitSha' => $commitSha,
                'catalogBlobSha' => $catalog['sha'],
            ],
            'images' => $images,
            'history' => array_map(static fn (array $commit): array => [
                'id' => (string) ($commit['sha'] ?? ''),
                'createdAt' => (string) ($commit['commit']['author']['date'] ?? ''),
                'revision' => null,
                'summary' => ['label' => (string) ($commit['commit']['message'] ?? 'Repository update')],
                'sourceJson' => substr((string) ($commit['sha'] ?? ''), 0, 7),
                'url' => (string) ($commit['html_url'] ?? ''),
            ], $history),
            'connection' => [
                'appRoot' => Config::OWNER . '/' . Config::REPOSITORY,
                'jsonPath' => $this->config->catalogPath,
                'imageDirectory' => Config::IMAGE_DIRECTORY,
                'branch' => $this->config->branch,
            ],
        ];
    }

    public function image(string $path, string $blobSha, string $signature): array
    {
        if (!$this->safeImagePath($path)
            || !preg_match('/^[0-9a-f]{40}$/', $blobSha)
            || $signature === ''
            || !hash_equals($this->imageSignature($path, $blobSha), $signature)) {
            throw new ApiException('Invalid image request.', 400);
        }
        $body = $this->cachedImageBlob($blobSha);
        $extension = strtolower(pathinfo($path, PATHINFO_EXTENSION));
        $mime = match ($extension) {
            'webp' => 'image/webp',
            'png' => 'image/png',
            'jpg', 'jpeg' => 'image/jpeg',
            default => 'application/octet-stream',
        };
        return ['body' => $body, 'mime' => $mime, 'etag' => $blobSha];
    }

    /**
     * Convert an uploaded image to the only format Deck Manager publishes.
     *
     * @return array{filename:string,mime:string,width:int,height:int,size:int,hash:string,data:string}
     */
    public function stageUpload(mixed $upload, string $filename): array
    {
        $filename = $this->safeWebpFilename($filename);
        if (!is_array($upload) || ($upload['error'] ?? UPLOAD_ERR_NO_FILE) !== UPLOAD_ERR_OK) {
            throw new ApiException('Choose an image to upload.');
        }
        $size = (int) ($upload['size'] ?? 0);
        if ($size < 1 || $size > 10 * 1024 * 1024) {
            throw new ApiException('Images must be between 1 byte and 10 MB.');
        }
        $temporary = (string) ($upload['tmp_name'] ?? '');
        $dimensions = @getimagesize($temporary);
        if (!is_array($dimensions) || ($dimensions[0] ?? 0) < 1 || ($dimensions[1] ?? 0) < 1) {
            throw new ApiException('The selected file is not a readable image.');
        }
        $sourceWidth = (int) $dimensions[0];
        $sourceHeight = (int) $dimensions[1];
        if ($sourceWidth > 6000 || $sourceHeight > 6000) {
            throw new ApiException('The selected image exceeds the 6000 by 6000 pixel limit.');
        }
        if ($sourceWidth < self::COVER_WIDTH || $sourceHeight < self::MINIMUM_COVER_HEIGHT) {
            throw new ApiException(
                'Cover images must be at least 625 by 938 pixels so they stay sharp on high-density phones.',
            );
        }
        $width = self::COVER_WIDTH;
        $height = max(1, (int) round($sourceHeight * ($width / $sourceWidth)));
        if ($height > 6000) {
            throw new ApiException('This image is too tall to resize safely to 625 pixels wide.');
        }
        if (!function_exists('imagecreatefromstring') || !function_exists('imagewebp')) {
            throw new ApiException('This server cannot convert images to WebP. Enable PHP GD with WebP support.', 503);
        }
        $sourceBytes = file_get_contents($temporary);
        $image = is_string($sourceBytes) ? @imagecreatefromstring($sourceBytes) : false;
        if ($image === false) {
            throw new ApiException('PHP could not decode this image type, so no file was staged.');
        }
        $resized = false;
        try {
            if (function_exists('imagepalettetotruecolor')) {
                @imagepalettetotruecolor($image);
            }
            $resized = @imagecreatetruecolor($width, $height);
            if ($resized === false) {
                throw new ApiException('PHP could not allocate the resized cover image, so no file was staged.');
            }
            imagealphablending($resized, false);
            imagesavealpha($resized, true);
            $transparent = imagecolorallocatealpha($resized, 0, 0, 0, 127);
            imagefill($resized, 0, 0, $transparent);
            if (!@imagecopyresampled(
                $resized,
                $image,
                0,
                0,
                0,
                0,
                $width,
                $height,
                $sourceWidth,
                $sourceHeight,
            )) {
                throw new ApiException('PHP could not resize this image, so no file was staged.');
            }
            ob_start();
            $converted = @imagewebp($resized, null, 88);
            $webp = ob_get_clean();
        } finally {
            if ($resized !== false) {
                imagedestroy($resized);
            }
            imagedestroy($image);
        }
        if (!$converted || !is_string($webp) || $webp === ''
            || substr($webp, 0, 4) !== 'RIFF' || substr($webp, 8, 4) !== 'WEBP') {
            throw new ApiException('PHP could not convert this image to WebP, so no file was staged.');
        }
        if (strlen($webp) > 10 * 1024 * 1024) {
            throw new ApiException('The converted WebP exceeds the 10 MB upload limit, so no file was staged.');
        }
        return [
            'filename' => $filename,
            'mime' => 'image/webp',
            'width' => $width,
            'height' => $height,
            'size' => strlen($webp),
            'hash' => hash('sha256', $webp),
            'data' => base64_encode($webp),
        ];
    }

    public function publish(array $input, array $uploads, string $adminLogin): array
    {
        $this->assertLockedRepository();
        $baseSha = (string) ($input['baseSnapshot']['commitSha'] ?? '');
        if (!preg_match('/^[0-9a-f]{40}$/', $baseSha)) {
            throw new ApiException('The loaded GitHub revision is unavailable. Get latest changes before publishing.', 409, [], true);
        }
        if (!hash_equals($baseSha, $this->headSha())) {
            throw new ApiException('New changes are available on GitHub. Get latest changes before publishing.', 409, [], true);
        }
        $currentCatalog = $this->content($this->config->catalogPath, $baseSha);
        $storedCatalog = CatalogDocument::parse($currentCatalog['source'], $this->config->catalogPath);
        if (($storedCatalog['schemaVersion'] ?? null) !== 5) {
            throw new ApiException('The GitHub catalog must be migrated to schema version 5 before hosted publishing can begin.', 422);
        }

        $catalog = $input['catalog'] ?? null;
        if (!is_array($catalog)) {
            throw new ApiException('The catalog payload is invalid.');
        }
        $catalog['schemaVersion'] = 5;
        $catalog['revision'] = (int) ($storedCatalog['revision'] ?? 0) + 1;
        $catalog['updatedAt'] = gmdate('Y-m-d\TH:i:s\Z');
        foreach ($catalog['decks'] ?? [] as $index => &$deck) {
            if (is_array($deck)) {
                $deck['order'] = $index + 1;
            }
        }
        unset($deck);
        foreach ($catalog['bundles'] ?? [] as $index => &$bundle) {
            if (is_array($bundle)) {
                $bundle['order'] = $index + 1;
            }
        }
        unset($bundle);
        $validationErrors = CatalogValidator::validate($catalog);
        if ($validationErrors !== []) {
            throw new ApiException('The catalog has blocking validation errors.', 422, $validationErrors);
        }

        $commit = $this->github->api('GET', $this->repoPath() . '/git/commits/' . rawurlencode($baseSha), $this->token);
        $baseTreeSha = (string) ($commit['tree']['sha'] ?? '');
        if (!preg_match('/^[0-9a-f]{40}$/', $baseTreeSha)) {
            throw new ApiException('The GitHub repository tree could not be resolved.', 502);
        }
        $catalogSource = CatalogDocument::serialize($catalog, $this->config->catalogPath, $currentCatalog['source']);
        $treeEntries = [[
            'path' => $this->config->catalogPath,
            'mode' => '100644',
            'type' => 'blob',
            'sha' => $this->createBlob($catalogSource),
        ]];

        $tree = $this->github->api('GET', $this->repoPath() . '/git/trees/' . rawurlencode($baseTreeSha) . '?recursive=1', $this->token);
        if (($tree['truncated'] ?? false) === true) {
            throw new ApiException('The GitHub repository tree is too large to safely publish.', 502);
        }
        $knownImages = [];
        foreach ($tree['tree'] ?? [] as $entry) {
            $path = $entry['path'] ?? '';
            if (($entry['type'] ?? '') === 'blob' && is_string($path) && $this->safeImagePath($path)) {
                $knownImages[strtolower(basename($path))] = ['path' => $path, 'sha' => (string) ($entry['sha'] ?? '')];
            }
        }
        $projected = $knownImages;
        $operations = $input['imageOperations'] ?? [];
        if (!is_array($operations)) {
            throw new ApiException('Image operations are invalid.');
        }
        $targetedImages = [];
        $totalUploadBytes = 0;
        foreach ($operations as $operation) {
            if (!is_array($operation)) {
                throw new ApiException('An image operation is invalid.');
            }
            $type = (string) ($operation['type'] ?? '');
            if ($type === 'add' || $type === 'replace') {
                $filename = $this->safeWebpFilename((string) ($operation['filename'] ?? ''));
                $key = strtolower($filename);
                if (isset($targetedImages[$key])) {
                    throw new ApiException("Image $filename is targeted more than once.");
                }
                $targetedImages[$key] = true;
                if ($type === 'add' && isset($knownImages[$key])) {
                    throw new ApiException("Image $filename already exists.", 409, [], true);
                }
                if ($type === 'replace' && !isset($knownImages[$key])) {
                    throw new ApiException("Image $filename no longer exists.", 409, [], true);
                }
                $uploadKey = (string) ($operation['uploadKey'] ?? '');
                $upload = $uploads[$uploadKey] ?? null;
                $bytes = $this->validatedUpload($upload, $filename);
                $totalUploadBytes += strlen($bytes);
                if ($totalUploadBytes > 50 * 1024 * 1024) {
                    throw new ApiException('A single publish may include at most 50 MB of new image data.');
                }
                $path = Config::IMAGE_DIRECTORY . '/' . $filename;
                $sha = $this->createBlob($bytes);
                $treeEntries[] = ['path' => $path, 'mode' => '100644', 'type' => 'blob', 'sha' => $sha];
                $projected[$key] = ['path' => $path, 'sha' => $sha];
            } elseif ($type === 'rename') {
                $from = $this->safeImageFilename((string) ($operation['from'] ?? ''));
                $to = $this->safeImageFilename((string) ($operation['to'] ?? ''));
                $fromKey = strtolower($from);
                $toKey = strtolower($to);
                if (isset($targetedImages[$fromKey]) || isset($targetedImages[$toKey])) {
                    throw new ApiException('An image is targeted more than once.');
                }
                $targetedImages[$fromKey] = true;
                $targetedImages[$toKey] = true;
                if (!isset($knownImages[$fromKey]) || isset($projected[$toKey])) {
                    throw new ApiException('An image rename conflicts with the current GitHub files.', 409, [], true);
                }
                $treeEntries[] = ['path' => Config::IMAGE_DIRECTORY . '/' . $from, 'mode' => '100644', 'type' => 'blob', 'sha' => null];
                $treeEntries[] = ['path' => Config::IMAGE_DIRECTORY . '/' . $to, 'mode' => '100644', 'type' => 'blob', 'sha' => $knownImages[$fromKey]['sha']];
                unset($projected[$fromKey]);
                $projected[$toKey] = ['path' => Config::IMAGE_DIRECTORY . '/' . $to, 'sha' => $knownImages[$fromKey]['sha']];
            } elseif ($type === 'remove') {
                $filename = $this->safeImageFilename((string) ($operation['filename'] ?? ''));
                $key = strtolower($filename);
                if (isset($targetedImages[$key])) {
                    throw new ApiException("Image $filename is targeted more than once.");
                }
                $targetedImages[$key] = true;
                if (!isset($knownImages[$key])) {
                    throw new ApiException("Image $filename no longer exists.", 409, [], true);
                }
                $treeEntries[] = ['path' => Config::IMAGE_DIRECTORY . '/' . $filename, 'mode' => '100644', 'type' => 'blob', 'sha' => null];
                unset($projected[$key]);
            } else {
                throw new ApiException('An image operation has an unsupported type.');
            }
        }

        foreach ($catalog['decks'] as $index => $deck) {
            $cover = (string) ($deck['coverImage'] ?? '');
            if ($cover !== '' && !isset($projected[strtolower(basename($cover))])) {
                throw new ApiException('Referenced deck images are missing.', 422, [[
                    'path' => "decks[$index].coverImage",
                    'message' => $cover,
                ]]);
            }
        }

        $newTree = $this->github->api('POST', $this->repoPath() . '/git/trees', $this->token, [
            'base_tree' => $baseTreeSha,
            'tree' => $treeEntries,
        ]);
        $newTreeSha = (string) ($newTree['sha'] ?? '');
        if (!preg_match('/^[0-9a-f]{40}$/', $newTreeSha)) {
            throw new ApiException('GitHub did not return the new repository tree.', 502);
        }
        $message = trim((string) ($input['commitMessage'] ?? ''));
        $message = preg_replace('/\s+/u', ' ', $message) ?? '';
        if ($message === '') {
            $message = 'Update deck catalog';
        }
        $message = substr($message, 0, 200);
        $description = PublishChangeDescription::build($storedCatalog, $catalog, $operations);
        $newCommit = $this->github->api('POST', $this->repoPath() . '/git/commits', $this->token, [
            'message' => $message
                . "\n\n" . $description
                . "\n\nPublished by @$adminLogin using WHATZ IT? Deck Manager.",
            'tree' => $newTreeSha,
            'parents' => [$baseSha],
        ]);
        $newSha = (string) ($newCommit['sha'] ?? '');
        if (!preg_match('/^[0-9a-f]{40}$/', $newSha)) {
            throw new ApiException('GitHub did not return the new commit.', 502);
        }
        $this->github->api('PATCH', $this->repoPath() . '/git/refs/heads/' . self::encodePath($this->config->branch), $this->token, [
            'sha' => $newSha,
            'force' => false,
        ]);

        return [
            'commitSha' => $newSha,
            'commitUrl' => 'https://github.com/' . Config::OWNER . '/' . Config::REPOSITORY . '/commit/' . $newSha,
            'catalog' => $catalog,
        ];
    }

    private function headSha(): string
    {
        $ref = $this->github->api(
            'GET',
            $this->repoPath() . '/git/ref/heads/' . self::encodePath($this->config->branch),
            $this->token,
        );
        $sha = (string) ($ref['object']['sha'] ?? '');
        if (!preg_match('/^[0-9a-f]{40}$/', $sha)) {
            throw new ApiException('The configured GitHub branch could not be resolved.', 502);
        }
        return $sha;
    }

    /** @return array{source:string,sha:string} */
    private function content(string $path, string $ref): array
    {
        if (!Config::safeRepositoryPath($path)) {
            throw new ApiException('The configured catalog path is unsafe.', 503);
        }
        $data = $this->github->api(
            'GET',
            $this->repoPath() . '/contents/' . self::encodePath($path) . '?ref=' . rawurlencode($ref),
            $this->token,
        );
        $encoded = preg_replace('/\s+/', '', (string) ($data['content'] ?? ''));
        $source = base64_decode($encoded, true);
        if (!is_string($source)) {
            throw new ApiException('The catalog returned by GitHub could not be decoded.', 502);
        }
        return ['source' => $source, 'sha' => (string) ($data['sha'] ?? '')];
    }

    private function createBlob(string $bytes): string
    {
        $blob = $this->github->api('POST', $this->repoPath() . '/git/blobs', $this->token, [
            'content' => base64_encode($bytes),
            'encoding' => 'base64',
        ]);
        $sha = (string) ($blob['sha'] ?? '');
        if ($sha === '') {
            throw new ApiException('GitHub did not return a blob identifier.', 502);
        }
        return $sha;
    }

    private function validatedUpload(mixed $upload, string $filename): string
    {
        if (!is_array($upload) || ($upload['error'] ?? UPLOAD_ERR_NO_FILE) !== UPLOAD_ERR_OK) {
            throw new ApiException("The upload for $filename is missing or incomplete.");
        }
        $size = (int) ($upload['size'] ?? 0);
        if ($size < 1 || $size > 10 * 1024 * 1024) {
            throw new ApiException("$filename must be between 1 byte and 10 MB.");
        }
        $temporary = (string) ($upload['tmp_name'] ?? '');
        $bytes = file_get_contents($temporary);
        if (!is_string($bytes)) {
            throw new ApiException("$filename could not be read.");
        }
        $expected = match (strtolower(pathinfo($filename, PATHINFO_EXTENSION))) {
            'png' => str_starts_with($bytes, "\x89PNG\r\n\x1a\n"),
            'jpg', 'jpeg' => str_starts_with($bytes, "\xff\xd8\xff"),
            'webp' => substr($bytes, 0, 4) === 'RIFF' && substr($bytes, 8, 4) === 'WEBP',
            default => false,
        };
        if (!$expected) {
            throw new ApiException("$filename does not match its image extension.");
        }
        $dimensions = @getimagesize($temporary);
        if (!is_array($dimensions) || ($dimensions[0] ?? 0) < 1 || ($dimensions[1] ?? 0) < 1) {
            throw new ApiException("$filename is not a readable image.");
        }
        if ($dimensions[0] > 6000 || $dimensions[1] > 6000) {
            throw new ApiException("$filename exceeds the 6000 by 6000 pixel limit.");
        }
        return $bytes;
    }

    private function safeImageFilename(string $filename): string
    {
        if (preg_match('/^[A-Za-z0-9][A-Za-z0-9_-]*\.(?:webp|png|jpe?g)$/i', $filename) !== 1) {
            throw new ApiException('An image filename is unsafe.');
        }
        return $filename;
    }

    private function safeWebpFilename(string $filename): string
    {
        if (preg_match('/^[a-z0-9][a-z0-9_-]*\.webp$/', $filename) !== 1) {
            throw new ApiException('Converted images must use a lowercase, hyphenated .webp filename.');
        }
        return $filename;
    }

    private function safeImagePath(string $path): bool
    {
        return str_starts_with($path, Config::IMAGE_DIRECTORY . '/')
            && dirname($path) === Config::IMAGE_DIRECTORY
            && preg_match('/^[A-Za-z0-9][A-Za-z0-9_-]*\.(?:webp|png|jpe?g)$/i', basename($path)) === 1;
    }

    private function imageSignature(string $path, string $blobSha): string
    {
        return hash_hmac('sha256', $path . "\n" . $blobSha, $this->config->clientSecret);
    }

    private function cachedImageBlob(string $blobSha): string
    {
        $directory = rtrim(sys_get_temp_dir(), DIRECTORY_SEPARATOR)
            . DIRECTORY_SEPARATOR . 'whatzit-deck-manager-image-cache';
        $cacheReady = is_dir($directory) || @mkdir($directory, 0700, true);
        $cacheFile = $directory . DIRECTORY_SEPARATOR . $blobSha;
        if ($cacheReady && is_file($cacheFile)) {
            $cached = file_get_contents($cacheFile);
            if (is_string($cached) && $cached !== '') {
                return $cached;
            }
        }
        $response = $this->github->raw(
            $this->repoPath() . '/git/blobs/' . rawurlencode($blobSha),
            $this->token,
        );
        if ($cacheReady && $response['body'] !== '') {
            @file_put_contents($cacheFile, $response['body'], LOCK_EX);
        }
        return $response['body'];
    }

    private function repoPath(): string
    {
        return '/repos/' . Config::OWNER . '/' . Config::REPOSITORY;
    }

    private function assertLockedRepository(): void
    {
        $repository = $this->github->api('GET', $this->repoPath(), $this->token);
        if ((string) ($repository['id'] ?? '') !== $this->config->repositoryId
            || strcasecmp((string) ($repository['full_name'] ?? ''), Config::OWNER . '/' . Config::REPOSITORY) !== 0) {
            throw new ApiException('The GitHub App installation does not match the locked WHATZ IT? repository.', 403);
        }
    }

    private static function encodePath(string $path): string
    {
        return implode('/', array_map('rawurlencode', explode('/', $path)));
    }
}

final class CatalogDocument
{
    public static function parse(string $source, string $path): array
    {
        $json = $source;
        if (!str_ends_with(strtolower($path), '.json')) {
            $startMarker = '/* DECK_MANAGER_CATALOG_START */';
            $endMarker = '/* DECK_MANAGER_CATALOG_END */';
            $start = strpos($source, $startMarker);
            $end = strrpos($source, $endMarker);
            if ($start === false || $end === false || $end <= $start) {
                throw new ApiException('The TypeScript catalog is not managed by Deck Manager.', 422);
            }
            $json = trim(substr($source, $start + strlen($startMarker), $end - ($start + strlen($startMarker))));
        }
        try {
            $catalog = json_decode($json, true, 512, JSON_THROW_ON_ERROR);
        } catch (JsonException) {
            throw new ApiException('The managed catalog JSON could not be parsed.', 422);
        }
        if (!is_array($catalog)) {
            throw new ApiException('The managed catalog must contain an object.', 422);
        }
        return $catalog;
    }

    public static function serialize(array $catalog, string $path, string $currentSource): string
    {
        $json = json_encode($catalog, JSON_PRETTY_PRINT | JSON_UNESCAPED_SLASHES | JSON_UNESCAPED_UNICODE | JSON_THROW_ON_ERROR) . "\n";
        if (str_ends_with(strtolower($path), '.json')) {
            return $json;
        }
        $startMarker = '/* DECK_MANAGER_CATALOG_START */';
        $endMarker = '/* DECK_MANAGER_CATALOG_END */';
        $withCatalog = self::replaceManagedSection($currentSource, $startMarker, $endMarker, rtrim($json));
        if ($withCatalog === null) {
            throw new ApiException('The TypeScript catalog is not managed by Deck Manager.', 422);
        }

        $coverPaths = [];
        foreach ($catalog['decks'] ?? [] as $deck) {
            $cover = is_array($deck) ? (string) ($deck['coverImage'] ?? '') : '';
            if ($cover !== '') {
                $coverPaths[$cover] = true;
            }
        }
        $paths = array_keys($coverPaths);
        sort($paths, SORT_STRING);
        $coverLines = array_map(
            static fn (string $cover): string => '  '
                . json_encode($cover, JSON_UNESCAPED_SLASHES | JSON_THROW_ON_ERROR)
                . ': require('
                . json_encode('../../' . $cover, JSON_UNESCAPED_SLASHES | JSON_THROW_ON_ERROR)
                . '),',
            $paths,
        );
        $coverRegistry = "{\n" . implode("\n", $coverLines) . "\n}";
        $withCovers = self::replaceManagedSection(
            $withCatalog,
            '/* DECK_MANAGER_COVERS_START */',
            '/* DECK_MANAGER_COVERS_END */',
            $coverRegistry,
        );
        if ($withCovers === null) {
            throw new ApiException('The TypeScript cover registry markers are missing.', 422);
        }
        return $withCovers;
    }

    private static function replaceManagedSection(
        string $source,
        string $startMarker,
        string $endMarker,
        string $value,
    ): ?string
    {
        $start = strpos($source, $startMarker);
        $end = strrpos($source, $endMarker);
        if ($start === false || $end === false || $end <= $start) {
            return null;
        }
        return substr($source, 0, $start + strlen($startMarker))
            . "\n$value\n"
            . substr($source, $end);
    }
}

final class CatalogValidator
{
    /** @return list<array{path:string,message:string}> */
    public static function validate(array $catalog, bool $allowProtectedCardsOmitted = false): array
    {
        $errors = [];
        $add = static function (string $path, string $message) use (&$errors): void {
            $errors[] = ['path' => $path, 'message' => $message];
        };
        self::checkKeys($catalog, ['schemaVersion', 'revision', 'updatedAt', 'decks', 'bundles', 'deckOrders'], '$', $add);
        if (($catalog['schemaVersion'] ?? null) !== 5) {
            $add('schemaVersion', 'schemaVersion must be 5.');
        }
        if (!is_int($catalog['revision'] ?? null) || $catalog['revision'] < 0) {
            $add('revision', 'revision must be a non-negative integer.');
        }
        if (!is_array($catalog['decks'] ?? null) || !array_is_list($catalog['decks'])) {
            $add('decks', 'decks must be an array.');
            return $errors;
        }
        if (!is_array($catalog['bundles'] ?? null) || !array_is_list($catalog['bundles'])) {
            $add('bundles', 'bundles must be an array.');
            return $errors;
        }
        $deckIds = [];
        $coverNames = [];
        foreach ($catalog['decks'] as $index => $deck) {
            $path = "decks[$index]";
            if (!is_array($deck)) {
                $add($path, 'Each deck must be an object.');
                continue;
            }
            self::checkKeys($deck, ['id', 'order', 'title', 'description', 'coverImage', 'version', 'cardContentVersion', 'cardCount', 'tags', 'access', 'price', 'storeProducts', 'cards'], $path, $add);
            $id = (string) ($deck['id'] ?? '');
            $key = strtolower($id);
            if (!self::validId($id)) {
                $add("$path.id", 'Deck ID is invalid.');
            } elseif (isset($deckIds[$key])) {
                $add("$path.id", "Duplicate deck ID: $id.");
            }
            $deckIds[$key] = $deck;
            if (($deck['order'] ?? null) !== $index + 1) {
                $add("$path.order", 'Deck orders must be sequential.');
            }
            if (!is_string($deck['title'] ?? null) || trim($deck['title']) === '' || strlen($deck['title']) > 120) {
                $add("$path.title", 'Deck title must contain 1 to 120 characters.');
            }
            if (!in_array($deck['access'] ?? null, ['free', 'paid'], true)) {
                $add("$path.access", 'Deck access must be free or paid.');
            }
            if (!is_string($deck['description'] ?? null)) {
                $add("$path.description", 'Deck description must be text.');
            }
            if (!is_array($deck['tags'] ?? null)
                || !array_is_list($deck['tags'])
                || array_filter($deck['tags'] ?? [], static fn (mixed $tag): bool => !is_string($tag) || trim($tag) === '') !== []) {
                $add("$path.tags", 'Deck tags must be nonblank strings.');
            }
            self::validatePrice($deck, $path, $add);
            if (!is_int($deck['version'] ?? null) || $deck['version'] < 1) {
                $add("$path.version", 'Deck version must be a positive integer.');
            }
            if (array_key_exists('cardContentVersion', $deck)
                && (!is_int($deck['cardContentVersion']) || $deck['cardContentVersion'] < 1)) {
                $add("$path.cardContentVersion", 'Card-content version must be a positive integer.');
            }
            $cover = (string) ($deck['coverImage'] ?? '');
            if ($cover !== '' && preg_match('#^assets/images/decks/(?:baseline/)?[A-Za-z0-9][A-Za-z0-9_-]*\.(?:webp|png|jpe?g)$#i', $cover) !== 1) {
                $add("$path.coverImage", 'coverImage must be empty or a safe deck-image path.');
            } elseif ($cover !== '') {
                $coverKey = strtolower(basename($cover));
                if (isset($coverNames[$coverKey])) {
                    $add("$path.coverImage", 'Each deck must use a unique cover image filename.');
                }
                $coverNames[$coverKey] = true;
            }
            if (!is_array($deck['cards'] ?? null) || !array_is_list($deck['cards'])) {
                $add("$path.cards", 'cards must be an array.');
            } else {
                if (array_key_exists('cardCount', $deck)
                    && (!is_int($deck['cardCount'])
                        || ($deck['cardCount'] !== count($deck['cards'])
                            && !($allowProtectedCardsOmitted
                                && ($deck['access'] ?? null) === 'paid'
                                && $deck['cards'] === []
                                && $deck['cardCount'] > 0)))) {
                    $add("$path.cardCount", 'Card count must match the number of cards.');
                }
                $cardIds = [];
                $featuredOrders = [];
                foreach ($deck['cards'] as $cardIndex => $card) {
                    $cardPath = "$path.cards[$cardIndex]";
                    if (is_array($card)) {
                        self::checkKeys($card, ['id', 'text', 'byline', 'featuredOrder'], $cardPath, $add);
                    }
                    $cardId = is_array($card) ? (string) ($card['id'] ?? '') : '';
                    if (!is_array($card) || !self::validId($cardId)) {
                        $add("$cardPath.id", 'Card ID is invalid.');
                    } elseif (isset($cardIds[strtolower($cardId)])) {
                        $add("$cardPath.id", "Duplicate card ID: $cardId.");
                    }
                    $cardIds[strtolower($cardId)] = true;
                    if (!is_array($card) || !is_string($card['text'] ?? null) || trim($card['text']) === '') {
                        $add("$cardPath.text", 'Card text cannot be blank.');
                    }
                    if (is_array($card) && array_key_exists('byline', $card) && !is_string($card['byline'])) {
                        $add("$cardPath.byline", 'Card byline must be text.');
                    }
                    if (is_array($card) && array_key_exists('featuredOrder', $card)) {
                        $featuredOrder = $card['featuredOrder'];
                        if (!is_int($featuredOrder) || $featuredOrder < 1) {
                            $add("$cardPath.featuredOrder", 'Featured order must be a positive integer.');
                        } elseif (isset($featuredOrders[$featuredOrder])) {
                            $add("$cardPath.featuredOrder", "Featured order $featuredOrder is already in use in this deck.");
                        } else {
                            $featuredOrders[$featuredOrder] = true;
                        }
                    }
                }
            }
            self::validateStoreProducts($deck, $path, 'deck', $id, $add);
        }

        $bundleIds = [];
        $freeBundles = 0;
        foreach ($catalog['bundles'] as $index => $bundle) {
            $path = "bundles[$index]";
            if (!is_array($bundle)) {
                $add($path, 'Each bundle must be an object.');
                continue;
            }
            self::checkKeys($bundle, ['id', 'order', 'title', 'description', 'access', 'price', 'version', 'storeProducts', 'deckIds'], $path, $add);
            $id = (string) ($bundle['id'] ?? '');
            if (!self::validId($id) || isset($bundleIds[strtolower($id)])) {
                $add("$path.id", 'Bundle ID is invalid or duplicated.');
            }
            $bundleIds[strtolower($id)] = true;
            if ($id === 'free-bundle') {
                $freeBundles++;
                if (($bundle['access'] ?? null) !== 'free') {
                    $add("$path.access", 'Free Bundle access must remain free.');
                }
            }
            if (($bundle['order'] ?? null) !== $index + 1) {
                $add("$path.order", 'Bundle orders must be sequential.');
            }
            if (!is_string($bundle['title'] ?? null) || trim($bundle['title']) === '' || strlen($bundle['title']) > 120) {
                $add("$path.title", 'Bundle title must contain 1 to 120 characters.');
            }
            if (array_key_exists('description', $bundle)
                && (!is_string($bundle['description']) || strlen($bundle['description']) > 500)) {
                $add("$path.description", 'Bundle description must be text up to 500 characters.');
            }
            if (!in_array($bundle['access'] ?? null, ['free', 'paid'], true)) {
                $add("$path.access", 'Bundle access must be free or paid.');
            }
            self::validatePrice($bundle, $path, $add);
            if (array_key_exists('version', $bundle)
                && (!is_int($bundle['version']) || $bundle['version'] < 1)) {
                $add("$path.version", 'Bundle version must be a positive integer.');
            }
            self::validateStoreProducts($bundle, $path, 'bundle', $id, $add);
            if (!is_array($bundle['deckIds'] ?? null) || !array_is_list($bundle['deckIds'])) {
                $add("$path.deckIds", 'Bundle deckIds must be an array.');
                continue;
            }
            $members = [];
            foreach ($bundle['deckIds'] as $memberIndex => $deckId) {
                $memberKey = strtolower((string) $deckId);
                if (!isset($deckIds[$memberKey]) || isset($members[$memberKey])) {
                    $add("$path.deckIds[$memberIndex]", 'Bundle deck reference is unknown or duplicated.');
                } elseif ($id === 'free-bundle' && ($deckIds[$memberKey]['access'] ?? null) !== 'free') {
                    $add("$path.deckIds[$memberIndex]", 'Free Bundle may contain free decks only.');
                }
                $members[$memberKey] = true;
            }
        }
        if ($freeBundles !== 1) {
            $add('bundles', 'Catalog must contain exactly one free-bundle.');
        }

        $orders = $catalog['deckOrders'] ?? null;
        if (!is_array($orders)) {
            $add('deckOrders', 'deckOrders must define free and paid arrays.');
        } else {
            self::checkKeys($orders, ['free', 'paid'], 'deckOrders', $add);
            foreach (['free', 'paid'] as $scope) {
                $ids = $orders[$scope] ?? null;
                if (!is_array($ids) || !array_is_list($ids)) {
                    $add("deckOrders.$scope", "$scope deck order must be an array.");
                    continue;
                }
                $eligible = array_keys(array_filter($deckIds, static fn (array $deck): bool => ($deck['access'] ?? '') === $scope));
                $normalized = array_map('strtolower', array_map('strval', $ids));
                sort($eligible);
                $unique = array_values(array_unique($normalized));
                sort($unique);
                if ($eligible !== $unique) {
                    $add("deckOrders.$scope", "$scope deck order must contain every eligible deck exactly once.");
                }
            }
        }
        return $errors;
    }

    private static function validId(string $id): bool
    {
        return preg_match('/^[A-Za-z0-9][A-Za-z0-9_-]{0,99}$/', $id) === 1;
    }

    private static function checkKeys(array $value, array $allowed, string $path, callable $add): void
    {
        foreach (array_diff(array_keys($value), $allowed) as $key) {
            $add($path === '$' ? (string) $key : "$path.$key", 'Unsupported property.');
        }
    }

    private static function validatePrice(array $value, string $path, callable $add): void
    {
        if (($value['access'] ?? null) === 'free' && array_key_exists('price', $value)) {
            $add("$path.price", 'Free content cannot have a price.');
            return;
        }
        if (!array_key_exists('price', $value)) {
            return;
        }
        $price = $value['price'];
        if ((!is_int($price) && !is_float($price))
            || $price < 0
            || $price > 99999.99
            || abs($price * 100 - round($price * 100)) > 0.00001) {
            $add("$path.price", 'Price must be between 0 and 99999.99 with at most two decimal places.');
        }
    }

    private static function validateStoreProducts(
        array $value,
        string $path,
        string $targetType,
        string $targetId,
        callable $add,
    ): void
    {
        if (!array_key_exists('storeProducts', $value)) {
            return;
        }
        $products = $value['storeProducts'];
        if (!is_array($products)) {
            $add("$path.storeProducts", 'Store products must be an object.');
            return;
        }
        self::checkKeys($products, ['apple', 'google'], "$path.storeProducts", $add);
        if (($value['access'] ?? null) !== 'paid') {
            $add("$path.storeProducts", 'Free content cannot have store-product mappings.');
        }
        foreach (['apple', 'google'] as $platform) {
            if (!array_key_exists($platform, $products)) {
                continue;
            }
            $mapping = $products[$platform];
            $mappingPath = "$path.storeProducts.$platform";
            if (!is_array($mapping)) {
                $add($mappingPath, 'A store-product mapping must be an object.');
                continue;
            }
            self::checkKeys(
                $mapping,
                $targetType === 'bundle'
                    ? ['productId', 'status', 'ownedDeckCountProducts']
                    : ['productId', 'status'],
                $mappingPath,
                $add,
            );
            $productId = $mapping['productId'] ?? null;
            if (!is_string($productId)
                || $productId === ''
                || strlen($productId) > 100
                || preg_match('/^[A-Za-z0-9._-]+$/', $productId) !== 1) {
                $add("$mappingPath.productId", 'Product ID must contain at most 100 letters, numbers, periods, underscores, or hyphens.');
            } elseif ($platform === 'apple'
                && $productId !== 'com.cadelawless.whatzit.' . $targetType . '.' . str_replace(['_', '-'], ['__', '_'], $targetId)) {
                $expectedTargetId = str_replace(['_', '-'], ['__', '_'], $targetId);
                $add(
                    "$mappingPath.productId",
                    "Apple product ID must be com.cadelawless.whatzit.$targetType.$expectedTargetId.",
                );
            } elseif ($platform === 'google'
                && preg_match('/^[a-z0-9][a-z0-9._]{0,39}$/', $productId) !== 1) {
                $add("$mappingPath.productId", 'Google product ID must use at most 40 lowercase letters, numbers, periods, or underscores.');
            }
            if (!in_array($mapping['status'] ?? null, ['draft', 'available', 'retired'], true)) {
                $add("$mappingPath.status", 'Product status must be draft, available, or retired.');
            }
            $tiers = $mapping['ownedDeckCountProducts'] ?? [];
            if (!is_array($tiers)) {
                $add("$mappingPath.ownedDeckCountProducts", 'Bundle discount products must be an object.');
                continue;
            }
            foreach ($tiers as $ownedCount => $tier) {
                $tierPath = "$mappingPath.ownedDeckCountProducts.$ownedCount";
                if ($targetType !== 'bundle'
                    || !ctype_digit((string) $ownedCount)
                    || (int) $ownedCount < 1
                    || (int) $ownedCount >= count($value['deckIds'] ?? [])) {
                    $add($tierPath, 'Discount tiers must use a partial owned-deck count.');
                    continue;
                }
                if (!is_array($tier)) {
                    $add($tierPath, 'A discount product must be an object.');
                    continue;
                }
                self::checkKeys($tier, ['productId', 'status'], $tierPath, $add);
                $tierId = $tier['productId'] ?? null;
                $expected = $productId . '.owned_' . $ownedCount;
                if (!is_string($tierId) || preg_match('/^[A-Za-z0-9._-]{1,100}$/', $tierId) !== 1) {
                    $add("$tierPath.productId", 'Discount product ID is invalid.');
                } elseif ($platform === 'apple' && $tierId !== $expected) {
                    $add("$tierPath.productId", "Apple discount product ID must be $expected.");
                } elseif ($platform === 'google'
                    && preg_match('/^[a-z0-9][a-z0-9._]{0,39}$/', $tierId) !== 1) {
                    $add("$tierPath.productId", 'Google discount product ID must use at most 40 lowercase letters, numbers, periods, or underscores.');
                }
                if (!in_array($tier['status'] ?? null, ['draft', 'available', 'retired'], true)) {
                    $add("$tierPath.status", 'Discount product status is invalid.');
                }
            }
        }
    }
}
