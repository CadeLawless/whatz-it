<?php

declare(strict_types=1);

// Deploy outside public_html as:
// <domain-root>/whatzit-secrets/deck-manager-staging-config.php
// Set mode 600. The manager-staging wrappers select this exact file.
return [
    'WHATZIT_BASE_URL' => 'https://manager-staging.playwhatzit.com',
    'WHATZIT_DECK_MANAGER_STORAGE' => 'database',
    'WHATZIT_DECK_MANAGER_AUTH' => 'local',
    // Generate once with: php -r "echo bin2hex(random_bytes(32)), PHP_EOL;"
    'WHATZIT_AUTH_RATE_LIMIT_SECRET' => 'REPLACE_WITH_64_RANDOM_HEX_CHARACTERS',

    'WHATZIT_PLATFORM_ENV' => 'test',
    'WHATZIT_DB_HOST' => 'localhost',
    'WHATZIT_DB_PORT' => '3306',
    'WHATZIT_DB_NAME' => 'HOSTINGER_DATABASE_NAME',
    'WHATZIT_DB_USER' => 'HOSTINGER_DATABASE_USER',
    'WHATZIT_DB_PASSWORD' => 'HOSTINGER_DATABASE_PASSWORD',
    'WHATZIT_PUBLIC_API_BASE_URL' => 'https://api-staging.playwhatzit.com',
    'WHATZIT_CONTENT_BASE_URL' => 'https://api-staging.playwhatzit.com/content',
    'WHATZIT_ARTIFACT_ROOT' => '/home/ACCOUNT/domains/playwhatzit.com/whatzit-platform-staging/artifacts',
    'WHATZIT_MEDIA_ROOT' => '/home/ACCOUNT/domains/playwhatzit.com/whatzit-platform-staging/seed',
    // Fail Update Test App and Publish Changes when an available Apple mapping
    // is absent or unusable in App Store Connect. Use a Team API key.
    'WHATZIT_APPLE_CATALOG_VALIDATION' => 'required',
    'WHATZIT_ASC_APP_ID' => 'NUMERIC_APP_STORE_CONNECT_APP_ID',
    'WHATZIT_ASC_KEY_ID' => 'ASC_KEY_ID',
    'WHATZIT_ASC_ISSUER_ID' => 'ASC_ISSUER_UUID',
    'WHATZIT_ASC_PRIVATE_KEY_PATH' => '/home/ACCOUNT/domains/playwhatzit.com/whatzit-secrets/AuthKey_ASC_KEY_ID.p8',
];
